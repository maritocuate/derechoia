import { styled, Grid } from '@mui/material';
import React, { memo } from 'react';
import { usePageList } from '../../hooks/list/usePageList';
import FrequentlyAskedQuestions from '../../components/FrequentlyAskedQuestions';
import FaqsCabins from '../../components/FaqsCabins';

interface IFaqsContainer {
  averagePrice: number;
  minPrice: number;
  maxCapacity: number;
}

const StyledFaqsContainer = styled(Grid)`
  display: flex;
  width: 100%;
  justify-content: center;
  margin-bottom: 48px;
`;

const FaqsContainer = ({
  averagePrice,
  minPrice,
  maxCapacity,
}: IFaqsContainer) => {
  const { province, locality, filters } = usePageList();
  return (
    <StyledFaqsContainer>
      {filters.length === 1 && filters.includes('T:A') ? (
        <FaqsCabins
          locality={locality.replace('/', '').replace(/-/g, ' ')}
          averagePrice={averagePrice}
          province={province.replace('-', ' ')}
          maxCapacity={maxCapacity}
        />
      ) : null}
      {province && locality && filters.length === 0 ? (
        <FrequentlyAskedQuestions
          locality={locality.replace('/', '').replace(/-/g, ' ')}
          averagePrice={averagePrice}
          minPrice={minPrice}
          province={province.replace('-', ' ')}
        />
      ) : null}
    </StyledFaqsContainer>
  );
};

export default memo(FaqsContainer);
