export interface IHostProfileContainer {
  reference: string;
  name: string;
  profilePhoto: string;
  clientAntiquity: number;
  maxSpeedOfAction: boolean;
  maxConfirmedPercentage: boolean;
  newHostProfile: boolean;
}

export interface IHostProfile {
  name: string;
  profilePhoto: string | null;
  clientAntiquity: number;
  maxSpeedOfAction: boolean;
  maxConfirmedPercentage: boolean;
  formattedClientAntiquity: { number: number; text: string };
  isStarClient: boolean;
  isMobile: boolean;
}
