/* eslint-disable @typescript-eslint/indent */
import React, { memo } from 'react';
import HostProfile from '../../components/HostProfile';
import NewHostProfileDesktop from '../../components/HostProfile/NewHostProfile/NewHostProfileDesktop';
import useIsMobile from '../../hooks/useIsMobile';
import { IHostProfileContainer } from './types/hostProfile.types';
import NewHostProfileMobile from '../../components/HostProfile/NewHostProfile/NewHostProfileMobile';
import getClientAntiquity from '../../utils/helpers/hostProfile/getClientAntiquity';

const HostProfileContainer = ({
  reference,
  name,
  profilePhoto,
  clientAntiquity,
  maxSpeedOfAction,
  maxConfirmedPercentage,
  newHostProfile,
}: IHostProfileContainer) => {
  const isMobile = useIsMobile();
  const profilePhotoFormat = profilePhoto
    ? `${
        process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
      }_propiedades_/${reference}/${profilePhoto}?p=propietario_sm`
    : null;
  const formattedClientAntiquity = getClientAntiquity(clientAntiquity);
  const isStarClient =
    clientAntiquity >= 12 && maxConfirmedPercentage && maxSpeedOfAction;

  const hostProfileProps = {
    clientAntiquity,
    maxSpeedOfAction,
    maxConfirmedPercentage,
    name,
    profilePhoto: profilePhotoFormat,
    formattedClientAntiquity,
    isStarClient,
    isMobile,
  };

  if (!newHostProfile) {
    return (
      <HostProfile
        referencia={reference}
        name={name}
        profilePhoto={profilePhoto}
      />
    );
  }

  if (isMobile && newHostProfile) {
    return <NewHostProfileMobile {...hostProfileProps} />;
  }
  return <NewHostProfileDesktop {...hostProfileProps} />;
};

export default memo(HostProfileContainer);
