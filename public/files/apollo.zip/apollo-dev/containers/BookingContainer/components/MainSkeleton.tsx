import React from 'react';
import { Skeleton, styled, Box } from '@mui/material';
import HostCardSkeleton from '../../../components/HostCard/components/Skeleton';
import PaymentCardSkeleton from '../../../components/PaymentCard/components/Skeleton';
import BookingCardSkeleton from '../../../components/BookingCard/components/Skeleton';
import useIsMobile from '../../../hooks/useIsMobile';

const StyledContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2),
}));

const textSkeletonStyles = {
  width: { xs: '50%', sm: '30%' },
  height: { xs: 40, sm: 35 },
  mt: { xs: -1, sm: -2 },
  ml: { xs: 2, sm: 0 },
};

const MainSkeleton = () => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer>
      <Skeleton
        variant="text"
        sx={{ ...textSkeletonStyles, width: '50%', height: isMobile ? 40 : 60 }}
      />
      <Skeleton variant="text" sx={textSkeletonStyles} />
      {isMobile ? (
        <>
          <Skeleton
            variant="rounded"
            width="100%"
            height={258}
            sx={{ mt: 2 }}
          />
          <Skeleton variant="text" width="50%" height={35} sx={{ mt: 1 }} />
          <Skeleton variant="text" width="50%" height={35} sx={{ mt: -2 }} />
          <Skeleton
            variant="text"
            width="30%"
            height={40}
            sx={{ mt: 5, ml: 2 }}
          />
          <Skeleton variant="text" width="80%" height={30} sx={{ ml: 2 }} />
          <Skeleton
            variant="text"
            width="80%"
            height={30}
            sx={{ mt: -3, ml: 2 }}
          />
          <Skeleton variant="text" width="30%" height={40} sx={{ ml: 2 }} />
          <Skeleton variant="text" width="70%" height={40} sx={{ mt: 8 }} />
          <Skeleton variant="text" width="80%" height={30} sx={{ ml: 2 }} />
          <Skeleton
            variant="text"
            width="80%"
            height={30}
            sx={{ mt: -3, ml: 2 }}
          />
          <Skeleton variant="text" width="30%" height={40} sx={{ ml: 2 }} />
        </>
      ) : (
        <>
          <BookingCardSkeleton />
          <Box sx={{ display: 'flex', flexDirection: 'row', gap: '2rem' }}>
            <Box sx={{ flexGrow: 1 }}>
              <Skeleton variant="text" width="50%" height={35} sx={{ mt: 4 }} />
              <Skeleton
                variant="text"
                width="50%"
                height={30}
                sx={{ mt: 3, ml: 2 }}
              />
              <Skeleton
                variant="text"
                width="50%"
                height={30}
                sx={{ mt: 1, ml: 2 }}
              />
            </Box>
            <Box
              sx={{
                width: '24rem',
                display: 'flex',
                flexDirection: 'column',
                gap: 2,
              }}
            >
              <HostCardSkeleton />
              <PaymentCardSkeleton />
            </Box>
          </Box>
        </>
      )}
    </StyledContainer>
  );
};

export default MainSkeleton;
