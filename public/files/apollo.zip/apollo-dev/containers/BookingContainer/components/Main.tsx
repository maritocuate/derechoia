import React from 'react';
import { styled, Box } from '@mui/material';
import BookingCard from '../../../components/BookingCard/BookingCard';
import {
  BookingCardProps,
  BookingPageProps,
} from '../../../components/BookingCard/types';
import { HostCardProps } from '../../../components/HostCard/types';
import { PaymentCardProps } from '../../../components/PaymentCard/types';
import HostCard from '../../../components/HostCard/HostCard';
import PaymentCard from '../../../components/PaymentCard/PaymentCard';
import useIsMobile from '../../../hooks/useIsMobile';
import { BookingDetails } from '../../../types/booking.types';
import TosReserva from '../../../components/TosReserva/TosReserva';
import BookingHeader from '../../../components/BookingHeader/BookingHeader';
import Guests from '../../../components/BookingCard/components/Guests';
import Accommodation from '../../../components/BookingCard/components/Accommodation';

const StyledContainer = styled(Box)(`
    display: flex;
    flex-direction: column;
    gap: 1rem;
`);

interface MainProps {
  detailsProps: BookingDetails;
  bookingPageProps: BookingPageProps;
  bookingCardProps: BookingCardProps;
  hostCardProps: HostCardProps;
  paymentCardProps: PaymentCardProps;
}

const Main = ({
  detailsProps,
  bookingPageProps,
  bookingCardProps,
  hostCardProps,
  paymentCardProps,
}: MainProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer>
      <BookingHeader
        title={bookingPageProps.title}
        location={bookingPageProps.location}
      />
      <BookingCard {...bookingCardProps} />
      {isMobile && (
        <>
          <HostCard {...hostCardProps} />
          <Guests
            maxPeople={bookingCardProps.booking.maxPeople}
            confirmationCode={bookingCardProps.booking.confirmationCode}
            voucherLink={bookingCardProps.actions.goVoucher}
            anteriores={bookingCardProps.booking.anteriores}
          />
          <Accommodation
            roomType={bookingCardProps.hotelDetails.name}
            maxPeople={bookingCardProps.booking.maxPeople}
            rooms={bookingCardProps.booking.rooms}
            bathrooms={bookingCardProps.booking.bathrooms}
            accommodationLink={bookingCardProps.actions.goAlojamiento}
          />
          <PaymentCard {...paymentCardProps} />
        </>
      )}

      <Box
        sx={{
          display: 'flex',
          flexDirection: !isMobile ? 'row' : 'column',
          gap: '2rem',
        }}
      >
        <TosReserva data={detailsProps} />
        <Box
          sx={{
            display: !isMobile ? 'flex' : 'none',
            flexDirection: 'column',
            gap: '1rem',
          }}
        >
          <HostCard {...hostCardProps} />
          <PaymentCard {...paymentCardProps} />
        </Box>
      </Box>
    </StyledContainer>
  );
};

export default Main;
