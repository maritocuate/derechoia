import React from 'react';
import useBookingData from '../../hooks/useBooking/useBooking';
import useIsMobile from '../../hooks/useIsMobile';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Main from './components/Main';
import ContentWrapper from '../../components/ContentWrapper/ContentWrapper';
import MainSkeleton from './components/MainSkeleton';

const BookingsContainer = ({ bookingId }: { bookingId: string }) => {
  const isMobile = useIsMobile();
  const { isLoading, bookingDetails } = useBookingData(bookingId);
  const showLoader = isLoading || !bookingDetails;

  return (
    <>
      <Header openCheckoutSIC={false} openMedia={false} />
      <ContentWrapper
        maxWidth={isMobile ? 600 : 1190}
        marginTop={isMobile ? 5 : 7}
      >
        {showLoader ? (
          <MainSkeleton />
        ) : (
          bookingDetails && (
            <Main
              detailsProps={bookingDetails.detailsProps}
              bookingPageProps={bookingDetails.bookingPageProps}
              bookingCardProps={bookingDetails.bookingCardProps}
              hostCardProps={bookingDetails.hostCardProps}
              paymentCardProps={bookingDetails.paymentCardProps}
            />
          )
        )}
      </ContentWrapper>
      <Footer footerList={false} />
    </>
  );
};

export default BookingsContainer;
