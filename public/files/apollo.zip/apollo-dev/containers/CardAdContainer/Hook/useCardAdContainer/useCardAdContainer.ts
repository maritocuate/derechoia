import { useEffect, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { useChangeFavorite } from '../../../../hooks/useChangeFavorite';
import { useRequestToApiList } from '../../../../hooks/list/useRequestToApiList';
import { IStatusListado } from '../../../../redux/filtersListado/types';
import { useLoadingCardAdList } from '../useLoadingCardAdList/useLoadingCardAdList';

export const useCardAdContainer = () => {
  const { handleFavoriteAds, showSnackBar, setShowSnackbar } =
    useChangeFavorite();

  const { listData, filters } = useRequestToApiList();
  const [openModalFavorite, setOpenModalFavorite] = useState(false);
  const { adults, youngs } = useSelector(
    ({ listadoStatus }: { listadoStatus: IStatusListado }) => listadoStatus,
  );
  const hasDates = filters.some((item) => item.startsWith('F:'));
  const { isLoading, isLoadingGoToAd } = useLoadingCardAdList();
  const clickFavorite = (ref: string) => {
    handleFavoriteAds(ref, setOpenModalFavorite);
  };
  const isViewSeeMoreAds: boolean = useMemo(() => {
    if (listData?.solo_hay_anuncios_sin_precio) {
      return false;
    }
    if (Number(listData?.last_page) === listData?.current_page) {
      if (listData?.hay_anuncios_sin_precio) {
        return true;
      }
      return false;
    }
    return false;
  }, [
    listData?.current_page,
    listData?.last_page,
    listData?.solo_hay_anuncios_sin_precio,
    listData?.hay_anuncios_sin_precio,
  ]);
  useEffect(() => {
    if (isLoadingGoToAd) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      document.body.style.overflow = 'auto';
    };
    // Applying on unmount
  }, [isLoadingGoToAd]);

  return {
    isViewSeeMoreAds,
    listData,
    clickFavorite,
    adults,
    youngs,
    showSnackBar,
    setShowSnackbar,
    openModalFavorite,
    setOpenModalFavorite,
    isLoading,
    isLoadingGoToAd,
    hasDates,
  };
};
// solo_hay_anuncios_sin_precio si es verdad, no aparece.
// hay_anuncios_sin_precio si es verdad: aparece
// acepta_anuncios_sin_precios si es verdad: aparece
