import { useDispatch, useSelector } from 'react-redux';
import { useCallback } from 'react';
import { IStatusListado } from '../../../../redux/filtersListado/types';
import {
  changeIsLoading,
  changeIsLoadingGoToAd,
} from '../../../../redux/filtersListado/slice';

export const useLoadingCardAdList = () => {
  const dispatch = useDispatch();
  const { isLoading, isLoadingGoToAd } = useSelector(
    ({ listadoStatus }: { listadoStatus: IStatusListado }) => listadoStatus,
  );
  const changeLoadingListAds = useCallback(
    (boolean: boolean) => {
      dispatch(changeIsLoading({ isLoading: boolean }));
    },
    [dispatch],
  );

  const changeLoadingListToAd = useCallback(
    (boolean: boolean) => {
      dispatch(changeIsLoadingGoToAd({ isLoadingGoToAd: boolean }));
    },
    [dispatch],
  );

  return {
    isLoading,
    changeLoadingListAds,
    isLoadingGoToAd,
    changeLoadingListToAd,
  };
};
