import { Box, CircularProgress } from '@mui/material';
import React from 'react';

const LoadingList = ({ isLoading }: { isLoading: boolean }) => {
  if (!isLoading) return null;
  return (
    <Box
      display="flex"
      position="absolute"
      top="0"
      left="0"
      height="100%"
      width="100%"
      flexDirection="column"
      alignItems="center"
      zIndex={999999}
      sx={{
        '&': {
          backdropFilter: 'blur(5px)',
          backgroundColor: 'rgba(255,255, 255,0.8)',
        },
      }}
    >
      <Box position="sticky" top="50%" marginTop="25%">
        <CircularProgress />
      </Box>
    </Box>
  );
};

export default LoadingList;
