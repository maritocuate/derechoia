import React, { useCallback } from 'react';
import dynamic from 'next/dynamic';
import useUserSession from '../../../../hooks/userSession/useUserSession';
import { useGetFavoriteQuery } from '../../../../services/favorites';
import { IPropiedadesListado } from '../../../../types/listado.type';
import useIsMobile from '../../../../hooks/useIsMobile';

const CardWithGTM = dynamic(
  () => import('../../../../components/CardAd/CardAdWithGTM'),
);
interface ListOfCardsProps {
  data: IPropiedadesListado[];
  people: number;
  hasDates: boolean;
  onClickFavorite: (referencia: string) => void;
}

export const ListOfCards = ({
  data,
  people,
  hasDates,
  onClickFavorite,
}: ListOfCardsProps) => {
  const {
    user: { email },
    isLogged,
  } = useUserSession();
  const { data: dataFav, isFetching } = useGetFavoriteQuery(email || '', {
    skip: !isLogged,
  });
  const isMobile = useIsMobile();
  const isPriority = useCallback(
    (index: number) => {
      if (isMobile && index === 0) {
        return true;
      }
      if (!isMobile && index < 3) {
        return true;
      }
      return undefined;
    },
    [isMobile],
  );

  return (
    <>
      {data.map((props: IPropiedadesListado, index: number) => {
        const isFav =
          dataFav && isLogged ? !!dataFav[props?.referencia] : false;
        return (
          <CardWithGTM
            {...props}
            hasDates={hasDates}
            isFav={isFav}
            handleFavorite={() => onClickFavorite(props.referencia)}
            key={`keyCardAdList-${index}`}
            isLoadingFav={isFetching}
            people={people}
            index={index + 1}
            priorityImage={isPriority(index)}
          />
        );
      })}
    </>
  );
};
