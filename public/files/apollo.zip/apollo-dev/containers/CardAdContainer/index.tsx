import { styled, Box } from '@mui/material';
import React, { memo } from 'react';
import { useDispatch } from 'react-redux';
import dynamic from 'next/dynamic';
import { openLoginModal } from '../../redux/appStatus/slice';
import { useCardAdContainer } from './Hook/useCardAdContainer/useCardAdContainer';

import LowPriceReccomended from '../LowPriceReccomended/LowPriceReccomended';
import useIsMobile from '../../hooks/useIsMobile';
import { useReccommendeds } from '../../hooks/list/useRequestToApiList/useReccommendeds';

const ListOfCards = dynamic(
  () =>
    import('./components/ListOfComponent/ListOfComponent').then(
      (mod) => mod.ListOfCards,
    ),
  {
    ssr: true,
  },
);
const LoadingList = dynamic(
  () => import('./components/LoadingList/LoadingList'),
  {
    ssr: false,
  },
);

const FavoriteModal = dynamic(() => import('../../components/FavoriteModal'), {
  ssr: false,
});
const SnackBarFavorite = dynamic(
  () => import('../../components/SnackBarFavorite'),
  {
    ssr: false,
  },
);

const SeeMoreAdsContainer = dynamic(
  () => import('../SeeMoreAdsContainer/SeeMoreAdsContainer'),
  { ssr: false },
);

const StyledCardAnuncioContainer = styled(Box)(
  ({ theme }) => `
  position: relative;
  top: 0;
  display: flex;
  gap: 1.5rem;
  flex-direction: column;
  min-height: 60vh;
  padding: 0 1rem;
  ${theme.breakpoints.up('lg')} {
    padding: 0 0 0 1.5rem;
  }
`,
);

const CardAdContainer = () => {
  const dispatch = useDispatch();
  const isMobile = useIsMobile();
  const {
    openModalFavorite,
    showSnackBar,
    listData,
    adults,
    youngs,
    setShowSnackbar,
    clickFavorite,
    setOpenModalFavorite,
    isViewSeeMoreAds,
    isLoading,
    isLoadingGoToAd,
    hasDates,
  } = useCardAdContainer();
  const { showReccomendedAccommodations, reccommendedRefsArrays } =
    useReccommendeds();
  const filteredListData = listData?.data.filter(
    (el) => !reccommendedRefsArrays?.includes(el.referencia),
  );
  return (
    <>
      {isMobile && showReccomendedAccommodations && (
        <LowPriceReccomended
          hasDates={hasDates}
          onClickFavorite={clickFavorite}
          people={adults + youngs}
        />
      )}
      <StyledCardAnuncioContainer>
        {!!openModalFavorite && (
          <FavoriteModal
            onClose={() => setOpenModalFavorite(false)}
            onClickLogin={() => {
              dispatch(openLoginModal());
            }}
          />
        )}
        {!!showSnackBar && (
          <SnackBarFavorite open={showSnackBar} onClose={setShowSnackbar} />
        )}
        {!isMobile && showReccomendedAccommodations && (
          <LowPriceReccomended
            hasDates={hasDates}
            onClickFavorite={clickFavorite}
            people={adults + youngs}
          />
        )}
        {!!listData?.data.length && (
          <ListOfCards
            hasDates={hasDates}
            onClickFavorite={clickFavorite}
            data={
              showReccomendedAccommodations && filteredListData
                ? filteredListData
                : listData.data
            }
            people={adults + youngs}
          />
        )}
        <LoadingList isLoading={isLoadingGoToAd || isLoading} />

        {isViewSeeMoreAds && <SeeMoreAdsContainer />}
        {!!openModalFavorite && (
          <FavoriteModal
            onClose={() => setOpenModalFavorite(false)}
            onClickLogin={() => {
              dispatch(openLoginModal());
            }}
          />
        )}
        {!!showSnackBar && (
          <SnackBarFavorite open={showSnackBar} onClose={setShowSnackbar} />
        )}
      </StyledCardAnuncioContainer>
    </>
  );
};
export default memo(CardAdContainer);
