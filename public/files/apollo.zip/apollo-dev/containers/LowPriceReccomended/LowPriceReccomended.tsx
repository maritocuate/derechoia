import React, { useCallback } from 'react';
import { Box, Skeleton, Typography, styled } from '@mui/material';
import useIsMobile from '../../hooks/useIsMobile';
import { useReccommendeds } from '../../hooks/list/useRequestToApiList/useReccommendeds';
import CardAdWithGTM from '../../components/CardAd/CardAdWithGTM';
import useUserSession from '../../hooks/userSession/useUserSession';
import { useGetFavoriteQuery } from '../../services/favorites';

interface IReccommendeds {
  people: number;
  hasDates: boolean;
  onClickFavorite: (referencia: string) => void;
}

const StyledContainter = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1rem;
    width: 100vw;
    border-top: 1px solid #FBC02D;
    border-bottom: 1px solid #FBC02D;
    background-color: #FBC02D0A;
    padding: 1.5rem 1rem;
    margin-bottom: 1rem;
    ${theme.breakpoints.up('lg')}{
      width: 100%;
      border: 1px solid #FBC02D;
      border-radius: 0.5rem;
      padding: 1.5rem;
      margin-bottom: 0;
      gap: 1.5rem;
    }
`,
);

const LowPriceReccomended = ({
  hasDates,
  onClickFavorite,
  people,
}: IReccommendeds) => {
  const isMobile = useIsMobile();
  const { reccommendedsList, isLoading } = useReccommendeds();
  const {
    user: { email },
    isLogged,
  } = useUserSession();
  const { data: dataFav, isFetching } = useGetFavoriteQuery(email || '', {
    skip: !isLogged,
  });
  const isPriority = useCallback(
    (index: number) => {
      if (isMobile && index === 0) {
        return true;
      }
      if (!isMobile && index < 3) {
        return true;
      }
      return undefined;
    },
    [isMobile],
  );
  return (
    <StyledContainter>
      <Typography variant={isMobile ? 'seeMoreAdsText' : 'textPostDesktop'}>
        Recomendados a bajo precio
      </Typography>
      {reccommendedsList?.data?.map((el, index) => {
        const isFav = dataFav && isLogged ? !!dataFav[el?.referencia] : false;
        if (isLoading) {
          return (
            <Skeleton
              width="100%"
              height={190}
              sx={{ transform: 'scale(1)' }}
              key={`skeleton-${index}`}
            />
          );
        }
        return (
          <CardAdWithGTM
            {...el}
            hasDates={hasDates}
            isFav={isFav}
            handleFavorite={() => onClickFavorite(el.referencia)}
            key={`keyCardAdList-${index}`}
            isLoadingFav={isFetching}
            people={people}
            index={index + 1}
            priorityImage={isPriority(index)}
            reccommended
          />
        );
      })}
    </StyledContainter>
  );
};

export default LowPriceReccomended;
