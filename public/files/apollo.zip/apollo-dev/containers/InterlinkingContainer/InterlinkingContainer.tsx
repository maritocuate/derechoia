import { Box, Typography, styled } from '@mui/material';
import Link from 'next/link';
import React from 'react';

interface IDestiny {
  nombre: string;
  link: string;
}

interface IInterlinking {
  cities: IDestiny[];
  place: string;
}

const StyledBox = styled(Box)`
  display: flex;
  flex-wrap: wrap;
`;

const StyledContainer = styled(Box)(
  ({ theme }) => `
  border-radius: 0.5rem;
  border: 1px solid rgba(0, 0, 0, 0.23);
  padding: 1rem;
  width: calc(100% - 2rem);
  margin: 0 auto;
  margin-bottom: 3rem;
  ${theme.breakpoints.up('lg')}{
    width: 100%;
    margin: 0;
    margin-bottom: 3rem;
    padding: 1.5rem;
  }
`,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
  margin-bottom: 1rem;
  font-size: 1.25rem;
  font-weight: 700;
  ${theme.breakpoints.up('lg')}{
    margin-bottom: 1.5rem;
  }
`,
);

const StyledTypography = styled(Typography)(
  ({ theme }) => `
    min-width: 100%;
    text-decoration: underline;
    cursor: pointer;
    margin-bottom: 1rem;
    ${theme.breakpoints.up('lg')}{
      min-width: 33%;
    }
  `,
);

const InterlinkingContainer = ({ cities, place }: IInterlinking) => {
  return (
    <StyledContainer>
      <StyledTitle variant="h2">Localidades cercanas a {place}</StyledTitle>
      <StyledBox>
        {cities.map((el) => (
          <StyledTypography variant="body1" key={`key${el.link}`}>
            <Link href={el.link}>{el.nombre}</Link>
          </StyledTypography>
        ))}
      </StyledBox>
    </StyledContainer>
  );
};

export default InterlinkingContainer;
