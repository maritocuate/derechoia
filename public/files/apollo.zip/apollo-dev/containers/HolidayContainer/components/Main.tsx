/* eslint-disable @typescript-eslint/naming-convention */
import React, { useState } from 'react';
import { Box, Skeleton, styled } from '@mui/material';
import { useDispatch } from 'react-redux';
import dynamic from 'next/dynamic';
import { Content, HolidayProps, Item } from '../../../types/holiday.types';
import HolidayHeader from '../../../components/HolidayHeader/HolidayHeader';
import HolidayTitle from '../../../components/HolidayTitle/HolidayTitle';
import { TGoogleReviews } from '../../../types/publicar.types';
import { useGetHomeDataQuery } from '../../../services/home';
import AccordionCard from '../../../components/AccordionCard';
import SpecialListContainer from '../../../components/SpecialListSectionContainer/SpecialListSectionContainer';
import useUserSession from '../../../hooks/userSession/useUserSession';
import { useChangeFavorite } from '../../../hooks/useChangeFavorite';
import SnackBarFavorite from '../../../components/SnackBarFavorite';
import FavoriteModal from '../../../components/FavoriteModal';
import { openLoginModal } from '../../../redux/appStatus/slice';
import useIsMobile from '../../../hooks/useIsMobile';

const GoogleReviews = dynamic(
  () => import('../../../components/GoogleReviews/GoogleReviews'),
  { ssr: false },
);

const SearchContainer = dynamic(
  () => import('../../../components/SearchContainer/SearchContainer'),
  { ssr: false },
);

const StyledContainer = styled(Box)(`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-bottom: 3rem;
`);

const Main = ({
  detailsProps,
  reviews,
}: {
  detailsProps: HolidayProps;
  reviews?: TGoogleReviews;
}) => {
  const { title, top_content, banner, content } = detailsProps;
  const [modalFavorite, setOpenModalFavorite] = useState(false);
  const dispatch = useDispatch();
  const { data } = useGetHomeDataQuery('home');
  const { user, isLogged } = useUserSession();
  const { handleFavoriteAds, showSnackBar, setShowSnackbar } =
    useChangeFavorite();
  const isMobile = useIsMobile();

  const renderContentSection = (section: Content, index: number) => {
    switch (section.type) {
      case 'listado_section':
        return section.items.map((item: Item, idx: number) =>
          item.url && item.url.length > 3 ? (
            <SpecialListContainer
              key={`${index}-${idx}`}
              setOpenModalFavorite={setOpenModalFavorite}
              email={user?.email || ''}
              handleFavoriteAds={handleFavoriteAds}
              isLogged={isLogged}
              title={item.title}
              description={item.description}
              urlList={item.url}
            />
          ) : null,
        );

      case 'bottom_content':
        return section.items.map((item: Item, idx: number) => (
          <HolidayTitle
            key={`${index}-${idx}`}
            title={item.title}
            description={item.text}
          />
        ));

      case 'faqs_list':
        return (
          <Box width="100%" maxWidth={isMobile ? 600 : 1200} marginY="5rem">
            <AccordionCard
              title="Preguntas frecuentes"
              content={section.items}
            />
          </Box>
        );

      case 'reviews_google':
        return (
          <Box maxWidth={isMobile ? 600 : 1200} marginBottom="4rem">
            {reviews ? (
              <GoogleReviews
                title="Alquiler Argentina"
                reviews={reviews}
                withMargin={false}
              />
            ) : (
              <Skeleton width={isMobile ? 600 : 1200} height={550} />
            )}
          </Box>
        );

      case 'buscador_listado_especial':
        return <SearchContainer banner={data?.mainBanner} />;

      default:
        return null;
    }
  };

  return (
    <StyledContainer>
      <HolidayHeader
        title={title}
        topContent={top_content}
        bannerUrl={banner}
      />

      {content.map((section, index) => renderContentSection(section, index))}

      {!!showSnackBar && (
        <SnackBarFavorite open={showSnackBar} onClose={setShowSnackbar} />
      )}
      {!!modalFavorite && (
        <FavoriteModal
          onClose={() => setOpenModalFavorite(false)}
          onClickLogin={() => dispatch(openLoginModal())}
        />
      )}
    </StyledContainer>
  );
};

export default Main;
