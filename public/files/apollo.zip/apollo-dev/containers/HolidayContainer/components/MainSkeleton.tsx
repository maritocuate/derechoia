import React from 'react';
import { Box, Skeleton } from '@mui/material';
import useIsMobile from '../../../hooks/useIsMobile';

const MainSkeleton = () => {
  const isMobile = useIsMobile();
  return (
    <Box display="flex" justifyContent="center">
      <Box
        maxWidth={isMobile ? 600 : 1200}
        marginTop={isMobile ? 12 : 14}
        width="100%"
        padding="0 1rem"
      >
        <Skeleton variant="text" width="60%" height={75} sx={{ mt: -1 }} />
        <Skeleton variant="text" width="80%" height={30} />
        <Skeleton variant="text" width="80%" height={30} />
        <Skeleton variant="rounded" width="100%" height={450} sx={{ mt: 6 }} />
        <Skeleton variant="text" width="60%" height={50} sx={{ mt: 11 }} />
      </Box>
    </Box>
  );
};

export default MainSkeleton;
