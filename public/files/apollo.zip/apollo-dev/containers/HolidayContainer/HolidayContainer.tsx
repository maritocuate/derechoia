import React from 'react';
import { Box, Grid, styled } from '@mui/material';
import useHolidayData from '../../hooks/useHoliday/useHoliday';
import Header from '../../components/Header';
import Main from './components/Main';
import Footer from '../../components/Footer';
import { useGetReviewsQuery } from '../../services/reviews';

const StyledFooterContainer = styled(Grid)(
  ({ theme }) => `
    margin-block-end: 5rem;
    ${theme.breakpoints.up('lg')} {
      margin-block-end: initial;
    }
  `,
);
const StyledContainer = styled(Box)(`
  height: 100%;
  min-height: 100%;
`);

const HolidayContainer = ({ urlEvent }: { urlEvent: string }) => {
  const { holidayDetails } = useHolidayData(urlEvent);
  const { data: reviews } = useGetReviewsQuery('2');
  if (!holidayDetails) return null;

  return (
    <StyledContainer>
      <Header openCheckoutSIC={false} openMedia={false} />
      <Main detailsProps={holidayDetails} reviews={reviews} />
      <StyledFooterContainer>
        <Footer />
      </StyledFooterContainer>
    </StyledContainer>
  );
};

export default HolidayContainer;
