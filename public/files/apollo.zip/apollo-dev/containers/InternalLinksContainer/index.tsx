import { styled, Grid } from '@mui/material';
import React, { memo } from 'react';
import { usePageList } from '../../hooks/list/usePageList';
import InternalLinks from '../../components/InternalLinks';
import useIsMobile from '../../hooks/useIsMobile';

const StyledInternalLinksContainer = styled(Grid)`
  display: flex;
  width: 100%;
  justify-content: center;
  margin-bottom: 48px;
`;

const InternalLinksContainer = () => {
  const { province, locality } = usePageList();
  const isMobile = useIsMobile();
  if (province && !locality) {
    return (
      <StyledInternalLinksContainer>
        <InternalLinks
          province={province.replace('-', ' ')}
          mobile={isMobile}
        />
      </StyledInternalLinksContainer>
    );
  }
  return null;
};

export default memo(InternalLinksContainer);
