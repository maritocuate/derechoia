import React, { useMemo, useState, memo } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import Divider from '@alquiler-argentina/demiurgo/components/Divider';
import { Box, styled, Collapse, Grid, Typography } from '@mui/material';
import Head from 'next/head';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import LinkFaq from '../LinkFaqs';
import IconFaqs from '../../utils/helpers/Faqs/IconFaqs';

interface IFaqs {
  locality: string;
  minPrice: number;
  province: string;
  averagePrice: number;
}

interface Answer {
  value: boolean;
}

const StyledIconWithText = styled(IconWithText)`
  cursor: pointer;
  justify-content: flex-end !important;
  margin-bottom: 1rem;
`;

const StyledTypography = styled(Typography)`
  margin-bottom: 1rem;
`;

const StyledTitle = styled(Typography)`
  margin-bottom: 1.75rem;
  font-weight: 700;
  font-size: 1.3rem;
`;

const StyledContainer = styled(Box)(
  ({ theme }) => `
  border: 1px solid rgba(0, 0, 0, 0.23);
  padding: 1rem;
  border-radius: 8px;
  width: calc(100% - 2rem);
  ${theme.breakpoints.up('sm')}{
    width: 100%;
  }
`,
);

function FrequentlyAskedQuestions({
  locality,
  minPrice,
  province,
  averagePrice,
}: IFaqs) {
  const [answers, setAnswers] = useState<Answer[]>([
    { value: false },
    { value: false },
    { value: false },
    { value: false },
    { value: false },
    { value: false },
  ]);
  const url = useMemo(
    () => `/${province}/${locality}/`.replace(/\s+/g, '-'),
    [province, locality],
  );
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: `¿Cuánto cuesta en promedio hospedarse una noche en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `El precio promedio para hospedarse en ${locality} es de  ${formatPriceToArs(
            averagePrice,
          )} por noche. Los valores son aproximados y dependen del tipo de alojamiento que se trate, de su ubicación y de la época del año.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Todos los hospedajes en ${locality} cuentan con conexión WiFi?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `En Alquiler Argentina tenés múltiples opciones de <a href=${`${url}_S:I/`} style='color: #3f3e3e;' font-weight:600'>alojamientos con WiFi en ${locality} </a> para conectarte en tus vacaciones o viajes de trabajo.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿A partir de qué precio hay alquileres económicos en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Hay alquileres económicos en ${locality} a partir de un precio aproximado de  ${formatPriceToArs(
            minPrice,
          )} por noche. `,
        },
      },
      {
        '@type': 'Question',
        name: `¿Puedo elegir un hospedaje en ${locality} según la cantidad de personas?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Disfrutá tu estadía en ${locality} con quienes prefieras.  Indicá en la búsqueda la cantidad de adultos, niños o bebés y encontrá los mejores alojamientos de acuerdo a tus preferencias.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Todos los hospedajes en ${locality} aceptan mascotas?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `En Alquiler Argentina podés encontrar distintas opciones de <a href=${`${url}_R:M/`} style='color: #3f3e3e;'>hospedajes en ${locality} que aceptan mascotas.</a>  Viajá con ellas y disfrutá al máximo tu estadía.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Se pueden elegir alquileres temporarios por día, semana o mes en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Podés elegir las fechas que prefieras para tu estadía en ${locality}. Viajá todo el tiempo que quieras, ¡no te quedes con las ganas!`,
        },
      },
    ],
  };

  const faqs = useMemo(
    () => [
      {
        question: `¿Cuánto cuesta en promedio hospedarse una noche en ${locality}?`,
        answer: `El precio promedio para hospedarse en ${locality} es de  ${formatPriceToArs(
          averagePrice,
        )} por noche. Los valores son aproximados y dependen del tipo de alojamiento que se trate, de su ubicación y de la época del año.`,
      },
      {
        question: `¿Todos los hospedajes en ${locality} cuentan con conexión WiFi?`,
        answer: (
          <LinkFaq
            title="En Alquiler Argentina tenés múltiples opciones de "
            url={`${url}_S:I/`}
            linkText={`alojamientos con WiFi en ${locality}`}
            textBody=" para conectarte en tus vacaciones o viajes de trabajo."
          />
        ),
      },
      {
        question: `¿A partir de qué precio hay alquileres económicos  en ${locality}?`,
        answer: `Hay alquileres económicos en ${locality} a partir de un precio aproximado de  ${formatPriceToArs(
          minPrice,
        )} por noche. `,
      },
      {
        question: `¿Puedo elegir un hospedaje en ${locality} según la cantidad de personas?`,
        answer: `Disfrutá tu estadía en ${locality} con quienes prefieras. 
      Indicá en la búsqueda la cantidad de adultos, niños o bebés y encontrá los mejores alojamientos de acuerdo a tus preferencias.`,
      },
      {
        question: `¿Todos los hospedajes en ${locality} aceptan mascotas?`,
        answer: (
          <LinkFaq
            title="En Alquiler Argentina podés encontrar distintas opciones de "
            url={`${url}_R:M/`}
            linkText={`hospedajes en ${locality} que aceptan mascotas.`}
            textBody=" Viajá con ellas y disfrutá al máximo tu estadía."
          />
        ),
      },
      {
        question: `¿Se pueden elegir alquileres temporarios por día, semana o mes en ${locality}?`,
        answer: `Podés elegir las fechas que prefieras para tu estadía en ${locality}. Viajá todo el tiempo que quieras, ¡no te quedes con las ganas!`,
      },
    ],
    [locality, minPrice, averagePrice, url],
  );

  const toggleAnswer = (index: number) => {
    const newAnswers = Array.from(answers);
    newAnswers[index] = { ...answers[index], value: !answers[index].value };
    setAnswers(newAnswers);
  };
  const icon = (index: number) => IconFaqs({ index, answers });

  return (
    <>
      <Head>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      </Head>
      <StyledContainer>
        <StyledTitle variant="body1">Preguntas frecuentes</StyledTitle>
        <Grid gap={2} container direction="column">
          {faqs.map((faq, index, array) => (
            <Grid item key={index}>
              <StyledIconWithText
                icon={icon(index)}
                onClick={() => toggleAnswer(index)}
                anchor="right"
              >
                <Typography variant="h2" fontWeight={600} fontSize="1rem">
                  {faq.question}
                </Typography>
              </StyledIconWithText>
              <Collapse in={answers[index].value}>
                <StyledTypography>{faq.answer}</StyledTypography>
              </Collapse>
              {array.length !== index + 1 && <Divider />}
            </Grid>
          ))}
        </Grid>
      </StyledContainer>
    </>
  );
}

export default memo(FrequentlyAskedQuestions);
