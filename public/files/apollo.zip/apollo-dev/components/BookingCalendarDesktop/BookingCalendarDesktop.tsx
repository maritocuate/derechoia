import React, { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { ClickAwayListener, styled } from '@mui/material';
import Calendar from '@alquiler-argentina/demiurgo/components/Calendar';
import dayjs from 'dayjs';
import { LicenseInfo } from '@mui/x-date-pickers-pro';
import useCalendarHandler from '../../hooks/alojamientos/useCalendarHandler';
import { ICheckoutState } from '../../redux/checkout/types';
import { handleOpenCalendar } from '../../redux/checkout/slice';

LicenseInfo.setLicenseKey(String(process.env.NEXT_PUBLIC_CALENDAR_KEY));

const StyledCalendar = styled('div')`
  position: absolute;
  top: 6%;
  right: 6%;
  z-index: 2;
  & .MuiPaper-rounded {
    max-width: 42rem;
  }
`;

const BookingCalendarDesktop = ({
  referencia,
  testProperty,
}: {
  referencia: string;
  testProperty?: boolean;
}) => {
  const dispatch = useDispatch();
  const {
    reserva: { startDate, endDate },
    isOpenCalendar,
  } = useSelector(({ checkout }: { checkout: ICheckoutState }) => checkout);

  const {
    handleChangeDates,
    handleClearDates,
    blockLessThanMinStay,
    listDate,
  } = useCalendarHandler({
    referencia,
    testProperty,
  });

  const setOpenCalendar = useCallback(
    (newState: boolean) => {
      dispatch(handleOpenCalendar({ isOpenCalendar: newState }));
    },
    [dispatch],
  );

  if (isOpenCalendar)
    return (
      <ClickAwayListener onClickAway={handleClearDates}>
        <StyledCalendar>
          {isOpenCalendar && (
            <Calendar
              startDate={dayjs(startDate)}
              endDate={dayjs(endDate)}
              blockedDays={[...listDate, ...blockLessThanMinStay]}
              actions={[
                `${
                  startDate && endDate && startDate !== endDate
                    ? 'accept'
                    : 'disabled'
                }`,
              ]}
              onChange={handleChangeDates}
              handleClose={setOpenCalendar}
            />
          )}
        </StyledCalendar>
      </ClickAwayListener>
    );
  return null;
};

export default BookingCalendarDesktop;
