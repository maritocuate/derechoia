import React from 'react';
import MapMarker from '../MapMarker/ListMapMarker';
import { LIST_MAP_MARKER_VARIANTS } from '../../constants/list/listMarkersVariants';

export type TMarkerVariant = keyof typeof LIST_MAP_MARKER_VARIANTS;

export interface ListMapMarkerProps {
  variant?: TMarkerVariant;
  price?: number;
  onClick?: () => void;
}

const ListMapMarker = ({
  variant = 'default',
  price,
  onClick,
}: ListMapMarkerProps) => {
  const markerVariantProps = LIST_MAP_MARKER_VARIANTS[variant || 'default'];
  const handleClick = () => {
    if (onClick) onClick();
  };

  return (
    <MapMarker
      handleClick={handleClick}
      price={price}
      {...markerVariantProps}
    />
  );
};

export default ListMapMarker;
