import { Box, LinkProps, styled } from '@mui/material';
import React, { memo, useMemo } from 'react';
import Image from 'next/image';
import { useGetPropiedadQuery } from '../../services/propiedades';
import useIsMobile from '../../hooks/useIsMobile';
import MainInfoAnuncio from '../MainInfoAnuncio';

const StyledHeader = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column-reverse;
    gap: 1rem;
    ${theme.breakpoints.up('lg')} {
      flex-direction: column;
    }
`,
);

const StyledImageContainer = styled(Box)(
  ({ isMobile }: { isMobile: boolean }) => ({
    width: '100%',
    height: isMobile ? '15.625rem' : '29.69rem',
    position: 'relative',
  }),
);

interface HeaderDiscountProps {
  referencia: string;
  breadcrumsLocation: LinkProps[] | null;
}

const HeaderDiscount = ({
  referencia,
  breadcrumsLocation,
}: HeaderDiscountProps) => {
  const isMobile = useIsMobile();
  const { data } = useGetPropiedadQuery(
    { referencia, test: false },
    { skip: !referencia },
  );
  const headerProps = useMemo(() => {
    if (!data) return null;
    return data?.formatedData?.headerAdData;
  }, [data]);

  return (
    <Box width="100%">
      {headerProps && (
        <StyledHeader>
          <MainInfoAnuncio
            BreadcrumsLocation={breadcrumsLocation}
            title={headerProps?.title}
            average={Number(headerProps?.average)}
            href={headerProps?.href}
            total={headerProps?.total}
          />
          <StyledImageContainer isMobile={isMobile}>
            <Image
              src={headerProps?.featuredImage}
              layout="fill"
              objectFit="cover"
              alt="featuredImage"
              style={{ borderRadius: isMobile ? '0' : '0.5rem' }}
            />
          </StyledImageContainer>
        </StyledHeader>
      )}
    </Box>
  );
};

export default memo(HeaderDiscount);
