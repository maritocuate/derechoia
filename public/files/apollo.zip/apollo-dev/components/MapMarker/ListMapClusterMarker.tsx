/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import React from 'react';

/*
 *
 * This component uses css in js,
 * because styled components don't work with Leaflet.
 *
 */

const ListMapClusterMarker = ({ count }: { count: string | number }) => {
  return (
    <div
      style={{
        cursor: 'pointer',
        backgroundColor: '#ffffff',
        borderRadius: '4px',
        padding: '4px 8px',
        display: 'inline-block',
        border: '1px solid rgba(0, 0, 0, 0.87)',
        whiteSpace: 'nowrap',
        boxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
        WebkitBoxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
        MozBoxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
      }}
    >
      <p
        style={{
          margin: '0',
          fontWeight: 500,
          color: '#000000',
          fontSize: '14px',
          lineHeight: '20px',
          fontFamily: 'Plus Jakarta Sans',
        }}
      >
        {`${count} alojamientos`}
      </p>
    </div>
  );
};

export default ListMapClusterMarker;
