/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { memo } from 'react';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';

/*
 *
 * This component uses css in js,
 * because styled components don't work with Leaflet.
 *
 */
interface IMarker {
  price?: number;
  fontColor?: string;
  fontWeight?: number;
  backgroundColor?: string;
  tagColor?: string;
  handleClick: () => void;
}

const MapMarker = ({
  price,
  fontColor,
  tagColor,
  backgroundColor,
  fontWeight,
  handleClick,
}: IMarker) => {
  return (
    <div
      style={{
        position: 'relative',
        width: '4rem',
        height: '4rem',
        padding: '1rem',
        backgroundColor: 'transparent',
      }}
      data-testid="marker-container"
    >
      <div
        style={{
          width: '1rem',
          height: '1rem',
          position: 'absolute',
          top: 'calc(-50% + 2px)',
          left: 'calc(-50% + 2px)',
          backgroundColor: 'transparent',
        }}
      >
        <div
          onClick={handleClick}
          style={{
            position: 'relative',
            cursor: 'pointer',
            whiteSpace: 'nowrap',
            display: 'inline-block',
            backgroundColor: backgroundColor || '#FFFFFF',
            padding: '4px 8px 4px 4px',
            borderRadius: '4px',
            boxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
            WebkitBoxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
            MozBoxShadow: '4px 5px 22px .3rem rgba(0,0,0,0.12)',
            borderLeft: `4px solid ${
              backgroundColor || tagColor || 'transparent'
            }`,
          }}
        >
          <div
            style={{
              content: '',
              position: 'absolute',
              bottom: '-15px',
              left: 'calc(50% - 2px)',
              transform: 'translateX(-50%)',
              width: '0',
              height: '0',
              borderTop: `7px solid ${backgroundColor || '#FFFFFF'}`,
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderBottom: '9px solid transparent',
            }}
          />
          <p
            style={{
              margin: '0',
              fontWeight: fontWeight || 500,
              color: fontColor || '#000000',
              fontSize: '14px',
              lineHeight: '20px',
              fontFamily: 'Plus Jakarta Sans',
            }}
            data-testid="marker-text"
          >
            {price ? formatPriceToArs(price) : '$ Consultar'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default memo(MapMarker);
