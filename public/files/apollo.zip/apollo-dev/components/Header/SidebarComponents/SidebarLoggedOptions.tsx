import React from 'react';
import { useTranslation } from 'react-i18next';
import FavoriteBorderOutlinedIcon from '@mui/icons-material/FavoriteBorderOutlined';
import RemoveRedEyeOutlinedIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import ForwardToInboxOutlinedIcon from '@mui/icons-material/ForwardToInboxOutlined';
import LuggageOutlinedIcon from '@mui/icons-material/LuggageOutlined';
import {
  Divider,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import Link from 'next/link';

const itemsLogged = [
  {
    href: '/mis-reservas/',
    text: 'bookings',
    icon: <LuggageOutlinedIcon />,
  },
  {
    href: '/favoritos/',
    text: 'favorites',
    icon: <FavoriteBorderOutlinedIcon />,
  },
  {
    href: '/vistos/',
    text: 'viewed',
    icon: <RemoveRedEyeOutlinedIcon />,
  },
  {
    href: '/consultados/',
    text: 'consulted',
    icon: <ForwardToInboxOutlinedIcon />,
  },
];

const SidebarLoggedOptions = () => {
  const { t } = useTranslation('Header');
  // TODO: Review links and routes

  return (
    <>
      {itemsLogged.map(({ href, text, icon }) => (
        <ListItem disablePadding key={`${text}-${href}`}>
          <Link href={href} style={{ width: '100%' }}>
            <ListItemButton>
              <ListItemIcon>{icon}</ListItemIcon>
              <ListItemText primary={t(text)} />
            </ListItemButton>
          </Link>
        </ListItem>
      ))}
      <Divider />
    </>
  );
};

export default SidebarLoggedOptions;
