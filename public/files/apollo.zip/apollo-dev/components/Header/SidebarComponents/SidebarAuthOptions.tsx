/* eslint-disable @typescript-eslint/no-misused-promises */
import React from 'react';
import {
  Avatar,
  Box,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  styled,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import { useTranslation } from 'react-i18next';
import GridViewOutlined from '@mui/icons-material/GridViewOutlined';
import Person from '@mui/icons-material/Person';
import useUserSession from '../../../hooks/userSession/useUserSession';
import { openLoginModal } from '../../../redux/appStatus/slice';
import { PANEL_ADMIN, PANEL_CLIENTE } from '../../AuthLib/Links/authLinks';

const StyledUserLogged = styled(Box)`
  padding: 1.5rem 1rem;
  width: 100%;
  display: flex;
  align-items: center;
  background-color: #00acc1;
  color: #fff;
`;
const StyledAvatar = styled(Avatar)`
  width: 2.5rem;
  height: 2.5rem;
  background-color: #fff;
`;

const SidebarAuthOptions = () => {
  const { t } = useTranslation('Header');
  const dispatch = useDispatch();
  const {
    isLogged,
    user: { name, tipo, picture },
  } = useUserSession();
  // todo: Review links and routes, and andleLogout logic
  return (
    <>
      {isLogged && (
        <>
          <ListItem disablePadding>
            <StyledUserLogged>
              <ListItemIcon>
                <StyledAvatar alt={name || ''} src={picture || ''}>
                  <Person sx={{ color: '#00acc1' }} />
                </StyledAvatar>
              </ListItemIcon>
              <ListItemText primary={name} />
            </StyledUserLogged>
          </ListItem>
          {Number(tipo) !== 1 ? (
            <ListItem disablePadding>
              <ListItemButton
                component="a"
                href={Number(tipo) === 2 ? PANEL_CLIENTE : PANEL_ADMIN}
              >
                <ListItemIcon>
                  <GridViewOutlined />
                </ListItemIcon>
                <ListItemText primary={t('access_panel')} />
              </ListItemButton>
            </ListItem>
          ) : null}
        </>
      )}
      {!isLogged && (
        <ListItem disablePadding>
          <ListItemButton
            component="a"
            onClick={() => {
              dispatch(openLoginModal());
            }}
          >
            <ListItemIcon
              sx={{ display: 'flex', alignItems: 'center', height: '3.5rem' }}
            >
              <Avatar
                alt="avatar"
                sx={{
                  backgroundColor: '#bdbdbd',
                  height: '2rem',
                  width: '2rem',
                }}
              >
                <Person />
              </Avatar>
            </ListItemIcon>
            <ListItemText primary="Iniciá sesión o registrate" />
          </ListItemButton>
        </ListItem>
      )}
    </>
  );
};

export default SidebarAuthOptions;
