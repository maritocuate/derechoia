import React, { memo } from 'react';
import {
  Avatar,
  Box,
  Button,
  Skeleton,
  Typography,
  styled,
} from '@mui/material';
import { useDispatch } from 'react-redux';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import Person from '@mui/icons-material/Person';
import useUserSession from '../../../hooks/userSession/useUserSession';
import { openLoginModal } from '../../../redux/appStatus/slice';
import { PANEL_ADMIN, PANEL_CLIENTE } from '../../AuthLib/Links/authLinks';

const StyleButton = styled(Button)`
  text-transform: none;
  &:hover {
    background-color: #fff;
  }
  &:hover .MuiTypography-root {
    font-weight: bold;
  }
`;
const StyledBorderButton = styled(Button)`
  border: 0.0625rem solid rgba(0, 0, 0, 0.08);
  border-radius: 0.25rem;
  padding: 0.4375rem 1rem;
  gap: 0.5rem;
`;
const StyledAvatar = styled(Avatar)`
  width: 2rem;
  height: 2rem;
  background-color: #bdbdbd;
`;

const LoginButton = dynamic(() => import('../LoginButton/LoginButton'), {
  loading: () => <Skeleton width={100} height={20} />,
  ssr: false,
});

const HeaderOptions = () => {
  const dispatch = useDispatch();
  const {
    isLogged,
    user: { name, tipo, picture },
  } = useUserSession();
  const welcomeCopy = `¡Hola, ${name?.split(' ')[0] || ''}!`;
  const letter = name?.charAt(0) || '';
  const kind = Number(tipo);
  return (
    <Box display="flex" gap="1.5rem">
      <StyleButton color="inherit" href="/publicar.html">
        <Typography fontSize="1rem" fontWeight="600" color="rgba(0, 0, 0, 0.6)">
          Publicar Alojamiento
        </Typography>
      </StyleButton>
      {!isLogged && (
        <StyledBorderButton
          onClick={() => {
            dispatch(openLoginModal());
          }}
        >
          <StyledAvatar alt="avatar">
            <Person />
          </StyledAvatar>
          <LoginButton />
        </StyledBorderButton>
      )}
      {isLogged && kind === 1 && (
        <StyledBorderButton disabled>
          <StyledAvatar
            alt={name || ''}
            src={picture || ''}
            sx={{ bgcolor: '#00acc1' }}
          >
            {letter}
          </StyledAvatar>
          <Typography
            fontSize="1rem"
            fontWeight="600"
            color="rgba(0, 0, 0, 0.6)"
          >
            {kind === 1 ? welcomeCopy : 'Ingresar al panel'}
          </Typography>
        </StyledBorderButton>
      )}
      {isLogged && kind !== 1 && (
        <Link href={kind === 2 ? PANEL_CLIENTE : PANEL_ADMIN} passHref>
          <StyledBorderButton>
            <StyledAvatar
              alt={name || ''}
              src={picture || ''}
              sx={{ bgcolor: '#00acc1' }}
            >
              {letter}
            </StyledAvatar>
            <Typography
              fontSize="1rem"
              fontWeight="600"
              color="rgba(0, 0, 0, 0.6)"
            >
              {kind === 1 ? welcomeCopy : 'Ingresar al panel'}
            </Typography>
          </StyledBorderButton>
        </Link>
      )}
    </Box>
  );
};

export default memo(HeaderOptions);
