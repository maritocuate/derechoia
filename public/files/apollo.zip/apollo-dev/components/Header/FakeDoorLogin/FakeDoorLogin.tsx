import React from 'react';
import { Box, styled, Typography } from '@mui/material';
import Close from '@mui/icons-material/Close';
import PersonOutlined from '@mui/icons-material/PersonOutlined';
import { useDispatch } from 'react-redux';
import { openLoginModal } from '../../../redux/appStatus/slice';

const StyledContainer = styled(Box)`
  width: 100%;
  height: 2.5rem;
  background-color: #b3e7ed;
  padding: 0.8rem 0.5rem 0.5rem 0.5rem;
  cursor: pointer;
`;

interface FakeDoorLoginProps {
  onClose: () => void;
}

const FakeDoorLogin = ({ onClose }: FakeDoorLoginProps) => {
  const dispatch = useDispatch();

  return (
    <StyledContainer
      display="flex"
      justifyContent="space-between"
      alignItems="center"
    >
      <Box
        display="flex"
        gap="0.75rem"
        onClick={() => {
          dispatch(openLoginModal());
        }}
      >
        <Box>
          <PersonOutlined sx={{ color: '#000000' }} />
        </Box>
        <Box>
          <Typography variant="fakeDoorIaText">
            ¡<span style={{ textDecoration: 'underline' }}>Iniciá sesión</span>{' '}
            y disfrutá de beneficios!
          </Typography>
        </Box>
      </Box>
      <Box onClick={onClose}>
        <Close sx={{ color: '#000000' }} />
      </Box>
    </StyledContainer>
  );
};

export default FakeDoorLogin;
