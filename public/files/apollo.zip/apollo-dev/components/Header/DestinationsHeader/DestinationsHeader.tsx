import KeyboardArrowUpOutlined from '@mui/icons-material/KeyboardArrowUpOutlined';
import {
  Box,
  Button,
  Fade,
  Typography,
  styled,
  useScrollTrigger,
} from '@mui/material';
import Link from 'next/link';
import React, { memo, useCallback, useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { DestinationProps } from './Destinations.type';
import destinationsInfo from './destinationsList.json';

const DestinationsList = dynamic(() => import('./components/DestinationsList'));

interface IMostBookDestination {
  isOpenDrawer: boolean;
}

const StyleButton = styled(Button)`
  text-transform: none;
  color: rgba(0, 0, 0, 0.6);
  &:hover {
    background-color: #fff;
  }
  &:hover .MuiTypography-root {
    font-weight: bold;
  }
`;

const StyledIcon = styled(KeyboardArrowUpOutlined)`
  transition: all 0.5s;
`;

const StyledBox = styled(Box)`
  position: absolute;
  display: flex;
  gap: 1.5rem;
  justify-content: space-between;
  padding: 1.25rem 3rem 2rem 3rem;
  background-color: #fafafa;
  right: 0;
  border-top: 1px solid #0000001f;
  transition: all 0.5s;
  box-shadow: 0px 5px 5px -3px rgb(0 0 0 / 20%),
    0px 8px 10px 1px rgb(0 0 0 / 14%);
`;

const DestinationsHeader = ({ isOpenDrawer }: IMostBookDestination) => {
  const [showDestinations, setShowDestinations] = useState(false);
  const trigger = useScrollTrigger({
    threshold: 200,
  });
  const handleShowDestinations = useCallback((val: boolean) => {
    setShowDestinations(val);
  }, []);
  useEffect(() => {
    if (trigger) {
      setShowDestinations(false);
    }
  }, [trigger]);
  return (
    <Box display="flex" gap="1.5rem">
      <Link href="/">
        <StyleButton>
          <Typography fontSize="1rem" color="inherit">
            Inicio
          </Typography>
        </StyleButton>
      </Link>
      <StyleButton
        onMouseOver={() => handleShowDestinations(true)}
        data-testid="DestinationsButton"
      >
        <Typography fontSize="1rem" color="inherit">
          Destinos populares
        </Typography>
        <StyledIcon
          fontSize="medium"
          color="inherit"
          sx={{ rotate: `${showDestinations ? '0' : '180deg'}` }}
        />
      </StyleButton>
      <Fade in={showDestinations}>
        <StyledBox
          top={showDestinations ? '4.03rem' : '-10vh'}
          height={showDestinations ? 'fit-content' : '0'}
          width={isOpenDrawer ? 'calc(100% - 20.625rem)' : '100%'}
          color={showDestinations ? '#121212' : 'transparent'}
          data-testid="DestinationsContainer"
          onMouseLeave={() => handleShowDestinations(false)}
        >
          {destinationsInfo.map((el, index) => (
            <DestinationsList
              content={{
                listTitle: el.listTitle || '',
                links: el.links || [],
                image: { src: el.image.src, alt: el.image.alt },
              }}
              type={el.type as DestinationProps['type']}
              destinations={el.destinations as DestinationProps['destinations']}
              showDestinations={showDestinations}
              key={`${index}-{listTitle}`}
            />
          ))}
        </StyledBox>
      </Fade>
    </Box>
  );
};

export default memo(DestinationsHeader);
