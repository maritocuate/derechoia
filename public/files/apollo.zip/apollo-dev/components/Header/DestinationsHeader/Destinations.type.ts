interface ContentProps {
  listTitle: string;
  links: { title: string; href: string }[];
  image: { src: string; alt: string };
}

export type ContentDestinationProps = Omit<ContentProps, 'image'>;

export interface DestinationProps {
  content: ContentProps;
  type: 'multiDestinations' | 'oneDestination';
  destinations: ContentDestinationProps[] | undefined;
  showDestinations: boolean;
}
