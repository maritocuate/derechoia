import React, { memo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import Image from 'next/image';
import Link from 'next/link';
import { DestinationProps } from '../Destinations.type';

const StyledCard = styled(Box)`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

const StyledImageContainer = styled(Box)`
  position: relative;
  width: 100%;
  border-radius: 0.5rem;
  overflow: hidden;
  height: 4.375rem;
`;

const StyledTypography = styled(Typography)`
  display: block;
  &:hover {
    font-weight: 600;
  }
`;

const StyledDestinationsBox = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const DestinationsList = ({
  content,
  destinations,
  type,
  showDestinations,
}: DestinationProps) => {
  return (
    <StyledCard
      color={showDestinations ? 'inherit' : 'transparent'}
      data-testid="List"
    >
      <StyledImageContainer>
        <Image
          alt={content.image.alt}
          src={content.image.src}
          fill
          sizes="100%"
          style={
            !showDestinations
              ? { display: 'none', objectFit: 'cover' }
              : { objectFit: 'cover' }
          }
          data-testid="ImageDestination"
        />
      </StyledImageContainer>
      {type === 'oneDestination' && (
        <StyledDestinationsBox>
          <StyledTypography variant="textPostMobile" data-testid="ListTitle">
            {content.listTitle}
          </StyledTypography>
          {content.links.map((el, index) => (
            <Link
              href={el.href}
              data-testid="ListLink"
              key={`${el.title}${index}`}
            >
              <StyledTypography
                variant="myBookingCardDescription"
                key={`${el.title}${index}`}
              >
                {el.title}
              </StyledTypography>
            </Link>
          ))}
        </StyledDestinationsBox>
      )}
      {type === 'multiDestinations' &&
        !!destinations?.length &&
        destinations.map((destination, index) => (
          <StyledDestinationsBox key={`${destination.listTitle}${index}`}>
            <StyledTypography variant="textPostMobile" data-testid="ListTitle">
              {destination.listTitle}
            </StyledTypography>
            {destination.links.map((el, i) => (
              <Link
                href={el.href}
                data-testid="ListLink"
                key={`${el.title}${i}`}
              >
                <StyledTypography variant="myBookingCardDescription">
                  {el.title}
                </StyledTypography>
              </Link>
            ))}
          </StyledDestinationsBox>
        ))}
    </StyledCard>
  );
};

export default memo(DestinationsList);
