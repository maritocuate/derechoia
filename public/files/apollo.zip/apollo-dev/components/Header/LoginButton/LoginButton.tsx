import React from 'react';
import { Typography } from '@mui/material';

const LoginButton = () => {
  return (
    <Typography
      fontSize="1rem"
      fontWeight="600"
      color="rgba(0, 0, 0, 0.6)"
      style={{ cursor: 'pointer' }}
    >
      Iniciar sesión
    </Typography>
  );
};

export default LoginButton;
