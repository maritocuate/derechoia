import React from 'react';
import AutoAwesomeSharp from '@mui/icons-material/AutoAwesomeSharp';
import { Box, styled, Typography } from '@mui/material';
import ModalFakeDoor from './components/ModalFakeDoor';
import useFakeDoorIa from './hook/useFakeDoorIA';

const StyledContainer = styled(Box)(
  ({ theme }) => `
  width: 100%;
  height: 3.5rem;
  background-color: #fdd835;
  padding: 0.5rem;
  cursor: pointer;
  ${theme.breakpoints.up('lg')}{
    padding: 1rem;
    height: 3.25rem;
  }
  `,
);

const StyledSpan = styled('span')`
  font-weight: 600;
`;

const FakeDoorIaContainer = ({ email }: { email: string }) => {
  const {
    openModal,
    emailToSend,
    onSuccess,
    isMobile,
    isLoading,
    errorMessage,
    onOpenModal,
    onCloseModal,
    onSubmit,
    setEmail,
  } = useFakeDoorIa({ email });
  return (
    <>
      <StyledContainer
        id="prueba-IA"
        onClick={onOpenModal}
        display="flex"
        justifyContent="space-between"
        alignItems="center"
      >
        <Box display="flex" gap="0.75rem">
          <Box>
            <AutoAwesomeSharp sx={{ color: '#000000DE' }} />
          </Box>
          <Box>
            <Typography
              fontSize={isMobile ? '0.875rem' : '1rem'}
              variant="fakeDoorIaText"
            >
              Encontrá tu alojamiento ideal con
              <StyledSpan> Inteligencia Artificial</StyledSpan>
            </Typography>
          </Box>
        </Box>
        {!isMobile && (
          <Box>
            <Typography variant="fakeDoorIaButton">Quiero probar</Typography>
          </Box>
        )}
      </StyledContainer>
      <ModalFakeDoor
        errorMessage={errorMessage}
        email={emailToSend}
        open={openModal}
        onClose={onCloseModal}
        setEmail={setEmail}
        onSubmit={onSubmit}
        success={onSuccess}
        isLoading={isLoading}
      />
    </>
  );
};

export default FakeDoorIaContainer;
