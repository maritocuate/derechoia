import React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { Box, Button, TextField, Typography, styled } from '@mui/material';
import AutoAwesomeSharp from '@mui/icons-material/AutoAwesomeSharp';

interface IModalFakeDoor {
  onClose: () => void;
  setEmail: React.Dispatch<React.SetStateAction<string>>;
  onSubmit: () => void;
  success: boolean;
  open: boolean;
  email: string;
  isLoading: boolean;
  errorMessage: string;
}

const StyledContent = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 1.5rem;
`;

const StyledModalTitle = styled(DialogTitle)(
  ({ theme }) => `
      height: 4rem;
      ${theme.breakpoints.up('lg')} {
        height: 5rem;
      }
    `,
);

const StyledContainer = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 0.5rem;
`;

const StyledIconButton = styled(IconButton)(
  ({ theme }) => `
      top: 10;
      ${theme.breakpoints.up('lg')} {
        top: 20;
      }
    `,
);

const StyledTextContainer = styled(Box)(
  ({ theme }) => `
      width: 17.5rem;
      text-align: center;
      ${theme.breakpoints.up('lg')} {
        width: 32rem;
      }
    `,
);

const StyledErrorOutlineOutlined = styled(AutoAwesomeSharp)(
  ({ theme }) => `
      font-size: 5rem;
      ${theme.breakpoints.up('lg')} {
        font-size: 5rem;
      }
    `,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
      font-weight: 600;
      font-size: 1.25rem;
      ${theme.breakpoints.up('lg')} {
        font-size: 1.5rem;
      }
    `,
);

export default function ModalFakeDoor({
  onClose,
  setEmail,
  onSubmit,
  success,
  open,
  email,
  isLoading,
  errorMessage,
}: IModalFakeDoor) {
  return (
    <Dialog onClose={onClose} open={open}>
      <StyledModalTitle>
        <StyledIconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
          }}
        >
          <CloseIcon />
        </StyledIconButton>
      </StyledModalTitle>
      <DialogContent sx={{ padding: '1.5rem' }} dividers>
        <StyledContent>
          <StyledContainer>
            <Box>
              <StyledErrorOutlineOutlined color="primary" />
            </Box>
            <Box textAlign="center">
              <StyledTitle fontWeight={600}>
                {success ? '¡Gracias por suscribirte!' : '¡No te lo pierdas!'}
              </StyledTitle>
            </Box>
            <StyledTextContainer>
              {success ? (
                <Typography fontWeight={400} fontSize="1rem">
                  Pronto recibirás novedades en tu correo electrónico sobre la
                  búsqueda con Inteligencia Artificial.
                </Typography>
              ) : (
                <Typography fontWeight={400} fontSize="1rem">
                  Pronto lanzaremos una búsqueda con Inteligencia Artificial
                  para mejorar tu experiencia. Dejanos tu mail y enterate antes
                  que nadie.
                </Typography>
              )}
            </StyledTextContainer>
          </StyledContainer>
          {!success && (
            <Box width="17.5rem">
              <TextField
                size="small"
                fullWidth
                label="Correo electrónico"
                onChange={(event) => setEmail(event.target.value)}
                type="email"
                value={email}
                error={!!errorMessage}
                helperText={errorMessage}
              />
            </Box>
          )}
          <Box width="17.5rem">
            <Button
              variant={success ? 'outlined' : 'contained'}
              size="large"
              fullWidth
              disabled={isLoading}
              onClick={success ? onClose : onSubmit}
            >
              {success ? 'Cerrar' : 'Avisarme'}
            </Button>
          </Box>
        </StyledContent>
      </DialogContent>
    </Dialog>
  );
}
