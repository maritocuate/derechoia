import { useState, useEffect } from 'react';
import useIsMobile from '../../../../hooks/useIsMobile';
import { useSaveEmailMutation } from '../../../../services/fakeDoorIA';
import { formatMessageError } from '../../../../utils/helpers/formatMessageError';

interface UseFakeDoorIaProps {
  email: string;
}

interface ResponseError {
  data: {
    message: string;
  };
  status: number;
}

const useFakeDoorIa = ({ email }: UseFakeDoorIaProps) => {
  const isMobile = useIsMobile();
  const [openModal, setOpenModal] = useState(false);
  const [emailToSend, setEmail] = useState(email);
  const [onSuccess, setSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [saveEmail, { isLoading }] = useSaveEmailMutation();

  useEffect(() => {
    if (email) {
      setEmail(email);
    }
  }, [email]);

  const onOpenModal = () => {
    setOpenModal(true);
    setSuccess(false);
    setErrorMessage('');
  };

  const onCloseModal = () => {
    setOpenModal(false);
  };

  const onSubmit = () => {
    saveEmail({ email: emailToSend })
      .unwrap()
      .then(() => {
        setSuccess(true);
        setErrorMessage('');
      })
      .catch((error: unknown) => {
        if (typeof error === 'object' && error !== null) {
          const serverError = error as ResponseError;
          const serverMessage = serverError.data?.message || '';
          setErrorMessage(formatMessageError(serverMessage));
        } else {
          setErrorMessage('Ocurrió un error inesperado.');
        }
        setSuccess(false);
      });
  };
  return {
    openModal,
    emailToSend,
    onSuccess,
    isMobile,
    errorMessage,
    onOpenModal,
    onCloseModal,
    onSubmit,
    setEmail,
    isLoading,
  };
};

export default useFakeDoorIa;
