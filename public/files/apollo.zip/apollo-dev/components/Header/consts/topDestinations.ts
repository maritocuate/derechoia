export const topDestination = [
  {
    listTitle: 'Costa Atlántica',
    destinations: [
      {
        text: 'Mar del Plata',
        href: '/Buenos-Aires/Mar-Del-Plata/',
      },
      {
        text: 'Miramar',
        href: '/Buenos-Aires/Miramar/',
      },
      {
        text: 'Monte Hermoso',
        href: '/Buenos-Aires/Monte-Hermoso/',
      },
      {
        text: 'Necochea',
        href: '/Buenos-Aires/Necochea/',
      },
      {
        text: 'Pinamar',
        href: '/Buenos-Aires/Pinamar/',
      },
      {
        text: 'San Clemente Del Tuyú',
        href: '/Buenos-Aires/San-Clemente-Del-Tuyú/',
      },
      {
        text: 'San Bernardo del Tuyú',
        href: '/Buenos-Aires/San-Bernardo-del-Tuyú/',
      },
      {
        text: 'Villa Gesell',
        href: '/Buenos-Aires/Villa-Gesell/',
      },
    ],
  },
  {
    listTitle: 'Patagonia',
    destinations: [
      {
        text: 'Bariloche',
        href: '/Río-Negro/San-Carlos-De-Bariloche/',
      },
      {
        text: 'El Calafate',
        href: '/Santa-Cruz/El Calafate/',
      },
      {
        text: 'El Bolsón',
        href: '/Río-Negro/El-Bolsón/',
      },
      {
        text: 'Las Grutas',
        href: '/Río-Negro/Las-Grutas/',
      },
      {
        text: 'Puerto Madryn',
        href: '/Chubut/Puerto-Madryn/',
      },
      {
        text: 'San Martín de los Andes',
        href: '/Neuquén/San-Martín-De-Los-Andes/',
      },
      {
        text: 'Ushuaia',
        href: '/Tierra-Del-Fuego/Ushuaia/',
      },
      {
        text: 'Villa La Angostura',
        href: '/Neuquén/Villa-La-Angostura/',
      },
    ],
  },
  {
    listTitle: 'Centro del país',
    destinations: [
      {
        text: 'Ciudad de Córdoba',
        href: '/Córdoba/Ciudad-De-Córdoba/',
      },
      {
        text: 'Mina Clavero',
        href: '/Córdoba/Mina-Clavero/',
      },
      {
        text: 'Rosario',
        href: '/Santa-Fe/Rosario/',
      },
      {
        text: 'Santa Rosa de Calamuchita',
        href: '/Córdoba/Santa-Rosa-De-Calamuchita/',
      },
      {
        text: 'Villa Carlos Paz',
        href: '/Córdoba/Villa-Carlos-Paz/',
      },
      {
        text: 'Villa Carlos Paz',
        href: '/Córdoba/Villa-General-Belgrano/',
      },
    ],
  },
  {
    listTitle: 'Cuyo',
    destinations: [
      { text: 'Chacras de Coria', href: '/Mendoza/Chacras-de-Coria/' },
      { text: 'Ciudad de Mendoza', href: '/Mendoza/Ciudad-De-Mendoza/' },
      { text: 'Godoy Cruz', href: '/Mendoza/Godoy-Cruz/' },
      { text: 'Luján de Cuyo', href: '/Mendoza/Lujan-De-Cuyo/' },
      { text: 'Maipú', href: '/Mendoza/Maipu/' },
      { text: 'San Rafael', href: '/Mendoza/San-Rafael/' },
      { text: 'Villa de Merlo', href: '/San-Luis/Villa-De-Merlo/' },
    ],
  },
  {
    listTitle: 'Buenos Aires',
    destinations: [
      { text: 'CABA', href: '/Buenos-Aires/Capital-Federal/' },
      { text: 'Tandil', href: '/Buenos-Aires/Tandil/' },
    ],
  },
  {
    listTitle: 'Norte',
    destinations: [
      { text: 'San Salvador de Jujuy', href: '/Jujuy/San-Salvador-De-Jujuy/' },
      { text: 'Ciudad de Salta', href: '/Salta/Ciudad-de-Salta/' },
    ],
  },
  {
    listTitle: 'Litoral',
    destinations: [
      { text: 'Colón', href: '/Entre-Ríos/Colón/' },
      { text: 'Puerto Iguazú', href: '/Misiones/Puerto-Iguazú/' },
    ],
  },
];
