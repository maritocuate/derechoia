/* eslint-disable @typescript-eslint/indent */
import { useTranslation } from 'next-i18next';
import {
  Box,
  Collapse,
  Divider,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  styled,
  AppBar,
  Slide,
  BoxProps,
} from '@mui/material';
import React, { memo, useEffect, useState } from 'react';
import useScrollTrigger from '@mui/material/useScrollTrigger';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import Image from 'next/image';
// import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import AttachMoneyOutlinedIcon from '@mui/icons-material/AttachMoneyOutlined';
import LocationOnOutlinedIcon from '@mui/icons-material/LocationOnOutlined';
// import GpsFixedOutlinedIcon from '@mui/icons-material/GpsFixedOutlined';
// import FormatBoldOutlinedIcon from '@mui/icons-material/FormatBoldOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import SupportAgentOutlinedIcon from '@mui/icons-material/SupportAgentOutlined';
import OpenInBrowserOutlinedIcon from '@mui/icons-material/OpenInBrowserOutlined';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import { useSelector } from 'react-redux';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/navigation';
import { IAppStatusState } from '../../redux/appStatus/types';
import useIsMobile from '../../hooks/useIsMobile';
import useUserSession from '../../hooks/userSession/useUserSession';
import { topDestination } from './consts/topDestinations';
import FakeDoorLogin from './FakeDoorLogin/FakeDoorLogin';

const SidebarLoggedOptions = dynamic(
  () => import('./SidebarComponents/SidebarLoggedOptions'),
  { ssr: true },
);

const DestinationsHeader = dynamic(
  () => import('./DestinationsHeader/DestinationsHeader'),
  { ssr: true },
);

const SidebarAuthOptions = dynamic(
  () => import('./SidebarComponents/SidebarAuthOptions'),
  { ssr: true },
);
const HeaderOptions = dynamic(
  () => import('./HeaderComponents/HeaderOptions'),
  { ssr: true },
);
const LoginModal = dynamic(() => import('../LoginModal/LoginModal'), {
  ssr: true,
});

const Link = dynamic(() =>
  import('@alquiler-argentina/demiurgo/components/Link').then(
    (res) => res.default,
  ),
);
const StyledNavBar = styled(Box)`
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 0.5rem 1.5rem;
  background: #fff;
  min-height: 4rem;
  width: 100%;
  top: 0;
  z-index: 99999;
  border-bottom: 1px solid #0000001f;
`;
const StyledSideBar = styled(Box)<ISideBar>(
  ({ theme, togglemenu }) => `
  width: 330px;
  height: 100%;
  position: fixed;
  overflow: auto;
  top: 58px;
  right: 0;
  z-index: 1099;
  box-shadow: ${
    togglemenu
      ? '0px 5px 5px -3px rgb(0 0 0 / 20%),0px 8px 10px 1px rgb(0 0 0 / 14%), 0px 3px 14px 2px rgb(0 0 0 / 12%)'
      : 'none'
  };
  transform: translate(${!togglemenu ? '100%' : '0px'});
  background: white;
  transition: all 0.3s ease-out;
  ::-webkit-scrollbar {
    display: none;
  }
  ${theme.breakpoints.up('lg')} {
    top: 4rem;
    right: auto;
    transform: translate(${!togglemenu ? '-500px' : '0px'});
  }
`,
);

const StyleMenuIcon = styled(MenuIcon)`
  color: rgba(0, 0, 0, 0.6);
`;

const StyleCloseIcon = styled(CloseIcon)`
  color: rgba(0, 0, 0, 0.6);
`;

const StyleArrowBack = styled(ArrowBackIosNewIcon)`
  color: rgba(0, 0, 0, 0.6);
`;

const StyledArrow = styled(Box)`
  color: rgba(0, 0, 0, 0.6);
  cursor: pointer;
`;

const MenuBurger = styled(Box)`
  cursor: pointer;
  height: 1.5rem;
  width: 1.5rem;
`;

const StyleBoxEmpty = styled(Box)`
  width: 100%;
  height: 100vh;
  background-color: transparent;
  position: fixed;
  z-index: 1099;
  z-index: 1099;
  top: 0;
`;

const StyledList = styled(List)`
  padding-top: 0;
  padding-bottom: 4.5rem;
`;

interface IHeaderProps {
  openCheckoutSIC: boolean;
  openMedia: boolean;
  isHomeView?: boolean;
  isRefView?: boolean;
  showFakeDoorLogin?: boolean;
}

interface IHideOnScrollProps {
  children: React.ReactElement;
  openCheckoutSIC?: boolean;
  openMedia?: boolean;
  isRefView?: boolean;
}

interface ISideBar extends BoxProps {
  togglemenu: number;
}

function HideOnScroll({
  children,
  openMedia,
  openCheckoutSIC,
  isRefView,
}: IHideOnScrollProps) {
  const isMobile = useIsMobile();
  const trigger = useScrollTrigger();
  const triggerRef = useScrollTrigger({
    target: typeof window !== 'undefined' ? window : undefined,
    disableHysteresis: !isMobile,
    threshold: isMobile ? 100 : 500,
  });
  return (
    <Slide
      appear={false}
      direction="down"
      in={
        (!trigger && !openCheckoutSIC && !openMedia && !isRefView) ||
        (isRefView && !triggerRef)
      }
    >
      {children}
    </Slide>
  );
}

const Header = ({
  openMedia,
  openCheckoutSIC,
  isHomeView,
  isRefView,
  showFakeDoorLogin,
}: IHeaderProps) => {
  const { t } = useTranslation('Header');
  const router = useRouter();
  const [toggleMenu, setToggleMenu] = useState(false);
  const [open, setOpen] = useState(false);
  const [openDestinationList, setOpenDestinationList] = useState(-1);
  const [isFakeDoorVisible, setIsFakeDoorVisible] = useState(true);
  const { isLogged, handleLogout } = useUserSession();
  const { isOpenLoginModal } = useSelector(
    ({ appStatus }: { appStatus: IAppStatusState }) => appStatus,
  );

  useEffect(() => {
    if (toggleMenu) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [toggleMenu]);

  const handleOpenDestinationList = (val: number) => {
    if (val !== openDestinationList) {
      setOpenDestinationList(val);
    } else {
      setOpenDestinationList(-1);
    }
  };

  const handleOpenTopDestination = () => {
    setOpen(!open);
  };
  const handleToggleMenu = () => {
    if (open) setOpen(() => false);
    setToggleMenu((prevState) => !prevState);
  };

  const isMobile = useIsMobile();
  const isFakeDoorLogin =
    isMobile && showFakeDoorLogin && !isLogged && isFakeDoorVisible;
  return (
    <>
      {isOpenLoginModal && <LoginModal />}
      <HideOnScroll
        openCheckoutSIC={openCheckoutSIC}
        openMedia={openMedia}
        isRefView={isRefView}
      >
        <AppBar>
          <StyledNavBar sx={openMedia ? { display: 'none' } : null}>
            <Box
              display="flex"
              alignItems="center"
              justifyContent="space-between"
              gap="1.5rem"
              width={isMobile ? '100%' : 'auto'}
              flexDirection={isMobile ? 'row-reverse' : 'row'}
            >
              <MenuBurger onClick={handleToggleMenu}>
                {toggleMenu ? <StyleCloseIcon /> : <StyleMenuIcon />}
              </MenuBurger>

              <Link href={process.env.NEXT_PUBLIC_URL}>
                <Image
                  src="/images/logo-aa_h.svg"
                  alt="Logo AA"
                  width={150}
                  height={25}
                />
              </Link>
              {!isMobile && (
                <DestinationsHeader
                  isOpenDrawer={toggleMenu}
                  key={`reset--${String(toggleMenu)}`}
                />
              )}
              {isHomeView && <Box />}
              {!isHomeView && (
                <Box onClick={() => router.back()}>
                  <StyledArrow
                    display={isMobile ? 'flex' : 'none'}
                    visibility={isMobile ? 'visible' : 'hidden'}
                  >
                    <StyleArrowBack color="inherit" />
                  </StyledArrow>
                </Box>
              )}
            </Box>
            {!isMobile && <HeaderOptions />}
          </StyledNavBar>
          {isFakeDoorLogin && (
            <FakeDoorLogin onClose={() => setIsFakeDoorVisible(false)} />
          )}
        </AppBar>
      </HideOnScroll>
      {toggleMenu && <StyleBoxEmpty onClick={handleToggleMenu} />}

      <StyledSideBar togglemenu={toggleMenu ? 1 : 0}>
        <StyledList sx={{ marginTop: isFakeDoorLogin ? '3.25rem' : 0 }}>
          <SidebarAuthOptions />
          <Divider />
          {isLogged && <SidebarLoggedOptions />}
          {isMobile && (
            <>
              <ListItemButton component="a" onClick={handleOpenTopDestination}>
                <ListItemIcon>
                  <LocationOnOutlinedIcon />
                </ListItemIcon>
                <ListItemText primary={t('popular_destinations')} />
                {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
              </ListItemButton>
              <Collapse in={open} timeout="auto">
                <List component="div" disablePadding>
                  {topDestination.map((destinationList, index) => (
                    <Box padding="0 1rem" key={`topDestination-${index}`}>
                      <ListItemButton component="a">
                        <ListItemText
                          primary={destinationList.listTitle}
                          onClick={() => handleOpenDestinationList(index)}
                          primaryTypographyProps={{ fontWeight: 600 }}
                        />
                        {openDestinationList === index ? (
                          <ExpandLessIcon />
                        ) : (
                          <ExpandMoreIcon />
                        )}
                      </ListItemButton>
                      <Collapse in={openDestinationList === index}>
                        {destinationList.destinations.map((el, i) => (
                          <Box padding="0.75rem 2rem" key={`destination--${i}`}>
                            <Link
                              href={el.href}
                              color="inherit"
                              underline="none"
                            >
                              <ListItemText primary={el.text} />
                            </Link>
                          </Box>
                        ))}
                      </Collapse>
                    </Box>
                  ))}
                </List>
              </Collapse>
            </>
          )}

          <ListItem disablePadding>
            <ListItemButton component="a" href="/ofertas-imperdibles/">
              <ListItemIcon>
                <AttachMoneyOutlinedIcon />
              </ListItemIcon>
              <ListItemText primary={t('unmissable_offers')} />
            </ListItemButton>
          </ListItem>

          <ListItem disablePadding>
            <ListItemButton component="a" href="/contacto.html">
              <ListItemIcon>
                <SupportAgentOutlinedIcon />
              </ListItemIcon>
              <ListItemText primary={t('contact')} />
            </ListItemButton>
          </ListItem>
          <Divider />
          <ListItem disablePadding>
            <ListItemButton component="a" href="/publicar.html">
              <ListItemIcon>
                <OpenInBrowserOutlinedIcon />
              </ListItemIcon>
              <ListItemText primary="Publicar Alojamiento" />
            </ListItemButton>
          </ListItem>

          {isLogged && (
            <ListItem disablePadding onClick={handleLogout}>
              <ListItemButton component="a">
                <ListItemIcon>
                  <LogoutOutlinedIcon />
                </ListItemIcon>
                <ListItemText primary={t('log_out')} />
              </ListItemButton>
            </ListItem>
          )}
        </StyledList>
      </StyledSideBar>
    </>
  );
};

export default memo(Header);
