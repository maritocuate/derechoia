import { Box, Skeleton } from '@mui/material';
import React from 'react';
import ContentWrapper from '../ContentWrapper/ContentWrapper';
import useIsMobile from '../../hooks/useIsMobile';

export default function ReviewsContainerSkeleton() {
  const isMobile = useIsMobile();
  return (
    <ContentWrapper
      margin="0px"
      maxWidth={isMobile ? 600 : 1200}
      marginTop={isMobile ? 5 : 7}
    >
      <Skeleton variant="text" width="80%" height={60} sx={{ mt: 8 }} />
      <Skeleton variant="text" width="40%" height={50} sx={{ mt: -1 }} />

      <Box
        sx={{
          mt: 10,
          display: 'flex',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
        }}
      >
        <Skeleton variant="rounded" width={370} height={330} sx={{ mb: 8 }} />
        <Skeleton variant="rounded" width={370} height={330} />
        <Skeleton variant="rounded" width={370} height={330} />
        <Skeleton variant="rounded" width={370} height={330} />
        <Skeleton variant="rounded" width={370} height={330} />
        <Skeleton variant="rounded" width={370} height={330} />
      </Box>
    </ContentWrapper>
  );
}
