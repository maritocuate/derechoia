import React from 'react';
import { Box, Button, styled } from '@mui/material';
import Link from 'next/link';
import { TGoogleReviews } from '../../types/publicar.types';
import ContentWrapper from '../ContentWrapper/ContentWrapper';
import useIsMobile from '../../hooks/useIsMobile';
import ReviewsHeader from '../ReviewsHeader/ReviewsHeader';
import ReviewsGrid from '../ReviewsGrid/ReviewsGrid';

const StyledBackground = styled(Box)`
  position: absolute;
  background-color: #fafafa;
  top: 0;
  left: 0;
  width: 100%;
  height: 27rem;
  z-index: -1;
`;
const StyledLink = styled(Link)(
  ({ theme }) => `
  display: inline-block;
  margin: 1rem 1rem;
  top: -4rem;
  position: relative;
  ${theme.breakpoints.up('lg')}{
    margin: 0 0 3rem 0;
    top: -5rem;
  }
`,
);
const StyledButton = styled(Button)`
  &,
  &:hover {
    border-width: 0.125rem;
    border-color: #00acc1;
    font-size: 0.9rem;
    font-weight: 600;
    padding: 0.5rem 1.375rem;
  }
`;

const TOTAL_COMMENTS_LINKS = {
  DESKTOP:
    'https://www.google.com/search?sca_esv=03b57f710e47560e&q=Alquiler+Argentina&si=AKbGX_pupYoY5_Pz6ilccZjjFXt57YRFxQVuSLPHQeMYhqnkzK1Y_-3_fLCkrxp8-ZBtZtviDJ1dJOzM4GHY9E5sFcMf4HtUZ5XTD6qk7blg0Ere2w6-iYYOiENUjZeQRB8e0G5AuPTFpuY9ZB1WOrRx9Mvzvd07yZi8acYkMQUn6WqKiD_JT8aB091hwAVb0JLYssCoaDPlMV9qTMZNvhIiL3LMoQcUCQ%3D%3D&sa=X&ved=2ahUKEwjj1Yf-05aEAxUmqZUCHSGrAx0Q6RN6BAg_EAE&biw=1745&bih=887&dpr=1.1#lrd=0x942d6640daa97f31:0x3f7c6c2d1506f139,1,,,,',
  MOBILE:
    'https://www.google.com/search?q=alquilerargentina&oq=alquilerargentina&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRhBMgYIAhBFGDwyBggDEEUYPDIGCAQQRRg8MgYIBRBFGEEyBggGEEUYQdIBCDI0MDdqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8#lkt=LocalPoiReviews&trex=m_t:lcl_akp,rc_ludocids:4574650262383685945,rc_q:alquilerargentina,ru_gwp:0%252C7,ru_q:alquilerargentina,trex_id:w1Save&lpg=cid:CgIgAQ%3D%3D',
};

interface ReviewsContainerProps {
  dataReviews: TGoogleReviews;
}

export default function ReviewsContainer({
  dataReviews,
}: ReviewsContainerProps) {
  const isMobile = useIsMobile();
  const { averageRating, totalReviewCount, reviews } = dataReviews;

  return (
    <ContentWrapper
      margin="0px"
      maxWidth={isMobile ? 600 : 1200}
      marginTop={isMobile ? 5 : 7}
    >
      <StyledBackground />
      <ReviewsHeader
        averageRating={averageRating}
        totalReviewCount={totalReviewCount}
      />
      <ReviewsGrid reviews={reviews} />

      <StyledLink
        href={
          isMobile
            ? TOTAL_COMMENTS_LINKS?.MOBILE
            : TOTAL_COMMENTS_LINKS?.DESKTOP
        }
        target="_blank"
      >
        <StyledButton color="primary" variant="outlined">
          Ver todos los comentarios
        </StyledButton>
      </StyledLink>
    </ContentWrapper>
  );
}
