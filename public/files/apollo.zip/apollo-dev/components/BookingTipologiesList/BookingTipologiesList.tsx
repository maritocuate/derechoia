/* eslint-disable arrow-body-style */
import React, { memo, useCallback, useEffect, useMemo } from 'react';
import { Grid, Typography, styled } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import CardValueOffer from '../CardValueOffer';
import { IFichaSecondCharge } from '../../redux/ficha/types';
import { setSelectedTipologyId } from '../../redux/ficha/slice';
import {
  changeTypology,
  setSelectDiscount,
  setSelectPrice,
} from '../../redux/checkout/slice';
import { ICheckoutState } from '../../redux/checkout/types';

const StyledTypography = styled(Typography)`
  font-size: 1.5rem;
  width: 100%;
  font-weight: 700;
  margin-top: 1rem;
  margin-left: 2rem;
  position: relative;
  top: 1rem;
`;

const BookingTipologiesList = ({
  cyberMondayDiscount,
}: {
  cyberMondayDiscount?: number | null;
}) => {
  const dispatch = useDispatch();
  const {
    formatedTipologies,
    tipologies,
    isAllBlocked,
    isActive,
    description,
    selectedTipologyId,
  } = useSelector(
    ({ fichaSecondCharge }: { fichaSecondCharge: IFichaSecondCharge }) =>
      fichaSecondCharge,
  );
  const { personas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const handleSelectTopologyId = useCallback(
    (id: number | null) => {
      if (id) dispatch(setSelectedTipologyId(id));
    },
    [dispatch],
  );

  const typologySelected = useMemo(() => {
    return (
      (tipologies.length > 0 &&
        tipologies.find(
          (typology) => typology.id_tipologia_legacy === selectedTipologyId,
        )) ||
      undefined
    );
  }, [tipologies, selectedTipologyId]);

  const activeTip = useMemo(
    () =>
      formatedTipologies.find(
        (el) => el.legacyTypologyId === typologySelected?.id_tipologia_legacy,
      ),
    [formatedTipologies, typologySelected?.id_tipologia_legacy],
  );
  const hasChange = useMemo(() => activeTip?.blocked.estado, [activeTip]);
  useEffect(() => {
    if (!formatedTipologies.length && isAllBlocked) return;
    dispatch(
      setSelectDiscount({
        discount:
          activeTip?.prices.discounts && activeTip?.guests === personas
            ? activeTip?.prices.discounts[activeTip?.guests]?.percentage
            : 0,
      }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch, formatedTipologies, isAllBlocked, personas]);
  useEffect(() => {
    if (!formatedTipologies.length) return;
    if (formatedTipologies.length > 0 && !isAllBlocked) {
      const autoSelected = formatedTipologies.find(
        (item) => !item.blocked.estado,
      );

      if (autoSelected?.legacyTypologyId)
        handleSelectTopologyId(autoSelected?.legacyTypologyId);
      dispatch(setSelectPrice({ price: autoSelected?.prices?.basePrice }));
      dispatch(
        setSelectDiscount({
          discount:
            autoSelected?.prices.discounts && autoSelected?.guests === personas
              ? autoSelected?.prices.discounts[autoSelected?.guests]?.percentage
              : 0,
        }),
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasChange]);
  useEffect(() => {
    if (selectedTipologyId && typologySelected) {
      dispatch(
        changeTypology({
          typologyId: selectedTipologyId,
          typologyIdV4: typologySelected.id,
        }),
      );
    }
  }, [selectedTipologyId, typologySelected, dispatch]);

  const handleSelectDiscount = useCallback(
    (discount: number | null) => {
      if (discount) return dispatch(setSelectDiscount({ discount }));
      return dispatch(setSelectDiscount({ discount: 0 }));
    },
    [dispatch],
  );

  const handleSelectPrice = useCallback(
    (price: number | null) => {
      if (price) dispatch(setSelectPrice({ price }));
    },
    [dispatch],
  );
  const availableTipologies = formatedTipologies?.filter(
    (el) => !el.blocked.estado,
  );
  const blockedTipologies = formatedTipologies?.filter(
    (el) => el.blocked.estado,
  );
  return (
    <Grid item container spacing={4}>
      {!!availableTipologies.length && (
        <>
          <StyledTypography>
            {availableTipologies.length > 1
              ? 'Opciones disponibles'
              : 'Opción disponible'}
          </StyledTypography>
          {availableTipologies.map((offer, i) => (
            <Grid item xs={12} key={i}>
              <CardValueOffer
                selected={
                  offer.legacyTypologyId ===
                  typologySelected?.id_tipologia_legacy
                }
                descripcion={description}
                isLoading={false}
                setSelectUnity={handleSelectTopologyId}
                setSelectPrice={handleSelectPrice}
                setSelectDiscount={handleSelectDiscount}
                cyberMondayDiscount={cyberMondayDiscount}
                {...offer}
                active={isActive}
              />
            </Grid>
          ))}
        </>
      )}
      {!!blockedTipologies.length && (
        <>
          <StyledTypography>
            {blockedTipologies.length > 1
              ? 'Opciones no disponibles'
              : 'Opción no disponible'}
          </StyledTypography>
          {blockedTipologies.map((offer, i) => (
            <Grid item xs={12} key={i}>
              <CardValueOffer
                selected={
                  offer.legacyTypologyId ===
                  typologySelected?.id_tipologia_legacy
                }
                cyberMondayDiscount={cyberMondayDiscount}
                descripcion={description}
                isLoading={false}
                setSelectUnity={handleSelectTopologyId}
                setSelectPrice={handleSelectPrice}
                setSelectDiscount={handleSelectDiscount}
                {...offer}
                active={isActive}
              />
            </Grid>
          ))}
        </>
      )}
    </Grid>
  );
};

export default memo(BookingTipologiesList);
