import React from 'react';
import Image from 'next/image';
import { useTranslation } from 'react-i18next';
import { Box, BoxProps, Skeleton, Typography, styled } from '@mui/material';
import NewReleasesOutlined from '@mui/icons-material/NewReleasesOutlined';
import Star from '@mui/icons-material/Star';
import valorationsTextHelper from '../../utils/helpers/valorationsTextHelper';
import formatUrlRecentlySeen from '../../utils/helpers/imageUrlFormat';

export interface ICardRecentlySeen {
  city: string;
  name: string;
  province: string;
  valoration: number;
  photo: string;
  reference: string;
  isNew: boolean;
  isLoading: boolean;
  fullseen: number;
}

interface ICardStyle extends BoxProps {
  fullseen: string;
}

const StyledCard = styled(Box)<ICardStyle>(
  ({ theme, fullseen }) => `
  display: flex;
  flex-direction: column;
  margin-right: 2rem;
  ${theme.breakpoints.up('lg')}{
    margin-right: ${fullseen === 'true' ? '0rem' : '2rem'};
  }
  `,
);

const StyledBoxImage = styled(Box)(
  ({ theme }) => `
  width: 15rem;
  height: 12.5rem;
  margin: 0;
  position: relative;
  margin-bottom: 1rem;
  cursor: pointer;
  overflow: hidden;
  border-radius: 0.5rem;
  ${theme.breakpoints.up('lg')}{
    width: 17.5rem;
    height: 13.675rem;
  }
`,
);
const StyledName = styled(Typography)(
  ({ theme }) => `
  font-weight: 600;
  max-width: 240px;
  margin: .25rem 0;
  cursor: pointer;
  ${theme.breakpoints.up('lg')}{
    max-width: 270px;
    margin: .5rem 0;
    font-size: 1.25rem;
  }
`,
);

const StyledUbication = styled(Typography)`
  cursor: pointer;
  font-size: 0.875rem;
  color: #00000099;
  margin-bottom: 0.5rem;
`;

const StyledValoration = styled(Box)`
  display: flex;
  margin-bottom: 1.5rem;
  color: #e7bc3d;
`;

const StyledImage = styled(Image)`
  transition: all 0.2s;
  &:hover {
    transform: scale(1.1);
  }
`;

const StyledValorationText = styled(Typography)`
  font-weight: 500;
  font-size: 0.875;
  color: black;
  margin-left: 0.25rem;
`;

const StyledRating = styled(Box)`
  font-weight: 600;
  margin-right: 0.25rem;
`;

const StyledSkeletonBox = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    margin-right: 1rem;
    ${theme.breakpoints.up('sm')}{
      margin-right: 0;
    }
  `,
);

export default function CardRecentlySeen({
  name,
  city,
  province,
  photo,
  valoration,
  reference,
  isNew,
  isLoading,
  fullseen,
}: ICardRecentlySeen) {
  const { t } = useTranslation('RecentlySeen');
  if (isLoading) {
    return (
      <StyledSkeletonBox>
        <Box display="flex" alignItems="flex-start">
          <Skeleton variant="rectangular" width={260} height={200} />
        </Box>
        <Skeleton variant="text" sx={{ fontSize: '2rem' }} />
        <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
        <Skeleton variant="text" sx={{ fontSize: '1rem' }} />
      </StyledSkeletonBox>
    );
  }
  return (
    <StyledCard fullseen={fullseen === 4 ? 'true' : 'false'}>
      <StyledBoxImage data-testid="RecentlySeenCard">
        <StyledImage
          src={formatUrlRecentlySeen(photo, reference)}
          alt={name}
          fill
          sizes="100%"
        />
      </StyledBoxImage>
      <StyledName>{name}</StyledName>
      <StyledUbication>
        {city},{province}
      </StyledUbication>
      {!!valoration && !isNew && (
        <StyledValoration>
          <Star />
          <StyledValorationText>
            <StyledRating component="span">
              {valoration.toFixed(1)}
            </StyledRating>
            • {t(valorationsTextHelper(valoration))}
          </StyledValorationText>
        </StyledValoration>
      )}
      {isNew && (
        <StyledValoration>
          <NewReleasesOutlined />
          <StyledValorationText>{t('isNew')}</StyledValorationText>
        </StyledValoration>
      )}
    </StyledCard>
  );
}
