import React from 'react';
import { Box, styled } from '@mui/material';
import CardBenefits from '../CardBenefits/CardBenefits';
import { benefits } from './constants/benefits';

const StyledBackground = styled(Box)(
  ({ theme }) => `
  width: 100%;
  background-color: #0000000a;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 1rem 0;
  margin: 1.5rem 0;
  margin-bottom: 0.25rem;
  ${theme.breakpoints.up('lg')}{
    padding: 2rem 0;
  }
`,
);

const DisplayCards = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 100%;
    ${theme.breakpoints.up('md')}{
        max-width: 800px;
        justify-content: space-around;
    }
    ${theme.breakpoints.up('lg')}{
        max-width: 1200px;
        justify-content: space-between;
    }  
  `,
);

export default function Benefits() {
  return (
    <StyledBackground>
      <DisplayCards>
        {benefits.map((el, index) => (
          <CardBenefits
            icon={el.icon}
            title={el.title}
            text={el.text}
            key={index}
          />
        ))}
      </DisplayCards>
    </StyledBackground>
  );
}
