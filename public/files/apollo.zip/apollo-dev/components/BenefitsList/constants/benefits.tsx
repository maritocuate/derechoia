import React from 'react';
import AttachMoney from '@mui/icons-material/AttachMoney';
import FeedOutlined from '@mui/icons-material/FeedOutlined';
import GroupOutlined from '@mui/icons-material/GroupOutlined';
import VerifiedUserOutlined from '@mui/icons-material/VerifiedUserOutlined';

export const benefits = [
  {
    icon: <AttachMoney fontSize="inherit" />,
    title: 'price',
    text: 'rates',
  },
  {
    icon: <FeedOutlined fontSize="inherit" />,
    title: 'commissions',
    text: 'paid',
  },
  {
    icon: <GroupOutlined fontSize="inherit" />,
    title: 'intermediaries',
    text: 'direct',
  },
  {
    icon: <VerifiedUserOutlined fontSize="inherit" />,
    title: 'hosts',
    text: 'owners',
  },
];
