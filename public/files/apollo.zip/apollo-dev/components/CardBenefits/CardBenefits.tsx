import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';

interface ICard {
  icon: JSX.Element;
  title: string;
  text: string;
}

const StyledCard = styled(Box)(
  ({ theme }) => `
    max-width: 320px;
    margin: 1rem;
    text-align: center;
    ${theme.breakpoints.up('sm')}{
        max-width: 235px;
        text-align: left;
    }
    ${theme.breakpoints.up('xl')}{
        max-width: 260px;
    }
`,
);

const StyledIcon = styled(Typography)(
  ({ theme }) => `
    line-height: 0;
    font-size: 2.5rem;
    color: ${theme.palette.primary.main};
    ${theme.breakpoints.up('sm')}{
      font-size: 3rem;
    }
  `,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
    color: #000000DE;
    font-weight: 600; 
    margin: .25rem 0;
  ${theme.breakpoints.up('sm')}{
    font-weight: 700;
    margin: .5rem 0;
    font-size: 1.25rem;
  }
  `,
);

const StyledText = styled(Typography)`
  max-width: '320px';
  color: #00000099;
`;

export default function CardBenefits({ icon, title, text }: ICard) {
  const { t } = useTranslation('Benefits');
  return (
    <StyledCard>
      <StyledIcon>{icon}</StyledIcon>
      <StyledTitle variant="subtitle1">{t(title)}</StyledTitle>
      <StyledText variant="body1">{t(text)}</StyledText>
    </StyledCard>
  );
}
