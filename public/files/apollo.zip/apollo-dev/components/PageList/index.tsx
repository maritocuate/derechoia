import React from 'react';
import Link from 'next/link';
import { useTranslation } from 'next-i18next';

export default function PageList() {
  const { t } = useTranslation('common');
  return (
    <ul>
      <li>
        <Link href="/">{t('page-list.home')}</Link>
      </li>
      <li>
        <Link href="/listado">{t('page-list.listings')}</Link>
      </li>
      <li>
        <Link href="/valoration?bookingId=26615660">
          {t('page-list.form-valoration')}
        </Link>
      </li>
      <li>
        <Link href="/alojamientos/eh05-Casa-Sueños-de-Libertad-Villa-Santa-Cruz-Del-Lago.html">
          {t('page-list.ficha')}
        </Link>
      </li>
      <li>
        <Link href="/checkout">{t('page-list.checkout')}</Link>
      </li>
    </ul>
  );
}
