import React, { memo } from 'react';
import TermsAndConditionsBooking from '../TermsAndConditionsBooking';
import { BookingDetails } from '../../types/booking.types';
import { TRule } from '../../types/propiedades.types';

const TosReserva = ({ data }: { data: BookingDetails }) => {
  return (
    <TermsAndConditionsBooking
      valorPagoAnticipado={data?.porcentaje_seña}
      nights={Number(data?.estadia_minima)}
      cancelacion={data?.cancelacion}
      acepta_familias={Number(data?.acepta_familias) as TRule}
      acepta_parejas={Number(data?.acepta_parejas) as TRule}
      acepta_grupo_jovenes={Number(data?.acepta_grupo_jovenes) as TRule}
      apto_niños={Number(data?.apto_niños) as TRule}
      apto_bebes={Number(data?.apto_bebes) as TRule}
      acepta_mascotas={Number(data?.acepta_mascotas) as TRule}
      apto_movilidad_reducida={Number(data?.apto_movilidad_reducida) as TRule}
      permite_fumar={Number(data?.permite_fumar) as TRule}
      permite_hacer_fiestas={Number(data?.permite_hacer_fiestas) as TRule}
      permite_recibir_visitas={Number(data?.permite_recibir_visitas) as TRule}
      permite_musica={Number(data?.permite_musica) as TRule}
      garantia={Number(data?.garantia)}
      a_reintegrar={Number(data?.a_reintegrar) > 0}
      valor_a_reintegrar={data?.valor_a_reintegrar}
      datos_tarjeta={Number(data?.datos_tarjeta) > 0}
      foto_dni={Number(data?.foto_dni) > 0}
      presentar_documento={Number(data?.presentar_documento) > 0}
      firma_contrato={Number(data?.firma_contrato) > 0}
      cancelationFreeDays={Number(data?.valor_dias_cancelacion_gratis)}
      cancelationFlexMonths={Number(data?.valor_meses_cancelacion_flexible)}
    />
  );
};

export default memo(TosReserva);
