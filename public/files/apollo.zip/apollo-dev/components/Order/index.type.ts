export interface IOrderArr {
  orderName: string;
  orderValue: number;
  orderUrlValue: string;
  orderApi: string;
}

export interface IOrder {
  setOpenOrder: (value: boolean) => void;
  handleClickMenuItem: (e: React.SyntheticEvent) => void;
  orderOptions: IOrderArr[];
  propValue: number;
  selectedProp: string;
  openOrder: boolean;
}
