import React, { useState } from 'react';
import { Box, styled, MenuList, MenuItem, Button } from '@mui/material';
import SwapVertOutlined from '@mui/icons-material/SwapVertOutlined';
import { useTranslation } from 'next-i18next';
import dynamic from 'next/dynamic';
import { IOrder } from './index.type';

const Popover = dynamic(
  () => import('@mui/material/Popover').then((module) => module.default),
  { ssr: false },
);

interface IStyledOrder {
  openpopover: number;
}

const StyledButton = styled(Button)<IStyledOrder>(
  ({ openpopover }) =>
    `
  background-color: ${openpopover ? 'rgba(0, 172, 193, 0.12)' : 'transparent'};
  font-weight: 700;
  text-transform: capitalize;
  border-width: 0.125rem;
`,
);
const StyledMenuItem = styled(MenuItem)(
  ({ selected }) => `
  background-color: ${selected ? '#00ACC114' : 'undefined'};
  padding: 12px;
  &: hover {
    background-color: #0000000a;
    cursor: pointer;
  } ;
`,
);

const StyledBox = styled(Box)`
  display: flex;
  justify-content: flex-end;
  align-items: flex-end;
`;

const StyledPopover = styled(Popover)`
  & .MuiPaper-root {
    width: 177px;
    border-radius: 8px;
    margin-top: 0.4rem;
  }
`;

export default function Order({
  selectedProp,
  propValue,
  orderOptions,
  handleClickMenuItem,
}: Omit<IOrder, 'openOrder' | 'setOpenOrder'>) {
  const [openPopOver, setOpenPopOver] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
  const { t } = useTranslation('Order');

  const handlePopOver = () => {
    setOpenPopOver((prevValue) => !prevValue);
  };

  return (
    <StyledBox onClick={openPopOver ? handlePopOver : undefined}>
      <StyledButton
        openpopover={openPopOver ? 1 : 0}
        onClick={(event) => {
          setOpenPopOver((prevValue) => !prevValue);
          setAnchorEl(event.currentTarget);
        }}
        variant="outlined"
        startIcon={<SwapVertOutlined />}
      >
        {t(selectedProp)}
      </StyledButton>
      <StyledPopover
        open={openPopOver}
        elevation={5}
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'right',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <MenuList disablePadding>
          {orderOptions.map((e, i) => (
            <StyledMenuItem
              selected={propValue === e.orderValue}
              value={e.orderValue}
              key={i}
              onClick={handleClickMenuItem}
            >
              {t(e.orderName)}
            </StyledMenuItem>
          ))}
        </MenuList>
      </StyledPopover>
    </StyledBox>
  );
}
