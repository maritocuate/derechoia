import React from 'react';
import { Skeleton, SkeletonProps, styled } from '@mui/material';

const StyledSkeleton = styled(Skeleton)`
  transform: scale(1);
  margin: 0;
`;

const BaseSkeleton = (props: SkeletonProps) => {
  return <StyledSkeleton {...props} />;
};

export default BaseSkeleton;
