import { Box, styled } from '@mui/material';
import React from 'react';
import BaseSkeleton from './BaseSkeleton';

const StyledList = styled(Box)`
  display: flex;
  justify-content: space-between;
  width: 51rem;
  margin-top: 0.5rem;
`;

const ListTitleDeskSkeleton = () => {
  return (
    <StyledList data-testid="ListTitleSkeleton">
      <BaseSkeleton variant="text" width="16rem" height="2.5rem" />
      <BaseSkeleton variant="text" width="10.5rem" height="2.5rem" />
    </StyledList>
  );
};

export default ListTitleDeskSkeleton;
