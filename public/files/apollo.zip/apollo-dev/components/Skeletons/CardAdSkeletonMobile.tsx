import React from 'react';
import { Card, CardContent, Divider, Skeleton, styled } from '@mui/material';
import BaseSkeleton from './BaseSkeleton';

const StyledCard = styled(Card)`
  margin: 0.5rem 0;
`;

const StyledCardHeader = styled(BaseSkeleton)`
  width: 100%;
  height: 12rem;
`;

const CardAdSkeletonMobile = () => {
  return (
    <StyledCard elevation={4} data-testid="CardAdsSkeletonMobile">
      <StyledCardHeader width="100%" height="12rem" />
      <CardContent>
        <Skeleton variant="text" width="40%" height="1.75rem" />
        <Skeleton variant="text" width="80%" height="1.25rem" />
        <Skeleton variant="text" width="60%" height="1rem" />
        <Skeleton variant="text" width="80%" height="1rem" />
      </CardContent>
      <Divider sx={{ margin: '0' }} variant="fullWidth" />
      <CardContent>
        <Skeleton variant="text" width="80%" height="1.25rem" />
        <Skeleton variant="text" width="60%" height="1rem" />
      </CardContent>
    </StyledCard>
  );
};

export default CardAdSkeletonMobile;
