import { Box, styled } from '@mui/material';
import React from 'react';
import BaseSkeleton from './BaseSkeleton';

const StyledSection = styled(Box)`
  padding: 1.5rem 0;
  border-bottom: 1px solid #0000001f;
`;

const StyledFiltersSection = () => {
  return (
    <StyledSection>
      <Box display="flex" flexDirection="column" gap="1rem" maxWidth="13rem">
        <BaseSkeleton variant="text" width="70%" height="1.25rem" />
        <BaseSkeleton variant="text" width="100%" height="0.75rem" />
        <BaseSkeleton variant="text" width="100%" height="0.75rem" />
        <BaseSkeleton variant="text" width="100%" height="0.75rem" />
        <BaseSkeleton variant="text" width="100%" height="0.75rem" />
      </Box>
    </StyledSection>
  );
};

export default StyledFiltersSection;
