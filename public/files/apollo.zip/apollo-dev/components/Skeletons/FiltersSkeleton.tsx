import React from 'react';
import { Box, Card, styled } from '@mui/material';
import BaseSkeleton from './BaseSkeleton';
import StyledFiltersSection from './StyledFiltersSection';
import useIsMobile from '../../hooks/useIsMobile';

const StyledCard = styled(Card)`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  width: 20.5rem;
  height: 153rem;
  padding: 1.5rem;
  margin-top: 1rem;
`;

const FiltersSkeleton = () => {
  const isMobile = useIsMobile();
  if (isMobile) {
    return (
      <Box
        data-testid="FiltersSkeleton"
        display="flex"
        flexDirection="column"
        gap="1rem"
      >
        <BaseSkeleton variant="text" width="80%" height="2.5rem" />
        <Box display="flex" justifyContent="space-between">
          <BaseSkeleton variant="text" width="45%" height="2.5rem" />
          <BaseSkeleton variant="text" width="45%" height="2.5rem" />
        </Box>
      </Box>
    );
  }
  return (
    <Box
      position="absolute"
      sx={{ backgroundColor: 'white' }}
      zIndex={10}
      data-testid="FiltersSkeleton"
    >
      <StyledCard elevation={2}>
        <BaseSkeleton variant="text" width="40%" height="2rem" />
        <BaseSkeleton variant="text" width="100%" height="4rem" />
        <StyledFiltersSection />
        <StyledFiltersSection />
        <StyledFiltersSection />
        <StyledFiltersSection />
        <Box display="flex" justifyContent="space-between">
          <BaseSkeleton variant="text" width="45%" height="2.5rem" />
          <BaseSkeleton variant="text" width="45%" height="2.5rem" />
        </Box>
      </StyledCard>
    </Box>
  );
};

export default FiltersSkeleton;
