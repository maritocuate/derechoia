import React from 'react';
import { Box, Card, CardContent, Skeleton, styled } from '@mui/material';
import BaseSkeleton from './BaseSkeleton';

interface ICard {
  isMyBookingsSection?: boolean;
}

const StyledCard = styled(Card)`
  margin: 0.5rem 0;
  display: flex;
`;

const StyledCardHeader = styled(BaseSkeleton)`
  width: 100%;
  height: 12rem;
`;

const CardAdSkeletonDesk = ({ isMyBookingsSection }: ICard) => {
  return (
    <StyledCard
      elevation={4}
      sx={{ width: `${isMyBookingsSection ? '55rem' : '51rem'}` }}
    >
      <StyledCardHeader
        width="16rem"
        height="11rem"
        data-testid="CardAdsSkeletonDesk"
      />
      <CardContent
        sx={{
          width: '22rem',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          borderRight: '1px solid rgba(0, 0, 0, 0.12)',
        }}
      >
        <Box>
          <Skeleton variant="text" width="40%" height="1.75rem" />
          <Skeleton variant="text" width="60%" height="1.25rem" />
        </Box>
        <Box>
          <Skeleton variant="text" width="60%" height="1rem" />
          <Skeleton variant="text" width="80%" height="1rem" />
        </Box>
      </CardContent>
      <CardContent
        sx={{
          width: '14.75rem',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
        }}
      >
        <Box>
          <Skeleton variant="text" width="80%" height="1rem" />
          <Skeleton variant="text" width="60%" height="2rem" />
          <Skeleton variant="text" width="60%" height="1rem" />
        </Box>
        <Skeleton variant="text" width="60%" height="2rem" />
      </CardContent>
    </StyledCard>
  );
};

export default CardAdSkeletonDesk;
