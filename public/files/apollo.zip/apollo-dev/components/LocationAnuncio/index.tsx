/* eslint-disable @typescript-eslint/indent */
import React, { useState } from 'react';
import { styled, Skeleton } from '@mui/material';
import {
  IconButton,
  IconWithText,
  Typography,
  Grid,
  Button,
} from '@alquiler-argentina/demiurgo';
import PlaceOutlined from '@mui/icons-material/PlaceOutlined';
import ZoomOutMapOutlined from '@mui/icons-material/ZoomOutMapOutlined';
import { useTranslation } from 'next-i18next';
import dynamic from 'next/dynamic';
import { IMapResume } from '../MapFicha';

interface IImgForMapProps {
  reference: string;
}

interface ILocationAnuncioProps {
  reference: string;
  ubication: string;
  mapProps: IMapResume;
}

const ImgForMap = styled('div')<IImgForMapProps>(
  ({ theme, reference }) => `
  background-image: url('${
    process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
  }_mapas_/${reference}.png');
  background-size: cover;
  height: 220px;
  ${theme.breakpoints.up('sm')}{
    height: 360px;
  }
  background-position: center;
  position: relative;
  display: flex;
  justify-content: center;
`,
);

const StyledSkeleton = styled(Skeleton)(
  ({ theme }) => `
  height: 220px;
  ${theme.breakpoints.up('sm')}{
    height: 360px;
  }
`,
);

const StyledIconButton = styled(IconButton)`
  position: absolute;
  bottom: 20px;
  background-color: #ffffff;
  &:hover {
    background-color: #e0e0e0;
  }
`;

const StyledGrid = styled(Grid)`
  border-radius: 8px;
  padding: 0;
  margin: 0;
  margin-right: 16px;
  overflow: hidden;
`;

const StyledSkeletonMap = styled(Skeleton)`
  height: 360px;
  transform: scale(0.98, 1);
`;

const ButtonMap = styled(Button)`
  color: black;
  font-size: 1rem;
  text-decoration: underline;
  font-weight: 600;
  margin-top: 1rem;
`;

const MapFicha = dynamic(() => import('../MapFicha'), {
  ssr: false,
  loading: () => <StyledSkeleton variant="rectangular" />,
});

export default function LocationAnuncio({
  reference,
  ubication,
  mapProps,
}: ILocationAnuncioProps) {
  const { t } = useTranslation('LocationAnuncio');
  const [mapView, setMapView] = useState(false);
  const handleClick = () => {
    setMapView(true);
  };

  const generateMapUrl = (lat: number, long: number) =>
    `https://www.google.com/maps/place/${lat},${long}`;

  if (!reference) {
    return (
      <Grid container flexDirection="column" spacing={0} marginLeft={1}>
        <Grid item>
          <Typography fontWeight={700} fontSize="1.5rem" variant="h2">
            {t('location')}
          </Typography>
        </Grid>
        <Grid item marginTop={2} marginBottom={2}>
          <IconWithText anchor="left" icon={<PlaceOutlined />}>
            {ubication}
          </IconWithText>
        </Grid>
        <StyledSkeletonMap />
      </Grid>
    );
  }
  return (
    <Grid container flexDirection="column" spacing={0} marginLeft={1}>
      <Grid item>
        <Typography fontWeight={700} fontSize="1.5rem" variant="h2">
          {t('location')}
        </Typography>
      </Grid>
      <Grid item marginTop={2} marginBottom={2}>
        <IconWithText anchor="left" icon={<PlaceOutlined />}>
          {ubication}
        </IconWithText>
      </Grid>
      <StyledGrid item>
        {!mapView ? (
          <ImgForMap reference={reference}>
            <StyledIconButton
              size="large"
              onClick={handleClick}
              startIcon={<ZoomOutMapOutlined />}
              variant="contained"
              color="inherit"
            >
              <Typography textTransform="capitalize">
                {t('interact')}
              </Typography>
            </StyledIconButton>
          </ImgForMap>
        ) : (
          <MapFicha {...mapProps} />
        )}
        <ButtonMap
          onClick={() =>
            window.open(generateMapUrl(mapProps.lat, mapProps.long), '_blank')
          }
          variant="text"
        >
          {t('openMap')}
        </ButtonMap>
      </StyledGrid>
    </Grid>
  );
}
