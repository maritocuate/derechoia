import dynamic from 'next/dynamic';
import React, { useState } from 'react';

import ChevronLeft from '@mui/icons-material/ChevronLeft';
import Close from '@mui/icons-material/Close';
import { IconButton, styled } from '@mui/material';

const Lightbox = dynamic(() => import('react-spring-lightbox'), { ssr: false });

export interface IImg {
  src: string;
  loading: 'lazy';
  alt: string;
}
interface IType {
  imagesList: IImg[];
  open: boolean;
  handleCloseSlider: () => void;
  active: number;
}

const StyledArrow = styled(ChevronLeft)(
  ({ theme }) => `
  font-size: 40px;
  position: absolute;
  z-index: 1100;
  background-color: transparent;
  color: white;
  ${theme.breakpoints.up('sm')}{
    cursor:pointer;
    font-size: 50px;
  }
`,
);
const StyledArrowBack = styled(StyledArrow)`
  left: 2%;
`;
const StyledArrowNext = styled(StyledArrow)`
  right: 2%;
  transform: rotate(180deg);
`;
const StyledIconButton = styled(IconButton)`
  cursor: pointer;
  position: absolute;
  right: 2%;
  top: 20px;
  z-index: 1000;
  background-color: transparent;
  color: white;
`;
const StyledLightbox = styled(Lightbox)(
  ({ theme }) => `
  .lightbox-image {
    border-radius: 10px;
    cursor: zoom-in;
    z-index: 10000;
    ${theme.breakpoints.down('sm')}{
      width: 90%;
      cursor:pointer;
      font-size: 50px;
    }
  }
`,
);

function Slider({ imagesList, open, handleCloseSlider, active }: IType) {
  const [currentImageIndex, setCurrentIndex] = useState(active);

  const gotoPrevious = () =>
    currentImageIndex > 0 && setCurrentIndex(currentImageIndex - 1);

  const gotoNext = () =>
    currentImageIndex + 1 < imagesList.length &&
    setCurrentIndex(currentImageIndex + 1);

  return (
    <StyledLightbox
      isOpen={open}
      onPrev={gotoPrevious}
      onNext={gotoNext}
      images={imagesList}
      currentIndex={currentImageIndex}
      onClose={handleCloseSlider}
      renderPrevButton={() =>
        currentImageIndex !== 0 && <StyledArrowBack onClick={gotoPrevious} />
      }
      renderNextButton={() =>
        currentImageIndex !== imagesList.length - 1 && (
          <StyledArrowNext onClick={gotoNext} />
        )
      }
      renderHeader={() => (
        <StyledIconButton onClick={handleCloseSlider}>
          <Close fontSize="large" />
        </StyledIconButton>
      )}
      className="cool-class"
      singleClickToZoom
      // En la documentación aclara que la forma para cambiar el color del fondo es mediante estilo en línea.
      // https://www.npmjs.com/package/react-spring-lightbox
      style={{ background: 'rgb(12,12,12)', zIndex: '999999999999' }}
    />
  );
}
export default Slider;
