import { Box, Button, Typography, styled } from '@mui/material';
import React from 'react';
import Image from 'next/image';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';
import imageLoaderPostMobile from '../../utils/helpers/imageLoaders/imageLoaderPostMobile';
import ContentWrapper from '../ContentWrapper/ContentWrapper';

const StyledBackground = styled(Box)`
  background-position: center;
  width: 100%;
  height: 32.1875rem;
`;

const StyledImage = styled(Image)`
  position: absolute;
  margin-top: 4rem;
  z-index: -1;
  object-fit: cover;
  max-height: 32.1875rem;
  object-position: top;
`;

const StyledContent = styled(Box)`
  display: flex;
  flex-direction: column;
  text-align: start;
  margin-left: 1rem;
  max-width: 22rem;
  padding-top: 2.5rem;
  gap: 1.25rem;
`;

const PostBannerMobile = ({
  onClick,
  secondPhoto,
}: {
  onClick: () => void;
  secondPhoto: boolean;
}) => {
  return (
    <StyledBackground data-testid="postbanner-container-mobile">
      <StyledImage
        src={
          secondPhoto
            ? formatUrlWithCdnLink('/BannerPrincipalMobile.png')
            : formatUrlWithCdnLink('/BannerSecundarioMobile.jpg')
        }
        alt="Publicá tu alojamiento"
        loader={imageLoaderPostMobile}
        priority
        fill
        sizes="100%"
      />
      <ContentWrapper marginTop={0} maxWidth={600}>
        <StyledContent>
          <Box paddingRight={6}>
            <Typography
              component="h1"
              variant="bannerTitle"
              alignSelf="stretch"
            >
              Publicá tu alojamiento en Alquiler Argentina y aumentá tus
              ingresos
            </Typography>
          </Box>
          <Box>
            <Typography component="h2" variant="bannerText">
              Sumate a una plataforma de alquileres temporarios con alcance
              nacional y presente en cada rincón del país
            </Typography>
          </Box>
          <Button
            sx={{
              width: 'fit-content',
              padding: '0.5rem 1.38rem',
            }}
            onClick={onClick}
            fullWidth
            color="primary"
            variant="contained"
          >
            <Typography variant="bannerButtonText">
              Cargar mi alojamiento
            </Typography>
          </Button>
        </StyledContent>
      </ContentWrapper>
    </StyledBackground>
  );
};

export default PostBannerMobile;
