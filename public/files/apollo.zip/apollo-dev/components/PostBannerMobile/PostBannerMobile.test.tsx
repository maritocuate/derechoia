import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import PostBannerMobile from './PostBannerMobile';

test('renders PostBannerMobile without crashing', () => {
  const onClickMock = jest.fn();
  render(<PostBannerMobile onClick={onClickMock} secondPhoto={false} />);

  const postBannerContainer = screen.getByTestId('postbanner-container-mobile');
  expect(postBannerContainer).toBeInTheDocument();
});

test('renders PostBannerMobile with correct title and subtitle', () => {
  const onClickMock = jest.fn();
  render(<PostBannerMobile onClick={onClickMock} secondPhoto={false} />);

  expect(
    screen.getByText(
      /Publicá tu alojamiento en Alquiler Argentina y aumentá tus ingresos/i,
    ),
  ).toBeInTheDocument();
  expect(
    screen.getByText(
      /Sumate a una plataforma de alquileres temporarios con alcance nacional y presente en cada rincón del país/i,
    ),
  ).toBeInTheDocument();
});

test('triggers onClick when "Cargar mi alojamiento" button is clicked', () => {
  const onClickMock = jest.fn();
  render(<PostBannerMobile onClick={onClickMock} secondPhoto={false} />);

  const cargarAlojamientoButton = screen.getByRole('button', {
    name: /Cargar mi alojamiento/i,
  });
  fireEvent.click(cargarAlojamientoButton);

  expect(onClickMock).toHaveBeenCalled();
});
