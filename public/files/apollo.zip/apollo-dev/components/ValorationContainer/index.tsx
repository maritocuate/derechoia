import React, { useState } from 'react';
import { Typography } from '@alquiler-argentina/demiurgo';
import { styled, Box } from '@mui/material';
import { useTranslation } from 'next-i18next';
import dynamic from 'next/dynamic';
import { IValoration } from '../../types/valoration.type';
import { IValorationsIA } from '../../types/propiedades.types';

const ValorationResume = dynamic(() => import('../ValorationResume'), {
  ssr: true,
});

const ShowAllButton = dynamic(
  () => import('../Valoration/components/ShowAllButton/ShowAllButton'),
  { ssr: true },
);

const ValorationsModal = dynamic(
  () => import('../Valoration/components/ValorationsModal/ValorationsModal'),
  {
    ssr: true,
  },
);

const NoValorations = dynamic(
  () => import('../Valoration/components/NoValorations/NoValorations'),
  {
    ssr: true,
  },
);

const ValorationsList = dynamic(
  () => import('../Valoration/components/ValorationsList/ValorationsList'),
  {
    ssr: true,
  },
);

const ValorationsIA = dynamic(() => import('../ValorationsIA/ValorationsIA'), {
  ssr: true,
});
export interface IValorationContainer {
  ratingsData: IValoration[];
  hostName: string;
  valorationTotal: number;
  valorationsIA: IValorationsIA;
  refID: number;
}

const StyledTitle = styled(Typography)`
  font-size: 1.5rem;
  font-weight: 700;
`;

const ValorationContainer = ({
  ratingsData,
  hostName,
  valorationTotal,
  valorationsIA,
  refID,
}: IValorationContainer) => {
  const { t } = useTranslation('ValorationContainer');
  const [openModal, setOpenModal] = useState(false);
  const handleOpen = () => {
    setOpenModal(!openModal);
  };
  return (
    <Box>
      <Box>
        <StyledTitle variant="h2">{t('valorations')}</StyledTitle>
      </Box>
      {ratingsData?.length > 0 ? (
        <>
          <Box padding={1} data-testid="valoration-resume">
            <ValorationResume
              valorationTotal={valorationTotal}
              ratingsData={ratingsData}
            />
          </Box>
          {valorationsIA !== null && valorationsIA?.caracteristicas?.length && (
            <Box>
              <ValorationsIA
                caracteristicas={valorationsIA.caracteristicas}
                refID={refID}
              />
            </Box>
          )}
          {ratingsData?.map((rating, i) =>
            i < 3 ? (
              <Box key={i} width="100%" padding={2}>
                <ValorationsList
                  nombre_apellido={rating.nombre_apellido}
                  comentario={rating.comentario}
                  valoracion={rating.valoracion}
                  replica={rating.replica}
                  anio_estadia={rating.anio_estadia}
                  mes_estadia={rating.mes_estadia}
                  hostName={hostName}
                />
              </Box>
            ) : null,
          )}
          {openModal && (
            <ValorationsModal
              title={t('valorations')}
              ratingsData={ratingsData}
              handleOpen={handleOpen}
              openModal={openModal}
              setOpenModal={setOpenModal}
              hostName={hostName}
            />
          )}
          {ratingsData.length > 3 && (
            <Box>
              <ShowAllButton handleClick={handleOpen} text={t('show-all')} />
            </Box>
          )}
        </>
      ) : (
        <NoValorations />
      )}
    </Box>
  );
};

export default ValorationContainer;
