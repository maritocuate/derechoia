import { Box, BoxProps, styled } from '@mui/material';
import React, { ReactNode } from 'react';

interface ContentWrapperProps {
  maxWidth: number;
  children: ReactNode;
  marginTop: number;
  margin?: string;
}

interface IStyledBox extends BoxProps {
  margintop: number;
}

const StyledBox = styled(Box)<IStyledBox>(
  ({ theme, margintop }) => `
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: 0 auto;
    margin-top: ${margintop}rem;
    ${theme.breakpoints.up('lg')}{
      margin-top: ${margintop}rem;
    }
`,
);

const ContentWrapper = ({
  children,
  maxWidth,
  marginTop,
  margin,
}: ContentWrapperProps) => {
  return (
    <StyledBox maxWidth={maxWidth} margintop={marginTop}>
      <Box margin={margin || '1rem'}>{children}</Box>
    </StyledBox>
  );
};

export default ContentWrapper;
