import React from 'react';
import Snackbar from '@alquiler-argentina/demiurgo/components/Snackbar';
import { useTranslation } from 'react-i18next';

export interface ISnackBar {
  open: boolean;
  onClose: (value: boolean) => void;
}

export default function SnackBarFavorite({ open, onClose }: ISnackBar) {
  const { t } = useTranslation('SnackBarFavorite');
  return (
    <Snackbar
      open={open}
      onClose={() => onClose(false)}
      severity="success"
      message={t('text')}
    />
  );
}
