import React from 'react';
import {
  Breadcrums,
  Divider,
  Grid,
  Typography,
} from '@alquiler-argentina/demiurgo';
import { styled, LinkProps } from '@mui/material';
import DateRangeOutlinedIcon from '@mui/icons-material/DateRangeOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';

import { useTranslation } from 'react-i18next';
import {
  StyledInfo,
  StyledIconWithText,
  StyledTitle,
  Styledimage,
} from '../CheckoutSiro/CheckoutInfo';

interface IAcommodationInfo {
  image?: string;
  title: string;
  typology: string;
  date: {
    startDate: string;
    endDate: string;
  };
  guests: number;
  locationData: LinkProps[];
}

const StyledDividerWrapper = styled(Grid)`
  margin-block-start: 0.5rem;
`;

const StyledTypology = styled(Typography)`
  font-weight: 500;
  font-size: 14px;
`;

export default function AcommodationInfo({
  image,
  title,
  typology,
  date,
  guests,
  locationData,
}: IAcommodationInfo) {
  const { t } = useTranslation(['FormValoration']);
  return (
    <StyledInfo item container rowSpacing={1}>
      {image ? <Styledimage item featuredimage={image} /> : null}
      <Grid item container direction="column" spacing={1}>
        <Grid item>
          <StyledTitle variant="h6">{title}</StyledTitle>
        </Grid>
        <Grid item>
          <Breadcrums separator="/" linkAttribute={locationData} />
        </Grid>
      </Grid>
      <StyledDividerWrapper item xs={12}>
        <Divider />
      </StyledDividerWrapper>
      <Grid item container rowGap={0.5} sx={{ paddingTop: 'initial' }}>
        <Grid item>
          <StyledTypology variant="subtitle2">{typology}</StyledTypology>
        </Grid>
        <Grid item container columnSpacing={3}>
          <Grid item>
            <StyledIconWithText icon={<DateRangeOutlinedIcon />} anchor="left">
              {`${date.startDate} - ${date.endDate}`}
            </StyledIconWithText>
          </Grid>
          <Grid item>
            <StyledIconWithText
              icon={<PersonOutlineOutlinedIcon />}
              anchor="left"
            >
              {t('guests', {
                guests,
                count: guests,
              })}
            </StyledIconWithText>
          </Grid>
        </Grid>
      </Grid>
    </StyledInfo>
  );
}
