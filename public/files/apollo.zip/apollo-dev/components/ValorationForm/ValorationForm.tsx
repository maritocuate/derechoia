import React, { SyntheticEvent } from 'react';
import { styled } from '@mui/material';
import Ratings from '@alquiler-argentina/demiurgo/components/Rating';
import { Grid, Input, Typography } from '@alquiler-argentina/demiurgo';
import StarIcon from '@mui/icons-material/Star';
import StarBorderOutlinedIcon from '@mui/icons-material/StarBorderOutlined';
import { useTranslation } from 'react-i18next';
import useIsMobile from '../../hooks/useIsMobile';

interface IValorationForm {
  name: string;
  lastname: string;
  comment: string;
  valoration: number;
  hover: number | null;
  disabled: boolean;
  nameError: boolean;
  lastnameError: boolean;
  valorationError: boolean;
  commentError: boolean;
  handleInput: (e: SyntheticEvent) => void;
  handleFocus: (e: SyntheticEvent) => void;
  handleHoverRating: (e: SyntheticEvent, newHover: number) => void;
}

const StyledContainer = styled(Grid)`
  justify-content: center;
  max-width: 1200px;
`;

const StyledTitle = styled(Grid)`
  margin-block-end: 1rem;
`;

const StyledTitleWrapper = styled(StyledTitle)`
  margin-block-end: initial;
`;

const StyledInnerTitle = styled(Typography)`
  font-weight: 700;
  font-size: 20px;
`;

const StyledSubtitle = styled(Typography)`
  color: rgba(0, 0, 0, 0.6);
  font-size: 14px;
`;

const StyledRatingsWrapper = styled(Grid)`
  align-item: container;
`;

const StyledRating = styled(Grid)`
  display: flex;
  align-items: center;
`;

const StyledStarIcon = styled(StarIcon)`
  opacity: 0.5;
  font-size: inherit;
`;

const StyledStarBorderOutlinedIcon = styled(StarBorderOutlinedIcon)(
  ({ theme }) => `
  font-size: inherit;
  color: ${theme.palette.error.main}
`,
);

const StyledSection = styled(Grid)(
  ({ theme }) => `
  padding-inline: 1rem;
  padding-block-start: 1.5rem;
  padding-block-end: 1.3rem;
  background-color: #ffffff;
  border-radius: 8px;
  ${theme.breakpoints.up('sm')} {
    background-color: rgba(2, 136, 209, 0.04);
    padding-inline: 2rem;
    padding-block-end: 2rem;
    padding-block-start: initial;
    width: 712px;
  }
`,
);

const StyledInput = styled(Input)(
  ({ theme }) => `
  background: white;
  ${theme.breakpoints.up('sm')} {
    width: 400px;
  }
`,
);

const StyledInputComment = styled(StyledInput)(
  ({ theme }) => `
  ${theme.breakpoints.up('sm')} {
    width: 100%;
  }
`,
);

const StyledHelperText = styled(Grid)`
  padding-block-start: 0.5rem;
  padding-inline: 0.5rem;
  color: rgba(0, 0, 0, 0.6);
  p {
    font-size: 0.875rem;
  }
`;

export default function ValorationForm({
  valoration,
  name,
  lastname,
  comment,
  hover,
  disabled,
  nameError,
  lastnameError,
  valorationError,
  commentError,
  handleInput,
  handleFocus,
  handleHoverRating,
}: IValorationForm) {
  const isMobile = useIsMobile();
  const { t } = useTranslation('FormValoration');

  const qualifications: { [index: string]: string } = {
    1: t('qualifications.bad'),
    2: t('qualifications.regular'),
    3: t('qualifications.good'),
    4: t('qualifications.very-good'),
    5: t('qualifications.excellent'),
  };

  return (
    <StyledContainer container direction="column" gap={3}>
      <StyledSection item container direction="column" rowSpacing={1.5}>
        <StyledTitleWrapper item container direction="column">
          <Grid item>
            <StyledInnerTitle variant="h6">
              {t('personal-info')}
            </StyledInnerTitle>
          </Grid>
          <Grid item>
            <StyledSubtitle variant="body2">
              {t('required-fields')}
            </StyledSubtitle>
          </Grid>
        </StyledTitleWrapper>
        <Grid item container direction="column" rowSpacing={1.5}>
          <Grid item>
            <StyledInput
              name="name"
              value={name}
              fullWidth={isMobile}
              label={t('first-name')}
              onChange={handleInput}
              error={nameError}
              disabled={disabled}
              type="text"
              inputProps={{ maxLength: 30 }}
              onFocus={handleFocus}
            />
          </Grid>
          <Grid item>
            <StyledInput
              name="lastname"
              value={lastname}
              fullWidth={isMobile}
              label={t('last-name')}
              onChange={handleInput}
              error={lastnameError}
              disabled={disabled}
              type="text"
              inputProps={{ maxLength: 30 }}
              onFocus={handleFocus}
            />
          </Grid>
        </Grid>
      </StyledSection>
      <StyledSection item container direction="column" rowSpacing={1}>
        <StyledTitleWrapper item>
          <StyledInnerTitle variant="h6">{t('valoration')}</StyledInnerTitle>
        </StyledTitleWrapper>
        <StyledRatingsWrapper item container columnSpacing={1}>
          <Grid item>
            <Ratings
              name="valoration"
              size="large"
              precision={1}
              onChange={handleInput}
              onChangeActive={handleHoverRating}
              emptyIcon={
                valorationError ? (
                  <StyledStarBorderOutlinedIcon />
                ) : (
                  <StyledStarIcon />
                )
              }
              disabled={disabled}
            />
          </Grid>
          <StyledRating item>
            <Typography>
              {qualifications[hover && hover !== -1 ? hover : valoration]}
            </Typography>
          </StyledRating>
        </StyledRatingsWrapper>
        <Grid item container direction="column">
          <Grid item>
            <StyledInputComment
              name="comment"
              value={comment}
              fullWidth={isMobile}
              multiline
              rows={5}
              placeholder={t('comments')}
              label={t('comments')}
              onChange={handleInput}
              error={commentError}
              disabled={disabled}
              type="text"
              inputProps={{ maxLength: 350 }}
              onFocus={handleFocus}
            />
          </Grid>
          <StyledHelperText item container justifyContent="space-between">
            <Grid item>
              <Typography variant="body1">
                {t('min-amount-of-chars')}
              </Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{comment.length}/350</Typography>
            </Grid>
          </StyledHelperText>
        </Grid>
      </StyledSection>
    </StyledContainer>
  );
}
