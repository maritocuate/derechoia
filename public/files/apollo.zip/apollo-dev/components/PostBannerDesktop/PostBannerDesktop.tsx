/* eslint-disable @typescript-eslint/indent */
import { Box, Button, Typography, styled } from '@mui/material';
import React from 'react';
import Image from 'next/image';
import MaxWidthDesktopWrapper from '../MaxWidthDesktopWrapper/MaxWidthDesktopWrapper';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';
import imageLoaderPost from '../../utils/helpers/imageLoaders/imageLoaderPost';

const StyledBackground = styled(Box)`
  width: 100%;
  height: 37.5rem;
  margin-top: 4.3rem;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;

const StyledImage = styled(Image)`
  z-index: -1;
  margin-top: 4.3rem;
  object-fit: cover;
  position: absolute;
  max-height: 37.5rem;
`;

const StyledTitle = styled(Typography)`
  font-size: 3rem;
  font-weight: 600;
  color: #ffffff;
` as typeof Typography;

const StyledContent = styled(Box)`
  display: flex;
  flex-direction: column;
  text-align: start;
  margin-right: 30%;
  max-width: 41.438rem;
  gap: 1.5rem;
`;

const StyledSubtitle = styled(Typography)`
  font-size: 1.25rem;
  font-weight: 500;
  color: #ffffff;
` as typeof Typography;

const PostBannerDesktop = ({
  onClick,
  secondPhoto,
}: {
  onClick: () => void;
  secondPhoto: boolean;
}) => {
  return (
    <StyledBackground data-testid="postbanner-container-desktop">
      <StyledImage
        src={
          secondPhoto
            ? formatUrlWithCdnLink('/BannerPrincipalDesktop.jpg')
            : formatUrlWithCdnLink('/BannerSecundarioDesktop.jpg')
        }
        alt="Publicá tu alojamiento"
        loader={imageLoaderPost}
        priority
        fill
        sizes="100%"
      />
      <MaxWidthDesktopWrapper>
        <StyledContent>
          <Box>
            <StyledTitle component="h1">
              Publicá tu alojamiento en Alquiler Argentina y aumentá tus
              ingresos
            </StyledTitle>
          </Box>
          <Box>
            <StyledSubtitle component="h2">
              Sumate a una plataforma de alquileres temporarios con alcance
              nacional y presente en cada rincón del país
            </StyledSubtitle>
          </Box>
          <Box width="13.25rem" marginTop="1.5rem">
            <Button
              onClick={onClick}
              fullWidth
              color="primary"
              variant="contained"
              sx={{ height: '2.625rem' }}
            >
              <Typography fontWeight={600}>Cargar mi alojamiento</Typography>
            </Button>
          </Box>
        </StyledContent>
      </MaxWidthDesktopWrapper>
    </StyledBackground>
  );
};

export default PostBannerDesktop;
