import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import PostBannerDesktop from './PostBannerDesktop';
import '@testing-library/jest-dom';

test('renders PostBannerDesktop without crashing', () => {
  const onClickMock = jest.fn();
  render(<PostBannerDesktop onClick={onClickMock} secondPhoto={false} />);

  const postBannerContainer = screen.getByTestId(
    'postbanner-container-desktop',
  );
  expect(postBannerContainer).toBeInTheDocument();
});

test('renders PostBannerDesktop with correct title and subtitle', () => {
  const onClickMock = jest.fn();
  render(<PostBannerDesktop onClick={onClickMock} secondPhoto={false} />);

  expect(
    screen.getByText(
      /Publicá tu alojamiento en Alquiler Argentina y aumentá tus ingresos/i,
    ),
  ).toBeInTheDocument();
  expect(
    screen.getByText(
      /Sumate a una plataforma de alquileres temporarios con alcance nacional y presente en cada rincón del país/i,
    ),
  ).toBeInTheDocument();
});

test('triggers onClick when "Cargar mi alojamiento" button is clicked', () => {
  const onClickMock = jest.fn();
  render(<PostBannerDesktop onClick={onClickMock} secondPhoto={false} />);

  const cargarAlojamientoButton = screen.getByRole('button', {
    name: /Cargar mi alojamiento/i,
  });
  fireEvent.click(cargarAlojamientoButton);

  expect(onClickMock).toHaveBeenCalled();
});
