import React from 'react';
import { useTranslation } from 'react-i18next';
import { Typography, Button, styled } from '@mui/material';
import { IBannerJoin } from '../interfaces/interfaces';

const StlyedButton = styled(Button)`
  height: 2.625rem;
`;

const BannerJoinButton = ({ onClick }: IBannerJoin) => {
  const { t } = useTranslation('BannerJoin');
  return (
    <StlyedButton color="primary" variant="contained" onClick={onClick}>
      <Typography color="#fff" variant="modalButtonText">
        {t('bannerButton')}
      </Typography>
    </StlyedButton>
  );
};

export default BannerJoinButton;
