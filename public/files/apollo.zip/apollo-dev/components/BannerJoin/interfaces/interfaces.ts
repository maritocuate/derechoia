export interface IBannerJoin {
  onClick: () => void;
}
