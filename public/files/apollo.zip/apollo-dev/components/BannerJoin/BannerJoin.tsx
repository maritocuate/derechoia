import React from 'react';
import { useTranslation } from 'react-i18next';
import { Box, Grid, styled, Typography } from '@mui/material';
import Image from 'next/image';
import useIsMobile from '../../hooks/useIsMobile';
import { IBannerJoin } from './interfaces/interfaces';
import BannerJoinButton from './components/BannerJoinButton';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';
import imageLoader from '../../utils/helpers/imageLoaders/imageLoader';
import imageLoaderJoin from '../../utils/helpers/imageLoaders/imageLoaderJoin';
import ContentWrapper from '../ContentWrapper/ContentWrapper';

const StyledContentDesktop = styled(Grid)`
  display: flex;
  height: 33rem;
  padding: 0 4rem;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 1.125rem;
  flex-shrink: 0;
  background: rgba(0, 0, 0, 0.87);
`;

const StyledImageContainer = styled(Grid)`
  position: relative;
  height: 46.6vw;
  max-height: 33rem;
  overflow: hidden;
`;

const StyledImage = styled(Image)`
  background-position: center;
  background-size: cover;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

const StyledContentMobile = styled(Box)`
  position: relative;
  height: 22.9rem;
  display: flex;
  padding: 4rem 1.5rem;
  flex-direction: column;
  justify-content: center;
  gap: 1.5rem;
  align-items: flex-start;
`;

const StyledImageMobile = styled(Image)`
  position: absolute;
  z-index: -1;
  height: 22.9rem;
  object-fit: cover;
  object-position: bottom;
`;

const BannerJoin = ({ onClick }: IBannerJoin) => {
  const isMobile = useIsMobile();
  const { t } = useTranslation('BannerJoin');

  if (isMobile) {
    return (
      <StyledContentMobile>
        <StyledImageMobile
          src={formatUrlWithCdnLink('/BannerSumateMobile.jpg')}
          alt="Sumate a Alquiler Argentina"
          loader={imageLoader}
          fill
          sizes="100%"
        />
        <ContentWrapper marginTop={0} maxWidth={600}>
          <Typography
            component="h2"
            variant="titleSectionPostMobile"
            color="#fff"
            marginBottom={2}
          >
            {t('bannerTitle')}
          </Typography>
          <BannerJoinButton onClick={onClick} />
        </ContentWrapper>
      </StyledContentMobile>
    );
  }

  return (
    <Grid container>
      <StyledImageContainer item lg={6} md={6}>
        <StyledImage
          src={formatUrlWithCdnLink('/BannerSumateDesktop.jpg')}
          alt="Sumate a Alquiler Argentina"
          loader={imageLoaderJoin}
          height={540}
          width={1200}
        />
      </StyledImageContainer>
      <StyledContentDesktop item lg={6} md={6}>
        <Typography
          color="#fff"
          variant="titleSectionPostDestkop"
          mb="4rem"
          textAlign="center"
          component="h2"
        >
          {t('bannerTitle')}
        </Typography>
        <BannerJoinButton onClick={onClick} />
      </StyledContentDesktop>
    </Grid>
  );
};

export default BannerJoin;
