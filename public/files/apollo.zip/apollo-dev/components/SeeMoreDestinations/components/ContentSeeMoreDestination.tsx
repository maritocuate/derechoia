import React, { memo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import Link from 'next/link';
import { useLinkSeparator } from '../hooks/useLinkSeparator';
import { ContentSeeMoreDestinationProps } from '../SeeMoreDestinations.type';

const StyledContenainterLinks = styled(Box)`
  display: flex;
  flex-wrap: wrap;
  padding-top: 8px;
`;

const ContentSeeMoreDestination = ({
  listTitle,
  links,
  isMobile,
}: ContentSeeMoreDestinationProps) => {
  const containerRef = useLinkSeparator();

  return (
    <Box p="1rem" pr=".1rem">
      <Typography
        variant={
          isMobile
            ? 'titleSeMoreDestinationMobile'
            : 'titleSeMoreDestinationDesk'
        }
        component="h6"
      >
        {listTitle}
      </Typography>
      <StyledContenainterLinks ref={containerRef}>
        {links?.map(({ href, title }) => (
          <Link
            href={href}
            key={href}
            style={{
              fontSize: '14px',
              paddingRight: '12px',
              paddingTop: '8px',
              textDecoration: 'underline #0000002B',
              color: '#000000DE',
            }}
          >
            {title}
          </Link>
        ))}
      </StyledContenainterLinks>
    </Box>
  );
};

export default memo(ContentSeeMoreDestination);
