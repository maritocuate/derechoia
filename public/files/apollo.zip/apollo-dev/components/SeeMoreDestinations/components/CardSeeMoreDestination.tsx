import { Box, styled } from '@mui/material';
import Image from 'next/image';
import React, { memo } from 'react';
import ContentSeeMoreDestination from './ContentSeeMoreDestination';
import { SeeMoreDestinationProps } from '../SeeMoreDestinations.type';
import imageLoaderSeeMoreDestiantions from '../../../utils/helpers/imageLoaders/imageLoaderSeeMoreDestiantions';
import ContentSeeMoreMultiDestination from './ContentSeeMoreMultiDestination';

const StyledCardContainer = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  height: 325px;
  width: 15rem;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid rgba(0, 0, 0, 0.23);
  ${theme.breakpoints.up('lg')} {
    height: 15rem;
    width: 24rem;
    flex-direction: row;
  }
`,
);

const CardSeeMoreDestination = ({
  content,
  destinations,
  type,
  isMobile,
}: SeeMoreDestinationProps) => {
  return (
    <StyledCardContainer>
      <Image
        src={content.image.src}
        height={isMobile ? 86 : 240}
        width={isMobile ? 240 : 128}
        alt={content.image.alt}
        loader={(props) =>
          imageLoaderSeeMoreDestiantions({
            ...props,
            height: isMobile ? 86 : 240,
          })
        }
        style={{ objectFit: 'cover' }}
      />
      <Box display="flex" flexDirection="column" rowGap=".5rem">
        {type === 'oneDestination' && (
          <ContentSeeMoreDestination
            links={content.links}
            listTitle={content.listTitle}
            isMobile={isMobile}
          />
        )}

        {type === 'multiDestinations' && (
          <Box p="1rem">
            {destinations?.map(({ links, listTitle }) => (
              <ContentSeeMoreMultiDestination
                links={links}
                listTitle={listTitle}
                isMobile={isMobile}
                key={listTitle}
              />
            ))}
          </Box>
        )}
      </Box>
    </StyledCardContainer>
  );
};

export default memo(CardSeeMoreDestination);
