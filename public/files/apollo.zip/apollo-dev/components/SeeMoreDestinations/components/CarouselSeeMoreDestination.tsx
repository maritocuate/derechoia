import React from 'react';
import NavigateBeforeOutlined from '@mui/icons-material/NavigateBeforeOutlined';
import NavigateNextOutlined from '@mui/icons-material/NavigateNextOutlined';

import { Box, Button, styled } from '@mui/material';
import { useCarouselSeeMoreDestinations } from '../hooks/useCarousel.SeeMoreDestinations';

const StyledContainerMaster = styled(Box)(
  ({ theme }) => `
  position: relative;
  overflow-y: hidden;
  overflow-x: scroll;
  height: 100%;
  width: 100%;
  ::-webkit-scrollbar {
    display: none;
  }
  ${theme.breakpoints.up('lg')}{
    width: 75rem;
  }
`,
);

const StyledButtons = styled(Button)`
  display: flex;
  cursor: pointer;
  width: fit-content;
  height: fit-content;
  padding: 0;
  min-width: auto;
`;

const CarouselSeeMoreDestination = ({
  children,
  isMobile,
}: {
  children: React.ReactNode;
  isMobile: boolean;
}) => {
  const {
    containerRef,
    prevSlide,
    nextSlide,
    handleDragEnd,
    handleDragStart,
    buttonState,
  } = useCarouselSeeMoreDestinations();
  return (
    <>
      {!isMobile && (
        <StyledButtons
          onClick={prevSlide}
          disabled={buttonState.prev}
          color="inherit"
        >
          <NavigateBeforeOutlined fontSize="large" />
        </StyledButtons>
      )}
      {isMobile && (
        <StyledContainerMaster draggable ref={containerRef}>
          {children}
        </StyledContainerMaster>
      )}
      {!isMobile && (
        <StyledContainerMaster
          onTouchStart={handleDragStart}
          onTouchEnd={handleDragEnd}
          ref={containerRef}
        >
          {children}
        </StyledContainerMaster>
      )}
      {!isMobile && (
        <StyledButtons
          onClick={nextSlide}
          disabled={buttonState.next}
          color="inherit"
        >
          <NavigateNextOutlined fontSize="large" />
        </StyledButtons>
      )}
    </>
  );
};

export default CarouselSeeMoreDestination;
