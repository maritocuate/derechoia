import { useCallback, useRef, useState } from 'react';

export const useCarouselSeeMoreDestinations = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const dragStartX = useRef(0);
  const [buttonState, setButtonState] = useState({ prev: true, next: false });

  // Resto de tu lógica para el carrusel...

  const handleScroll = useCallback((disable: 'prev' | 'next') => {
    if (containerRef.current) {
      setButtonState({
        prev: disable === 'prev',
        next: disable === 'next',
      });
    }
  }, []);
  const nextSlide = useCallback(() => {
    if (containerRef.current) {
      const container = containerRef.current;
      const childWidth = container.offsetWidth; // Ancho de cada slide

      container.scrollTo({
        left: container.scrollLeft + childWidth,
        behavior: 'smooth',
      });
      handleScroll('next');
    }
  }, [handleScroll]);

  const prevSlide = useCallback(() => {
    if (containerRef.current) {
      const container = containerRef.current;
      const childWidth = container.offsetWidth; // Ancho de cada slide
      container.scrollTo({
        left: container.scrollLeft - childWidth,
        behavior: 'smooth',
      });
      handleScroll('prev');
    }
  }, [handleScroll]);

  const handleDragStart = useCallback((event: React.TouchEvent) => {
    dragStartX.current = event.touches[0].clientX;
  }, []);
  const handleDragEnd = useCallback(
    (event: React.TouchEvent) => {
      const dragEndX = event.changedTouches[0].clientX;
      const deltaX = dragEndX - dragStartX.current;
      if (deltaX > 50) {
        prevSlide();
      } else if (deltaX < -50) {
        nextSlide();
      }
    },
    [nextSlide, prevSlide],
  );
  return {
    handleDragStart,
    handleDragEnd,
    prevSlide,
    nextSlide,
    containerRef,
    handleScroll,
    buttonState,
  };
};
