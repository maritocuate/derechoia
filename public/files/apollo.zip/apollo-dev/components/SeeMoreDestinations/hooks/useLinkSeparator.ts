import { useEffect, useRef } from 'react';

function areOnTheSameRow(link1: HTMLAnchorElement, link2: HTMLAnchorElement) {
  return link1.offsetTop === link2.offsetTop;
}

export const useLinkSeparator = (paddingTop = '8px') => {
  const containerRef = useRef<HTMLAnchorElement>(null);
  useEffect(() => {
    const container = containerRef.current;

    if (container !== null) {
      const links = Array.from(container.querySelectorAll('a'));
      for (let i = 0; i < links.length; i += 1) {
        for (let j = i + 1; j < links.length; j += 1) {
          if (!links[j] || !links[i]) return;
          if (areOnTheSameRow(links[i], links[j])) {
            // Verificar si ya hay un separador presente
            const { previousSibling } = links[j];
            if (
              !previousSibling ||
              (previousSibling.textContent &&
                previousSibling.textContent.trim() !== '|')
            ) {
              const { parentNode } = links[i];
              if (parentNode) {
                const separador = document.createElement('span');
                separador.textContent = '|';
                separador.style.marginRight = '12px';
                separador.style.paddingTop = paddingTop;
                separador.style.fontSize = '0.875rem';
                separador.style.lineHeight = '143%';

                parentNode.insertBefore(separador, links[j]);
              }
            }
          }
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return containerRef;
};
