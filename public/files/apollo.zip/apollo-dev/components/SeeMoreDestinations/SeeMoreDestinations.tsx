import React from 'react';
import { Box, styled } from '@mui/material';
import DestinationsList from './DestinationsList.json';
import CardSeeMoreDestination from './components/CardSeeMoreDestination';
import { SeeMoreDestinationProps } from './SeeMoreDestinations.type';
import CarouselSeeMoreDestination from './components/CarouselSeeMoreDestination';

const StyledMasterContainer = styled(Box)(
  ({ theme }) => `
  display: flex;
  column-gap: 1.5rem;
  position: absolute;
  padding-left: 1rem;
  padding-right: 1rem;
  user-select: none;
  ${theme.breakpoints.up('lg')} {
    padding-left: 0;
    padding-right: 0;
    column-gap: 1.5rem;
  }
`,
);

const SeeMoreDestinations = ({ isMobile }: { isMobile: boolean }) => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        position: 'relative',
        top: 0,
        height: isMobile ? '325px' : '240px',
        alignItems: 'center',
      }}
    >
      <CarouselSeeMoreDestination isMobile={isMobile}>
        <StyledMasterContainer>
          {DestinationsList.map(
            ({ links, listTitle, destinations, type, image }, index) => {
              return (
                <CardSeeMoreDestination
                  content={{
                    listTitle: listTitle || '',
                    links: links || [],
                    image: { src: image.src, alt: image.alt },
                  }}
                  type={type as SeeMoreDestinationProps['type']}
                  destinations={
                    destinations as SeeMoreDestinationProps['destinations']
                  }
                  isMobile={isMobile}
                  key={`${index}-{listTitle}`}
                />
              );
            },
          )}
        </StyledMasterContainer>
      </CarouselSeeMoreDestination>
    </div>
  );
};

export default SeeMoreDestinations;
