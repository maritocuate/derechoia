export interface ContentProps {
  listTitle: string;
  links: { title: string; href: string }[];
  image: { src: string; alt: string };
}

export type ContentSeeMoreDestinationProps = Omit<ContentProps, 'image'> & {
  isMobile: boolean;
};

export interface SeeMoreDestinationProps {
  content: ContentProps;
  type: 'multiDestinations' | 'oneDestination';
  destinations: ContentSeeMoreDestinationProps[] | undefined;
  isMobile: boolean;
}
