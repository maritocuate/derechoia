import { DateRange } from '@mui/lab';
import { Dayjs } from 'dayjs';

export interface IModalCalendarMobile {
  startDate: string | null;
  endDate: string | null;
  openCalendar: boolean;
  setOpenCalendar: (newvalue: boolean) => void;
  onChange: (e: DateRange<Dayjs>) => void;
  blockedDays: string[] | [];
  handleClose?: () => void;
}
