import { Dialog, DialogContent, styled } from '@mui/material';

export const StyledDialog = styled(Dialog)`
  z-index: 9999;
  & .MuiPaper-root {
    padding: 0;
    width: 100%;
    background-color: #fff;
    position: fixed;
    margin: 0;
    bottom: 0;
    left: 0;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    box-shadow: 0px -1px 12px -4px rgba(0, 0, 0, 0.25);
    z-index: 9999;
  }
`;

export const StyledDialogContent = styled(DialogContent)`
  display: flex;
  flex-direction: column;
  align-self: center;
  justify-content: center;
`;
