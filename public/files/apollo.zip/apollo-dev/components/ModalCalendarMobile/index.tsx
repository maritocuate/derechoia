import React, { memo } from 'react';

import dynamic from 'next/dynamic';
import { Box, IconButton, styled, Typography } from '@mui/material';
import Calendar from '@alquiler-argentina/demiurgo/components/Calendar';
import dayjs from 'dayjs';
import CloseOutlined from '@mui/icons-material/CloseOutlined';
import { LicenseInfo } from '@mui/x-date-pickers-pro';
import { IModalCalendarMobile } from './interfaces';

LicenseInfo.setLicenseKey(String(process.env.NEXT_PUBLIC_CALENDAR_KEY));

const StyledDialog = dynamic(
  () => import('./styles').then((res) => res.StyledDialog),
  { ssr: false },
);
const StyledDialogContent = dynamic(
  () => import('./styles').then((res) => res.StyledDialogContent),
  {
    ssr: false,
  },
);

dayjs.locale('es');

const StyledTitleContainer = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
`;

function ModalCalendarMobile({
  openCalendar,
  startDate,
  endDate,
  setOpenCalendar,
  onChange,
  blockedDays,
  handleClose,
}: IModalCalendarMobile) {
  const hasDates = startDate && endDate;

  return (
    <StyledDialog onClose={handleClose} open={openCalendar}>
      <StyledTitleContainer>
        <Typography variant="modalTitle">
          Seleccioná las fechas de tu estadía
        </Typography>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseOutlined fontSize="medium" />
        </IconButton>
      </StyledTitleContainer>
      <StyledDialogContent
        sx={{ marginBottom: '.1rem', paddingBottom: hasDates ? '4.5rem' : 0 }}
      >
        {openCalendar && (
          <Calendar
            startDate={dayjs(startDate)}
            endDate={dayjs(endDate)}
            handleClose={setOpenCalendar}
            blockedDays={blockedDays}
            onChange={onChange}
            actions={[
              `${
                startDate && endDate && startDate !== endDate
                  ? 'accept'
                  : 'disabled'
              }`,
            ]}
          />
        )}
      </StyledDialogContent>
    </StyledDialog>
  );
}

export default memo(ModalCalendarMobile);
