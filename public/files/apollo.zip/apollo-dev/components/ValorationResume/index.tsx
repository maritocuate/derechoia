import React, { useMemo } from 'react';
import Ratings from '@alquiler-argentina/demiurgo/components/Rating';
import { Typography, Progress } from '@alquiler-argentina/demiurgo';
import { linearProgressClasses } from '@mui/material/LinearProgress';
import { Grid, styled, Box } from '@mui/material';
import { useTranslation } from 'next-i18next';
import { IValoration } from '../../types/valoration.type';
import getTotalValoration from '../../utils/helpers/totalValoration';

export interface IValorationResume {
  ratingsData: IValoration[];
  valorationTotal: number;
}

const StyledProgressContainer = styled(Grid)`
  padding-right: 10px;
  margin: auto auto auto 0;
  @media (max-width: 450px) {
    max-width: 70%;
    position: relative;
    left: 30px;
  }
`;

const StyledProgress = styled(Progress)(
  ({ theme }) => `
  width: 100%;
  ${theme.breakpoints.up('sm')}{
    width: 37%;
  }
  border-radius: 5px;
  height: 8px;
  background: rgba(0, 0, 0, 0.1);
  & .${linearProgressClasses.bar} {
    border-radius: 5px;
    background: #ffb400;
  }
`,
);

const StyledGrid = styled(Grid)`
  text-align: center;
  @media (max-width: 450px) {
    width: 90px;
  }
`;

const StyledTypography = styled(Typography)`
  @media (max-width: 450px) {
    width: 90px;
  }
`;

export default function ValorationResume({
  ratingsData,
  valorationTotal,
}: IValorationResume) {
  const { t } = useTranslation('valorationResume');
  const quantityByRating: { [key: number]: number } = useMemo(
    () =>
      ratingsData.reduce(
        (acc: { [key: number]: number }, item) => {
          const result = { ...acc };
          result[item.valoracion] += 1;
          return result;
        },
        { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
      ),
    [ratingsData],
  );
  const totalRatings = ratingsData.length;
  const totalValoration = getTotalValoration(valorationTotal);
  return (
    <Grid container flexDirection="row-reverse">
      <StyledProgressContainer item xs={9} md={10}>
        {[5, 4, 3, 2, 1].map((numbers) => (
          <Box key={numbers} display="flex" alignItems="center">
            <Box minWidth={30}>
              <Typography fontWeight={700} variant="body2" textAlign="center">
                {numbers}
              </Typography>
            </Box>
            <Box width="100%">
              <StyledProgress
                shape="linear"
                variant="determinate"
                value={(quantityByRating[numbers] * 100) / totalRatings || 0}
              />
            </Box>
          </Box>
        ))}
      </StyledProgressContainer>
      <StyledGrid item xs={3} md={2}>
        <Grid>
          <Typography fontWeight={900} variant="h3">
            {totalValoration}
          </Typography>
        </Grid>
        <Grid>
          <Ratings
            readOnly
            value={valorationTotal}
            precision={0.1}
            size="small"
          />
        </Grid>
        <Grid>
          <StyledTypography variant="caption">
            {t('title', { count: totalRatings })}
          </StyledTypography>
        </Grid>
      </StyledGrid>
    </Grid>
  );
}
