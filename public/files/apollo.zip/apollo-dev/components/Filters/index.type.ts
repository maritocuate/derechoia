export interface FiltersContainerProps {
  applyFilters?: () => void;
  maxPrice?: number;
  minPrice?: number;
  cyberMondayFilter?: boolean;
}
