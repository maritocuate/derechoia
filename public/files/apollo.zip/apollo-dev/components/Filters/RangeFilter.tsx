import React, { SyntheticEvent, memo, useState } from 'react';
import { Slider } from '@mui/material';

interface IRangeProps {
  initialState?: number | null;
  handleChangeLocation: (
    event: Event | SyntheticEvent<Element, Event>,
    newValue: number | number[],
  ) => void;
}

const RangeFilter = ({ initialState, handleChangeLocation }: IRangeProps) => {
  const [rangeFilterArea, setRangeFilterArea] = useState(initialState || 10);
  return (
    <Slider
      value={rangeFilterArea}
      onChange={(event, value) => setRangeFilterArea(value as number)}
      onChangeCommitted={handleChangeLocation}
      valueLabelDisplay="auto"
      min={1}
      max={100}
    />
  );
};

export default memo(RangeFilter);
