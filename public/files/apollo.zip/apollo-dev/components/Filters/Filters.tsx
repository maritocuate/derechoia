/* eslint-disable @typescript-eslint/indent */
import React, {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  styled,
  Switch,
  Typography,
  Button,
} from '@mui/material';
import Divider from '@alquiler-argentina/demiurgo/components/Divider';
import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import { useSelector, useDispatch } from 'react-redux';
import { useParams } from 'next/navigation';
import ShoppingBagOutlined from '@mui/icons-material/ShoppingBagOutlined';
import {
  propertiesType,
  facilities,
  servicesFilter,
  equipmentFilter,
} from './constant/constants';
import { IStatusListado } from '../../redux/filtersListado/types';
import {
  listadoStatusSlice,
  changeKilometers,
} from '../../redux/filtersListado/slice';
import { changePets } from '../../redux/checkout/slice';
import { useHandleFilters } from './hooks/useFilters';
import { usePageListRouter } from '../../hooks/list/usePageListRouter';
import RoomFilterItem from './components/RoomFilterItem/RoomFilterItem';
import useFilterList from '../../hooks/list/useFIlterList/useFilterList';
import { CheckboxContainerFilter } from './components/CheckboxContainer/CheckboxContainer';
import useIsMobile from '../../hooks/useIsMobile';
import { ICheckoutState } from '../../redux/checkout/types';
import { FiltersContainerProps } from './index.type';
import RangeFilter from './RangeFilter';
import SliderPrices from './components/SliderPrices/SliderPrices';
import { ISearchState } from '../../redux/search/type';

export interface IFilters {
  setFilterApi: (value: string) => void;
  setOpenFilters: (value: boolean) => void;
  locationRange: number;
}

const LabelReservation = styled(Box)`
  display: flex;
  align-items: center;
`;
const SwitchLabelReservation = styled(Box)`
  display: flex;
  align-items: center;
  background-color: rgba(0, 172, 193, 0.08);
  border: 1px solid #00acc1;
  border-radius: 8px;
  padding: 0.75rem 0.563rem;
  justify-content: space-between;
`;

const SwitchLabelCyberMonday = styled(Box)`
  display: flex;
  align-items: center;
  background-color: rgba(63, 148, 237, 0.08);
  border: 1px solid #7d34c4;
  border-radius: 0.5rem;
  padding: 0.75rem 0.563rem;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const BoxContainerCheckbox = styled(FormGroup)`
  margin-left: 0.938rem;
`;

const LabelOffers = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const LabelMinAndMaxRange = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 0.75rem;
`;

const ContainerButtonsFiltersMaster = styled(Box)(
  ({ theme }) => `
  ${theme.breakpoints.up('lg')}{
    position: sticky;
    background: white;
    bottom: 2%;
    z-index: 1;
    width: 20.5rem;
    &:before {
      content: '';
      position: absolute;
      top: -1%;
      left: 0px;
      border-top: 0;
      height: 2px;
      width: 20.438rem;
      background: rgba(128, 128, 128, 0.1);;
      z-index: 1; 
    }
  }
`,
);

const ContainerButtonsFilters = styled(Box)(
  ({ theme }) => `
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  padding: 1rem;
  background-color: #fff;
  gap: 1rem;
  position: fixed;
  bottom: 0;
  box-shadow: 0px 3px 14px 2px rgba(0, 0, 0, 0.1);
  ${theme.breakpoints.up('lg')}{
    position: relative;
    box-shadow: none;
    &:before {
      content: '';
      position: absolute;
      top: 0;
      left: -1px;
      width: 100%;
      border: solid 1px rgba(0, 0, 0, 0.23);
      border-top: 0;
      height: 100%;
      background: #fff;
      border-radius: 0 0 8px 8px;
    }
    &:after {
      content: '';
      position: absolute;
      bottom: -25%;
      left: -1px;
      width: 100%;
      height: 52px;
      background: #fff;
      z-index: -1;
    }
  }
`,
);

const ButtonOutline = styled(Button)`
  text-transform: none;
  border: none;
  padding: 0.5rem 1.375rem;
  font-size: 0.938rem;
  font-weight: 600;
  &:hover {
    border: none;
  }
`;

const ButtonContained = styled(Button)`
  text-transform: none;
  padding: 8px 22px;
  font-size: 0.938rem;
  font-weight: 600;
`;

const LabelStyled = styled(Typography)`
  font-weight: 600;
  font-size: 1rem;
  margin-bottom: 0.625rem;
`;

const Filters = ({
  applyFilters,
  maxPrice,
  minPrice,
  cyberMondayFilter,
}: FiltersContainerProps) => {
  const [searchType, setSearchType] = useState('');
  const params = useParams();
  const { filtersListado, rangePrice, bath, bedroom, rangeLocation } =
    useSelector(
      ({ listadoStatus }: { listadoStatus: IStatusListado }) => listadoStatus,
    );
  const {
    destination: { tipo },
  } = useSelector(({ search }: { search: ISearchState }) => search);
  const { mascotas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const { handleChangeViewFilterList } = useFilterList();
  const [isDisableButton, setIsDisableButton] = useState(false);
  const dispatch = useDispatch();
  const ref = useRef<HTMLDivElement>(null);

  const isMobile = useIsMobile();
  // Filters Globals
  const poolStatusOptions: string[] = [];
  if (filtersListado.pool) poolStatusOptions.push('S');
  if (filtersListado.climatizedPool) poolStatusOptions.push('C');
  const { handleApplyFilters } = usePageListRouter();
  const {
    handleBath,
    handleRooms,
    handleClearFilters,
    handleChangePrices,
    handleChangeLocation,
    handleChangePricesTextField,
  } = useHandleFilters(minPrice || 0, maxPrice || 200000);

  const handleFilters = useCallback(() => {
    if (isDisableButton) return;
    setIsDisableButton(true);
    if (isMobile) {
      handleChangeViewFilterList();
    }
    return handleApplyFilters(() => {
      setIsDisableButton(false);
      dispatch(changeKilometers(rangeLocation));
    });
  }, [
    handleApplyFilters,
    handleChangeViewFilterList,
    isDisableButton,
    isMobile,
    rangeLocation,
    dispatch,
  ]);

  const handleClick = useCallback(() => {
    if (filtersListado.climatizedPool) {
      dispatch(
        listadoStatusSlice.actions.updateFilter({
          filter: 'climatizedPool',
          value: !filtersListado.climatizedPool,
        }),
      );
    }

    dispatch(
      listadoStatusSlice.actions.updateFilter({
        filter: 'pool',
        value: !filtersListado.pool,
      }),
    );
  }, [filtersListado, dispatch]);

  useEffect(() => {
    setSearchType(tipo);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const rangePriceValue = useMemo(() => {
    return rangePrice[1] === 0 && maxPrice && minPrice
      ? [minPrice, maxPrice]
      : rangePrice;
  }, [rangePrice, minPrice, maxPrice]);

  return (
    <Box color="rgba(0, 0, 0, 0.87)">
      <Box display="flex" flexDirection="column" padding="1rem">
        {/* Cyber Monday */}
        {cyberMondayFilter && (
          <SwitchLabelCyberMonday>
            <LabelReservation>
              <ShoppingBagOutlined sx={{ color: '#7D34C4' }} />
              <Typography variant="onlineBookintTitle" marginLeft=".5rem">
                Cyber Monday
              </Typography>
            </LabelReservation>
            <Switch
              sx={{
                '& .MuiSwitch-thumb': {
                  color: filtersListado.previaje ? '#7d34c4' : '#FAFAFA',
                },
                '& .MuiSwitch-track': {
                  backgroundColor: filtersListado.previaje
                    ? '#7d34c4 !important'
                    : '#000000 !important',
                },
                '& .MuiTouchRipple-root ': {
                  color: '#7d34c4',
                },
              }}
              checked={filtersListado.previaje}
              onChange={() => {
                dispatch(
                  listadoStatusSlice.actions.updateFilter({
                    filter: 'previaje',
                    value: !filtersListado.previaje,
                  }),
                );
              }}
            />
          </SwitchLabelCyberMonday>
        )}
        {/* Reserva online */}
        <SwitchLabelReservation>
          <LabelReservation>
            <EventAvailableRoundedIcon color="primary" />
            <Typography variant="onlineBookintTitle" marginLeft=".5rem">
              Reserva online
            </Typography>
          </LabelReservation>
          <Switch
            color="primary"
            checked={filtersListado.reservation}
            onChange={() => {
              dispatch(
                listadoStatusSlice.actions.updateFilter({
                  filter: 'reservation',
                  value: !filtersListado.reservation,
                }),
              );
            }}
          />
        </SwitchLabelReservation>
        {/* Populares */}
        <Box
          display="flex"
          flexDirection="column"
          padding="1.5rem 0 1.5rem 1rem"
          color="rgba(0, 0, 0, 0.87)"
        >
          <LabelStyled variant="body2">Populares</LabelStyled>
          <BoxContainerCheckbox>
            <FormControlLabel
              control={
                <Checkbox
                  checked={filtersListado.pool}
                  onChange={handleClick}
                />
              }
              label="Pileta"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={mascotas}
                  onChange={() => {
                    dispatch(
                      changePets({
                        mascotas: !mascotas,
                      }),
                    );
                  }}
                />
              }
              label="Viajo con mascotas"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={filtersListado.parking}
                  onChange={() => {
                    dispatch(
                      listadoStatusSlice.actions.updateFilter({
                        filter: 'parking',
                        value: !filtersListado.parking,
                      }),
                    );
                  }}
                />
              }
              label="Cochera"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={filtersListado.wifi}
                  onChange={() => {
                    dispatch(
                      listadoStatusSlice.actions.updateFilter({
                        filter: 'wifi',
                        value: !filtersListado.wifi,
                      }),
                    );
                  }}
                />
              }
              label="Wi-Fi"
            />
          </BoxContainerCheckbox>
        </Box>
        <Divider />
        {/* Tipos de propiedades */}
        <CheckboxContainerFilter
          title={propertiesType.title}
          checkboxs={propertiesType.checkboxs}
        />
        <Divider />
        {/* Instalaciones */}
        <CheckboxContainerFilter
          title={facilities.title}
          checkboxs={facilities.checkboxs}
        />
        <Divider />
        {/* baños y habitaciones */}
        <Box padding="1.5rem 1rem">
          <Typography
            variant="body2"
            fontWeight="600"
            fontSize="1rem"
            marginBottom="1rem"
          >
            Cantidad de ambientes
          </Typography>
          <RoomFilterItem
            roomName="Baños"
            roomValue={bath}
            substractOnClick={() => handleBath('subtract')}
            addOnClick={() => handleBath('add')}
          />
          <RoomFilterItem
            roomName="Habitaciones"
            roomValue={bedroom}
            substractOnClick={() => handleRooms('subtract')}
            addOnClick={() => handleRooms('add')}
          />
        </Box>
        <Divider />
        {/* ofertas y previaje */}
        <Box padding="1.5rem 1rem">
          <LabelOffers>
            <Typography variant="body2" fontWeight="600" fontSize="1rem">
              Ofertas
            </Typography>
            <Switch
              color="primary"
              checked={filtersListado.offers}
              onChange={() => {
                dispatch(
                  listadoStatusSlice.actions.updateFilter({
                    filter: 'offers',
                    value: !filtersListado.offers,
                  }),
                );
              }}
            />
          </LabelOffers>
        </Box>
        <Divider />
        <Box padding="1rem">
          <SliderPrices
            rangePriceValue={rangePriceValue}
            handleChangePrices={handleChangePrices}
            handleChangePricesTextField={handleChangePricesTextField}
            minPrice={minPrice || 0}
            maxPrice={maxPrice || 200000}
          />
        </Box>
        <Divider />
        {/* Servicios */}
        <CheckboxContainerFilter
          title={servicesFilter.title}
          checkboxs={servicesFilter.checkboxs}
        />
        <Divider />
        {/* Equipamiento */}
        <CheckboxContainerFilter
          title={equipmentFilter.title}
          checkboxs={equipmentFilter.checkboxs}
        />
        {searchType === 'localidad' && (
          <>
            <Divider />
            {/* Rango de busqueda  */}
            <Box padding="1rem" marginBottom={isMobile ? '4rem' : '0'}>
              <Typography
                variant="body1"
                fontWeight="600"
                fontSize="1rem"
                marginBottom="1rem"
              >
                Distancia de búsqueda
              </Typography>
              <Box
                display="flex"
                flexDirection="column"
                alignItems="center"
                padding="0 .5rem"
              >
                <RangeFilter
                  handleChangeLocation={handleChangeLocation}
                  initialState={rangeLocation}
                  key={rangeLocation}
                />
              </Box>
              <LabelMinAndMaxRange>
                <Typography>1km</Typography>
                <Typography>100km</Typography>
              </LabelMinAndMaxRange>
            </Box>
          </>
        )}
      </Box>

      <ContainerButtonsFiltersMaster>
        <ContainerButtonsFilters ref={ref}>
          <ButtonOutline
            variant="text"
            color="primary"
            onClick={handleClearFilters}
          >
            Borrar filtros
          </ButtonOutline>
          <ButtonContained
            variant="contained"
            color="primary"
            onClick={applyFilters || handleFilters}
            disabled={isDisableButton}
          >
            Aplicar
          </ButtonContained>
        </ContainerButtonsFilters>
      </ContainerButtonsFiltersMaster>
    </Box>
  );
};
export default memo(Filters);
