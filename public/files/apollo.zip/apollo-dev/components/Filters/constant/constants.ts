import { CheckboxContainerFilterProps } from '../components/CheckboxContainer/CheckboxContainer';

const propertiesType: CheckboxContainerFilterProps = {
  title: 'Tipo de alojamiento',
  checkboxs: [
    {
      filter: 'cabinsAndBungalows',
      label: 'Cabañas y bungalows',
    },
    {
      filter: 'housesAndChalets',
      label: 'Casas y chalets',
    },
    {
      filter: 'apartmentsAndDuplexes',
      label: 'Departamentos y dúplex',
    },
    {
      filter: 'hotelsAndResorts',
      label: 'Hoteles y resorts',
    },
    {
      filter: 'apartmentsAndSuites',
      label: 'Aparts y suites',
    },
    {
      filter: 'quintasAndStays',
      label: 'Quintas y estancias',
    },
    /*   {
      filter: 'motorhomes',
      label: 'Motorhomes',
    }, */
  ],
};

const facilities: CheckboxContainerFilterProps = {
  title: 'Instalaciones',
  checkboxs: [
    {
      filter: 'pool',
      label: 'Pileta',
    },
    {
      filter: 'climatizedPool',
      label: 'Pileta climatizada',
    },
    {
      filter: 'parking',
      label: 'Cochera',
    },
  ],
};

const servicesFilter: CheckboxContainerFilterProps = {
  title: 'Servicios',
  checkboxs: [
    {
      filter: 'breakfast',
      label: 'Desayuno',
    },
    {
      filter: 'wifi',
      label: 'Wi-Fi',
    },
    {
      filter: 'periodicCleaning',
      label: 'Limpieza periódica',
    },
    {
      filter: 'wowels',
      label: 'Ropa Blanca',
    },
    {
      filter: 'sheets',
      label: 'Ropa de Cama',
    },
    {
      filter: 'spa',
      label: 'Spa',
    },
    {
      filter: 'gamesForKids',
      label: 'Juegos para niños',
    },
    {
      filter: 'restaurant',
      label: 'Restaurante',
    },
  ],
};

const equipmentFilter: CheckboxContainerFilterProps = {
  title: 'Equipamiento',
  checkboxs: [
    {
      filter: 'airConditioning',
      label: 'Aire acondicionado',
    },
    { filter: 'heating', label: 'Calefacción' },
    {
      filter: 'microwave',
      label: 'Microondas',
    },
    {
      filter: 'tv',
      label: 'Televisor',
    },
    {
      filter: 'laundry',
      label: 'Lavarropa',
    },
    {
      filter: 'peopleWithReducedMobility',
      label: 'Apto para personas con movilidad reducida',
    },
  ],
};

export { propertiesType, facilities, servicesFilter, equipmentFilter };
