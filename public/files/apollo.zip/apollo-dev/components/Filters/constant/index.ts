/* 
_S:I-D-L-T-S-P-J-R
_T:C-D-A-O-H-Q-M
_E:A-C-M-T-L-R
_P:S-N-E-C

*/

export interface IAlphabet {
  [index: string]: string;
}
type TFilterHouses =
  | 'cabinsAndBungalows'
  | 'housesAndChalets'
  | 'apartmentsAndDuplexes'
  | 'motorhomes'
  | 'quintasAndStays'
  | 'hotelsAndResorts'
  | 'apartmentsAndSuites';
interface IFilterHouses {
  [key: string]: TFilterHouses;
}
type TFiltersEquipment =
  | 'airConditioning'
  | 'heating'
  | 'microwave'
  | 'tv'
  | 'laundry'
  | 'peopleWithReducedMobility';
interface ITypesOfEquipment {
  [key: string]: TFiltersEquipment;
}
type TTypesOfServices =
  | 'breakfast'
  | 'wifi'
  | 'periodicCleaning'
  | 'wowels'
  | 'sheets'
  | 'spa'
  | 'gamesForKids'
  | 'restaurant';
interface ITypesOfServices {
  [key: string]: TTypesOfServices;
}
interface ITypePool {
  [key: string]: 'climatizedPool' | 'pool';
}

export type IAllType = ITypesOfEquipment | IFilterHouses | ITypesOfServices;

export type TGeneralFilters =
  | 'rangeLocation'
  | 'bath'
  | 'parking'
  | 'bedroom'
  | 'filterEquipment'
  | 'offers'
  | 'previaje'
  | 'reservation'
  | 'poolStatus'
  | 'filterServices'
  | 'filterHouses'
  | 'rangePrice'
  | 'pets'
  | 'ads'
  | 'multiplesAds'
  | 'district';
export interface IGeneralFilters {
  [key: string]: TGeneralFilters;
}
export type IFiltersTypesValues = {
  filterHouses?: IFilterHouses;
  filterServices?: ITypesOfServices;
  filterEquipment?: ITypesOfEquipment;
  poolStatus?: ITypePool;
};
export type IFilterType =
  | 'filterHouses'
  | 'filterServices'
  | 'filterEquipment'
  | 'poolStatus';
export type IFIlterValueNumber = 'rangeLocation' | 'bath' | 'bedroom';
type AllowedValues = {
  [key: string]: Array<string> | Array<number> | Array<Array<number>>;
};

// OBJECTS
export const allowedValues: AllowedValues = {
  A: [1, 100],
  B: ['1'],
  D: ['1'],
  E: ['A', 'C', 'M', 'T', 'L', 'R'], // A-C-M-T-L-R
  G: ['S'],
  PV: ['P'],
  M: ['T'],
  O: ['1'],
  P: ['S', 'C'], // S-N-E-C
  R: ['M'],
  S: ['I', 'D', 'L', 'T', 'S', 'P', 'J', 'R'], // I-D-L-T-S-P-J-R
  T: ['C', 'D', 'A', 'O', 'H', 'Q', 'M'], // C-D-A-O-H-Q-M-G
  W: [
    [1000, 80000],
    [1000, 80000],
  ],
};

export const filtersTypesValues: IFiltersTypesValues = {
  filterHouses: {
    C: 'housesAndChalets',
    D: 'apartmentsAndDuplexes',
    A: 'cabinsAndBungalows',
    H: 'hotelsAndResorts',
    O: 'apartmentsAndSuites',
    Q: 'quintasAndStays',
    M: 'motorhomes',
  },
  filterServices: {
    I: 'wifi',
    D: 'breakfast',
    L: 'periodicCleaning',
    T: 'wowels',
    S: 'sheets',
    P: 'spa',
    J: 'gamesForKids',
    R: 'restaurant',
  },
  filterEquipment: {
    A: 'airConditioning',
    C: 'heating',
    M: 'microwave',
    T: 'tv',
    L: 'laundry',
    R: 'peopleWithReducedMobility',
  },
  poolStatus: {
    S: 'pool',
    C: 'climatizedPool',
  },
};

export const generalFilters: IGeneralFilters = {
  A: 'rangeLocation',
  B: 'bath',
  D: 'bedroom',
  E: 'filterEquipment',
  G: 'offers',
  PV: 'previaje',
  M: 'reservation',
  O: 'parking',
  P: 'poolStatus',
  S: 'filterServices',
  T: 'filterHouses', //
  W: 'rangePrice', //
  R: 'pets', // mascotas  _R:M
  X: 'ads', // anuncio ej _X:wd40
  Z: 'multiplesAds', // ej _Z: wd40,ls22
};
