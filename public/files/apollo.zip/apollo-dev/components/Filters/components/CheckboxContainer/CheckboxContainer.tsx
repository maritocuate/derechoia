import React, { useCallback } from 'react';
import { FormControlLabel, Checkbox, Box, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { updateFilter } from '../../../../redux/filtersListado/slice';
import {
  FilterList,
  IFilters,
  IStatusListado,
  ITypesOfEquipment,
  ITypesOfHouses,
  ITypesOfServices,
} from '../../../../redux/filtersListado/types';

type FilterTypes =
  | keyof IFilters
  | keyof ITypesOfHouses
  | keyof ITypesOfServices
  | keyof ITypesOfEquipment;

export type NewType = {
  filter: keyof FilterList;
  label: string;
};

export interface CheckboxContainerFilterProps {
  title: string;
  checkboxs: NewType[];
}
interface CheckboxFilterProps {
  value: boolean;
  onChange?: (
    event: React.ChangeEvent<HTMLInputElement>,
    checked: boolean,
  ) => void;
  label: string;
}

const CheckboxFilter = ({ value, onChange, label }: CheckboxFilterProps) => {
  return (
    <FormControlLabel
      control={<Checkbox checked={value} onChange={onChange} />}
      label={label}
    />
  );
};

export const CheckboxContainerFilter = ({
  title,
  checkboxs,
}: CheckboxContainerFilterProps) => {
  const dispatch = useDispatch();
  const { filtersListado } = useSelector(
    ({ listadoStatus }: { listadoStatus: IStatusListado }) => listadoStatus,
  );

  const handleChange = useCallback(
    (filter: FilterTypes) => {
      let conflicting: keyof IFilters | null = null;

      if (filter === 'climatizedPool') conflicting = 'pool';
      else if (filter === 'pool') conflicting = 'climatizedPool';
      else conflicting = null;

      if (conflicting && filtersListado[conflicting]) {
        dispatch(
          updateFilter({
            filter: conflicting,
            value: !filtersListado[conflicting],
          }),
        );
      }

      dispatch(
        updateFilter({
          filter,
          value: !filtersListado[filter],
        }),
      );
    },
    [dispatch, filtersListado],
  );

  return (
    <Box padding="1.5rem 0 1.938rem 1rem" display="flex" flexDirection="column">
      <Typography
        variant="body2"
        fontSize="1rem"
        fontWeight={600}
        marginBottom="1rem"
      >
        {title}
      </Typography>
      <Box display="flex" flexDirection="column" paddingLeft="1rem">
        {checkboxs.map(({ label, filter }) => (
          <CheckboxFilter
            label={label}
            value={!!filtersListado[filter]}
            key={`key-${filter}`}
            onChange={() => handleChange(filter)}
          />
        ))}
      </Box>
    </Box>
  );
};
