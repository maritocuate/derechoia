import React, { memo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import RemoveCircleOutlineOutlinedIcon from '@mui/icons-material/RemoveCircleOutlineOutlined';
import AddCircleOutlineOutlinedIcon from '@mui/icons-material/AddCircleOutlineOutlined';

interface RoomFilterItemProps {
  roomName: string;
  roomValue: number;
  substractOnClick: () => void;
  addOnClick: () => void;
}

const LabelRooms = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0;
  margin-bottom: 1.5rem;
  &:last-child {
    margin-bottom: 0;
  }
`;
const LabelRoomsIcons = styled(Box)`
  display: flex;
  align-items: center;
`;
const StyledRemoveCircleOutlineOutlinedIcon = styled(
  RemoveCircleOutlineOutlinedIcon,
)`
  height: 1.25rem;
  width: 1.25rem;
  cursor: pointer;
`;
const StyledAddCircleOutlineOutlinedIcon = styled(AddCircleOutlineOutlinedIcon)`
  height: 1.25rem;
  width: 1.25rem;
  cursor: pointer;
`;

const RoomFilterItem = ({
  roomName,
  roomValue,
  substractOnClick,
  addOnClick,
}: RoomFilterItemProps) => (
  <LabelRooms>
    <Box>
      <Typography fontSize="1rem" color="inherit">
        {roomName}
      </Typography>
    </Box>
    <LabelRoomsIcons>
      <StyledRemoveCircleOutlineOutlinedIcon
        color="primary"
        onClick={substractOnClick}
      />
      <Box display="flex" width="3.125rem" justifyContent="center">
        <Typography fontSize="1rem" color="inherit">
          {roomValue}
        </Typography>
      </Box>
      <StyledAddCircleOutlineOutlinedIcon
        color="primary"
        onClick={addOnClick}
      />
    </LabelRoomsIcons>
  </LabelRooms>
);
export default memo(RoomFilterItem);
