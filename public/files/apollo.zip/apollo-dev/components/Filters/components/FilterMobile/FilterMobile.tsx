import Modal, {
  VARIANTS as VARIANTS_MODAL,
} from '@alquiler-argentina/demiurgo/components/Modal';
import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import { FiltersContainerProps } from '../../index.type';

const Filters = dynamic(() => import('../../Filters'), { ssr: false });

interface FilterMobileProps extends FiltersContainerProps {
  isOpen: boolean;
  onClose: () => void;
  handleClose: () => void;
}

const FilterMobile = ({
  handleClose,
  isOpen,
  onClose,
  maxPrice,
  applyFilters,
  minPrice,
  cyberMondayFilter,
}: FilterMobileProps) => {
  return (
    <Modal
      variant={VARIANTS_MODAL.MODAL}
      fullScreen
      title="Filtros"
      open={!!isOpen}
      onClose={onClose}
      handleClose={handleClose}
      paddingContent="0"
    >
      <Filters
        minPrice={minPrice}
        maxPrice={maxPrice}
        applyFilters={applyFilters}
        cyberMondayFilter={cyberMondayFilter}
      />
    </Modal>
  );
};

export default memo(FilterMobile);
