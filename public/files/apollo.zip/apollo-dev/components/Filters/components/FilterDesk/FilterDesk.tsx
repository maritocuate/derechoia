import React, { memo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import { FiltersContainerProps } from '../../index.type';
import Filters from '../../Filters';

const StyledFilterContainerDesktop = styled(Box)`
  padding: 1.5rem 1.5rem 0.5rem 2rem;
`;

const StyledTypography = styled(Typography)`
  font-weight: 700;
`;

const StyledBoxContainer = styled(Box)`
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-bottom: 0;
  border-radius: 1rem;
  margin-top: 1.3rem;
`;
const FilterDesk = ({
  minPrice,
  maxPrice,
  applyFilters,
  cyberMondayFilter,
}: FiltersContainerProps) => {
  return (
    <StyledBoxContainer display="flex">
      <Box display="flex" flexDirection="column">
        <StyledFilterContainerDesktop>
          <StyledTypography variant="body2" fontSize="1.25rem">
            Filtros
          </StyledTypography>
        </StyledFilterContainerDesktop>
        <Filters
          cyberMondayFilter={cyberMondayFilter}
          minPrice={minPrice}
          maxPrice={maxPrice}
          applyFilters={applyFilters}
        />
      </Box>
    </StyledBoxContainer>
  );
};

export default memo(FilterDesk);
