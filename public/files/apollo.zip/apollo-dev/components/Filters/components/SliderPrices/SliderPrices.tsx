import { Box, Slider, TextField, Typography, styled } from '@mui/material';
import React, { useState } from 'react';
import {
  formatPriceToArs,
  formatPriceWithDot,
} from '../../../../utils/helpers/formatPriceToArs';

const StyledPriceContainer = styled(Box)(
  ({ theme }) => `
      width: 100%;
      ${theme.breakpoints.up('sm')} {
        width: 14.5rem;
      }
    `,
);

const StyledTextFieldsContainer = styled(Box)`
  display: flex;
  gap: 1rem;
  align-items: center;
  padding-top: 1rem;
  padding-bottom: 1rem;
`;
const StyledTextField = styled(TextField)`
  & .MuiInputBase-root {
    padding-left: 0.5rem;
  }
  & .MuiOutlinedInput-input {
    padding-right: 0;
  }
`;
const LabelMinAndMaxRange = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 0.75rem;
`;

interface ISlider {
  rangePriceValue: number[];
  handleChangePrices: (event: Event, newValue: number | number[]) => void;
  handleChangePricesTextField: (index: number, value: string) => void;
  maxPrice: number;
  minPrice: number;
}

const SliderPrices = ({
  rangePriceValue,
  handleChangePrices,
  handleChangePricesTextField,
  maxPrice,
  minPrice,
}: ISlider) => {
  const [typingValue, setTypingValue] = useState({ min: '', max: '' });
  const [isTyping, setIsTyping] = useState({ min: false, max: false });

  const handleChange = (index: number, value: string) => {
    if (index === 0) {
      setIsTyping({ min: true, max: false });
      setTypingValue({ min: value, max: typingValue.max });
    } else {
      setIsTyping({ min: false, max: true });
      setTypingValue({ max: value, min: typingValue.min });
    }
  };

  const handleBlur = (index: number) => {
    if (index === 0) {
      setIsTyping({ min: false, max: false });
      const numericValue = typingValue.min.replace(/\./g, '');
      if (
        !Number(numericValue) ||
        Number(numericValue) < minPrice ||
        Number(numericValue) > maxPrice
      ) {
        handleChangePricesTextField(index, String(minPrice));
      } else {
        handleChangePricesTextField(index, numericValue);
      }
    } else {
      setIsTyping({ min: false, max: false });
      const numericValue = typingValue.max.replace(/\./g, '');
      if (
        !Number(numericValue) ||
        Number(numericValue) > maxPrice ||
        Number(numericValue) < minPrice
      ) {
        handleChangePricesTextField(index, String(maxPrice));
      } else {
        handleChangePricesTextField(index, numericValue);
      }
    }
  };

  const handleInputChange = (index: number, value: string) => {
    const formatedValue = value.replace(/\./g, '');
    if (/^\d*$/.test(formatedValue)) {
      handleChange(index, formatedValue);
    }
  };

  return (
    <Box>
      <Typography
        variant="body2"
        fontWeight="600"
        fontSize="1rem"
        marginBottom="1rem"
      >
        Rango de precios (por noche)
      </Typography>
      <StyledPriceContainer>
        <StyledTextFieldsContainer>
          <Box>
            <StyledTextField
              size="small"
              label="Mínimo"
              value={
                isTyping.min
                  ? typingValue.min
                  : formatPriceWithDot(rangePriceValue[0])
              }
              onChange={(event) => handleInputChange(0, event.target.value)}
              onBlur={() => handleBlur(0)}
              InputProps={{
                startAdornment: <Typography>$</Typography>,
              }}
            />
          </Box>
          <Box>
            <StyledTextField
              size="small"
              label="Máximo"
              value={
                isTyping.max
                  ? typingValue.max
                  : formatPriceWithDot(rangePriceValue[1])
              }
              onChange={(event) => handleInputChange(1, event.target.value)}
              onBlur={() => handleBlur(1)}
              InputProps={{
                startAdornment: <Typography>$</Typography>,
              }}
            />
          </Box>
        </StyledTextFieldsContainer>
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          padding="0 .5rem"
        >
          <Slider
            value={rangePriceValue}
            onChange={handleChangePrices}
            valueLabelDisplay="auto"
            min={minPrice}
            max={maxPrice}
            step={1000}
            valueLabelFormat={formatPriceToArs}
          />
        </Box>
        <LabelMinAndMaxRange>
          <Typography>{formatPriceToArs(minPrice)}</Typography>
          <Typography>{formatPriceToArs(maxPrice)}</Typography>
        </LabelMinAndMaxRange>
      </StyledPriceContainer>
    </Box>
  );
};

export default SliderPrices;
