import { useDispatch, useSelector } from 'react-redux';
import { SyntheticEvent, useCallback } from 'react';
import {
  changeBath,
  changeRooms,
  deleteAllFilters,
  setLocationRange,
  setPriceRange,
} from '../../../redux/filtersListado/slice';
import { IStatusListado } from '../../../redux/filtersListado/types';
import { changePets } from '../../../redux/checkout/slice';

export const useHandleFilters = (minPrice: number, maxPrice: number) => {
  const dispatch = useDispatch();
  const { bath, bedroom, rangePrice } = useSelector(
    ({ listadoStatus }: { listadoStatus: IStatusListado }) => listadoStatus,
  );
  const handleBath = (operacion: string) => {
    if (operacion === 'add') {
      dispatch(
        changeBath({
          bath: bath + 1,
        }),
      );
    } else if (operacion === 'subtract' && bath > 0) {
      dispatch(
        changeBath({
          bath: bath - 1,
        }),
      );
    }
  };

  const handleRooms = (operacion: string) => {
    if (operacion === 'add') {
      dispatch(
        changeRooms({
          bedroom: bedroom + 1,
        }),
      );
    } else if (operacion === 'subtract' && bedroom > 0) {
      dispatch(
        changeRooms({
          bedroom: bedroom - 1,
        }),
      );
    }
  };

  const handleChangeLocation = (
    event: Event | SyntheticEvent<Element, Event>,
    newValue: number | number[],
  ) => {
    dispatch(setLocationRange(newValue as number));
  };

  const handleChangePrices = (event: Event, newValue: number | number[]) => {
    dispatch(setPriceRange(newValue as number[]));
  };

  const handleChangePricesTextField = (index: number, value: string) => {
    if ((!value || Number(value) > rangePrice[1]) && index === 0) {
      dispatch(setPriceRange([0, rangePrice[1]]));
      return;
    }
    if (
      (!value || Number(value) < rangePrice[0] || Number(value) > maxPrice) &&
      index === 1
    ) {
      dispatch(setPriceRange([rangePrice[0], maxPrice]));
      return;
    }
    const newValue = [...rangePrice];
    newValue[index] = parseFloat(value);
    dispatch(setPriceRange(newValue));
  };

  // Button Clear
  const handleClearFilters = useCallback(() => {
    dispatch(deleteAllFilters());
    dispatch(changePets({ mascotas: false }));
  }, [dispatch]);

  const handleScrollUp = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  return {
    handleBath,
    handleRooms,
    handleScrollUp,
    handleClearFilters,
    handleChangePrices,
    handleChangeLocation,
    handleChangePricesTextField,
  };
};
