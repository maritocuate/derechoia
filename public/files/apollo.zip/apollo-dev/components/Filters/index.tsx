import { Box } from '@mui/material';
import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import useIsMobile from '../../hooks/useIsMobile';
import useFilterList from '../../hooks/list/useFIlterList/useFilterList';
import { FiltersContainerProps } from './index.type';

const FilterMobile = dynamic(
  () => import('./components/FilterMobile/FilterMobile'),
  { ssr: true },
);

const FilterDesk = dynamic(() => import('./components/FilterDesk/FilterDesk'));

const FilterContainer = ({
  applyFilters,
  maxPrice,
  minPrice,
  cyberMondayFilter,
}: FiltersContainerProps) => {
  const { isFilterOpen, handleChangeViewFilterList } = useFilterList();
  const isMobile = useIsMobile();
  return (
    <Box>
      {!isMobile ? (
        <FilterDesk
          minPrice={minPrice}
          maxPrice={maxPrice}
          applyFilters={applyFilters}
          cyberMondayFilter={cyberMondayFilter}
        />
      ) : (
        <FilterMobile
          isOpen={isFilterOpen}
          onClose={handleChangeViewFilterList}
          handleClose={handleChangeViewFilterList}
          minPrice={minPrice}
          maxPrice={maxPrice}
          applyFilters={applyFilters}
          cyberMondayFilter={cyberMondayFilter}
        />
      )}
    </Box>
  );
};
export default memo(FilterContainer);
