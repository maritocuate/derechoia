import { Grid } from '@mui/material';
import React, { memo, useMemo } from 'react';
import HeaderAnuncio from '../HeaderAnuncio';
import PopoverShare from '../PopoverShare';
import useHandePopoverShare from '../PopoverShare/hooks/useHandlePopoverShare';
import { useGetPropiedadQuery } from '../../services/propiedades';

const HeaderAdDesk = ({
  referencia,
  open,
  isFavorite,
  isLoadingFav,
  testProperty,
  cyberMonday,
  setOpen,
  onClickFavorite,
}: {
  referencia: string;
  open: boolean;
  isFavorite?: boolean;
  isLoadingFav?: boolean;
  testProperty?: boolean;
  cyberMonday?: boolean;
  setOpen: (open: boolean) => void;
  onClickFavorite: () => void;
}) => {
  const { data } = useGetPropiedadQuery(
    { referencia, test: testProperty },
    { skip: !referencia },
  );
  const headerProps = useMemo(() => {
    if (!data) return null;
    return data?.formatedData?.headerAdData;
  }, [data]);
  const { isOpenPopover, anchorEl, handlePopoverOpen, handlePopoverClose } =
    useHandePopoverShare();

  return (
    <Grid xs={12} item component="article" position="relative">
      {headerProps && (
        <HeaderAnuncio
          imagesTypologys={headerProps?.photosTypologies}
          imagesArray={headerProps?.arrayImagesFinal}
          featuredImage={headerProps?.featuredImage}
          BreadcrumsLocation={
            data?.formatedData?.locationData?.placeExistsInArgentina || null
          }
          title={headerProps?.title}
          average={Number(headerProps?.average)}
          href={headerProps?.href}
          total={headerProps?.total}
          mobileShare={handlePopoverOpen}
          addFavorite={onClickFavorite}
          isLoadingFav={isLoadingFav}
          isFavorite={isFavorite}
          video={headerProps?.video}
          iframe={headerProps?.iframe}
          isOpenPopover={isOpenPopover}
          dateCreated={headerProps?.dateCreated}
          open={open}
          setOpen={setOpen}
          cyberMonday={cyberMonday}
        />
      )}
      {isOpenPopover && (
        <PopoverShare
          open={isOpenPopover}
          anchorEl={anchorEl}
          onClose={() => handlePopoverClose()}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
        />
      )}
    </Grid>
  );
};

export default memo(HeaderAdDesk);
