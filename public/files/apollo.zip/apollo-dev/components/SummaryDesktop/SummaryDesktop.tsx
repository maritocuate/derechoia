/* eslint-disable arrow-body-style */
import React, { memo, useCallback, useMemo } from 'react';
import { Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import useBookingSummaryDesktop from '../../hooks/alojamientos/useBookingSummaryDesktop';
import BookingSummary from '../BookingSummary';
import { TEventType, sendInquiryGTM } from '../../utils/helpers/sendDataGTM';
import calculateDateRange from '../../utils/helpers/calculateDateRange';
import { handleOpenCalendar } from '../../redux/checkout/slice';
import { IFichaSecondCharge } from '../../redux/ficha/types';

const SummaryDesktop = ({
  referencia,
  openCheckoutSIC,
  testProperty,
  setOpenCheckoutSic,
}: {
  referencia: string;
  openCheckoutSIC: boolean;
  testProperty?: boolean;
  setOpenCheckoutSic: (value: boolean) => void;
}) => {
  const dispatch = useDispatch();
  const {
    data,
    startDate,
    endDate,
    selectedDiscount,
    selectedPrice,
    activa,
    isAllBlocked,
    lastBlockedMessage,
    persons,
    handleChangePersons,
    allowPets,
    maxPeopleAllowed,
    propiedades,
    hostWhatsAppNumber,
    totalDays,
    phoneList,
    bookingContactName,
    bookingHasEmail,
    bookingTitle,
    bookingReference,
    bookingIsSIC,
    bookingIsSIRO,
    bookingMinimalPrice,
    startDateFormated,
    endDateFormated,
    bookingCleaningFee,
    bookingOtherFee,
    bookingSenia,
  } = useBookingSummaryDesktop(referencia, testProperty);

  const { selectedTipology, bookingData } = useSelector(
    ({ fichaSecondCharge }: { fichaSecondCharge: IFichaSecondCharge }) =>
      fichaSecondCharge,
  );

  const setOpenCalendar = useCallback(
    (newState: boolean) => {
      dispatch(handleOpenCalendar({ isOpenCalendar: newState }));
    },
    [dispatch],
  );

  const totalPrice = useMemo(() => {
    return totalDays !== 0 && selectedPrice
      ? selectedPrice * totalDays
      : selectedPrice;
  }, [selectedPrice, totalDays]);

  const handleSendInquiryGTM = useCallback(
    (eventType: TEventType) => {
      const bookedDays =
        startDate && endDate ? calculateDateRange(startDate, endDate) : null;

      const inquiry = {
        startDate,
        endDate,
        bookedDays,
        adults: persons.adults,
        youngAdults: null,
        teens: null,
        children: persons.children,
        babies: persons.babies,
        pets: persons.mascotas,
        totalPeople: persons.total,
        tipologyId: selectedTipology?.id ? selectedTipology?.id : null,
        minCapacity: selectedTipology ? selectedTipology.capacidad_min : null,
        maxCapacity: selectedTipology ? selectedTipology.capacidad_max : null,
        bathrooms: selectedTipology ? selectedTipology.banios : null,
        rooms: selectedTipology ? selectedTipology.dormitorios : null,
      };

      if (data) {
        sendInquiryGTM({
          eventType,
          acommodationGeneralData: data,
          inquiryGeneralData: inquiry,
        });
      }
    },
    [startDate, endDate, persons, selectedTipology, data],
  );

  return (
    <Grid item container>
      <BookingSummary
        blockedMessage={lastBlockedMessage}
        blocked={isAllBlocked}
        selectedDiscount={selectedDiscount}
        idTipologia={selectedTipology?.id}
        dataOcupaciones={propiedades}
        persons={persons}
        guests={persons.total}
        active={activa}
        changeProps={handleChangePersons}
        setOpenCalendar={setOpenCalendar}
        openCheckoutSIC={openCheckoutSIC}
        setOpenCheckoutSic={setOpenCheckoutSic}
        whatsappNumber={hostWhatsAppNumber}
        totalDays={totalDays}
        isImmediate={
          !!data?.aceptacion_inmediata || data?.cm_integrated != null
        }
        // esta llegando el precio con el descuento ya aplicado
        basePrice={selectedPrice}
        telefonos={phoneList}
        emailPropietario={!!bookingHasEmail}
        name={bookingContactName}
        title={bookingTitle}
        unidad={selectedTipology?.nombre_tipologia}
        referencia={bookingReference || ''}
        isSIC={!!bookingIsSIC}
        isSIRO={bookingIsSIRO}
        // esta llegando el precio con el descuento ya aplicado
        price={totalPrice || bookingMinimalPrice}
        startDate={startDateFormated || null}
        endDate={endDateFormated || null}
        cleaningFee={bookingCleaningFee}
        cargoExtra={bookingOtherFee}
        porcentajeSenia={bookingSenia}
        dayValueDiffers
        pets={allowPets}
        gtm={handleSendInquiryGTM}
        peopleMax={maxPeopleAllowed}
        location={
          data?.formatedData?.locationData?.placeExistsInArgentina
            ? data?.formatedData?.locationData?.placeExistsInArgentina
            : null
        }
        hasPhoneNumber={bookingData?.hasPhoneNumber}
        hasWhatsapp={bookingData?.hasWhatsapp}
        isFeatured={data?.es_destacado}
        testProperty={testProperty || false}
        isGold={data?.es_destacado_gold}
        cyberMondayDiscount={data?.porcentaje_oferta}
      />
    </Grid>
  );
};

export default memo(SummaryDesktop);
