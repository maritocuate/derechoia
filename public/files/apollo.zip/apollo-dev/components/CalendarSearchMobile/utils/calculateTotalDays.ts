import dayjs from 'dayjs';

export const calculateTotalDays = (
  startDate?: string | null,
  endDate?: string | null,
) => {
  const startDateCalc = dayjs(startDate || '');
  const endDateCalc = dayjs(endDate || '');
  const difference = endDateCalc.diff(startDateCalc);
  return Math.ceil(difference / (1000 * 3600 * 24));
};
