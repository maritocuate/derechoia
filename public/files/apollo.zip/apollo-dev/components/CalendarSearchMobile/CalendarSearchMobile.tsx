import dynamic from 'next/dynamic';
import dayjs, { Dayjs } from 'dayjs';
import 'dayjs/locale/es';
import React, { memo, useMemo } from 'react';
import type { DateRange } from '@mui/lab';
import Box from '@mui/material/Box';
import ItemContainer from '../Search/components/ItemContainer/ItemContainer';
import { StyledTypographyInput } from '../Search/components/StyledTypographyInput/StyledTypographyInput';

dayjs.locale('es');

const ModalCalendarMobile = dynamic(() => import('../ModalCalendarMobile'), {
  ssr: false,
});

const Tooltip = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/Tooltip').then(
      (mod) => mod.default,
    ),
  { ssr: true },
);

interface CalendarSearchProps {
  isDisable: boolean;
  isOpenCalendar: boolean;
  startDate: string | null;
  endDate: string | null;
  onClickOpenCalendar: (boolean: boolean) => void;
  handleChangeDates: (dates: DateRange<Dayjs>) => void;
  onClose: () => void;
  tooltip?: boolean;
}

const CalendarSearchMobile = memo(
  ({
    isDisable,
    isOpenCalendar,
    startDate,
    endDate,
    onClickOpenCalendar,
    handleChangeDates,
    onClose,
    tooltip,
  }: CalendarSearchProps) => {
    const dateText = useMemo(() => {
      if (!startDate && !endDate) return 'Elegir fechas';
      const startDateText = startDate
        ? dayjs(startDate).format('D MMM')
        : 'Elegir Fecha';

      const endDateText = endDate
        ? dayjs(endDate).format('D MMM')
        : 'Elegir Fecha';

      return `${startDateText} - ${endDateText} `;
    }, [endDate, startDate]);

    return (
      <>
        <Tooltip
          title="Elegí las fechas de llegada y de salida para ver el precio exacto"
          open={tooltip}
          arrow
          variant="secondary"
          placement="bottom-start"
          PopperProps={{
            sx: {
              width: '8.75rem !important',
              textAlign: 'left',
              fontWeight: 500,
            },
          }}
          sx={{
            '& .MuiTooltip-tooltip': { mt: '0.25rem !important' },
            zIndex: '12',
          }}
        >
          <Box>
            <ItemContainer
              label="Estadia"
              borderPosition="right"
              onClick={() => {
                onClickOpenCalendar(true);
              }}
            >
              <StyledTypographyInput
                color={isDisable ? 'rgba(0, 0, 0, .6)' : undefined}
              >
                {dateText}
              </StyledTypographyInput>
            </ItemContainer>
          </Box>
        </Tooltip>
        {isOpenCalendar && (
          <ModalCalendarMobile
            openCalendar={isOpenCalendar}
            startDate={startDate}
            endDate={endDate}
            setOpenCalendar={onClickOpenCalendar}
            onChange={handleChangeDates}
            blockedDays={[]}
            handleClose={() => {
              onClickOpenCalendar(false);
              onClose();
            }}
          />
        )}
      </>
    );
  },
);

export default memo(CalendarSearchMobile);
