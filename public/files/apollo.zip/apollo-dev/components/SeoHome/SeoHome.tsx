import React from 'react';
import Head from 'next/head';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';

const SeoHome = () => {
  return (
    <Head>
      <meta
        name="title"
        content="Alquileres Temporarios en Argentina - AlquilerArgentina"
      />
      <meta
        name="description"
        content="Alquiler temporario en Argentina. Encontrá los mejores alquileres temporarios para tus vacaciones: casas, departamentos, cabañas, complejos y más!"
      />
      <meta
        name="keywords"
        content="argentina, alquiler, alquileres, alojamiento, turismo, alojamientos, casas, departamentos, cabañas, complejos, apart, alquiler en argentina, alquilerargentina"
      />
      <link rel="canonical" href="https://www.alquilerargentina.com" />
      <link
        rel="shortcut icon"
        href="https://www.alquilerargentina.com/imagenes/favicon.png"
        type="image/png"
      />
      <meta property="og:image" content={formatUrlWithCdnLink('/logoaa.png')} />
      <meta property="og:url" content="https://www.alquilerargentina.com/" />
      <title>Alquileres Temporarios en Argentina - AlquilerArgentina</title>
    </Head>
  );
};

export default SeoHome;
