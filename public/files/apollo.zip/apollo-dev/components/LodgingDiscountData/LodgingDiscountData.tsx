/* eslint-disable @typescript-eslint/indent */
import React, { memo, useState } from 'react';
import {
  Box,
  Grid,
  styled,
  useMediaQuery,
  useTheme,
  ClickAwayListener,
} from '@mui/material';
import { SelectPeople, Typography } from '@alquiler-argentina/demiurgo';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { LoadingButton } from '@mui/lab';
import Link from 'next/link';
import HostProfile from '../HostProfile';
import LodgingAmenities from '../LodgingAmenities/LodgingAmenities';
import { useGetPropiedadQuery } from '../../services/propiedades';
import useFormatAmenities from '../LodgingData/hooks/useFormatAmenities';
import SummaryMobile from '../SummaryMobile/SummaryMobile';
import BookingDiscountTipologiesList from '../BookingDiscountTipologiesList/BookingDiscountTipologiesList';
import SummaryDiscountDesktop from '../SummaryDiscountDesktop/SummaryDiscountDesktop';
import { ICheckoutState } from '../../redux/checkout/types';
import { changeInput, setErrorInput } from '../../redux/checkout/slice';
import UserFormDiscount from '../UserFormDiscount/UserFormDiscount';
import CheckoutDiscount from '../CheckoutDiscount/CheckoutDiscount';
import { DiscountDataProps } from '../../types/common.types';
import { usePostCheckoutMutation } from '../../services/checkout';

const SummaryReserveData = styled(Grid)`
  display: flex;
  width: 21rem;
`;

const StyledSelectPeople = styled('div')`
  width: 95%;
  position: absolute;
  z-index: 1;
  right: 1.625rem;
  top: 1.5rem;
`;

const ContactButtonLoading = styled(LoadingButton)(
  ({ theme }) => `
    width: 100%;
    text-transform: none;
    font-weight: 600;
    margin-bottom: 5rem;
    ${theme.breakpoints.up('lg')} {
      width: 25rem;
    }
  `,
);
const StyledLink = styled(Link)`
  text-decoration: underline;
`;

interface IPaymentMethod {
  value: 'cupon' | 'tarjeta' | 'transferencia';
  label: string;
  idPayment: 1 | 2 | 3 | 4;
}

const LodgingDiscountData = ({
  referencia,
  testProperty,
  setOpenCalendar,
  discountData,
}: {
  referencia: string;
  testProperty?: boolean;
  setOpenCalendar: (value: boolean) => void;
  discountData?: DiscountDataProps;
}) => {
  const [openButtonLoading, setOpenButtonLoading] = useState(false);
  const [sendReservations] = usePostCheckoutMutation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { data } = useGetPropiedadQuery(
    { referencia, test: testProperty },
    { skip: !referencia },
  );
  const router = useRouter();
  const fichaLink: string = data?.link || '#';

  const { amenities, dataAmenities } = useFormatAmenities({
    amenities: data?.agregados,
  });

  const personasTest = 1;
  const persons = {
    adults: personasTest,
    children: 0,
    babies: 0,
    total: personasTest,
    mascotas: false,
  };
  const changeProps = () => {};
  const pets = false;
  const peopleMax = 10;
  const dispatch = useDispatch();
  const descuento = discountData?.descuento || 0;

  const [selectPeople, setSelectPeople] = React.useState(false);
  const [openCheckoutSIC, setOpenCheckoutSic] = useState(false);

  const {
    datosPersonales,
    datosPersonales: {
      nombre,
      apellido,
      tipo_identificacion: tipoIdentificacion,
      identificacion,
      email,
      telefono,
    },
    inputError,
    inputError: {
      nombre: errorNombre,
      apellido: errorApellido,
      identificacion: errorIdentificacion,
      tipoIdentificacion: errorTipoIdentificacion,
      email: errorEmail,
      telefono: errorTelefono,
    },
  } = useSelector(({ checkout }: { checkout: ICheckoutState }) => checkout);

  const {
    reserva: {
      startDate,
      endDate,
      typologyId,
      referenciaSaved,
      personas,
      adultos,
      menores,
      bebes,
      mascotas,
      monto,
    },
  } = useSelector(({ checkout }: { checkout: ICheckoutState }) => checkout);

  const dispatchOnChange = ({
    field,
    value,
  }: {
    field: string;
    value: string;
  }) => {
    dispatch(changeInput({ field, value }));
  };
  const dispatchSetError = ({
    field,
    value,
  }: {
    field: string;
    value: boolean;
  }) => {
    dispatch(setErrorInput({ field, value }));
  };

  const { test: testPropertyRouter } = router.query;
  const test = testPropertyRouter === '1';
  const [paymentId, setPaymentId] = useState(0);
  const { isLoading } = useGetPropiedadQuery(
    {
      referencia: referenciaSaved || '',
      test,
    },
    { skip: !referenciaSaved },
  );
  const montoTotal = monto || 0;
  const seña = data?.senia || 0;
  const señaTotal = montoTotal * (seña / 100);
  const paymentMethods: IPaymentMethod[] = [];
  if (data?.transferencia) {
    paymentMethods.push({
      value: 'transferencia',
      label: 'Transferencia bancaria',
      idPayment: 2,
    });
  }
  if (data?.tarjeta) {
    paymentMethods.push({
      value: 'tarjeta',
      label: 'Tarjeta de Débito / Crédito',
      idPayment: 3,
    });
  }
  if (data?.cupon) {
    paymentMethods.push({
      value: 'cupon',
      label: 'Cupón de pago',
      idPayment: 4,
    });
  }
  const thirdStepProps = {
    paymentMethods,
    paymentAmount: {
      type: 'ARS',
      advance: señaTotal,
      rest: montoTotal - señaTotal,
      total: montoTotal,
    },
    name: nombre,
    setPaymentId,
    paymentId,
    isLoading,
  };

  const handleValidation = () => {
    if (errorNombre || !nombre) {
      dispatch(
        setErrorInput({
          field: 'nombre',
          value: !nombre
            ? 'Ingresá un nombre'
            : 'Debes ingresar un nombre válido',
        }),
      );
    }
    if (errorApellido || !apellido) {
      dispatch(
        setErrorInput({
          field: 'apellido',
          value: !apellido
            ? 'Ingresá un apellido'
            : 'Debes ingresar un apellido válido',
        }),
      );
    }
    if (errorTipoIdentificacion || !tipoIdentificacion) {
      dispatch(setErrorInput({ field: 'tipoIdentificacion', value: true }));
    }
    if (errorIdentificacion || !identificacion) {
      dispatch(
        setErrorInput({
          field: 'identificacion',
          value: !identificacion
            ? 'Ingresá un número de documento'
            : 'Debes ingresar un número de documento válido',
        }),
      );
    }
    if (errorEmail || !email) {
      dispatch(
        setErrorInput({
          field: 'email',
          value: !email
            ? 'Ingresá un correo electrónico'
            : 'Debes ingresar un correo electrónico válido',
        }),
      );
    }
    if (errorTelefono || !telefono) {
      dispatch(
        setErrorInput({
          field: 'telefono',
          value: !telefono
            ? 'Ingresá un número de teléfono'
            : 'El código de área debe ir sin 0 y el número de celular sin 15. Ej: 351 511 2589',
        }),
      );
    }
  };

  // eslint-disable-next-line consistent-return
  const onSubmitReservation = async (e: { preventDefault: () => void }) => {
    e.preventDefault();

    if (!startDate || !endDate) {
      setOpenCalendar(true);
      setOpenButtonLoading(false);
      return false;
    }

    if (
      !nombre ||
      !apellido ||
      !identificacion ||
      !email ||
      !telefono ||
      errorNombre ||
      errorApellido ||
      errorIdentificacion ||
      !tipoIdentificacion ||
      errorEmail ||
      errorTelefono
    ) {
      handleValidation();
      window.scrollTo({ top: 2550, behavior: 'smooth' });
      return false;
    }

    try {
      await sendReservations({
        fields: {
          email,
          fecha_inicio: startDate,
          fecha_fin: endDate,
          personas,
          bebes,
          huesped_nombre: nombre,
          huesped_apellido: apellido,
          huesped_edad: 0,
          huesped_tipo_identificacion: datosPersonales.tipo_identificacion,
          huesped_identificacion: identificacion,
          id_metodo_pago: paymentId,
          monto: montoTotal,
          seña: señaTotal,
          porcentaje_seña: data?.senia,
          pide_tarjeta: 0,
          capacidad: {
            adultos,
            menores,
            mascotas,
          },
        },
        id_propiedad: data?.id_propiedad_legacy,
        id_tipologia: typologyId,
        cargo_extra_limpieza: data?.cargo_extra_limpieza,
        cargo_extra_otro: data?.cargo_extra_otro,
      });
    } catch (error) {
      await router.push('/descuentos/error');
    } finally {
      await router.push('/descuentos/success');
    }
  };

  return (
    <Grid
      item
      container
      component="article"
      rowSpacing={8}
      maxWidth={isMobile ? '37.5rem' : '75rem'}
      marginY={isMobile ? 1 : 0}
    >
      <Grid item container rowSpacing={10}>
        {data?.formatedData?.hostProfile && (
          <Grid item xs={12} component="article">
            <HostProfile
              referencia={data?.formatedData?.hostProfile?.reference}
              name={data?.formatedData?.hostProfile?.name}
              profilePhoto={data?.formatedData?.hostProfile?.profilePhoto}
            />
          </Grid>
        )}
        <Grid item xs={12} component="article">
          <LodgingAmenities
            amenities={amenities}
            dataAmenities={dataAmenities}
          />
        </Grid>

        <Grid item>
          <Box marginBottom="1rem">
            <Typography variant="benefitsTitle">
              Descuento especial del {descuento}%
            </Typography>
          </Box>
          <Typography variant="textPostDesktop">
            Si querés ver más datos del alojamiento,{' '}
            <StyledLink target="_blank" href={fichaLink}>
              ingresá aquí
            </StyledLink>
            .
            <br />
            Para reservar tu estadía con descuento, seguí los siguientes pasos:
          </Typography>
        </Grid>

        <Grid item>
          <Typography variant="contentTitle">
            Paso 1 : Seleccioná fecha y cantidad de personas
          </Typography>

          <SummaryReserveData>
            {selectPeople && (
              <ClickAwayListener onClickAway={() => setSelectPeople(false)}>
                <StyledSelectPeople>
                  <SelectPeople
                    handleClose={() => setSelectPeople(false)}
                    aceptaMascotas={pets || false}
                    persons={persons}
                    changeProps={changeProps}
                    typologyMaxCapacity={peopleMax || 2}
                  />
                </StyledSelectPeople>
              </ClickAwayListener>
            )}
          </SummaryReserveData>

          <Grid item container gap={3} marginTop={2}>
            <Grid item container>
              <SummaryMobile referencia={referencia} />
            </Grid>
            <Grid item>
              <BookingDiscountTipologiesList />
            </Grid>
          </Grid>
        </Grid>

        <Grid item>
          <Typography variant="contentTitle">
            Paso 3 : Verificá el precio y los detalles de tu estadía
          </Typography>
          <SummaryDiscountDesktop
            testProperty={testProperty}
            referencia={referencia}
            openCheckoutSIC={openCheckoutSIC}
            setOpenCheckoutSic={setOpenCheckoutSic}
          />
        </Grid>

        <Grid item>
          <Typography variant="contentTitle">
            Paso 4 : Completá el siguiente formulario y solicitá la reserva
          </Typography>
          <UserFormDiscount
            datosPersonales={datosPersonales}
            inputError={inputError}
            dispatchOnChange={dispatchOnChange}
            dispatchSetError={dispatchSetError}
          />
        </Grid>

        <Grid item>
          <CheckoutDiscount {...thirdStepProps} />
        </Grid>

        <ContactButtonLoading
          variant="contained"
          size="large"
          loading={openButtonLoading}
          // eslint-disable-next-line @typescript-eslint/no-misused-promises
          onClick={onSubmitReservation}
        >
          Reservar
        </ContactButtonLoading>
      </Grid>
    </Grid>
  );
};

export default memo(LodgingDiscountData);
