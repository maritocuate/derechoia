import React, { memo, useCallback, useEffect } from 'react';
import { LatLngTuple } from 'leaflet';
import { useMap } from 'react-leaflet';
import NearMeButton from '../MapFicha/components/Buttons/NearMeButton';

type MapCenterHandlerProps = {
  center: LatLngTuple;
};
const MapCenterHandler = ({ center }: MapCenterHandlerProps) => {
  const map = useMap();

  const handleMapCenter = useCallback(
    (mapCenter: LatLngTuple) => {
      if (mapCenter && map)
        map.flyTo(mapCenter, 13, {
          easeLinearity: 1,
        });
    },
    [map],
  );

  useEffect(() => {
    if (center) map.setView(center);
  }, [center, map]);
  return <NearMeButton callback={handleMapCenter} />;
};

const propsAreEqual = (
  prevProps: MapCenterHandlerProps,
  nextProps: MapCenterHandlerProps,
) => {
  const [prevLat] = prevProps.center;
  const [nextLat] = nextProps.center;
  if (prevLat !== nextLat) return false;
  const [prevLng] = prevProps.center;
  const [nextLng] = nextProps.center;
  if (prevLng !== nextLng) return false;
  return true;
};

const LeafletCenterHandler = memo(MapCenterHandler, propsAreEqual);

export default LeafletCenterHandler;
