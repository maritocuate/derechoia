import React from 'react';
import { Box, styled, Typography } from '@mui/material';
import Image from 'next/image';
import useIsMobile from '../../hooks/useIsMobile';
import { Banner } from '../../types/holiday.types';
import imageLoaderHeaderDesk from '../../utils/helpers/imageLoaders/imageloaderHeaderDesk';

interface BookingHeaderProps {
  title: string;
  topContent: string;
  bannerUrl: Banner;
}

const StyledBackground = styled(Box)(
  ({ theme }) => `
    display: flex;
    width: 100%;
    justify-content: center;
    position: relative;
    padding: 6.5rem 1rem 1.5rem 1rem;
    background: #fafafa;
    ${theme.breakpoints.up('lg')}{
      padding-top: 7rem;
    }`,
);
const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    padding: 0 0.9rem;
    gap: 1.5rem;
    ${theme.breakpoints.up('lg')}{
      gap: 0.7rem;
      padding: 0;
    }`,
);
const StyledImage = styled(Image)(
  ({ theme }) => `
    margin: 1rem 0;
    object-fit: cover;
    border-radius: 0.5rem;
    width: 100%;
    ${theme.breakpoints.up('lg')}{
      margin: 2.5rem 0 3.5rem 0;
    }`,
);

const HolidayHeader = ({
  title,
  topContent,
  bannerUrl,
}: BookingHeaderProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledBackground>
      <StyledContainer maxWidth={isMobile ? 600 : 1200}>
        <Typography
          component="h1"
          variant={isMobile ? 'benefitsTitle' : 'titleSectionPostDestkop'}
          color="rgb(0, 0, 0, 0.87)"
        >
          {title}
        </Typography>
        <Typography
          variant={isMobile ? 'descriptionText' : 'authTitle'}
          style={{ fontWeight: 500 }}
        >
          {topContent}
        </Typography>

        {!!bannerUrl.desktop && !!bannerUrl.mobile && (
          <StyledImage
            src={isMobile ? bannerUrl.mobile : bannerUrl.desktop}
            alt={title}
            loader={({ src }) =>
              imageLoaderHeaderDesk({ src, width: 1200, height: 500 })
            }
            width={isMobile ? 600 : 1200}
            height={450}
          />
        )}
      </StyledContainer>
    </StyledBackground>
  );
};

export default HolidayHeader;
