import React, { useMemo, useState, memo } from 'react';
import {
  Divider,
  Grid,
  IconWithText,
  Typography,
} from '@alquiler-argentina/demiurgo';
import { Box, styled, Collapse } from '@mui/material';
import Head from 'next/head';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import LinkFaq from '../LinkFaqs';
import IconFaqs from '../../utils/helpers/Faqs/IconFaqs';

interface IFaqsCabins {
  locality: string;
  province: string;
  averagePrice: number;
  maxCapacity: number;
}

interface Answer {
  value: boolean;
}

const StyledIconWithText = styled(IconWithText)`
  cursor: pointer;
  justify-content: flex-end !important;
  margin-bottom: 1rem;
`;

const StyledTypography = styled(Typography)`
  margin-bottom: 1rem;
`;

const StyledTitle = styled(Typography)`
  margin-bottom: 1.75rem;
  font-weight: 700;
  font-size: 1.3rem;
`;

const StyledContainer = styled(Box)(
  ({ theme }) => `
  border: 1px solid rgba(0, 0, 0, 0.23);
  padding: 1rem;
  border-radius: 8px;
  width: calc(100% - 2rem);
  ${theme.breakpoints.up('sm')}{
    width: 100%;
  }
`,
);

function FaqsCabins({
  locality,
  province,
  averagePrice,
  maxCapacity,
}: IFaqsCabins) {
  const [answers, setAnswers] = useState<Answer[]>([
    { value: false },
    { value: false },
    { value: false },
    { value: false },
    { value: false },
    { value: false },
  ]);
  const url = useMemo(
    () => `/${province}/${locality}/_T:A:`.replace(/\s+/g, '-'),
    [province, locality],
  );
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: [
      {
        '@type': 'Question',
        name: `¿Cuánto cuesta hospedarse en una cabaña en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `El precio promedio para hospedarse en una cabaña en ${locality} es de  ${formatPriceToArs(
            averagePrice,
          )} por noche. Ingresá a nuestra web y en pocos minutos compará todas las opciones que tenemos disponibles.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Para cuántas personas son las cabañas en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Las cabañas en ${locality} permiten hospedar hasta ${maxCapacity} personas. Encontrá en Alquiler Argentina los mejores alojamientos de acuerdo a tus preferencias.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Las cabañas en ${locality} cuentan con Wi-Fi?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `En Alquiler Argentina tenés muchas opciones de <a href=${`${url}_S:I/`} style='color: #3f3e3e;'>cabañas con WiFi en ${locality}</a>. Ingresá a nuestra web para encontrar todas las que tenemos para tu próximo viaje.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Los complejos de cabañas en ${locality} tienen pileta?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Hay una gran variedad de <a href=${`${url}_P:S/`} style='color: #3f3e3e;'>complejos de cabañas con pileta en ${locality}</a>. Ingresá a nuestra web y comenzá a soñar tus próximas vacaciones con pileta incluida.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Puedo alquilar cabañas en ${locality} por día, semana o quincena?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `Podés elegir las fechas que prefieras para tu estadía en ${locality}. Viajá todo el tiempo que quieras, ¡no te quedes con las ganas!.`,
        },
      },
      {
        '@type': 'Question',
        name: `¿Se pueden elegir alquileres temporarios por día, semana o mes en ${locality}?`,
        acceptedAnswer: {
          '@type': 'Answer',
          text: `En Alquiler Argentina podés encontrar distintas opciones de <a href=${`${url}_R:M/`} style='color: #3f3e3e;'>cabañas en ${locality} que aceptan mascotas.</a>  Viajá con ellas y disfrutá al máximo tu estadía.`,
        },
      },
    ],
  };

  const faqs = useMemo(
    () => [
      {
        question: `¿Cuánto cuesta hospedarse en una cabaña en ${locality}?`,
        answer: `El precio promedio para hospedarse en una cabaña en ${locality} es de ${formatPriceToArs(
          averagePrice,
        )} por noche. Ingresá a nuestra web y en pocos minutos compará todas las opciones que tenemos disponibles.`,
      },
      {
        question: `¿Para cuántas personas son las cabañas en ${locality}?`,
        answer: `Las cabañas en ${locality} permiten hospedar hasta ${maxCapacity} personas. 
        Encontrá en Alquiler Argentina los mejores alojamientos de acuerdo a tus preferencias.`,
      },
      {
        question: `¿Las cabañas en ${locality} cuentan con Wi-Fi?`,
        answer: (
          <LinkFaq
            title="En Alquiler Argentina tenés muchas opciones de "
            url={`${url}_S:I/`}
            linkText={`cabañas con WiFi en ${locality}.`}
            textBody=" Ingresá a nuestra web para encontrar todas las que tenemos para tu
          próximo viaje."
          />
        ),
      },
      {
        question: `¿Los complejos de cabañas en ${locality} tienen pileta?`,
        answer: (
          <LinkFaq
            title="Hay una gran variedad de "
            url={`${url}_P:S/`}
            linkText={`cabañas con pileta en ${locality}.`}
            textBody=" Ingresá a nuestra web y comenzá a soñar tus próximas vacaciones con
            pileta incluida."
          />
        ),
      },
      {
        question: `¿Puedo alquilar cabañas en ${locality} por día, semana o quincena?`,
        answer: `Podés elegir las fechas que prefieras para tu estadía en ${locality}. Viajá todo el tiempo que quieras, ¡no te quedes con las ganas!.`,
      },
      {
        question: `¿Aceptan mascotas en las cabañas para alquilar en ${locality}?`,
        answer: (
          <LinkFaq
            title="En Alquiler Argentina podés encontrar distintas opciones de "
            url={`${url}_R:M/`}
            linkText={`cabañas en ${locality} que aceptan mascotas.`}
            textBody=" Viajá con ellas y disfrutá al máximo tu estadía."
          />
        ),
      },
    ],
    [locality, averagePrice, maxCapacity, url],
  );

  const toggleAnswer = (index: number) => {
    const newAnswers = Array.from(answers);
    newAnswers[index] = { ...answers[index], value: !answers[index].value };
    setAnswers(newAnswers);
  };

  const icon = (index: number) => IconFaqs({ index, answers });
  return (
    <>
      <Head>
        <script
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      </Head>
      <StyledContainer>
        <StyledTitle variant="body1">Preguntas frecuentes</StyledTitle>
        <Grid gap={2} container direction="column">
          {faqs.map((faq, index) => (
            <Grid item key={index}>
              <StyledIconWithText
                icon={icon(index)}
                onClick={() => toggleAnswer(index)}
                anchor="right"
              >
                <Typography variant="h2" fontWeight={600} fontSize="1rem">
                  {faq.question}
                </Typography>
              </StyledIconWithText>
              <Collapse in={answers[index].value}>
                <StyledTypography>{faq.answer}</StyledTypography>
              </Collapse>
              <Divider />
            </Grid>
          ))}
        </Grid>
      </StyledContainer>
    </>
  );
}

export default memo(FaqsCabins);
