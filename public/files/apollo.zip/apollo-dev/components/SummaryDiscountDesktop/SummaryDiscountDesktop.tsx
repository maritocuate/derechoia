/* eslint-disable arrow-body-style */
import React, { memo, useCallback, useMemo } from 'react';
import { Grid } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import useBookingSummaryDesktop from '../../hooks/alojamientos/useBookingSummaryDesktop';
import BookingDiscountSummary from '../BookingDiscountSummary';
import { TEventType, sendInquiryGTM } from '../../utils/helpers/sendDataGTM';
import calculateDateRange from '../../utils/helpers/calculateDateRange';
import { handleOpenCalendar } from '../../redux/checkout/slice';
import { IFichaSecondCharge } from '../../redux/ficha/types';

const SummaryDiscountDesktop = ({
  referencia,
  openCheckoutSIC,
  testProperty,
  setOpenCheckoutSic,
}: {
  referencia: string;
  openCheckoutSIC: boolean;
  testProperty?: boolean;
  setOpenCheckoutSic: (value: boolean) => void;
}) => {
  const dispatch = useDispatch();
  const {
    data,
    startDate,
    endDate,
    selectedDiscount,
    selectedPrice,
    activa,
    isAllBlocked,
    lastBlockedMessage,
    persons,
    handleChangePersons,
    allowPets,
    maxPeopleAllowed,
    propiedades,
    hostWhatsAppNumber,
    totalDays,
    phoneList,
    bookingContactName,
    bookingHasEmail,
    bookingTitle,
    bookingReference,
    bookingMinimalPrice,
    startDateFormated,
    endDateFormated,
    bookingCleaningFee,
    bookingOtherFee,
  } = useBookingSummaryDesktop(referencia, testProperty);

  const { selectedTipology, bookingData } = useSelector(
    ({ fichaSecondCharge }: { fichaSecondCharge: IFichaSecondCharge }) =>
      fichaSecondCharge,
  );

  const setOpenCalendar = useCallback(
    (newState: boolean) => {
      dispatch(handleOpenCalendar({ isOpenCalendar: newState }));
    },
    [dispatch],
  );

  const totalPrice = useMemo(() => {
    return totalDays !== 0 && selectedPrice
      ? selectedPrice * totalDays
      : selectedPrice;
  }, [selectedPrice, totalDays]);

  const handleSendInquiryGTM = useCallback(
    (eventType: TEventType) => {
      const bookedDays =
        startDate && endDate ? calculateDateRange(startDate, endDate) : null;

      const inquiry = {
        startDate,
        endDate,
        bookedDays,
        adults: persons.adults,
        youngAdults: null,
        teens: null,
        children: persons.children,
        babies: persons.babies,
        pets: persons.mascotas,
        totalPeople: persons.total,
        tipologyId: selectedTipology?.id ? selectedTipology?.id : null,
        minCapacity: selectedTipology ? selectedTipology.capacidad_min : null,
        maxCapacity: selectedTipology ? selectedTipology.capacidad_max : null,
        bathrooms: selectedTipology ? selectedTipology.banios : null,
        rooms: selectedTipology ? selectedTipology.dormitorios : null,
      };

      if (data) {
        sendInquiryGTM({
          eventType,
          acommodationGeneralData: data,
          inquiryGeneralData: inquiry,
        });
      }
    },
    [startDate, endDate, persons, selectedTipology, data],
  );

  return (
    <Grid item container>
      <BookingDiscountSummary
        blockedMessage={lastBlockedMessage}
        blocked={isAllBlocked}
        selectedDiscount={selectedDiscount}
        idTipologia={selectedTipology?.id}
        dataOcupaciones={propiedades}
        persons={persons}
        active={activa}
        changeProps={handleChangePersons}
        setOpenCalendar={setOpenCalendar}
        openCheckoutSIC={openCheckoutSIC}
        setOpenCheckoutSic={setOpenCheckoutSic}
        whatsappNumber={hostWhatsAppNumber}
        totalDays={totalDays}
        // esta llegando el precio con el descuento ya aplicado
        basePrice={selectedPrice}
        telefonos={phoneList}
        emailPropietario={!!bookingHasEmail}
        name={bookingContactName}
        title={bookingTitle}
        unidad={selectedTipology?.nombre_tipologia}
        referencia={bookingReference || ''}
        // esta llegando el precio con el descuento ya aplicado
        price={totalPrice || bookingMinimalPrice}
        startDate={startDateFormated || null}
        endDate={endDateFormated || null}
        cleaningFee={bookingCleaningFee}
        cargoExtra={bookingOtherFee}
        dayValueDiffers
        pets={allowPets}
        gtm={handleSendInquiryGTM}
        peopleMax={maxPeopleAllowed}
        location={
          data?.formatedData?.locationData?.placeExistsInArgentina
            ? data?.formatedData?.locationData?.placeExistsInArgentina
            : null
        }
        hasPhoneNumber={bookingData?.hasPhoneNumber}
        hasWhatsapp={bookingData?.hasWhatsapp}
      />
    </Grid>
  );
};

export default memo(SummaryDiscountDesktop);
