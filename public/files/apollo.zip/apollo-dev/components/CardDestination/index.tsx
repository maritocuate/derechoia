import React from 'react';
import Image from 'next/image';
import { Box, Typography, styled } from '@mui/material';
import { useTranslation } from 'react-i18next';
import formatNumberWithDots from '../../utils/helpers/formatnumberDot';
import { MostBooked } from '../../types/home.types';
import imageLoaderMostBookDestinations from '../../utils/helpers/imageLoaders/imageLoaderMostBookDestinations';

//  Omit<MostBooked, 'cityV4' | 'provinceV4'>
interface CardDestinationProps
  extends Omit<MostBooked, 'cityV4' | 'provinceV4'> {
  isMobile: boolean;
}

const StyledCard = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  margin-right: 0rem;
  ${theme.breakpoints.up('lg')}{
    margin-right: 0rem;
  }
  `,
);

const StyledBoxImage = styled(Box)(
  ({ theme }) => `
  width: 15rem;
  height: 12.5rem;
  margin: 0;
  position: relative;
  margin-bottom: 1rem;
  cursor: pointer;
  overflow: hidden;
  border-radius: 0.5rem;
  ${theme.breakpoints.up('lg')}{
    width: 23.75rem;
    height: 20rem;
  }
`,
);
const StyledPlaceName = styled(Typography)(
  ({ theme }) => `
  font-weight: 700;
  margin: .5rem 0;
  cursor: pointer;
  ${theme.breakpoints.up('lg')}{
    margin: 0.25rem 0;
    font-weight: 600;
    font-size: 1.25rem;
  }
`,
);
const StyledQuantity = styled(Typography)(
  ({ theme }) => `
  color: #00000099;
  margin-bottom: 2.5rem;
  cursor: pointer;
  font-size: 0.875rem;
  ${theme.breakpoints.up('lg')}{
    font-size: 1rem;
  }
`,
);

const StyledImage = styled(Image)`
  transition: all 0.2s;
  object-fit: cover;
  &:hover {
    transform: scale(1.1);
  }
`;

export default function CardDestination({
  city,
  province,
  url,
  amount,
  isMobile,
}: CardDestinationProps) {
  const { t } = useTranslation('MostBookedDestinations');
  return (
    <StyledCard>
      <StyledBoxImage>
        <StyledImage
          src={url}
          alt={`Destinos más visitados - Fotos de ${city}, ${province}`}
          width={isMobile ? 240 : 380}
          height={isMobile ? 200 : 320}
          loader={imageLoaderMostBookDestinations}
        />
      </StyledBoxImage>
      <StyledPlaceName>{city}</StyledPlaceName>
      {amount ? (
        <StyledQuantity>
          {formatNumberWithDots(amount)} {t('accommodations')}
        </StyledQuantity>
      ) : (
        <StyledQuantity />
      )}
    </StyledCard>
  );
}
