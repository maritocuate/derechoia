import { useEffect, useState } from 'react';
import { useMapEvents } from 'react-leaflet';
import { TMapBounds } from '../../types/map.types';
import { IHandleChangePositionParams } from '../MapList/types';
import { CoordsMapArray } from '../../redux/filtersListado/types';

const LeafletBoundsHandler = ({
  callback,
}: {
  callback?: ({ bounds }: IHandleChangePositionParams) => void;
}) => {
  const [mapData, setMapData] = useState<{
    bounds: TMapBounds;
    center: CoordsMapArray;
    zoom?: number;
  }>({
    bounds: {
      southWest: null,
      northEast: null,
    },
    center: [null, null],
  });

  useEffect(() => {
    if (callback)
      callback({
        bounds: mapData.bounds,
        center: mapData.center,
        zoom: mapData.zoom,
      });
  }, [mapData, callback]);

  const map = useMapEvents({
    moveend: () => {
      try {
        const mapBounds = map.getBounds();
        const center = map.getCenter();
        const zoom = map.getZoom();
        const ne = mapBounds?.getNorthEast(); // Coordenada noreste
        const sw = mapBounds?.getSouthWest(); // Coordenada suroeste

        if (ne && sw)
          setMapData({
            bounds: {
              southWest: { lat: sw.lat, lng: sw.lng },
              northEast: { lat: ne.lat, lng: ne.lng },
            },
            center: [center.lat, center.lng],
            zoom,
          });
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error(error);
      }
    },
  });

  useEffect(() => {
    try {
      if (!map.getBounds) return;
      const mapBounds = map.getBounds();
      const ne = mapBounds?.getNorthEast(); // Coordenada noreste
      const sw = mapBounds?.getSouthWest(); // Coordenada suroeste

      if (ne && sw)
        setMapData((initialState) => ({
          ...initialState,
          bounds: {
            southWest: { lat: sw.lat, lng: sw.lng },
            northEast: { lat: ne.lat, lng: ne.lng },
          },
        }));
    } catch (error) {
      // eslint-disable-next-line no-console
      console.error(error);
    }
  }, [map]);

  return null;
};

export default LeafletBoundsHandler;
