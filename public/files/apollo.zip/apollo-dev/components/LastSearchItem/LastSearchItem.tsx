import PlaceOutlined from '@mui/icons-material/PlaceOutlined';
import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import formatDateDayMonth from '../../utils/helpers/FormatDateDayMonth';
import { ILastSearchItem } from '../../redux/lastSearchs/type';
import { isCountry } from '../../serverSide/managers/formatters/destination.formatter';

interface ICardDestination extends ILastSearchItem {
  lastCard: boolean;
}

const StyledLastSearch = styled(Box)`
  min-width: 17.5rem;
  max-width: 17.5rem;
  height: 90px;
  margin: 0rem;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: 1.5rem;
  border-radius: 0.5rem;
  border: 1px solid #0000003b;
  cursor: pointer;
  transition: all 0.6s;
  &:hover {
    background-color: #0000000a;
  }
  &:active {
    background-color: #00acc114;
  }
`;

const StyledIcon = styled(Typography)(
  ({ theme }) => `
  color: ${theme.palette.primary.main};
  margin-right: 1rem;
    
`,
);

const StyledPlace = styled(Typography)`
  font-size: 1rem;
  font-weight: 600;
  color: #000000de;
`;

const StyledDetail = styled(Typography)`
  font-size: 0.85rem;
  color: #00000099;
  position: relative;
  top: 2px;
`;

export default function LastSearchItem({
  city,
  province,
  startDate,
  endDate,
  adults,
  youngs,
  lastCard,
}: ICardDestination) {
  const { t } = useTranslation('LastSearch');
  const notInvalidDate =
    dayjs(startDate).isValid() &&
    dayjs(startDate).isAfter(dayjs()) &&
    dayjs(endDate).isValid() &&
    dayjs(endDate).isAfter(dayjs());
  const guests = adults + youngs;
  return (
    <StyledLastSearch
      sx={{ marginRight: `${lastCard ? '0rem' : '1.25rem'}` }}
      data-testid="LastSearchsItem"
    >
      <StyledIcon>
        <PlaceOutlined color="inherit" fontSize="medium" />
      </StyledIcon>
      <div>
        {!!city && <StyledPlace>{city}</StyledPlace>}
        <StyledPlace>
          {!city && !isCountry(province) && `${province} (${t('province')})`}
          {isCountry(province) && `${province} (País)`}
        </StyledPlace>
        <StyledDetail>
          {startDate &&
            endDate &&
            notInvalidDate &&
            `${formatDateDayMonth(startDate)} - ${formatDateDayMonth(
              endDate,
            )} •${' '}`}
          {guests} {t('people', { count: guests })}
        </StyledDetail>
        {!startDate ||
          !endDate ||
          (!notInvalidDate && (
            <StyledDetail>
              {guests} {t('people', { count: guests })}
            </StyledDetail>
          ))}
      </div>
    </StyledLastSearch>
  );
}
