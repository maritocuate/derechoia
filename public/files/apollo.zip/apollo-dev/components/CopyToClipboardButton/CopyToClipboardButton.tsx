import React from 'react';
import { Alert, Box, Snackbar, Typography, styled } from '@mui/material';
import { ContentCopyOutlined } from '@mui/icons-material';
import useCopyToClipboard from '../../hooks/useCopyToCipboard';

interface CopyToClipboardButtonProps {
  buttonText: string;
  copyText: string;
  confirmationText: string;
}

const StyledButton = styled(Box)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
`;

const CopyToClipboardButton = ({
  buttonText,
  copyText,
  confirmationText,
}: CopyToClipboardButtonProps) => {
  const [isCopied, copy] = useCopyToClipboard(copyText);
  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    if (typeof copy === 'function') {
      copy()
        .then(() => {
          setOpen(true);
        })
        .catch((error) => {
          // eslint-disable-next-line no-console
          console.error('Failed to copy text: ', error);
        });
    }
  };

  const handleClose = (
    event: React.SyntheticEvent | Event,
    reason?: string,
  ) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  return (
    <>
      <StyledButton onClick={handleClick}>
        <ContentCopyOutlined fontSize="inherit" />
        <Typography variant="myBookingDate" fontSize="0.813rem">
          {buttonText}
        </Typography>
      </StyledButton>
      <Snackbar open={open} autoHideDuration={2000} onClose={handleClose}>
        <Alert sx={{ border: '1px solid', borderColor: 'primary.main' }}>
          {isCopied && confirmationText}
        </Alert>
      </Snackbar>
    </>
  );
};

export default CopyToClipboardButton;
