// Ask about the case where there's a new accomodation
import React from 'react';
import { styled, Divider, Button, Grid, Typography } from '@mui/material';
import dynamic from 'next/dynamic';
import { BadgeTypes as BADGE_TYPES } from '@alquiler-argentina/demiurgo/components/BadgeAnuncio';
import EventRepeatOutlinedIcon from '@mui/icons-material/EventRepeatOutlined';
import EventAvailableOutlinedIcon from '@mui/icons-material/EventAvailableOutlined';
import FavoriteBorderOutlinedIcon from '@mui/icons-material/FavoriteBorderOutlined';
import { useTranslation } from 'react-i18next';
import { StyledImage as StyledImageCardValueOffer } from '../CardValueOffer/styles';
import useIsMobile from '../../hooks/useIsMobile';

const IconWithText = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/IconWithText'),
  { ssr: false },
);
const Valoraciones = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/Valoraciones'),
  { ssr: false },
);
const BadgeAnuncio = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/BadgeAnuncio'),
  { ssr: false },
);

interface ICardAnuncio {
  featuredimage: string;
  title: string;
  locality: string;
  badge?: {
    isGold?: boolean;
    isFeatured?: boolean;
  };
  averageScore?: number;
  offers: number;
  capacity: number;
  price?: {
    base: number;
    total: number;
  };
  guests: number;
  cancellation: {
    type: 'flexible' | 'free' | 'strict';
  };
}

const StyledContainer = styled(Grid)`
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 8px;
`;

const StyledImage = styled(StyledImageCardValueOffer)(
  ({ theme }) => `
    min-height: 194.65px;
    
    ${theme.breakpoints.down('sm')} {
      width: initial;
      max-height: initial;
      border-bottom-right-radius: initial;
      border-bottom-left-radius: initial;
    };
    ${theme.breakpoints.up('sm')} {
      border-top-right-radius: initial;
      border-bottom-right-radius: initial;
    };
`,
);

const StyledBadgeAnuncioWrapper = styled(Grid)`
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 4px;
  padding: 2px 8px 2px 6px;
  margin: 0.5rem;
  height: fit-content;
  &:hover {
    cursor: default;
  }
`;

const StyledFavoriteButton = styled(Button)`
  background-color: rgba(255, 255, 255, 0.8);
  min-height: 28px;
  min-width: 28px;
  padding: 2px 8px 2px 6px;
  margin: 0.5rem;
  & svg {
    fill: rgba(0, 0, 0, 0.87);
  }
`;

const StyledSection = styled(Grid)`
  padding: 1rem;
`;

const StyledTitle = styled(Typography)`
  font-weight: 600;
  font-size: 16px;
  line-height: 150%;
`;

const StyledSubtitle = styled(Typography)`
  font-weight: 400;
  font-size: 14px;
  line-height: 143%;
`;

const StyledCommonText = styled(StyledSubtitle)``;

const StyledDiscount = styled(StyledSubtitle)`
  color: rgba(0, 0, 0, 0.6);
  text-decoration: line-through;
`;

const StyledNoDiscount = styled(StyledDiscount)`
  text-decoration: none;
`;

const StyledPrice = styled(Typography)`
  font-weight: 700;
  font-size: 20px;
  color: rgba(0, 0, 0, 0.87);
`;

const StyledCancellationType = styled(IconWithText)(
  ({ theme }) => `
  font-size: 12px;
  color: ${theme.palette.primary.main};
`,
);

const StyledAlignCenter = styled(Grid)`
  align-items: center;
`;

const StyledValoraciones = styled(Valoraciones)`
  font-weight: 500;
`;

export default function CardAnuncio({
  featuredimage,
  title,
  locality,
  badge,
  averageScore,
  offers,
  capacity,
  price,
  guests,
  cancellation,
}: ICardAnuncio) {
  const { t } = useTranslation('CardAnuncio');
  const isMobile = useIsMobile();

  const handleFavorite = () => {
    // Add to favorites state goes here
  };

  const setCancellation = () => {
    switch (cancellation.type) {
      case 'free':
        return (
          <Grid item>
            <StyledCancellationType
              anchor="left"
              icon={<EventAvailableOutlinedIcon />}
            >
              {t('free_cancellation')}
            </StyledCancellationType>
          </Grid>
        );
      case 'flexible':
        return (
          <Grid item>
            <StyledCancellationType
              anchor="left"
              icon={<EventRepeatOutlinedIcon />}
            >
              {t('flexible_cancellation')}
            </StyledCancellationType>
          </Grid>
        );
      default:
        return null;
    }
  };

  const setDiscount = (
    varOffers: number,
    varPrice: { base: number; total: number },
  ) => {
    if (varOffers === 1 && varPrice.base !== varPrice.total) {
      return (
        <StyledDiscount>
          {t('$'.concat('{{val, number}}'), { val: varPrice.base })}
        </StyledDiscount>
      );
    }
    if (varOffers > 1 && varPrice.base === varPrice.total) {
      return <StyledNoDiscount>{t('starting_price')}</StyledNoDiscount>;
    }
    if (varOffers > 1 && varPrice.base !== varPrice.total) {
      return (
        <StyledDiscount>
          {t('starting_price_base', {
            base: t('$'.concat('{{val, number}}'), {
              val: varPrice.base,
            }),
          })}
        </StyledDiscount>
      );
    }
    return null;
  };

  return (
    <StyledContainer container direction={isMobile ? 'column' : 'row'}>
      <Grid item container direction={isMobile ? 'column' : 'row'}>
        <StyledImage
          item
          container
          featuredimage={featuredimage}
          justifyContent="space-between"
          xs={isMobile ? 12 : 3.9}
        >
          {badge && (
            <StyledBadgeAnuncioWrapper item>
              <BadgeAnuncio
                // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment, @typescript-eslint/no-unsafe-member-access
                badge={BADGE_TYPES?.featured}
                text={t('featured')}
              />
            </StyledBadgeAnuncioWrapper>
          )}
          <Grid item>
            <StyledFavoriteButton onClick={handleFavorite}>
              <FavoriteBorderOutlinedIcon />
            </StyledFavoriteButton>
          </Grid>
        </StyledImage>
        <StyledSection
          item
          container
          direction="column"
          rowSpacing={isMobile ? 0.5 : 0}
          columnSpacing={isMobile ? 0 : 0.5}
          xs={isMobile ? 12 : 5}
        >
          <Grid item>
            <StyledTitle variant="subtitle1">{title}</StyledTitle>
          </Grid>
          <Grid item>
            <StyledSubtitle variant="body2">{locality}</StyledSubtitle>
          </Grid>
          <StyledAlignCenter item container gap={0.5}>
            {averageScore && (
              <Grid item>
                <StyledValoraciones
                  anchor="valoracionPromedio"
                  average={averageScore === null ? 0 : averageScore}
                  children={0}
                />
              </Grid>
            )}
            <Grid item>
              <StyledCommonText variant="body2">•</StyledCommonText>
            </Grid>
            <Grid item>
              <StyledCommonText variant="body2">
                {t('capacity', {
                  capacity,
                  count: capacity,
                })}
              </StyledCommonText>
            </Grid>
          </StyledAlignCenter>
        </StyledSection>
        <Divider
          orientation={isMobile ? 'horizontal' : 'vertical'}
          flexItem={!isMobile}
        />
        <StyledSection
          item
          container
          direction="column"
          gap={1.5}
          xs={isMobile ? 12 : 3}
        >
          {price ? (
            <Grid item container rowSpacing={0.5}>
              <Grid item>{setDiscount(offers, price)}</Grid>
              <StyledAlignCenter item container columnSpacing={0.5}>
                <Grid item>
                  <StyledPrice>
                    {t('$'.concat('{{val, number}}'), { val: price?.total })}
                  </StyledPrice>
                </Grid>
                <Grid item>
                  <StyledCommonText variant="body2">
                    {t('guests', {
                      guests,
                      count: guests,
                    })}
                  </StyledCommonText>
                </Grid>
              </StyledAlignCenter>
            </Grid>
          ) : (
            <Grid item>
              <StyledPrice>{t('check_price')}</StyledPrice>
            </Grid>
          )}
          {price && cancellation.type !== 'strict' && setCancellation()}
        </StyledSection>
      </Grid>
    </StyledContainer>
  );
}
