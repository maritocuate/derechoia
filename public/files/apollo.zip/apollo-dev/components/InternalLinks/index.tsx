import React, { useMemo } from 'react';
import { Box, styled, Grid, Typography } from '@mui/material';
import Link from 'next/link';
import { useTranslation } from 'react-i18next';
import { locations } from './locations';
import normalizeText from '../../utils/helpers/normalizeText';

interface IInternalLinks {
  province: string;
  mobile?: boolean;
}

const StyledLink = styled(Typography)`
  font-weight: 400;
  font-size: 1rem;
  text-decoration: underline;
`;

export default function InternalLinks({ province, mobile }: IInternalLinks) {
  const { t } = useTranslation('InternalLinks');
  const indexLocalidad = useMemo(
    () =>
      locations.findIndex(
        (link) =>
          normalizeText(link.nombre.toLowerCase()) ===
          normalizeText(province.toLowerCase()),
      ),
    [province],
  );
  const url = useMemo(() => `/${province}`.replace(/\s+/g, '-'), [province]);
  const location = useMemo(() => {
    if (indexLocalidad !== -1) {
      return locations[indexLocalidad].list.map((localidad) => {
        const urlLocalidad = `${url}/${localidad}/`.replace(/\s+/g, '-');
        const linkAndLocation = {
          name: localidad,
          link: urlLocalidad,
        };
        return linkAndLocation;
      });
    }
    return [];
  }, [indexLocalidad, url]);
  return (
    <Box
      border="1px solid rgba(0, 0, 0, 0.23)"
      padding="1rem"
      borderRadius="8px"
      width="100%"
    >
      <Typography
        marginBottom="28px"
        fontWeight={700}
        fontSize="1.3rem"
        variant="h2"
      >
        {t('title-province', { province })}
      </Typography>
      <Grid
        container
        columnSpacing={3}
        rowSpacing={2}
        flexDirection={mobile ? 'column' : 'row'}
      >
        {location.map(({ name, link }, index) => (
          <Grid xs={mobile ? 12 : 4} item key={index}>
            <Link passHref href={link}>
              <StyledLink color="text.primary">
                {t('title-locality', { locality: name })}
              </StyledLink>
            </Link>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
