import React, { useState } from 'react';
import Carousel from 'react-material-ui-carousel';
import { Box, styled } from '@mui/material';
import Image from 'next/image';
import { useRouter } from 'next/router';
import FiberManualRecord from '@mui/icons-material/FiberManualRecord';
import { Banners } from '../../types/home.types';
import imageLoaderPromottionBannerMobile from '../../utils/helpers/imageLoaders/imageLoaderPromottionBannerMobile';

export interface IBanners {
  bannersPromotions: Banners[];
}

const MainBox = styled(Box)(
  ({ theme }) => `
  width: 100vw;
  height: 50vw;
  margin-top: 1.5rem;
  padding: 0 1rem;
  border-radius: 0.5rem;
  ${theme.breakpoints.up('sm')}{
    height: 40vw;
  }
`,
);

const StyledBox = styled(Box)(
  ({ theme }) => `
    width: 91vw;
    height: 50vw;
    position: relative;
    ${theme.breakpoints.up('sm')}{
      height: 40vw;
    }
  `,
);

const StyledDot = styled(FiberManualRecord)`
  position: relative;
  top: -2rem;
  z-index: 10;
  border-radius: 100%;
  transition: all 0.5s;
`;

export default function BannerMobile({ bannersPromotions }: IBanners) {
  const [autoPlay, setAutoplay] = useState(true);
  const [active, setActive] = useState(0);
  const router = useRouter();
  const handleClick = (url: string) => {
    router
      .push(url)
      .then(() => {})
      .catch(() => {});
  };
  const handleAutoPlay = () => {
    setAutoplay(false);
  };
  return (
    <MainBox>
      <Carousel
        indicators={false}
        swipe
        autoPlay={autoPlay}
        PrevIcon={false}
        NextIcon={false}
        cycleNavigation
        index={0}
        interval={8000}
        onChange={() => setActive(active === 1 ? 0 : 1)}
        sx={{ height: '100%' }}
      >
        {bannersPromotions?.map((el, index) => (
          <StyledBox
            key={`key${el.path.url}`}
            onClick={() => handleClick(el.path.url)}
            onTouchEnd={handleAutoPlay}
          >
            <Image
              src={el.size.mobile.url}
              alt="Banner promotion"
              loader={imageLoaderPromottionBannerMobile}
              fill
              sizes="100%"
              style={{ borderRadius: '.5rem', objectFit: 'cover' }}
              priority={index === 0}
            />
          </StyledBox>
        ))}
      </Carousel>
      {bannersPromotions && bannersPromotions.length > 1 && (
        <Box display="flex" justifyContent="center" width="100%">
          {bannersPromotions.map((el, index) => (
            <Box color={active === index ? 'white' : 'rgb(192, 192, 192)'}>
              <StyledDot
                key={`${el.size.mobile.url}${index}`}
                fontSize="small"
                color="inherit"
                transform={`scale(${active === index ? '0.75' : '0.5'})`}
              />
            </Box>
          ))}
        </Box>
      )}
    </MainBox>
  );
}
