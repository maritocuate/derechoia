/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { Box, styled } from '@mui/material';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { IBanners } from './BannerMobile';
import imageLoaderPromottionBanner from '../../utils/helpers/imageLoaders/imageLoaderPromottionBanner';
import isEmptyPath from './helpers/isEmptyPath';

const StyledBox = styled(Box)`
  width: 100%;
  display: flex;
  align-items: center;
  margin-top: 3rem;
`;

const DisplayImages = styled(Box)(`
  position: relative;
  height: 250px;
  border-radius: 1rem;
  overflow: hidden;
`);

const StyledImageFullSize = styled(Image)`
  transition: all 0.2s;
  border-radius: 1rem;
  &:hover {
    transform: scale(1.05);
    cursor: pointer;
  }
`;

export default function BannerDesktop({ bannersPromotions }: IBanners) {
  const router = useRouter();
  const handleClick = (url: string) => {
    if (url) {
      router
        .push(url)
        .then(() => {})
        .catch(() => {});
    }
  };
  return (
    <StyledBox
      justifyContent={
        bannersPromotions?.length === 1 ? 'center' : 'space-between'
      }
      data-testid="main-div"
    >
      {bannersPromotions?.length === 1 &&
        !!bannersPromotions[0].size.desktop_full && (
          <DisplayImages
            width="100%"
            onClick={() =>
              handleClick(isEmptyPath(bannersPromotions[0].path.url))
            }
            sx={{
              cursor: isEmptyPath(bannersPromotions[0].path.url)
                ? 'pointer'
                : 'default',
            }}
            key={`key${bannersPromotions[0].size.desktop_full.url}`}
          >
            <StyledImageFullSize
              src={`${bannersPromotions[0].size.desktop_full.url}`}
              alt="Promotion Banner"
              width={1200}
              height={250}
              loader={imageLoaderPromottionBanner}
              data-testid={`display-images-${bannersPromotions[0].path.url}`}
              priority
              unoptimized
            />
          </DisplayImages>
        )}
      {bannersPromotions?.length === 2 &&
        bannersPromotions?.map((el, index) =>
          el.size.desktop_dual.url ? (
            <DisplayImages
              width="36.5rem"
              onClick={() => handleClick(isEmptyPath(el.path.url))}
              key={`key${el.size.desktop_dual.url}`}
              sx={{ cursor: isEmptyPath(el.path.url) ? 'pointer' : 'default' }}
            >
              <Image
                src={`${el.size.desktop_dual.url}`}
                alt="Promotion Banner"
                width={584} // Establece el ancho deseado
                height={250} // Establece la altura deseada (ajusta según tu necesidad)
                loader={imageLoaderPromottionBanner}
                data-testid={`display-images-${index}`}
                priority
                style={{ objectFit: 'cover' }}
                unoptimized
              />
            </DisplayImages>
          ) : null,
        )}
    </StyledBox>
  );
}
