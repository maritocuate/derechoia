function isEmptyPath(inputString: string) {
  // Verificar si el string es igual a '/'
  if (inputString.trim() === '/') {
    return '';
  }
  return inputString;
}

export default isEmptyPath;
