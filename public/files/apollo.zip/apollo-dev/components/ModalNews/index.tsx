import {
  Dialog,
  DialogContent,
  DialogTitle,
  styled,
  Typography,
} from '@mui/material';

export const StyledContainer = styled(Dialog)(
  ({ theme }) => `
  margin-inline: -16px;
  z-index: 999999;
  ${theme.breakpoints.up('sm')} {
    margin-inline: 0;
    & .MuiPaper-root {
      height: 880px;
    }
  }
`,
);

export const StyledModalTitleWrapper = styled(DialogTitle)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px;
`;

export const StyledModalTitle = styled(Typography)`
  font-weight: 700;
  font-size: 20px;
`;

export const StyledContentWrapper = styled(DialogContent)(
  ({ theme }) => `
  padding-inline: 16px;
  ${theme.breakpoints.up('sm')} {
    padding-inline: 48px;
  }
`,
);
