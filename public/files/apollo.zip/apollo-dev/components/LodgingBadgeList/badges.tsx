import React from 'react';
import BadgeAnuncio, {
  BadgeTypes as BADGE_TYPES,
} from '@alquiler-argentina/demiurgo/components/BadgeAnuncio';
import { TFunction } from 'react-i18next';

type TTranslatorFunction = TFunction<'ficha', undefined>;

export const badges = {
  iconOnlineBooking: (t: TTranslatorFunction) => (
    <BadgeAnuncio
      badge={BADGE_TYPES?.onlineBooking}
      text={t('online-booking')}
    />
  ),
  iconGold: (t: TTranslatorFunction) => (
    <BadgeAnuncio badge={BADGE_TYPES?.gold} text={t('gold')} />
  ),
  iconDestacado: (t: TTranslatorFunction) => (
    <BadgeAnuncio badge={BADGE_TYPES?.featured} text={t('featured')} />
  ),
  habMunicipal: (t: TTranslatorFunction) => (
    <BadgeAnuncio
      badge={BADGE_TYPES?.municipalAuthorization}
      text={t('municipal-hab')}
    />
  ),
} as const;

export type TBadge = keyof typeof badges;
