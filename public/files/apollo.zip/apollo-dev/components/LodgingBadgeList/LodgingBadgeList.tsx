import React, { memo } from 'react';
import { useTranslation } from 'react-i18next';
import { Grid } from '@mui/material';
import { TBadge, badges } from './badges';

const LodgingBadgeList = ({ badgesListkeys }: { badgesListkeys: TBadge[] }) => {
  const { t } = useTranslation('ficha');

  return (
    <Grid
      item
      container
      xs={12}
      display="flex"
      justifyContent="center"
      borderTop="1px solid #e0e0e0"
      borderBottom="1px solid #e0e0e0"
      marginTop="2rem"
      padding="1rem 0"
      gap={3}
    >
      {badgesListkeys.map((badge) => (
        <Grid item key={badge}>
          {badges[badge](t)}
        </Grid>
      ))}
    </Grid>
  );
};

export default memo(LodgingBadgeList);
