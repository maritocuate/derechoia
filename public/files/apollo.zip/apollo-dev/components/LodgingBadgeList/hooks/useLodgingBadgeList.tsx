import { useMemo } from 'react';
import { useGetPropiedadQuery } from '../../../services/propiedades';
import { TBadge } from '../badges';

const useLodgingBadgeList = ({ referencia }: { referencia: string }) => {
  const { data } = useGetPropiedadQuery({ referencia }, { skip: !referencia });
  const badgesListKeys: TBadge[] = useMemo(() => {
    const keys: TBadge[] = [];
    if (!data) return keys;

    if (
      data?.es_destacado ||
      data?.es_habilitado_municipal ||
      data?.es_destacado_gold
    ) {
      if (data?.es_troya || data?.permite_reservas) {
        keys.push('iconOnlineBooking');
      }
      if (data?.es_destacado_gold) {
        keys.push('iconGold');
      }
      if (data?.es_destacado) {
        keys.push('iconDestacado');
      }
      if (data?.es_habilitado_municipal) {
        keys.push('habMunicipal');
      }
    }
    return keys;
  }, [data]);

  return { badgesListKeys };
};

export default useLodgingBadgeList;
