import React, { memo } from 'react';
import { Grid, LinkProps, styled } from '@mui/material';
import { Alert, Button, Typography } from '@alquiler-argentina/demiurgo';
import WarningAmberOutlined from '@mui/icons-material/WarningAmberOutlined';
import { useRouter } from 'next/router';

interface IProps {
  location: LinkPropsExt[] | null;
}

export interface LinkPropsExt extends LinkProps {
  href: string;
}

const InactiveBookingSum = styled(Grid)(
  ({ theme }) => `
  width: 100vw;
  border-radius: 8px;
  padding: 1rem;
  margin-top: 1.5rem;
  ${theme.breakpoints.up('sm')}{
    margin-top: 0;
    width: 340px;
    padding: 1.5rem;
    box-shadow: 0px 4px 18px 3px rgba(0, 0, 0, 0.12);
    position: relative;
    left: 55px;
}
`,
);

const StyledAlert = styled(Alert)`
  align-items: center;
  background-color: rgb(255, 244, 229);
  color: rgb(102, 60, 0);
  padding: 0.5rem 0.75rem;
  letter-spacing: 0.17px;
  & svg {
    color: rgb(102, 60, 0);
  }
`;

const StyledTypography = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  padding: 1rem 0;
`;

const StyledButton = styled(Button)`
  width: 100%;
  font-weight: 600;
  letter-spacing: 0.46px;
  color: white;
  background-color: #fbc02d;
  &:hover {
    background-color: #fbc02d;
  }
`;

const InactiveBookingSummary = ({ location }: IProps) => {
  const router = useRouter();
  const handleClick = () => {
    if (location) {
      if (location[1]) {
        router.push(location[1].href).then(
          () => {},
          () => {},
        );
      } else {
        router.push(location[0].href).then(
          () => {},
          () => {},
        );
      }
    } else {
      router.push('https://www.alquilerargentina.com/buscar/').then(
        () => {},
        () => {},
      );
    }
  };
  return (
    <InactiveBookingSum data-testid="InactiveBookingSummaryContainer">
      <StyledAlert
        variant="standard"
        severity="error"
        icon={<WarningAmberOutlined />}
      >
        Este anuncio se encuentra inactivo. No es posible realizar consultas ni
        reservas.
      </StyledAlert>
      <StyledTypography variant="body2">
        Si estás buscando dónde hospedarte, podés mirar alternativas similares.
      </StyledTypography>
      <StyledButton
        variant="contained"
        onClick={handleClick}
        data-testid="BotonInactive"
      >
        Ver más alojamientos
      </StyledButton>
    </InactiveBookingSum>
  );
};

export default memo(InactiveBookingSummary);
