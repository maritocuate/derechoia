export interface ITestimonial {
  img: string;
  title: string;
  subtitle: string;
  text: string;
}
