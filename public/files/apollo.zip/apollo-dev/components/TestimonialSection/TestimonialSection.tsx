import React from 'react';
import { Box, Paper, styled } from '@mui/material';
import { Button, Typography } from '@alquiler-argentina/demiurgo';
import { useTranslation } from 'react-i18next';
import TestimonialSlider from './components/TestimonialSlider';
import useIsMobile from '../../hooks/useIsMobile';
import { ITestimonial } from './interfaces/interfaces';

const StyledContinerInfo = styled(Paper)(
  ({ theme }) => `
    align-content: center;
    background-color: #000000de;
    border-radius: 0.5rem 0.5rem 0 0;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin: auto;
    padding: 3rem 1.5rem;
    width: 100%;
    max-width: 37.5rem;
    ${theme.breakpoints.up('lg')} {
      border-radius: 0.5rem 0 0 0.5rem;
      padding: 1rem 2rem 1rem 3rem;
      width: 42rem;
      height: 37.5rem;
      max-width: unset;
    }
  `,
);

const StyledContainerBackground = styled(Box)(
  ({ theme }) => `
    ${theme.breakpoints.up('lg')}{
      background-color: #f5f5f5;
      height: 50%;
      width: 100%;
      position: absolute;
      z-index: -1;
    }
  `,
);

const StyledBackground = styled(Box)(
  ({ theme }) => `
  background: rgba(0, 0, 0, 0.04);
  ${theme.breakpoints.up('lg')}{
    background: linear-gradient(to bottom, rgba(0, 0, 0, 0.04) 50%, #fff 50%);
    width: 100%;
    max-width: 72.5rem;
    margin: 0 auto;
  }
`,
);

const TestimonialSection = ({
  testimonials = [],
  onClickPublicar,
}: {
  testimonials: ITestimonial[];
  onClickPublicar: () => void;
}) => {
  const isMobile = useIsMobile();
  const { t } = useTranslation('Testimonials');

  return (
    <>
      <StyledContainerBackground />
      <StyledBackground p={isMobile ? '2rem 1.5rem' : '2rem auto'}>
        <Box
          display="flex"
          flexDirection={isMobile ? 'column' : 'row'}
          margin="auto"
          width={isMobile ? 'auto' : '72.5rem'}
        >
          <StyledContinerInfo elevation={isMobile ? 0 : 3}>
            <Typography
              variant="titleSectionPostMobile"
              color="#fff"
              mb="1.5rem"
            >
              {t('title')}
            </Typography>
            <Typography
              variant="textPostDesktop"
              color="#fff"
              mb={isMobile ? '1.5rem' : '3.5rem'}
            >
              {t('subtitle')}
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={onClickPublicar}
              sx={{ width: 200, height: '2.625rem' }}
            >
              {t('button')}
            </Button>
          </StyledContinerInfo>
          <TestimonialSlider testimonials={testimonials} />
        </Box>
      </StyledBackground>
    </>
  );
};

export default TestimonialSection;
