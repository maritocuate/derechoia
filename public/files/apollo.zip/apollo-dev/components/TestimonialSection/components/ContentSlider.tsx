import React from 'react';
import Image from 'next/image';
import { Box, styled, Typography } from '@mui/material';
import useIsMobile from '../../../hooks/useIsMobile';
import { ITestimonial } from '../interfaces/interfaces';
import imageLoaderTestimonials from '../../../utils/helpers/imageLoaders/imageLoaderTestimonials';
import formatUrlWithCdnLink from '../../../utils/helpers/formatUrlWithCdnLink';

const StyledImageContainer = styled(Box)(
  ({ theme }) => `
  display: flex;
  align-content: center;
  flex-direction: column;
  height: 30.875rem;
  justify-content: center;
  margin: auto;
  width: 16.938rem;
  ${theme.breakpoints.up('lg')}{
    height: 28.588rem;
    width: 18.938rem;
  }
`,
);

const StyledImage = styled(Image)`
  border-radius: 100%;
`;

const StyledProfileContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  width: 100%;
`;

const StyledTextContainer = styled(Box)`
  display: flex;
  align-content: center;
  flex-direction: column;
  justify-content: center;
  margin-left: 1rem;
`;

const ContentSlider = ({ img, title, subtitle, text }: ITestimonial) => {
  const isMobile = useIsMobile();

  return (
    <StyledImageContainer>
      <Image src="/images/Marks.svg" alt="" width={30} height={30} />
      <Box m="1.5rem 0 2rem 0">
        <Typography variant="testimonial">{text}</Typography>
      </Box>
      <StyledProfileContainer>
        <StyledImage
          src={formatUrlWithCdnLink(img)}
          alt={title}
          loader={imageLoaderTestimonials}
          width={80}
          height={80}
        />
        <StyledTextContainer>
          <Typography
            variant={isMobile ? 'contentTitle' : 'onlineBookintTitle'}
            gutterBottom
          >
            {title}
          </Typography>
          <Typography variant="orderText">{subtitle}</Typography>
        </StyledTextContainer>
      </StyledProfileContainer>
    </StyledImageContainer>
  );
};

export default ContentSlider;
