import React, { useState, useCallback } from 'react';
import Carousel from 'react-material-ui-carousel';
import { Paper, styled } from '@mui/material';
import useIsMobile from '../../../hooks/useIsMobile';
import { ITestimonial } from '../interfaces/interfaces';
import ContentSlider from './ContentSlider';

const StyledSliderContainer = styled(Paper)(
  ({ theme }) => `
    border-radius: 0 0 0.5rem 0.5rem;
    width: 100%;
    height: 37.625rem;
    padding: 1.5rem;
    margin: auto;
    max-width: 37.5rem;
    ${theme.breakpoints.up('lg')}{
      border-radius: 0 0.5rem 0.5rem 0;
      width: 30.813rem;
      height: 37.5rem;
      padding: 3.469rem 2rem 3.469rem 2rem;
    }
`,
);

const carouselStyles = {
  navButton: {
    backgroundColor: 'transparent',
    color: 'rgba(0, 0, 0, 0.54)',
    height: '2.188rem',
    width: '2.188rem',
  },
  navButtonMobile: {
    backgroundColor: 'transparent',
    color: 'rgba(0, 0, 0, 0.54)',
    height: '2.188rem',
    width: '2.188rem',
    marginTop: -150,
  },
  activeIndicatorIconButton: {
    color: '#00ACC1',
    transform: 'scale(1)',
    margin: '1rem 0.2rem',
  },
  indicatorIconButton: {
    color: '#E6E6E6',
    transform: 'scale(1)',
    margin: '1rem 0.2rem',
  },
};

const TestimonialSlider = ({
  testimonials,
}: {
  testimonials: ITestimonial[];
}) => {
  const [active, setActive] = useState<number>(0);
  const isMobile = useIsMobile();

  const handleNext = useCallback(() => {
    setActive((prevIndex) => (prevIndex + 1) % testimonials.length);
  }, [testimonials.length]);

  const handlePrev = useCallback(() => {
    setActive(
      (prevIndex) =>
        (prevIndex - 1 + testimonials.length) % testimonials.length,
    );
  }, [testimonials.length]);

  return (
    <StyledSliderContainer elevation={isMobile ? 0 : 3}>
      <Carousel
        autoPlay
        index={active}
        animation="slide"
        navButtonsAlwaysVisible={!isMobile}
        navButtonsAlwaysInvisible={isMobile}
        interval={8000}
        stopAutoPlayOnHover
        navButtonsProps={{
          style: isMobile
            ? carouselStyles.navButtonMobile
            : carouselStyles.navButton,
        }}
        activeIndicatorIconButtonProps={{
          style: carouselStyles.activeIndicatorIconButton,
        }}
        indicatorIconButtonProps={{
          style: carouselStyles.indicatorIconButton,
        }}
        next={handleNext}
        prev={handlePrev}
        indicators
        fullHeightHover={false}
      >
        {testimonials &&
          testimonials.map((testimonial, index) => (
            <ContentSlider
              key={`${testimonial.title}-${index}`}
              img={testimonial.img}
              title={testimonial.title}
              subtitle={testimonial.subtitle}
              text={testimonial.text}
            />
          ))}
      </Carousel>
    </StyledSliderContainer>
  );
};

export default TestimonialSlider;
