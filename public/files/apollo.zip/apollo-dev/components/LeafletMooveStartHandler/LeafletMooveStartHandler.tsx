import { useMapEvents } from 'react-leaflet';

const LeafletMoovStartHandler = ({ callback }: { callback: () => void }) => {
  useMapEvents({
    movestart: () => {
      if (callback) callback();
    },
  });
  return null;
};

export default LeafletMoovStartHandler;
