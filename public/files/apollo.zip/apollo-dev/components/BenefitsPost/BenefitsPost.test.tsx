import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import BenefitsPost from './BenefitsPost';

describe('BenefitsPost', () => {
  it('Render Container and Elements', () => {
    render(<BenefitsPost />);
    const containerElement = screen.getByTestId('benefits-container');
    expect(containerElement).toBeInTheDocument();
    const imageContainer1 = screen.getByTestId('benefits-image-container-1');
    const imageContainer2 = screen.getByTestId('benefits-image-container-2');
    const imageContainer3 = screen.getByTestId('benefits-image-container-3');

    expect(imageContainer1).toBeInTheDocument();
    expect(imageContainer2).toBeInTheDocument();
    expect(imageContainer3).toBeInTheDocument();
  });
});
