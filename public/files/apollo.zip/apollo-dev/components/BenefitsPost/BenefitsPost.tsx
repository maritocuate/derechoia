import { Box, Typography, styled } from '@mui/material';
import Image from 'next/image';
import React from 'react';

const benefitsData = [
  {
    id: 1,
    alt: 'Benefits-1',
    src: '/images/Beneficios-1.png',
    text: 'Facturación en pesos',
    testId: 'benefits-image-container-1',
  },
  {
    id: 2,
    alt: 'Benefits-2',
    src: '/images/Beneficios-2.png',
    text: 'Contacto directo con turistas',
    testId: 'benefits-image-container-2',
  },
  {
    id: 3,
    alt: 'Benefits-3',
    src: '/images/Beneficios-3.png',
    text: 'Software de gestión gratuito',
    testId: 'benefits-image-container-3',
  },
];

const StyledContainer = styled(Box)(
  ({ theme }) => `
    padding: 2rem 1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    text-align: center;
    gap: 2rem;
    background-color: #f5f5f5;
    ${theme.breakpoints.up('sm')}{
      padding: 5rem 0rem;
    }
  `,
);

const StyledListContainer = styled(Box)(
  ({ theme }) => `
  padding-top: 1.5rem;
  display: flex;
  flex-direction: column;
  text-align: center;
  justify-content: center;
  gap: 1.5rem;
  ${theme.breakpoints.up('lg')}{
    width: 72.5rem;
    padding: 1.5rem 1rem 0 1rem;    
    justify-content: space-between;
    margin: 0 auto;
    flex-direction: row;
}
`,
);

const StyledListItem = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  align-items: center;
  ${theme.breakpoints.up('sm')}{
  }
`,
);

const StyledImageText = styled(Box)(
  ({ theme }) => `
  max-width: 15rem;
  ${theme.breakpoints.up('sm')}{
    max-width: 100%;
  }
`,
);
const BenefitsPost = () => {
  return (
    <StyledContainer data-testid="benefits-container">
      <Box textAlign="center">
        <Typography variant="benefitsTitle" component="h2">
          Beneficios de publicar en Alquiler Argentina
        </Typography>
      </Box>
      <StyledListContainer>
        {benefitsData.map((benefit) => (
          <StyledListItem
            gap="0.5rem"
            key={benefit.id}
            data-testid={benefit.testId}
          >
            <Box>
              <Image
                alt={benefit.alt}
                width={200}
                height={200}
                src={benefit.src}
              />
            </Box>
            <StyledImageText>
              <Typography variant="benefitsText" marginBlock="1rem">
                {benefit.text}
              </Typography>
            </StyledImageText>
          </StyledListItem>
        ))}
      </StyledListContainer>
    </StyledContainer>
  );
};

export default BenefitsPost;
