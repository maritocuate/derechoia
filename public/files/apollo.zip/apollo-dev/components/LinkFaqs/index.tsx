import React from 'react';
import Link from 'next/link';

interface IHostProfile {
  url: string;
  title: string;
  linkText: string;
  textBody?: string;
}

export default function LinkFaq({
  title,
  url,
  linkText,
  textBody,
}: IHostProfile) {
  return (
    <span>
      {title}
      <Link
        passHref
        href={url}
        style={{
          textDecoration: 'underline',
          fontWeight: '400',
          fontSize: '1rem',
        }}
      >
        {linkText}
      </Link>
      {textBody}
    </span>
  );
}
