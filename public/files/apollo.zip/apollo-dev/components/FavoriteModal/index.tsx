import React, { memo } from 'react';
import { Box, styled, Typography, Button } from '@mui/material';
import Modal, {
  VARIANTS as VARIANTS_MODAL,
} from '@alquiler-argentina/demiurgo/components/Modal';
import LoginOutlined from '@mui/icons-material/LoginOutlined';
import { useTranslation } from 'react-i18next';
import useIsMobile from '../../hooks/useIsMobile';

const StyledIcon = styled(LoginOutlined)`
  font-size: 5rem;
`;

const StyledTypograpy = styled(Typography)`
  color: #000000de;
`;

const StyledButton = styled(Button)`
  width: 14.75rem;
  height: 2.6rem;
`;

const StyledBox = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 1rem;
  flex-direction: column;
  text-align: center;
  border-radius: 0.3rem;
  overflow: hidden;
  background-color: #fff;
  padding: 1.5rem;
`;

const FavoriteModal = ({
  onClickLogin,
  onClose,
}: {
  onClickLogin: () => void;
  onClose: () => void;
}) => {
  const handleClick = () => {
    onClickLogin();
    onClose();
  };
  const isMobile = useIsMobile();
  const { t } = useTranslation('FavoriteModal');
  return (
    <Modal
      variant={VARIANTS_MODAL.MODAL}
      title={t('main-title')}
      onClose={onClose}
      handleClose={onClose}
      open
    >
      <StyledBox
        data-testid="container-modal"
        width={isMobile ? '100%' : '30rem'}
      >
        <Box data-testid="svg-modal">
          <StyledIcon color="primary" />
        </Box>
        <Box textAlign="center">
          <StyledTypograpy
            data-testid="text-modal"
            fontSize="1.5rem"
            fontWeight={600}
          >
            {t('title')}
          </StyledTypograpy>
          <StyledTypograpy margin="1rem 0 1rem 0">{t('text')}</StyledTypograpy>
        </Box>
        <StyledButton
          data-testid="button-modal"
          variant="contained"
          color="primary"
          onClick={handleClick}
        >
          <Typography>{t('ingress')}</Typography>
        </StyledButton>
      </StyledBox>
    </Modal>
  );
};

export default memo(FavoriteModal);
