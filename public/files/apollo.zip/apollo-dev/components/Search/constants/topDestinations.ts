import { IOption } from '../../../redux/search/type';

export const topDestinations: IOption[] = [
  {
    tipo: 'localidad',
    provincia: 'Buenos Aires',
    pais: 'Argentina',
    nombre: 'Ciudad de Buenos Aires',
    groupText: 'Destinos más populares',
    topDestination: true,
  },
  {
    tipo: 'localidad',
    provincia: 'Buenos Aires',
    pais: 'Argentina',
    nombre: 'Mar Del Plata',
    groupText: 'Destinos más populares',
    topDestination: true,
  },
  {
    tipo: 'localidad',
    provincia: 'Río Negro',
    pais: 'Argentina',
    nombre: 'San Carlos De Bariloche',
    groupText: 'Destinos más populares',
    topDestination: true,
  },
  {
    tipo: 'localidad',
    provincia: 'Mendoza',
    pais: 'Argentina',
    nombre: 'Ciudad De Mendoza',
    groupText: 'Destinos más populares',
    topDestination: true,
  },
  {
    tipo: 'localidad',
    provincia: 'Misiones',
    pais: 'Argentina',
    nombre: 'Puerto Iguazú',
    groupText: 'Destinos más populares',
    topDestination: true,
  },
];
