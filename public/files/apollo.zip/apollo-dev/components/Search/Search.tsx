import { styled, Box, Button } from '@mui/material';
import React, { memo, useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { useSelector } from 'react-redux';
import CalendarSearch from './components/CalendarSearch/CalendarSearch';
import SelectPeopleSearch from './components/SelectPeopleSearch/SelectPeopleSearch';
import Autocomplete from './components/Autocomplete/AutoComplete';

import { ICheckoutState } from '../../redux/checkout/types';
import { isServer } from '../../constants/commons';

dayjs.locale('es');

interface SearchSectionProps {
  isSearchButton?: boolean;
  tooltip?: true;
  isDisabled: boolean;
  onClick: () => void;
  tooltipAutocomplete?: boolean;
  setTooltipAutocomplete?: (newVal: boolean) => void;
}

export type Ref = Element | ((element: Element) => Element) | null | undefined;

const CLEANSTATE = {
  autocomplete: false,
  calendar: false,
  selectPeople: false,
};

const StyledSection = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  width: 100%;
  max-width: 37.5rem;
  ${({ theme }) => theme.breakpoints.up('lg')} {
    flex-direction: row;
    max-width: 75rem;
  }
`;

const StyledSearchContent = styled(Box)`
  display: flex;
  border: solid 1px rgba(0, 0, 0, 0.23);
  border-radius: 4px;
  background: white;
  width: 100%;
  z-index: 10;
  ${(props) => props.theme.breakpoints.up('lg')} {
    width: 940px;
  }
`;

const StyledContainer = styled(Box)(
  ({ theme }) => `
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr auto;
  width: 100%;
  min-height: 120px;
  ${theme.breakpoints.up('lg')} {
    min-height: 100%;
    grid-template-columns: 50% repeat(3, 1fr);
    grid-template-rows: 1fr;
  }
`,
);

const StyledButtonSearch = styled(Button)(
  ({ theme }) => `
  margin-top: 0.75rem;
  width: 100%;
 ${theme.breakpoints.up('lg')}{
  width: auto;
  margin: 0;
  margin-left: 1rem;
 }
`,
);

function Search({
  isSearchButton,
  tooltip,
  isDisabled,
  onClick,
  tooltipAutocomplete,
  setTooltipAutocomplete,
}: SearchSectionProps) {
  const { startDate, endDate } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const [isOpen, setIsOpen] = useState({
    tooltip: false,
    autocompleteTooltip: false,
    calendar: false,
    selectPeople: false,
  });

  //
  const handleChangeOpenSelectPeople = useCallback(
    (newValue: boolean) => {
      setIsOpen((prev) => ({
        ...prev,
        ...CLEANSTATE,
        selectPeople: newValue,
        tooltip: tooltip && !(startDate && endDate) ? !newValue : prev.tooltip,
      }));
    },
    [endDate, startDate, tooltip],
  );
  const handleChangeCalendar = useCallback(
    (newValue: boolean) => {
      setIsOpen((prev) => ({
        ...prev,
        ...CLEANSTATE,
        calendar: newValue,
        tooltip: tooltip && !(startDate && endDate) ? !newValue : prev.tooltip,
      }));
    },
    [endDate, startDate, tooltip],
  );
  const handleChangeDesktop = useCallback(
    (newValue: boolean) => {
      if (startDate && endDate) return;
      handleChangeCalendar(newValue);
    },
    [endDate, handleChangeCalendar, startDate],
  );
  useEffect(() => {
    if (!isServer && tooltip) {
      setIsOpen((prev) => ({
        ...prev,
        tooltip: !(startDate && endDate),
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [endDate]);

  //
  return (
    <StyledSection>
      <StyledSearchContent>
        <StyledContainer>
          <Autocomplete
            onClick={handleChangeDesktop}
            tooltip={tooltipAutocomplete || false}
            setTooltipAutocomplete={setTooltipAutocomplete}
          />
          {/* calendar */}

          <CalendarSearch
            tooltip={isOpen.tooltip}
            open={isOpen.calendar}
            onClick={handleChangeCalendar}
          />

          {/* selectPeople */}
          <SelectPeopleSearch
            open={isOpen.selectPeople}
            onClick={handleChangeOpenSelectPeople}
          />
        </StyledContainer>
      </StyledSearchContent>
      {!!isSearchButton && (
        <StyledButtonSearch
          variant="contained"
          color="primary"
          size="large"
          disabled={!isDisabled}
          onClick={() => {
            onClick();
          }}
        >
          Buscar
        </StyledButtonSearch>
      )}
    </StyledSection>
  );
}
export default memo(Search);
