import React, { memo, useCallback, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';
import { ICheckoutState } from '../../../../redux/checkout/types';
import { changePassengers } from '../../../../redux/checkout/slice';

import ItemContainer from '../ItemContainer/ItemContainer';
import { StyledTypographyInput } from '../StyledTypographyInput/StyledTypographyInput';
import useIsMobile from '../../../../hooks/useIsMobile';

const SelectPeopleSearchDesk = dynamic(
  () => import('../../../SelectPeopleSearchDesk/SelectPeopleSearchDesk'),
  { ssr: false },
);
const SelectPeopleSearchMobile = dynamic(
  () => import('../../../SelectPeopleSearchMobile/SelectPeopleSearchMobile'),
  { ssr: false },
);

const SelectPeopleSearch = ({
  open,
  onClick,
}: {
  open: boolean;
  onClick: (newValue: boolean) => void;
}) => {
  const dispatch = useDispatch();
  const isMobile = useIsMobile();
  const ref = useRef(null);
  const { adultos, bebes, personas, menores, mascotas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const handleChangePersons = useCallback(
    (key: string, val: unknown) => {
      dispatch(
        changePassengers({
          adultos: (key === 'adults' ? val : adultos) as number,
          mascotas: (key === 'mascotas' ? val : mascotas) as boolean,
          menores: (key === 'children' ? val : menores) as number,
          bebes: (key === 'babies' ? val : bebes) as number,
        }),
      );
    },
    [adultos, bebes, dispatch, mascotas, menores],
  );
  return (
    <Box ref={ref}>
      <ItemContainer label="Huéspedes" onClick={() => onClick(true)}>
        <StyledTypographyInput>
          {personas} {personas === 1 ? 'persona' : 'personas'}
        </StyledTypographyInput>
      </ItemContainer>
      {isMobile && (
        <SelectPeopleSearchMobile
          adults={adultos}
          peoples={personas}
          babies={bebes}
          children={menores}
          pets={mascotas}
          handleChangePersons={handleChangePersons}
          setOpenSelectPeopleModal={onClick}
          openSelectPeopleModal={open}
        />
      )}
      {!isMobile && (
        <SelectPeopleSearchDesk
          adults={adultos}
          peoples={personas}
          babies={bebes}
          children={menores}
          pets={mascotas}
          handleChangePersons={handleChangePersons}
          setOpenSelectPeopleModal={onClick}
          openSelectPeopleModal={open}
          anchorEl={ref.current}
        />
      )}
    </Box>
  );
};

export default memo(SelectPeopleSearch);
