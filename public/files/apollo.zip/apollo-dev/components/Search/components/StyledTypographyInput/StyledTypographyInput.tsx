import { Typography, styled } from '@mui/material';

export const StyledTypographyInput = styled(Typography)(`
  display: flex;
  align-items: flex-end;
  font-size: 0.875rem;
  font-weight: 700;
  height: 100%;
  line-height: 1.1;
  user-select: none;
  cursor: pointer;
  text-transform: capitalize;
`);
