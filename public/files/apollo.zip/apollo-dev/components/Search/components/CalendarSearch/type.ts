import { DateRange } from '@mui/lab';
import { Dayjs } from 'dayjs';

export interface CalendarSearchProps {
  isDisable: boolean;
  isOpenCalendar: boolean;
  startDate: string | null;
  endDate: string | null;
  onClickOpenCalendar: (boolean: boolean) => void;
  handleChangeDates: (dates: DateRange<Dayjs>) => void;
  anchorEl?: Element | ((element: Element) => Element) | null;
  onClose: () => void;
  tooltip?: boolean;
}
