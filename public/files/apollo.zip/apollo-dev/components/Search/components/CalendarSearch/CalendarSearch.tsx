import React, { memo, useCallback, useMemo } from 'react';
import { Dayjs } from 'dayjs';
import { DateRange } from '@mui/lab';
import { useDispatch, useSelector } from 'react-redux';
import dynamic from 'next/dynamic';
import useIsMobile from '../../../../hooks/useIsMobile';
import { ICheckoutState } from '../../../../redux/checkout/types';
import { changeDates } from '../../../../redux/checkout/slice';

const CalendarSearchMobile = dynamic(
  () => import('../../../CalendarSearchMobile/CalendarSearchMobile'),
);
const CalendarSearchDesk = dynamic(
  () => import('../../../CalendarSearchDesk/CalendarSearchDesk'),
);

const CalendarSearch = ({
  tooltip,
  open,
  onClick,
}: {
  tooltip?: boolean;
  open: boolean;
  onClick: (newValue: boolean) => void;
}) => {
  const dispatch = useDispatch();
  const isMobile = useIsMobile();

  const { startDate, endDate } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );

  const handleChangeDates = useCallback(
    (dates: DateRange<Dayjs>) => {
      if (
        startDate === dates?.[0]?.format('YYYYMMDD') &&
        endDate === dates?.[1]?.format('YYYYMMDD')
      ) {
        return;
      }
      dispatch(
        changeDates({
          startDate: dates?.[0]?.isValid() ? dates[0].format('YYYYMMDD') : null,
          endDate: dates?.[1]?.isValid() ? dates[1].format('YYYYMMDD') : null,
        }),
      );
    },
    [dispatch, endDate, startDate],
  );
  const handleClearDates = useCallback(() => {
    if (startDate && !endDate)
      dispatch(
        changeDates({
          startDate: null,
          endDate: null,
        }),
      );
  }, [dispatch, endDate, startDate]);
  const isDisable = useMemo(
    () => !(startDate && endDate && startDate !== endDate),
    [endDate, startDate],
  );
  return (
    <>
      {isMobile && (
        <CalendarSearchMobile
          isDisable={isDisable}
          isOpenCalendar={open}
          startDate={startDate}
          endDate={endDate}
          onClickOpenCalendar={onClick}
          handleChangeDates={handleChangeDates}
          onClose={handleClearDates}
          tooltip={tooltip}
        />
      )}
      {!isMobile && (
        <CalendarSearchDesk
          isDisable={isDisable}
          isOpenCalendar={open}
          startDate={startDate}
          endDate={endDate}
          onClickOpenCalendar={onClick}
          handleChangeDates={handleChangeDates}
          onClose={handleClearDates}
          tooltip={tooltip}
        />
      )}
    </>
  );
};

export default memo(CalendarSearch);
