import React from 'react';
import { AutocompleteRenderGroupParams, Box, Typography } from '@mui/material';

export const GroupComponent = ({
  group,
  children,
}: AutocompleteRenderGroupParams) => {
  return (
    <Box padding="1rem">
      {!!group && (
        <Typography variant="subtitle1" fontWeight={600} color="#000000">
          {group}
        </Typography>
      )}
      {children}
    </Box>
  );
};
