import { ILastSearchItem } from '../../../../../redux/lastSearchs/type';
import { getUrlQueryToBrowser } from '../../../../../utils/helpers/FormattersList';

const formatUrlDestination = ({
  adults,
  youngs,
  startDate,
  endDate,
  province,
  city,
}: ILastSearchItem) => {
  const UrlToBrowserFilters = getUrlQueryToBrowser({
    adults,
    youngs,
    startDate,
    endDate,
  });
  const urlDestination = `/${encodeURI(province.replaceAll(' ', '-'))}/${
    !city ? '' : `${encodeURIComponent(city.replaceAll(' ', '-'))}/`
  }${!UrlToBrowserFilters ? '' : `${UrlToBrowserFilters}/`}`;
  return urlDestination;
};

export default formatUrlDestination;
