import { useCallback, useEffect, useState } from 'react';
import { AutocompleteInputChangeReason } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import useIsMobile from '../../../../../hooks/useIsMobile';
import useDebounce from '../../../../../hooks/useDebounce/useDebounce';
import {
  changeSearch,
  selectDestination,
} from '../../../../../redux/search/slice';
import { IOption, ISearchState } from '../../../../../redux/search/type';
import { textDestinationFormatter } from '../../../utils/helpers';
import { useGetBuscarQuery } from '../../../../../services/buscar';
import { isServer } from '../../../../../constants/commons';
import { IAppStatusState } from '../../../../../redux/appStatus/types';

export const useAutocomplete = (
  onClick: (newValue: boolean) => void,
  tooltip: boolean,
  handleSetAutocompleteTooltip?: (newValue: boolean) => void,
) => {
  const { destination, inputSearchValue } = useSelector(
    ({ search }: { search: ISearchState }) => search,
  );
  const { page } = useSelector(
    ({ appStatus }: { appStatus: IAppStatusState }) => appStatus,
  );
  const isMobile = useIsMobile();
  const dispatch = useDispatch();
  const [autocompleteState, setAutocompleteState] = useState({
    mounted: false,
    isLoading: true,
  });
  const { debouncedCallback, cancel } = useDebounce<string>(
    (newInputSearchValue) => {
      dispatch(changeSearch({ inputSearchValue: newInputSearchValue }));
    },
    380,
  );

  const { data: dataSuggestion = [], status } = useGetBuscarQuery();
  const [inputValue, setInputValue] = useState(
    textDestinationFormatter(destination) || '',
  );

  const handleSetInputValue = useCallback(
    (_e: unknown, newValue: string, reason: AutocompleteInputChangeReason) => {
      if (reason === 'reset') return;

      if (!newValue) {
        setInputValue(newValue);

        if (newValue !== inputSearchValue) debouncedCallback(newValue);

        if (!isMobile && handleSetAutocompleteTooltip) {
          handleSetAutocompleteTooltip(true);
        }
        return;
      }

      if (textDestinationFormatter(destination) === newValue) {
        setInputValue('');
        debouncedCallback('');
        return;
      }
      setInputValue(newValue);
      cancel();
      debouncedCallback(newValue);
    },

    [
      cancel,
      debouncedCallback,
      destination,
      handleSetAutocompleteTooltip,
      inputSearchValue,
      isMobile,
    ],
  );
  const handleClearSetInputValue = useCallback(() => {
    setAutocompleteState((prev) => ({
      ...prev,
      mounted: false,
    }));
    debouncedCallback('');
    setInputValue('');
  }, [debouncedCallback]);
  const handleSetDestination = useCallback(
    (val: IOption, isOpenModal = true) => {
      let selectedVal = val;
      if (val?.id_alias) {
        const foundVal = dataSuggestion.find(
          (item) => item.id === val.id_alias,
        );
        if (foundVal) {
          selectedVal = foundVal;
        }
      }
      if (selectedVal?.nombre) {
        setInputValue(textDestinationFormatter(val));
      }
      dispatch(
        selectDestination({
          ...selectedVal,
        }),
      );
      if (tooltip) {
        return (
          !!handleSetAutocompleteTooltip && handleSetAutocompleteTooltip(false)
        );
      }
      onClick(isOpenModal);
    },
    [dispatch, tooltip, onClick, dataSuggestion, handleSetAutocompleteTooltip],
  );

  const onOpen = () => {
    if (handleSetAutocompleteTooltip) {
      handleSetAutocompleteTooltip(false);
    }
  };
  useEffect(() => {
    if (!isServer) {
      setAutocompleteState((prev) => ({
        ...prev,
        mounted: true,
      }));

      if (!inputSearchValue && !autocompleteState.isLoading) {
        setAutocompleteState((prev) => ({
          ...prev,
          mounted: false,
          isLoading: true,
        }));
      }
    }
  }, [
    autocompleteState.isLoading,
    autocompleteState.mounted,
    inputSearchValue,
    inputValue,
  ]);

  useEffect(() => {
    if (!isServer) {
      if (
        status === 'fulfilled' &&
        autocompleteState.isLoading &&
        inputSearchValue
      ) {
        setAutocompleteState((prev) => ({
          ...prev,
          isLoading: false,
        }));
      }
    }
  }, [status, autocompleteState, inputSearchValue]);

  return {
    dataSuggestion,
    handleSetDestination,
    isMobile,
    handleClearSetInputValue,
    handleSetInputValue,
    inputValue,
    destination,
    inputSearchValue,
    autocompleteState,
    onOpen,
    page,
  };
};
