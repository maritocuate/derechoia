import { AutocompleteInputChangeReason } from '@mui/material';
import { ILastSearchState } from '../../../../redux/lastSearchs/type';
import type { IOption, VirtualElement } from '../../../../redux/search/type';

export type AnchorEl =
  | VirtualElement
  | (() => VirtualElement)
  | null
  | undefined;

export type SetInputValueProps = (
  e: unknown,
  newValue: string,
  reason: AutocompleteInputChangeReason,
) => void;
export interface AutoCompleteProps {
  value: IOption;
  inputValue: string;
  options: IOption[];
  setValue: (state: IOption, isOpenCalendar?: boolean) => void;
  setInputValue: SetInputValueProps;
  isMobile?: boolean;
  lastsDestination?: ILastSearchState['destinations'];
  topDestinations?: IOption[];
  inputSearchValue?: string;
  isLoading?: boolean;
  clearInputValue?: () => void;
  tooltip: boolean;
  handleTooltip?: (newValue: boolean) => void;
  onOpen?: () => void;
}
