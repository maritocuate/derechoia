import React, { memo } from 'react';
import SearchOutlined from '@mui/icons-material/SearchOutlined';
import { Box, BoxProps, Typography } from '@mui/material';
import StyledLi from '../StyledLi/StyledLi';

interface ItemListLastDestinationProps extends BoxProps<'li'> {
  primaryText: string;
  secondaryText: string;
  onClick?: (event: React.MouseEvent<HTMLLIElement>) => void;
}

const ItemListLastDestination = ({
  primaryText,
  secondaryText,
  onClick,
  ...props
}: ItemListLastDestinationProps) => {
  return (
    <Box component="li" onClick={onClick} {...props} sx={{ cursor: 'pointer' }}>
      <StyledLi>
        <SearchOutlined color="disabled" />
        <Box display="flex" flexDirection="column">
          <Typography variant="autocompleteOptionMobile">
            {primaryText}
            <Typography variant="body2" color="grey[600]">
              {secondaryText}
            </Typography>
          </Typography>
        </Box>
      </StyledLi>
    </Box>
  );
};

export default memo(ItemListLastDestination);
