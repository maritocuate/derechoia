import React, { memo, useMemo } from 'react';

import dynamic from 'next/dynamic';
import { useSelector } from 'react-redux';
import { topDestinations } from '../../constants/topDestinations';
import { useAutocomplete } from './hooks/useAutocomplete';
import AutocompleteMobile from '../../../AutocompleteMobile/AutocompleteMobile';
import {
  ILastSearchItem,
  ILastSearchState,
} from '../../../../redux/lastSearchs/type';
import { IOption } from '../../../../redux/search/type';
import { isCountry } from '../../../../serverSide/managers/formatters/destination.formatter';

const AutoCompleteDesktop = dynamic(
  () => import('../../../AutocompleteDesktop/AutocompleteDesktop'),
);

const checkType = ({ province, city }: ILastSearchItem) => {
  if (isCountry(province || '')) return 'país';
  if (city) return 'localidad';
  return 'provincia';
};

const Autocomplete = ({
  onClick,
  tooltip,
  setTooltipAutocomplete,
}: {
  onClick: (newValue: boolean) => void;
  tooltip: boolean;
  setTooltipAutocomplete?: (newVal: boolean) => void;
}) => {
  const {
    dataSuggestion,
    handleSetDestination,
    isMobile,
    handleClearSetInputValue,
    handleSetInputValue,
    inputValue,
    destination,
    inputSearchValue,
    autocompleteState,
    onOpen,
    page,
  } = useAutocomplete(onClick, tooltip, setTooltipAutocomplete);
  const { destinations: lastDestinations } = useSelector(
    ({ lastSearchs }: { lastSearchs: ILastSearchState }) => lastSearchs,
  );

  const lastDestinationsMemo = useMemo(() => {
    const isHome = page === 'home';
    const lastDestinationsFormatted: ILastSearchItem[] = lastDestinations.slice(
      isHome ? 0 : 1,
      isHome ? 3 : 4,
    );
    return lastDestinationsFormatted;
  }, [lastDestinations, page]);

  const initialDataDesk = useMemo(() => {
    const lastDestinationsFormattedDesk: IOption[] = lastDestinationsMemo.map(
      (element) => ({
        ...element,
        tipo: checkType(element),
        nombre: element.city || element.province,
        provincia: element.province,
        localidad: element.city,
        groupText: 'Búsquedas recientes',
      }),
    );
    if (!lastDestinationsMemo.length) return topDestinations;
    if (lastDestinationsMemo.length === 1)
      return [...lastDestinationsFormattedDesk, ...topDestinations];
    return lastDestinationsFormattedDesk;
  }, [lastDestinationsMemo]);
  return (
    <>
      {isMobile && (
        <AutocompleteMobile
          lastsDestination={lastDestinationsMemo}
          topDestinations={topDestinations}
          value={destination}
          setValue={handleSetDestination}
          setInputValue={handleSetInputValue}
          options={dataSuggestion}
          inputValue={inputValue}
          isMobile={isMobile}
          inputSearchValue={inputSearchValue}
          clearInputValue={!inputValue ? undefined : handleClearSetInputValue}
          tooltip={tooltip}
          handleTooltip={setTooltipAutocomplete}
        />
      )}
      {!isMobile && (
        <AutoCompleteDesktop
          lastsDestination={lastDestinationsMemo}
          value={destination}
          setValue={handleSetDestination}
          setInputValue={handleSetInputValue}
          options={!inputValue ? initialDataDesk : dataSuggestion}
          inputValue={inputValue}
          isMobile={isMobile}
          isLoading={autocompleteState.isLoading} // || autocompleteState.isLoading
          tooltip={tooltip}
          handleTooltip={setTooltipAutocomplete}
          onOpen={onOpen}
        />
      )}
    </>
  );
};
export default memo(Autocomplete);

/* 

1) Cuando el autocomplete esté desmontado -> aparece top destinations

2) Cuando el autocomplete esté vacio --> aparece top destinations 

3) Cuando el autocomplete tiene un nuevo destino --> aparece top destinations 

*/
