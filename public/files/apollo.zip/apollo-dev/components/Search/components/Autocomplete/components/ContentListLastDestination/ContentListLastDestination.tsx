import React, { memo } from 'react';
import { useRouter } from 'next/router';
import { ILastSearchItem } from '../../../../../../redux/lastSearchs/type';
import ItemListLastDestination from '../ItemListLastDestination/ItemListLastDestination';
import formatSecondaryTextLastDestinations from '../../helpers/secondaryTextLastDestinations';
import formatUrlDestination from '../../helpers/formatUrlDestination';
import { IOption } from '../../../../../../redux/search/type';

interface ContentListDestinationsProps {
  lastDestinations: ILastSearchItem[];
  onClick: (newDestination?: IOption) => void;
}

const ContentListLastDestination = ({
  lastDestinations,
  onClick,
}: ContentListDestinationsProps) => {
  const { push } = useRouter();

  if (!lastDestinations.length) return null;
  return (
    <>
      {lastDestinations.map((destination, index) => {
        return (
          <ItemListLastDestination
            primaryText={
              destination.city ? destination.city : destination.province
            }
            onClick={() => {
              onClick({
                ...destination,
                groupText: 'Búsquedas recientes',
              } as IOption);
              push(`${formatUrlDestination(destination)}`)
                .then(() => {})
                .finally(() => {});
            }}
            secondaryText={formatSecondaryTextLastDestinations(destination)}
            key={`key--${index}${destination.city}`}
          />
        );
      })}
    </>
  );
};

export default memo(ContentListLastDestination);
