import { ILastSearchItem } from '../../../../../redux/lastSearchs/type';
import formatDateDayMonth from '../../../../../utils/helpers/FormatDateDayMonth';

const formatSecondaryTextLastDestinations = ({
  startDate,
  endDate,
  youngs = 0,
  adults = 2,
}: ILastSearchItem) => {
  const numberOfPeople = adults + youngs;
  const peopleText = `${numberOfPeople} ${
    numberOfPeople === 1 ? 'persona' : 'personas'
  }`;
  if (!formatDateDayMonth(startDate) || !endDate) return peopleText;
  return `${formatDateDayMonth(startDate)} - ${formatDateDayMonth(
    endDate,
  )} • ${peopleText}`;
};

export default formatSecondaryTextLastDestinations;
