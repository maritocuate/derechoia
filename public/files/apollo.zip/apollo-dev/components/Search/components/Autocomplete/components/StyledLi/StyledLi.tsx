import { styled } from '@mui/material';

const StyledLi = styled('li')(
  ({ theme }) => `
      display: flex;
      align-items: center;
      list-style: none;
      min-height: 5.5rem;
      width: 100%;
      padding: 1rem;
      border-bottom: solid 1px ${theme.palette.grey[100]};`,
);

export default StyledLi;
