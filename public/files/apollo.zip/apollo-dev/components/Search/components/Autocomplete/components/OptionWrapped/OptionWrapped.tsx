import { Box, TypographyProps, styled, Typography } from '@mui/material';
import React, { HTMLAttributes, memo } from 'react';
import LocationOnOutlined from '@mui/icons-material/LocationOnOutlined';
import { useRouter } from 'next/router';
import { IOption } from '../../../../../../redux/search/type';
import { textDestinationFormatter } from '../../../../utils/helpers';
import ItemListLastDestination from '../ItemListLastDestination/ItemListLastDestination';
import formatSecondaryTextLastDestinations from '../../helpers/secondaryTextLastDestinations';
import { ILastSearchItem } from '../../../../../../redux/lastSearchs/type';
import formatUrlDestination from '../../helpers/formatUrlDestination';

const OptionTypography = styled(Typography)<TypographyProps>(`
font-weight: 400;
font-size: 1rem;
margin-left: 1.313rem;
`);

const OptionWrapped = ({
  props,
  optionsProps,
}: {
  props: HTMLAttributes<HTMLLIElement>;
  optionsProps: IOption;
}) => {
  const { push } = useRouter();
  if (optionsProps.groupText === 'Búsquedas recientes') {
    return (
      <Box
        onClick={() => {
          push(formatUrlDestination(optionsProps as ILastSearchItem)).finally(
            () => {},
          );
        }}
      >
        <ItemListLastDestination
          primaryText={optionsProps.nombre || ''}
          secondaryText={formatSecondaryTextLastDestinations(
            optionsProps as ILastSearchItem,
          )}
          {...props}
          aria-selected={false}
          key={`key--${optionsProps.nombre}`}
        />
      </Box>
    );
  }
  return (
    <Box
      component="li"
      {...props}
      height={64}
      width="100%"
      aria-selected={false}
      key={`${optionsProps.nombre}-keyBox`}
    >
      <LocationOnOutlined color="primary" />
      <OptionTypography
        variant="body1"
        color="initial"
        key={`${optionsProps.nombre}-keyTyp`}
      >
        {textDestinationFormatter(optionsProps)}
      </OptionTypography>
    </Box>
  );
};
export default memo(OptionWrapped);
