import React from 'react';
import { Box, styled, BoxProps, Typography } from '@mui/material';

interface IItemContainerStyled extends BoxProps {
  borderposition?: string;
  ref?: React.Ref<unknown> | null;
  isautocomplete?: number;
}
interface IItemContainer extends BoxProps {
  label: string;
  borderPosition?: string;
  isAutoComplete?: boolean;
}
const CaptionInput = styled(Typography)`
  font-size: 0.75rem;
  color: rgba(0, 0, 0, 0.6);
  margin-bottom: 6px;
  font-weigth: 400;
`;
const Container = styled(Box)<IItemContainerStyled>(
  ({ isautocomplete, borderposition, theme }) => {
    const isBorderPosition = borderposition
      ? `border${`-${borderposition}`}: ${theme.palette.grey[200]} solid 1px;`
      : '';
    return `
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 100%;
  padding: 8px 6px;
  ${isBorderPosition}
  ${isautocomplete ? 'grid-column: 1/3; grid-row: 1/2;' : ''}
  
  ${theme.breakpoints.up('lg')} {
    grid-column: auto; 
    grid-row: auto;
  }
  position: relative;
  `;
  },
);

function ItemContainer({
  borderPosition,
  label,
  children,
  ref,
  onClick,
  isAutoComplete,
}: IItemContainer) {
  return (
    <Container
      borderposition={borderPosition}
      ref={ref}
      isautocomplete={isAutoComplete ? 1 : 0}
      onClick={onClick}
    >
      <CaptionInput variant="body1">{label}</CaptionInput>
      {children}
    </Container>
  );
}

export default ItemContainer;
