import { IOption } from '../../../redux/search/type';

export const textDestinationFormatter = (option: IOption): string => {
  if (!option?.nombre) return '';
  const { nombre, provincia, tipo, localidad } = option;
  if (tipo === 'provincia') return `${nombre} (Provincia)`;
  if (tipo === 'país') return `${nombre} (País)`;
  if (tipo === 'localidad') return `${nombre}, ${provincia || ''}`;
  if (tipo === 'barrio') {
    return `${nombre}, ${localidad || ''}, ${provincia || ''} `;
  }
  return nombre;
};
