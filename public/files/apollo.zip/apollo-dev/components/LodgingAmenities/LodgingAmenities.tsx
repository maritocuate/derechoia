import React, { useState } from 'react';
import { Grid } from '@mui/material';
import FeaturedAmenities from '../FeaturedAmenities';
import ModalAllAmenities from '../ModalAllAmenities';
import {
  IDataAmenity,
  IFormatedAmenity,
} from '../LodgingData/hooks/useFormatAmenities';

const LodgingAmenities = ({
  amenities,
  dataAmenities,
}: {
  amenities: IFormatedAmenity[];
  dataAmenities: IDataAmenity[];
}) => {
  const [isOpenModalAmenities, setIsOpenModalAmenities] = useState(false);

  return (
    <>
      <FeaturedAmenities
        ameneties={amenities}
        isOpenModalAmenities={isOpenModalAmenities}
        setIsOpenModalAmenities={setIsOpenModalAmenities}
      />
      {isOpenModalAmenities && (
        <Grid item container>
          <Grid item>
            <ModalAllAmenities
              infoAmenities={dataAmenities}
              open={isOpenModalAmenities}
              setIsOpenModalAmenities={setIsOpenModalAmenities}
            />
          </Grid>
        </Grid>
      )}
    </>
  );
};

export default LodgingAmenities;
