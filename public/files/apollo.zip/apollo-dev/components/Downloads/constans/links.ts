export interface IDownloadLinks {
  name: string;
  href: string;
  rel: string;
  target: string;
}

export interface IDownloadLinksProps {
  links: Array<IDownloadLinks>;
}

export const links: IDownloadLinks[] = [
  {
    name: 'Google Play',
    href: 'https://play.google.com/store/apps/details?id=liricus.alquilerargentina',
    rel: 'nofollow',
    target: '_blank',
  },
  {
    name: 'App Store',
    href: 'https://apps.apple.com/ve/app/alquiler-argentina/id1588111749',
    rel: 'nofollow',
    target: '_blank',
  },
];
