import { Box, styled, Typography } from '@mui/material';

export const StyledContainer = styled(Box)(
  ({ theme }) => `
      align-items: center;
      border: 1px solid rgb(0 0 0 / 23%);
      border-radius: 0.5rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
      height: 16rem;
      margin-bottom: 3rem;
      margin-top: 5rem;
      width: 100%;
      ${theme.breakpoints.up('lg')}{
        flex-direction: row;
        display: flex;
        height: 7rem;
        margin-top: 2.5rem;
        margin-bottom: 5rem;
      }
    `,
);

export const StyledImage = styled(Box)`
  align-items: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin: 0.5rem;
  margin-top: 1rem;
`;

export const StyledSection = styled(Box)(
  ({ theme }) => `
      display: flex;
      flex-direction: row;
      margin: 0;
      padding: 0;
      ${theme.breakpoints.up('lg')}{
        margin: 0 2rem;
        padding: 1rem;
      }
    `,
);

export const StyledIcon = styled(Typography)(
  ({ theme }) => `
        align-items: center;
        color: ${theme.palette.primary.main};
        display: flex;
        flex-direction: row;
        font-size: 2.5rem;
        justify-content: center;
        line-height: 0;
        margin: 0rem 1rem;  
        ${theme.breakpoints.up('lg')}{
          font-size: 2.5rem;
        }
      `,
);
