/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import React from 'react';
import Image from 'next/image';
import { StyledImage, StyledSection } from '../styles/downloads.styles';
import { IDownloadLinksProps } from '../constans/links';
import useIsMobile from '../../../hooks/useIsMobile';
import GooglePlaySvg from '../../../public/images/googlePlay.svg';
import AppStoreSvg from '../../../public/images/appStore.svg';

export default function ImagesSection({ links }: IDownloadLinksProps) {
  const isMobile = useIsMobile();
  return (
    <StyledSection>
      {links.map((link, index) => (
        <StyledImage key={index}>
          <a href={link.href} rel={link.rel} target={link.target}>
            <Image
              src={link.name === 'Google Play' ? GooglePlaySvg : AppStoreSvg}
              alt={link.name}
              width={isMobile ? '142' : '170'}
              height={isMobile ? '42' : '50'}
            />
          </a>
        </StyledImage>
      ))}
    </StyledSection>
  );
}
