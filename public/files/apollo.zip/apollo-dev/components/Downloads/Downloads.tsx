import React from 'react';
import { useTranslation } from 'react-i18next';
import Typography from '@alquiler-argentina/demiurgo/components/Typography';
import { Box } from '@mui/material';
import PhoneAndroidIcon from '@mui/icons-material/PhoneAndroid';
import ImagesSection from './components/ImagesSection';
import {
  StyledContainer,
  StyledIcon,
  StyledSection,
} from './styles/downloads.styles';
import useIsMobile from '../../hooks/useIsMobile';
import { links } from './constans/links';

export default function Downloads() {
  const { t } = useTranslation('Downloads');
  const isMobile = useIsMobile();

  return (
    <StyledContainer>
      {isMobile && (
        <>
          <Box flexDirection="column" padding="0 1rem">
            <Box flexDirection="row" display="flex">
              <StyledIcon>
                <PhoneAndroidIcon fontSize="inherit" />
              </StyledIcon>
              <Typography
                fontSize="1.25rem"
                fontWeight="bold"
                margin="0.5rem 0"
              >
                {t('download')}
              </Typography>
            </Box>
            <Typography fontSize="1rem" margin="0.5rem 0" marginLeft="1rem">
              {t('search')}
            </Typography>
          </Box>
          <ImagesSection links={links} />
        </>
      )}
      {!isMobile && (
        <>
          <ImagesSection links={links} />
          <StyledSection>
            <StyledIcon>
              <PhoneAndroidIcon fontSize="inherit" />
            </StyledIcon>
            <Box>
              <Typography
                fontSize="1.25rem"
                fontWeight="bold"
                margin="0.5rem 0"
              >
                {t('download')}
              </Typography>
              <Typography fontSize="1rem" margin="0.5rem 0">
                {t('search')}
              </Typography>
            </Box>
          </StyledSection>
        </>
      )}
    </StyledContainer>
  );
}
