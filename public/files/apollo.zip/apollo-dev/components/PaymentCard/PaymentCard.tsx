import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import { PaymentCardProps } from './types';
import PaymentCardBody from './components/PaymentCardBody';
import PaymentCardFooter from './components/PaymentCardFooter';

const StyledPaymentCardContainer = styled(Box)(
  ({ theme }) => `
    border-radius: 0.5rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    max-width: 100%;
    padding: 1rem 0 2rem 0;
    border-bottom: 0.1rem solid #E0E0E0;
    ${theme.breakpoints.up('lg')}{
      border: 1px solid rgba(0, 0, 0, 0.23);
      padding: 2rem 1.5rem 1rem 1.5rem;
      max-width: 24rem;
    }`,
);
const StyledPaymentHr = styled(Box)(
  ({ theme }) => `
    border: none;
    background-color: #bdbdbd;
    height: 1px;
    display: none;
    ${theme.breakpoints.up('lg')}{
      display: block;
      margin: 1rem 0;
    }`,
);
const StyledBodyContainer = styled(Box)(
  ({ theme }) => `
    padding: 0 1rem;
    ${theme.breakpoints.up('lg')}{
      padding: 0;
    }`,
);

const PaymentCard = ({ values, paymentOptions }: PaymentCardProps) => {
  return (
    <StyledPaymentCardContainer>
      <Typography variant="authTitle" sx={{ marginBottom: '1rem' }}>
        Información de pago
      </Typography>
      <StyledBodyContainer>
        <PaymentCardBody values={values} />
        <StyledPaymentHr />
        <PaymentCardFooter paymentOptions={paymentOptions} />
      </StyledBodyContainer>
    </StyledPaymentCardContainer>
  );
};

export default PaymentCard;
