export type PaymentType = 'cash' | 'bank-transfer';

export type Values = {
  total: number;
  advance: number;
  balance: number;
};

export interface PaymentCardProps {
  values: Values;
  paymentOptions: PaymentType[];
}

export interface PaymentCardHeaderProps {
  values: Values;
}

export interface PaymentCardFooterProps {
  paymentOptions: PaymentType[];
}

export interface PaymentCardItemProps {
  id: number;
  icon: JSX.Element | null;
  type: string | null;
}

export interface PaymentCardBodyRowProps {
  description: string;
  amount: number;
  strong?: boolean;
}
