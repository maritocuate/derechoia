import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import { PaymentCardItemProps } from '../types';

const StyledItem = styled(Box)(`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  margin-bottom: 0.5rem;
`);

const PaymentCardItem = ({ id, icon, type }: PaymentCardItemProps) => {
  return (
    <StyledItem key={id}>
      {icon}
      <Typography>{type}</Typography>
    </StyledItem>
  );
};

export default PaymentCardItem;
