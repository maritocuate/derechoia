import React from 'react';
import { Box } from '@mui/material';
import {
  AccountBalanceOutlined,
  MonetizationOnOutlined,
} from '@mui/icons-material';
import { PaymentCardFooterProps, PaymentType } from '../types';
import PaymentCardItem from './PaymentCardItem';

const PaymentCardFooter = ({ paymentOptions }: PaymentCardFooterProps) => {
  const getIcon = (type: PaymentType) => {
    switch (type) {
      case 'cash':
        return <MonetizationOnOutlined color="primary" fontSize="small" />;
      case 'bank-transfer':
        return <AccountBalanceOutlined color="primary" fontSize="small" />;
      default:
        return null;
    }
  };
  const getTypePayment = (type: PaymentType) => {
    switch (type) {
      case 'cash':
        return 'Efectivo';
      case 'bank-transfer':
        return 'Transferencia bancaria';
      default:
        return null;
    }
  };

  return (
    <Box data-testid="payment-footer">
      {paymentOptions.map((payment, index) => (
        <PaymentCardItem
          id={index}
          icon={getIcon(payment)}
          type={getTypePayment(payment)}
        />
      ))}
    </Box>
  );
};

export default PaymentCardFooter;
