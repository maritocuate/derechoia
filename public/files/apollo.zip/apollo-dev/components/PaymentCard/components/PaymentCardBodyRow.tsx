import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import { PaymentCardBodyRowProps } from '../types';

const StyledRow = styled(Box)(`
    display: flex;
    font-size: 1rem;
    justify-content: space-between;
    margin-bottom: 0.5rem;
`);

const PaymentCardBodyRow = ({
  description,
  amount,
  strong,
}: PaymentCardBodyRowProps) => {
  return (
    <StyledRow>
      <Typography sx={{ fontWeight: strong ? '600' : '400' }}>
        {description}
      </Typography>
      <Typography sx={{ fontWeight: strong ? '600' : '400' }}>
        $ {amount}
      </Typography>
    </StyledRow>
  );
};

export default PaymentCardBodyRow;
