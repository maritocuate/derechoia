import React from 'react';
import { Box, styled } from '@mui/material';
import { PaymentCardHeaderProps } from '../types';
import PaymentCardBodyRow from './PaymentCardBodyRow';

const StyledContainer = styled(Box)(`
    font-weight: 600;
`);

const PaymentCardBody = ({ values }: PaymentCardHeaderProps) => {
  const { total, advance, balance } = values;

  return (
    <StyledContainer data-testid="payment-body">
      <PaymentCardBodyRow description="Total (ARS)" amount={total} strong />
      <PaymentCardBodyRow description="Adelanto de reserva" amount={advance} />
      <PaymentCardBodyRow description="Saldo al ingresar" amount={balance} />
    </StyledContainer>
  );
};

export default PaymentCardBody;
