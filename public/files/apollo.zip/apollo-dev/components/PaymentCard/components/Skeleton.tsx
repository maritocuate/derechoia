import React from 'react';
import { Skeleton, styled, Box } from '@mui/material';

const StyledPaymentCardContainer = styled(Box)(`
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 0.5rem;
  padding: 2rem 1.5rem 1rem 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  max-width: 24rem;
`);
const StyledItemContainer = styled(Box)(`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
`);
const StyledPaymentFooter = styled(Box)(`
  margin-top: 0.5rem;
`);
const StyledRow = styled(Box)(`
    display: flex;
    justify-content: space-between;
`);
const PaymentCardRow = () => {
  return (
    <StyledRow>
      <Skeleton variant="text" width="30%" />
      <Skeleton variant="text" width="10%" />
    </StyledRow>
  );
};
const PaymentCardItem = () => {
  return (
    <StyledItemContainer>
      <Skeleton variant="circular" width={15} height={15} />
      <Skeleton variant="text" width="40%" />
    </StyledItemContainer>
  );
};

const PaymentCardSkeleton = () => {
  return (
    <StyledPaymentCardContainer>
      <Skeleton variant="text" width="70%" height={40} />

      <PaymentCardRow />
      <PaymentCardRow />
      <PaymentCardRow />

      <StyledPaymentFooter>
        <PaymentCardItem />
        <PaymentCardItem />
      </StyledPaymentFooter>
    </StyledPaymentCardContainer>
  );
};

export default PaymentCardSkeleton;
