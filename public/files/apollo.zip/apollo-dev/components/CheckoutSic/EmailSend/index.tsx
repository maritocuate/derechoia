/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-floating-promises */
import React, { useState } from 'react';
import {
  Grid,
  Typography,
  IconWithText,
  Button,
} from '@alquiler-argentina/demiurgo';
import { TextField, IconButton, styled } from '@mui/material';
import ArrowBackIosOutlined from '@mui/icons-material/ArrowBackIosOutlined';
import { useTranslation } from 'next-i18next';
import Image from 'next/legacy/image';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import usePreloadedState from '../../../hooks/usePreloadedState';
import { usePostConsultaMutation } from '../../../services/consulta';
import { ICheckoutState } from '../../../redux/checkout/types';
import { TEventType } from '../../../utils/helpers/sendDataGTM';
import useSendStatistics from '../../../hooks/useSendStatistics';
import imageLoader from '../../../utils/helpers/imageLoaders/imageLoader';

interface IEmailSend {
  setEmailSend: (value: boolean) => void;
  setOpenCheckoutSic: (value: boolean) => void;
  nightsAmmount: number;
  alojamiento?: string;
  unidad?: string;
  huespedes?: number;
  totalAmount?: number | null;
  gtm: (eventType: TEventType) => void;
  referencia: string;
}

const StyledBox = styled(Grid)(
  ({ theme }) => `
  position:fixed;
  padding: 16px;
  width: 100vw;
  height:100vh;
  top:0;
  left:0;
  background-color:white;
  align-content:flex-start;
  ${theme.breakpoints.up('sm')}{
    position: initial;
    border-radius: 8px;
    box-shadow: 0px 3px 14px 2px rgba(0, 0, 0, 0.12);
    width: 340px;
    margin-right: -55px;
    height: 600px;
    padding: 24px;
    padding-top:16px;
  }
`,
);

const StyledImageBox = styled(Grid)(
  ({ theme }) => `
    margin-top: 80px;
  ${theme.breakpoints.up('sm')}{
    margin-top: 60px;
  }
`,
);

const StyledButton = styled(Button)(
  ({ theme }) => `
  position: absolute;
  bottom: 24px;
  left: 20.5%;
  width: 73%;
  ${theme.breakpoints.down('sm')}{
    position: relative;
    width: 100%;
    left:0%;
    margin-top: 48px;
  }
`,
);

const StyledText = styled('span')`
  font-weight: 500;
`;

const StyledTypography = styled(Typography)`
  font-weight: 700;
  margin-bottom: 16px;
  font-size: 16px;
`;

const StyledTypo = styled(Typography)`
  padding: 8px;
  font-weight: 600;
  font-size: 15px;
  text-transform: capitalize;
`;

const StyledIconWithText = styled(IconWithText)`
  & .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 0;
    position: relative;
    left: -5px;
  }
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  padding: 0;
  margin: 0;
  font-size: 20px;
`;

export default function EmailSend({
  setEmailSend,
  setOpenCheckoutSic,
  alojamiento,
  unidad,
  nightsAmmount,
  huespedes,
  totalAmount,
  gtm,
  referencia,
}: IEmailSend) {
  const [onSuccess, setSucces] = useState(false);
  const { t } = useTranslation('CheckoutSic');
  const { nombre, apellido, email } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.datosPersonales,
  );
  const {
    adultos,
    menores,
    bebes,
    startDate,
    endDate,
    mascotas,
    referenciaSaved,
    typologyId,
  } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const [sendConsult, dataConsult] = usePostConsultaMutation();
  const [additionalComment, setAdditionalComment] = useState('');
  const { sendStatistics } = useSendStatistics();

  usePreloadedState();

  const handleBack = () => {
    setEmailSend(false);
  };

  const handleDone = () => {
    setOpenCheckoutSic(false);
  };

  const handleSubmit = () => {
    gtm('consultaEmail' as unknown as TEventType);
    sendConsult({
      fecha_comienzo: startDate,
      fecha_fin: endDate,
      adultos,
      adolescentes: 0,
      jovenes: menores,
      niños: 0,
      bebes,
      mascotas: !mascotas ? 0 : 1,
      nombre: `${nombre} ${apellido}`,
      consulta: additionalComment || null,
      email,
      id_tipologia: typologyId,
      referencia: referenciaSaved,
      tipo: 'email',
      monto: totalAmount !== 0 ? totalAmount : null,
    });
    if (dataConsult.isError) {
      // Acá iría el error
      return false;
    }
    sendStatistics(referencia, 'email');
    return setSucces(true);
  };
  const numberFormat = new Intl.NumberFormat('es-AR');
  const formatPrice = numberFormat.format(totalAmount || 0);

  return (
    <StyledBox
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
    >
      <StyledIconWithText
        anchor="left"
        icon={
          <IconButton onClick={handleBack}>
            <ArrowBackIosOutlined fontSize="medium" />
          </IconButton>
        }
      >
        <StyledTitle
          marginLeft={1}
          fontWeight={700}
          fontSize="20px"
          variant="h6"
        >
          {t('title-email')}
        </StyledTitle>
      </StyledIconWithText>
      {onSuccess ? (
        <StyledImageBox
          spacing={1}
          container
          justifyContent="center"
          alignItems="center"
          direction="column"
          textAlign="center"
        >
          <Grid item>
            <Image
              src="/images/on-success.gif"
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              width="180px"
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              height="180px"
              loader={imageLoader}
            />
          </Grid>
          <Grid item>
            <Typography fontWeight={700} fontSize="24px">
              {t('success-title')}
            </Typography>
          </Grid>
          <Grid item>
            <Typography fontSize="16px">{t('success-content')}</Typography>
          </Grid>
        </StyledImageBox>
      ) : (
        <Grid
          spacing={1}
          marginTop={2}
          container
          justifyContent="center"
          direction="column"
        >
          <Grid item>
            <StyledTypography>{t('consultation-summary')}</StyledTypography>
          </Grid>
          <Grid item>
            <Typography marginBottom="5px" fontSize="14px" fontWeight={600}>
              {t('property')}: <StyledText> {alojamiento}</StyledText>
            </Typography>
            <Typography fontSize="14px" fontWeight={600}>
              {t('unit')}: <StyledText> {unidad}</StyledText>
            </Typography>
          </Grid>
          <Grid item>
            <Typography marginBottom="5px" fontSize="14px" fontWeight={600}>
              {t('dates')}:{' '}
              <StyledText>
                {dayjs(startDate).format('DD/MM/YYYY')} {t('to')}{' '}
                {dayjs(endDate).format('DD/MM/YYYY')}
              </StyledText>
            </Typography>
            <Typography marginBottom="5px" fontSize="14px" fontWeight={600}>
              {t('stay')}:{' '}
              <StyledText>
                {nightsAmmount}{' '}
                {t('nights', {
                  count: nightsAmmount,
                  nights: nightsAmmount,
                })}
              </StyledText>
            </Typography>
            <Typography fontSize="14px" fontWeight={600}>
              {t('guests')}:{' '}
              <StyledText>
                {t('people', {
                  count: huespedes,
                  people: huespedes,
                })}
              </StyledText>
            </Typography>
          </Grid>
          <Grid item>
            <Typography marginBottom="5px" fontSize="14px" fontWeight={600}>
              {t('total-ammount')}:
              <StyledText>
                {' '}
                {formatPrice !== '0' ? `$${formatPrice}` : 'Consultar precio'}
              </StyledText>
            </Typography>
          </Grid>
          <Grid item>
            <TextField
              value={additionalComment}
              onChange={(event) => setAdditionalComment(event.target.value)}
              label={t('additional-comment')}
              fullWidth
              rows={6}
              multiline
            />
          </Grid>
        </Grid>
      )}
      <Grid item>
        <StyledButton
          onClick={onSuccess ? handleDone : handleSubmit}
          variant="contained"
          color="primary"
        >
          <StyledTypo lineHeight={1}>
            {onSuccess ? t('done') : t('send')}
          </StyledTypo>
        </StyledButton>
      </Grid>
    </StyledBox>
  );
}
