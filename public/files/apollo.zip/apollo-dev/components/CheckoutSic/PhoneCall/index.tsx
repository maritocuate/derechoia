import React, { useState, useEffect } from 'react';
import {
  Grid,
  Typography,
  IconWithText,
  Button,
} from '@alquiler-argentina/demiurgo';
import { Alert, styled, IconButton } from '@mui/material';
import ArrowBackIosOutlined from '@mui/icons-material/ArrowBackIosOutlined';
import ContentCopyOutlined from '@mui/icons-material/ContentCopyOutlined';
import PhoneOutlined from '@mui/icons-material/PhoneOutlined';
import { useTranslation } from 'next-i18next';
import Link from 'next/link';

interface ITelefonos {
  number?: string;
}
interface IPhoneCall {
  setPhoneCall: (value: boolean) => void;
  setOpenCheckoutSic: (value: boolean) => void;
  telefonos?: ITelefonos[];
}

const StyledBox = styled(Grid)(
  ({ theme }) => `
  position: fixed;
  padding: 16px;
  width: 100vw;
  height:100vh;
  top:0;
  left:0;
  background-color:white;
  ${theme.breakpoints.up('sm')}{
    position: initial;
    border-radius: 8px;
    box-shadow: 0px 3px 14px 2px rgba(0, 0, 0, 0.12);
    width: 340px;
    margin-right: -55px;
    height: 600px;
    padding: 24px;
    padding-top:16px;
  }
`,
);

const StyledTipography = styled(Typography)`
  font-weight: 600;
  font-size: 16px;
`;

const StyledContentIcon = styled(ContentCopyOutlined)`
  font-size: 24px;
  color: rgba(0, 0, 0, 0.54);
`;

const StyledPhoneIcon = styled(PhoneOutlined)`
  font-size: 24px;
  color: rgba(0, 0, 0, 0.54);
`;

const StyledButton = styled(Button)(
  ({ theme }) => `
  position: absolute;
  bottom: 24px;
  left: 20.5%;
  width: 73%;
  ${theme.breakpoints.down('sm')}{
    position: relative;
    width: 100%;
    left:0%;
    margin-top: 48px;
  }
`,
);

const StyledAlert = styled(Alert)(
  ({ theme }) => `
  position: absolute;
  bottom: 100px;
  left:0;
  right:-50px;
  margin: 20px auto;
  width: 150px;
  ${theme.breakpoints.down('sm')}{
    width: 150px;
    position: absolute;
    bottom: 100px;
    margin: 0 auto;
    left: -60px;
  }
`,
);

const StyledTypo = styled(Typography)`
  padding: 8px;
  font-weight: 600;
  font-size: 15px;
  text-transform: capitalize;
`;

const StyledIconWithText = styled(IconWithText)`
  & .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 0;
    position: relative;
    left: -5px;
  }
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  padding: 0;
  margin: 0;
  font-size: 20px;
`;

export default function PhoneCall({
  setPhoneCall,
  setOpenCheckoutSic,
  telefonos,
}: IPhoneCall) {
  const [openSnackBar, setOpenAlert] = useState(false);
  const { t } = useTranslation('CheckoutSic');

  useEffect(() => {
    const timer = setTimeout(() => {
      setOpenAlert(false);
    }, 5000);
    return () => clearTimeout(timer);
  }, [openSnackBar]);

  const handleBack = () => {
    setPhoneCall(false);
  };

  const handleDone = () => {
    setOpenCheckoutSic(false);
  };

  const handleCopy = (event: string) => {
    setOpenAlert(true);
    navigator.clipboard.writeText(event).then(
      () => {
        setOpenAlert(true);
      },
      () => {
        // error
      },
    );
  };

  return (
    <StyledBox
      flexDirection="column"
      justifyContent="center"
      alignItems="center"
    >
      <StyledIconWithText
        anchor="left"
        icon={
          <IconButton onClick={handleBack}>
            <ArrowBackIosOutlined fontSize="medium" />
          </IconButton>
        }
      >
        <StyledTitle
          marginLeft={1}
          fontWeight={700}
          fontSize="20px"
          variant="h6"
        >
          {t('title-phone')}
        </StyledTitle>
      </StyledIconWithText>
      <Grid marginTop={2} container justifyContent="center" direction="column">
        {telefonos && (
          <Grid item>
            {telefonos.map((item, index) => (
              <Grid
                marginTop={4}
                container
                direction="row"
                key={index}
                marginBottom={2}
              >
                <Grid item xs={8}>
                  <StyledTipography lineHeight={2.5}>
                    {item.number}
                  </StyledTipography>
                </Grid>
                <Grid item xs={2} sx={{ textAlign: 'right' }}>
                  <IconButton
                    size="small"
                    onClick={() => handleCopy(item.number || '')}
                  >
                    <StyledContentIcon />
                  </IconButton>
                </Grid>
                <Grid item xs={2} sx={{ textAlign: 'right' }}>
                  <IconButton size="small">
                    <Link href={item.number ? `tel:${item.number}` : 'tel:'}>
                      <StyledPhoneIcon />
                    </Link>
                  </IconButton>
                </Grid>
              </Grid>
            ))}
          </Grid>
        )}
      </Grid>
      {openSnackBar && (
        <StyledAlert variant="outlined" severity="success">
          {t('copied')}
        </StyledAlert>
      )}
      <Grid item>
        <StyledButton variant="contained" color="primary" onClick={handleDone}>
          <StyledTypo lineHeight={1}>{t('done')}</StyledTypo>
        </StyledButton>
      </Grid>
    </StyledBox>
  );
}
