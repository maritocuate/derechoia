/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable no-useless-escape */
import React, { useState } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import Tooltip from '@alquiler-argentina/demiurgo/components/Tooltip';
import Input from '@alquiler-argentina/demiurgo/components/Input';
import Snackbar from '@alquiler-argentina/demiurgo/components/Snackbar';
import {
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  styled,
  IconButton,
  Grid,
  Typography,
} from '@mui/material';
import ArrowForwardIosOutlined from '@mui/icons-material/ArrowForwardIosOutlined';
import ArrowBackIosOutlined from '@mui/icons-material/ArrowBackIosOutlined';
import MailOutlineOutlined from '@mui/icons-material/MailOutlineOutlined';
import PhoneOutlined from '@mui/icons-material/PhoneOutlined';
import WhatsApp from '@mui/icons-material/WhatsApp';
import { useTranslation } from 'next-i18next';
import parsePhoneNumber from 'libphonenumber-js';
import { useSelector, useDispatch } from 'react-redux';
import dayjs from 'dayjs';
import PhoneCall from './PhoneCall';
import EmailSend from './EmailSend';
import { ICheckoutState } from '../../redux/checkout/types';
import { fillUserData } from '../../redux/checkout/slice';
import usePreloadedState from '../../hooks/usePreloadedState';
import { usePostConsultaMutation } from '../../services/consulta';
import { TEventType } from '../../utils/helpers/sendDataGTM';
import emailValidator from '../../utils/helpers/emailValidator';
import useSendStatistics from '../../hooks/useSendStatistics';
import getPersonsForConsult from '../../utils/helpers/getPersonsForConsult';
import useIsMobile from '../../hooks/useIsMobile';

interface ITelefonos {
  number?: string;
}
export interface ICheckoutSic {
  alojamiento?: string;
  unidad?: string;
  huespedes?: number;
  totalAmount?: number | null;
  referencia: string;
  name?: string;
  telefonos?: ITelefonos[];
  whatsappNumber?: string;
  mascotas?: boolean;
  setOpenCheckoutSic: (value: boolean) => void;
  gtm: (eventType: TEventType) => void;
  emailPropietario: boolean | null;
  hasPhoneNumber?: boolean;
  hasWhatsapp?: boolean;
}

export const StyledBox = styled(Grid)(
  ({ theme }) => `
  padding: 16px;
  width: 100%;
  height: 100vh;
  top: 0;
  left: 0;
  background-color:white;
  align-content:flex-start;
  ${theme.breakpoints.up('sm')}{
    border-radius: 8px;
    box-shadow: 0px 3px 14px 2px rgba(0, 0, 0, 0.12);
    width: 340px;
    margin-right: -55px;
    height: 600px;
    padding: 24px;
    padding-top:16px;
  }
`,
);

const StyledButton = styled(Box)`
  box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2),
    0px 2px 2px rgba(0, 0, 0, 0.14), 0px 1px 5px rgba(0, 0, 0, 0.12);
  border-radius: 4px;
`;

const StyledDiv = styled(Grid)`
  width: 100%;
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  padding: 0;
  margin: 0;
  font-size: 20px;
`;

const StyledIconButton = styled(IconButton)`
  width: 100%;
  padding: 4px 0;
  margin: 4px 0;
`;

const StyledTypography = styled(Typography)`
  font-weight: 500;
  font-size: 14px;
  color: #000000;
`;

const StyledIconWithText = styled(IconWithText)`
  & .css-78trlr-MuiButtonBase-root-MuiIconButton-root {
    padding: 0;
    position: relative;
    left: -5px;
  }
`;
const StyledRequiredData = styled(Typography)`
  width: 100%;
  font-size: 0.75rem;
  margin-bottom: 0.5rem;
  font-weight: 400;
`;

const StyledGrid = styled(Grid)`
  position: relative;
  bottom: 12px;
  left: 180px;
`;

export default function CheckoutSic({
  alojamiento,
  unidad,
  huespedes,
  referencia,
  totalAmount,
  name,
  telefonos,
  whatsappNumber,
  setOpenCheckoutSic,
  mascotas,
  gtm,
  emailPropietario,
  hasPhoneNumber,
  hasWhatsapp,
}: ICheckoutSic) {
  const { nombre, apellido, email } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.datosPersonales,
  );
  const { adultos, menores, bebes, startDate, endDate, typologyId } =
    useSelector(
      ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
    );
  const [sendConsult, dataConsult] = usePostConsultaMutation();
  usePreloadedState();

  const dispatch = useDispatch();
  const [snackBar, setSnackBar] = useState(false);
  const [emailFill, setEmail] = useState(email);
  const [nameHuesped, setName] = useState(nombre);
  const [lastnameHuesped, setLastname] = useState(apellido);
  const [openTooltip, setOpenTooltip] = useState(!nameHuesped);
  const [errorName, setErrorName] = useState(false);
  const [errorEmail, setErrorEmail] = useState(false);
  const [errorLastName, setErrorLastName] = useState(false);
  const [phoneCall, setPhoneCall] = useState(false);
  const [emailSend, setEmailSend] = useState(false);
  const { sendStatistics } = useSendStatistics();
  const numberFormat = new Intl.NumberFormat('es-AR');
  const formatPrice = numberFormat.format(totalAmount || 0);
  const isMobile = useIsMobile();
  const { t } = useTranslation('CheckoutSic');

  const nightsAmmount = dayjs(endDate).diff(dayjs(startDate), 'days');

  const validator = () => {
    const validations = {
      name: false,
      lastname: false,
      email: false,
    };

    if (nameHuesped.length < 2) {
      validations.name = false;
      setErrorName(true);
    } else {
      validations.name = true;
      setErrorName(false);
    }
    if (lastnameHuesped.length < 2) {
      validations.lastname = false;
      setErrorLastName(true);
    } else {
      validations.lastname = true;
      setErrorLastName(false);
    }
    if (emailValidator(emailFill) === false) {
      validations.email = false;
      setErrorEmail(true);
    } else {
      validations.email = true;
      setErrorEmail(false);
    }

    const isValidContactInfo =
      validations.name && validations.lastname && validations.email;

    return isValidContactInfo;
  };

  const onPhoneCall = () => {
    if (validator() === false) {
      return null;
    }

    gtm('consultaTelefono' as unknown as TEventType);

    dispatch(
      fillUserData({
        nombre: nameHuesped,
        apellido: lastnameHuesped,
        email: emailFill,
      }),
    );

    sendConsult({
      fecha_comienzo: startDate,
      fecha_fin: endDate,
      adultos,
      adolescentes: 0,
      jovenes: menores,
      niños: 0,
      bebes,
      mascotas: !mascotas ? 0 : 1,
      nombre: `${nameHuesped} ${lastnameHuesped}`,
      email: emailFill,
      id_tipologia: typologyId,
      referencia,
      tipo: 'llamada',
      monto: totalAmount !== 0 ? totalAmount : null,
    });

    if (dataConsult.isError) {
      setSnackBar(true);
      // Acá iría el error
      return false;
    }

    sendStatistics(referencia, 'telefono');

    return setPhoneCall(true);
  };

  const onClickEmail = () => {
    if (validator() === false) {
      return null;
    }

    dispatch(
      fillUserData({
        nombre: nameHuesped,
        apellido: lastnameHuesped,
        email: emailFill,
      }),
    );
    return setEmailSend(true);
  };

  const onClickWhatsapp = () => {
    if (validator() === false) {
      return null;
    }

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const telefonoValidar: any = parsePhoneNumber(whatsappNumber || '', 'AR');
    if (!telefonoValidar) {
      return false;
    }
    gtm('consultaWhatsapp' as unknown as TEventType);

    if (dataConsult.isError) {
      setSnackBar(true);
      // Acá iría el error
      return false;
    }
    const regex = /[\s\-]/g;
    const personsForConsult = getPersonsForConsult(
      adultos || 0,
      menores || 0,
      bebes || 0,
      mascotas || false,
    );
    const telefonoWs = `+54${telefonoValidar
      .format('NATIONAL')
      .replace(regex, '')}`;
    const urlWhatsapp = `https://api.whatsapp.com/send/?phone=${
      telefonoWs || ''
    }&text=Hola,+${
      name || ''
    }.+Quería+consultar+por+el+anuncio+de+Alquiler+Argentina.+Me+interesa+reservar%3A+%0A+%0AAlojamiento:+${
      referencia || ''
    }.alquilerargentina.com+%0AUnidad:+${unidad || ''}+%0AFechas:+${
      dayjs(startDate).format('DD/MM/YYYY') || ''
    }+al+${dayjs(endDate).format('DD/MM/YYYY') || ''}+%0AEstadía:${
      nightsAmmount !== 1
        ? ` ${nightsAmmount} noches`
        : ` ${nightsAmmount} noche`
    }+%0AHuéspedes:+${personsForConsult}+%0AImporte+total:+${
      formatPrice !== '0' ? ` $${formatPrice}` : 'consultar+precio'
    }%0A%0A+¡Gracias!%0A%0A+${nameHuesped}+${lastnameHuesped}&type=phone_number&app_absent=0`;
    window.open(urlWhatsapp);

    dispatch(
      fillUserData({
        nombre: nameHuesped,
        apellido: lastnameHuesped,
        email: emailFill,
      }),
    );

    sendConsult({
      fecha_comienzo: startDate,
      fecha_fin: endDate,
      adultos,
      adolescentes: 0,
      jovenes: menores,
      niños: 0,
      bebes,
      mascotas: !mascotas ? 0 : 1,
      nombre: `${nameHuesped} ${lastnameHuesped}`,
      email: emailFill,
      id_tipologia: typologyId,
      referencia,
      tipo: 'wpp',
      monto: totalAmount !== 0 ? totalAmount : null,
    });

    sendStatistics(referencia, 'wpp');

    return null;
  };

  if (phoneCall) {
    return (
      <PhoneCall
        telefonos={telefonos}
        setPhoneCall={setPhoneCall}
        setOpenCheckoutSic={setOpenCheckoutSic}
      />
    );
  }

  if (emailSend) {
    return (
      <EmailSend
        alojamiento={alojamiento}
        unidad={unidad}
        huespedes={huespedes}
        totalAmount={totalAmount}
        setEmailSend={setEmailSend}
        setOpenCheckoutSic={setOpenCheckoutSic}
        gtm={gtm}
        nightsAmmount={nightsAmmount}
        referencia={referencia}
      />
    );
  }

  const handleBack = () => {
    setOpenCheckoutSic(false);
  };

  return (
    <StyledBox
      container
      position={isMobile ? 'fixed' : undefined}
      data-testid="checkout-sic-test"
    >
      <StyledIconWithText
        anchor="left"
        icon={
          <IconButton onClick={handleBack}>
            <ArrowBackIosOutlined fontSize="medium" />
          </IconButton>
        }
      >
        <StyledTitle
          marginLeft={1}
          fontWeight={700}
          fontSize="20px"
          variant="h6"
        >
          {t('title')}
        </StyledTitle>
      </StyledIconWithText>
      <Typography
        marginTop={2}
        marginBottom={0.5}
        fontSize="16px"
        fontWeight={600}
        width="100%"
      >
        1. {t('first-data')}
      </Typography>

      <StyledRequiredData
        variant="caption"
        color={errorName || errorLastName || errorEmail ? '#D32F2F' : 'inherit'}
      >
        {t('required-data')}
      </StyledRequiredData>
      <Grid gap={1.5} marginTop={1} container direction="column">
        <Grid item>
          <Input
            fullWidth
            size="medium"
            value={nameHuesped}
            error={errorName}
            variant="outlined"
            onChange={(event) => setName(event.target.value)}
            onFocus={() => {
              setOpenTooltip(false);
              setErrorName(false);
            }}
            inputProps={{ style: { textTransform: 'capitalize' } }}
            label={t('name')}
          />
          <StyledGrid>
            <Tooltip
              variant="secondary"
              placement="top"
              arrow
              open={openTooltip}
              title="Completá los datos para poder realizar la consulta"
              sx={{ width: '140px' }}
            >
              <span> </span>
            </Tooltip>
          </StyledGrid>
        </Grid>
        <Grid item>
          <Input
            fullWidth
            size="medium"
            onChange={(event) => setLastname(event.target.value)}
            onFocus={() => setErrorLastName(false)}
            inputProps={{ style: { textTransform: 'capitalize' } }}
            value={lastnameHuesped}
            error={errorLastName}
            variant="outlined"
            label={t('lastname')}
          />
        </Grid>
        <Grid item>
          <Input
            fullWidth
            size="medium"
            onChange={(event) => {
              const emailSic = event.target.value;
              setEmail(emailSic.trim());
            }}
            onFocus={() => setErrorEmail(false)}
            inputProps={{ style: { textTransform: 'lowercase' } }}
            value={emailFill}
            error={errorEmail}
            variant="outlined"
            label={t('email')}
          />
        </Grid>
      </Grid>
      <Typography
        margin={0}
        marginBottom={1}
        marginTop={2}
        fontSize="1rem"
        fontWeight={600}
      >
        2. {t('second-data')}
      </Typography>
      <Grid
        justifyContent="flex-start"
        alignContent="start"
        gap="5px"
        container
        direction="column"
      >
        {hasWhatsapp ? (
          <StyledIconButton disableRipple onClick={onClickWhatsapp}>
            <StyledDiv item>
              <StyledButton>
                <List dense>
                  <ListItem secondaryAction={<ArrowForwardIosOutlined />}>
                    <ListItemIcon>
                      <WhatsApp color="primary" />
                    </ListItemIcon>
                    <ListItemText disableTypography>
                      <StyledTypography> WhatsApp </StyledTypography>
                    </ListItemText>
                  </ListItem>
                </List>
              </StyledButton>
            </StyledDiv>
          </StyledIconButton>
        ) : null}
        {emailPropietario ? (
          <StyledIconButton disableRipple onClick={onClickEmail}>
            <StyledDiv item>
              <StyledButton>
                <List dense>
                  <ListItem secondaryAction={<ArrowForwardIosOutlined />}>
                    <ListItemIcon>
                      <MailOutlineOutlined color="primary" />
                    </ListItemIcon>
                    <ListItemText disableTypography>
                      <StyledTypography> {t('email')} </StyledTypography>
                    </ListItemText>
                  </ListItem>
                </List>
              </StyledButton>
            </StyledDiv>
          </StyledIconButton>
        ) : null}

        {hasPhoneNumber ? (
          <StyledIconButton disableRipple onClick={onPhoneCall}>
            <StyledDiv item>
              <StyledButton>
                <List dense>
                  <ListItem secondaryAction={<ArrowForwardIosOutlined />}>
                    <ListItemIcon>
                      <PhoneOutlined color="primary" />
                    </ListItemIcon>
                    <ListItemText disableTypography>
                      <StyledTypography>{t('phone-call')}</StyledTypography>
                    </ListItemText>
                  </ListItem>
                </List>
              </StyledButton>
            </StyledDiv>
          </StyledIconButton>
        ) : null}
      </Grid>
      <Snackbar
        open={snackBar}
        onClose={() => setSnackBar(false)}
        severity="error"
        message="Ha ocurrido un Error"
      />
    </StyledBox>
  );
}
