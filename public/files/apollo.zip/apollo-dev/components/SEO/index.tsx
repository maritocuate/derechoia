/* eslint-disable arrow-body-style */
import Head from 'next/head';
import React, { memo } from 'react';

const GlobalStructuredData = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  url: 'https://www.alquilerargentina.com',
  logo: `${
    process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
  }_img_/logo-aa_sombra_400.png?p=general`,
  sameAs: [
    'https://www.facebook.com/alquilerargentina',
    'https://www.youtube.com/user/AlquilerArgentinaWeb',
    'https://twitter.com/AlqArgentina',
    'https://plus.google.com/+AlquilerargentinaWeb',
  ],
  contactPoint: [
    {
      '@type': 'ContactPoint',
      telephone: '+540810-888-0845',
      contactType: 'customer service',
    },
  ],
  address: [
    {
      '@type': 'PostalAddress',
      streetAddress: 'Lisandro de la Torre 101',
      addressLocality: 'Villa Carlos Paz',
      addressCountry: 'AR',
    },
  ],
};

interface SEOProps {
  title?: string;
  description?: string;
  image?: string;
  keywords?: string;
  url?: string;
  jsonStructuredData?: any; // eslint-disable-line @typescript-eslint/no-explicit-any
  metaRobots?: string;
}
const SEO = ({
  title,
  description,
  image,
  keywords,
  url,
  jsonStructuredData,
  metaRobots,
}: SEOProps) => {
  return (
    <Head>
      <meta charSet="utf-8" />

      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />

      <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"
      />

      <meta name="author" content="Alquiler Argentina" />

      <meta name="geo.region" content="AR" />

      <meta name="title" content={title} />

      <meta name="description" content={description} />

      <meta name="keywords" content={keywords} />

      <meta name="og:locale" content="es_LA" />

      <meta name="og:title" content={title} />

      <meta name="og:type" content="place" />

      <meta name="og:url" content={url} />

      <meta name="og:description" content={description} />

      <meta name="og:site_name" content="Alquiler Argentina" />

      <meta property="og:image" content={image} />

      <meta property="fb:app_id" content="193400040680800" />

      <meta property="fb:admins" content="100001734925397,777313376" />

      <meta name="robots" content={metaRobots} />

      <link
        rel="shortcut icon"
        href="https://www.alquilerargentina.com/imagenes/favicon.png"
        type="image/png"
      />

      <link rel="canonical" href={url} />

      <title>{title}</title>

      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(GlobalStructuredData),
        }}
      />

      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(jsonStructuredData),
        }}
      />
    </Head>
  );
};

export default memo(SEO);
