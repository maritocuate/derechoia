/* eslint-disable @typescript-eslint/indent */
import Image from 'next/legacy/image';
import React, { useState } from 'react';
import NavigateBeforeOutlined from '@mui/icons-material/NavigateBeforeOutlined';
import NavigateNextOutlined from '@mui/icons-material/NavigateNextOutlined';
import { Box, styled, Typography } from '@mui/material';
import Carousel from 'react-material-ui-carousel';
import { Grid } from '@alquiler-argentina/demiurgo';
import type { ITypologyData } from '../index';
import useIsMobile from '../../../hooks/useIsMobile';
import imageLoader from '../../../utils/helpers/imageLoaders/imageLoader';

const SpanLengthMobile = styled(Box)`
  display: flex;
  align-self: flex-end;
  justify-content: center;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 2px 10px;
  border-radius: 8px;
  position: relative;
  width: 90px;
  bottom: 1rem;
  right: 1rem;
  top: auto;
  z-index: 10;
`;

export default function CarouselTipologia({
  imgsCarousel,
}: Pick<ITypologyData, 'imgsCarousel'>) {
  const [active, setActive] = useState<number>(1);
  const isMobile = useIsMobile();
  const moreThanOnePhoto = imgsCarousel && imgsCarousel?.length > 1;

  const handlePrev = () => {
    if (imgsCarousel !== undefined) {
      setActive(active > 1 ? active - 1 : imgsCarousel.length);
    }
  };
  const handleNext = () => {
    if (imgsCarousel !== undefined) {
      setActive(active < imgsCarousel.length ? active + 1 : 1);
    }
  };
  return (
    <>
      <Carousel
        PrevIcon={moreThanOnePhoto && <NavigateBeforeOutlined />}
        navButtonsProps={{
          style: {
            background: moreThanOnePhoto ? '#FFFFFF' : 'transparent',
            borderRadius: '8px',
            color: moreThanOnePhoto ? 'rgba(0, 0, 0, 0.77)' : 'transparent',
          },
        }}
        navButtonsWrapperProps={{
          style: {
            height: '100%',
            top: '0',
          },
        }}
        indicatorContainerProps={{
          style: {
            position: 'absolute',
            top: '90%',
            zIndex: '1000',
            marginTop: '0',
          },
        }}
        activeIndicatorIconButtonProps={{
          style: {
            display: 'none',
          },
        }}
        indicatorIconButtonProps={{
          style: {
            display: 'none',
          },
        }}
        NextIcon={moreThanOnePhoto && <NavigateNextOutlined />}
        navButtonsAlwaysVisible
        animation="slide"
        autoPlay={false}
        swipe={false}
        next={handleNext}
        prev={handlePrev}
      >
        {imgsCarousel &&
          imgsCarousel.map((image) => (
            <Grid container key={`key-${image.id}`}>
              <Image
                src={image.src}
                alt={image.alt}
                style={{ borderRadius: '8px' }}
                width={isMobile ? 360 : 738}
                height={isMobile ? 270 : 450}
                objectFit="cover"
                loader={imageLoader}
              />
            </Grid>
          ))}
      </Carousel>
      <Box width="100%" display="flex" justifyContent="flex-end" height={0}>
        {imgsCarousel &&
        imgsCarousel[0].src !== '/images/MediaPlaceholderImage.png' ? (
          <SpanLengthMobile>
            <Typography fontSize="1rem">
              {active} / {imgsCarousel.length}
            </Typography>
          </SpanLengthMobile>
        ) : null}
      </Box>
    </>
  );
}
