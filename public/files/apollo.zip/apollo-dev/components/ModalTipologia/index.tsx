import React, { ReactNode } from 'react';
import { Grid, Typography, IconWithText } from '@alquiler-argentina/demiurgo';
import BedroomParentOutlined from '@mui/icons-material/BedroomParentOutlined';
import BathroomOutlined from '@mui/icons-material/BathroomOutlined';
import PortraitOutlined from '@mui/icons-material/PortraitOutlined';
import CloseOutlined from '@mui/icons-material/CloseOutlined';
import { Dialog, DialogContent, IconButton, styled } from '@mui/material';
import { useTranslation } from 'next-i18next';
import CarouselTipologia from './Carousel/index';
import useIsMobile from '../../hooks/useIsMobile';
import NoPhotos from '../NoPhotos/NoPhotos';

interface IImage {
  id: number;
  alt: string;
  src: string;
}
export interface ITypologyData {
  imgsCarousel?: IImage[];
  hostName: string;
  roomAmount: number;
  bathAmount: number;
  peopleAmount: number;
  descriptionHost?: string;
  isOpenModalTipology: boolean;
  handleClose: () => void;
}

const StyledCaptionTypography = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  font-size: 0.75rem;
  margin-right: 0.25rem;
`;

const StyledBodyTypography = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  font-size: 14px;
  letter-spacing: 0.17px;
  line-height: 20.02px;
`;

const StyledCloseIcon = styled(CloseOutlined)`
  fill: rgba(0, 0, 0, 0.54);
`;

const StyledModal = styled(Dialog)(
  ({ theme }) => `
  & .MuiDialog-paper {
    border-radius: 0.5rem;
    background-color: #ffffff;
    color: rgba(0, 0, 0, 0.54);
    max-height: 48rem;
    width: 48.125rem;
  }
  ,
  & .MuiBackdrop-root {
    background: rgba(0, 0, 0, 0.6);
  }

  & .MuiPaper-root {
    ${theme.breakpoints.down('sm')}{
      margin: 1rem;
    }
  }
`,
);

const StyledHead = styled(Grid)`
  justify-content: space-between;
  align-items: center;
  flex-wrap: nowrap;
  border-bottom: solid 1px rgba(0, 0, 0, 0.23);
  font-weight: 700;
  color: rgba(0, 0, 0, 0.87);
  padding: 1rem;
`;

const StyledTitle = styled(Typography)`
  font-size: 1.2rem;
  font-weight: 700;
`;

const StyledContet = styled(DialogContent)`
  padding: 1rem;
`;

export default function ModalTipologia({
  imgsCarousel,
  hostName,
  roomAmount,
  bathAmount,
  peopleAmount,
  descriptionHost,
  isOpenModalTipology,
  handleClose,
}: ITypologyData) {
  const descripcion = null;
  const { t } = useTranslation('ModalTipologia');
  const Amounts: [number, ReactNode, string][] = [
    [
      roomAmount,
      <BedroomParentOutlined color="primary" />,
      t('rooms', { count: roomAmount, rooms: roomAmount }),
    ],
    [
      bathAmount,
      <BathroomOutlined color="primary" />,
      t('baths', { count: bathAmount, baths: bathAmount }),
    ],
    [
      peopleAmount,
      <PortraitOutlined color="primary" />,
      t('people', { count: peopleAmount, people: peopleAmount }),
    ],
  ];

  const isMobile = useIsMobile();
  const imageDefault = {
    id: 1,
    alt: ' ',
    src: '/images/MediaPlaceholderImage.png',
  };

  return (
    <StyledModal
      onClose={handleClose}
      open={isOpenModalTipology}
      fullWidth={isMobile}
    >
      <StyledHead container>
        <Grid item>
          <StyledTitle variant="h6">{t('title-modal-tipologia')}</StyledTitle>
        </Grid>
        <Grid item>
          <IconButton onClick={handleClose} color="inherit">
            <StyledCloseIcon />
          </IconButton>
        </Grid>
      </StyledHead>
      <StyledContet>
        <Grid item container direction="column">
          <Grid item>
            {imgsCarousel?.length === 0 ? (
              <NoPhotos modalOpen />
            ) : (
              <CarouselTipologia
                imgsCarousel={
                  imgsCarousel?.length === 0 ? [imageDefault] : imgsCarousel
                }
              />
            )}
          </Grid>
          <Grid item container direction="column">
            <Typography
              variant="subtitle1"
              fontWeight={600}
              margin="1rem 0 0.5rem 0"
              color="rgba(0,0, 0, 0.87)"
            >
              {hostName}
            </Typography>
            <Grid
              container
              direction="row"
              marginBottom="0.5rem"
              flexWrap="wrap"
            >
              {Amounts.map(([amount, icon, translate], index, array) => (
                <Grid
                  item
                  container
                  width="auto"
                  marginRight="1rem"
                  alignItems="center"
                  key={`key-${0 + index}`}
                >
                  <IconWithText icon={icon} anchor="left">
                    <StyledCaptionTypography
                      variant="caption"
                      marginLeft="0.25rem"
                    >
                      <StyledCaptionTypography
                        variant="caption"
                        marginRight="0.25rem"
                      >
                        {array[0][amount] === 0 ? 'Monoambiente' : amount}
                      </StyledCaptionTypography>
                      {array[0][amount] === 0 ? null : translate}
                    </StyledCaptionTypography>
                  </IconWithText>
                </Grid>
              ))}
            </Grid>
            <Grid item>
              {descripcion !== null ? (
                <StyledBodyTypography variant="body2">
                  {descriptionHost}
                </StyledBodyTypography>
              ) : null}
            </Grid>
          </Grid>
        </Grid>
      </StyledContet>
    </StyledModal>
  );
}
