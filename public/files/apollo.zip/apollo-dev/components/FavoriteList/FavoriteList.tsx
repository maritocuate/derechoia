import React, { memo } from 'react';
import { Box, styled } from '@mui/material';
import { FavoritesList } from '../../types/favorites.types';
import FavouriteCard from '../FavoriteCard/FavoriteCard';
import { IChangeFavorite } from '../FavoriteCard/types';

export interface FavoriteListProps {
  favorites: FavoritesList['data'];
  personas: number;
  changeFavorite: IChangeFavorite;
  loadingReference?: string;
}

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  width: fit-content;
  height: fit-content;
  gap: 2.2rem;
  width: 100%;
`;

const FavoriteList = ({
  favorites = [],
  personas = 1,
  changeFavorite,
  loadingReference,
}: {
  favorites: FavoritesList['data'];
  personas: number;
  changeFavorite: IChangeFavorite;
  loadingReference?: string;
}) => {
  return (
    <StyledContainer>
      {favorites?.map((fav, key) => {
        return (
          <FavouriteCard
            key={key}
            cancelacion={fav?.cancelacion}
            cant_puntaje={Number(fav?.cant_puntaje)}
            capacidad_max={fav?.capacidad_max}
            cantidadUnidades={fav?.cantidadUnidades || 0}
            es_destacado={!!fav?.es_destacado}
            es_destacado_gold={!!fav?.es_destacado_gold}
            es_troya={!!fav?.es_troya}
            fecha_carga={fav?.fecha_carga}
            foto_listado={fav?.foto_listado}
            fotos={fav?.fotos || []}
            handleFavorite={changeFavorite}
            isLoadingFav={loadingReference === fav?.referencia}
            link={fav?.link}
            nombre_localidad={fav?.nombre_localidad}
            ofertas_flexibles={fav?.ofertasFlexibles || []}
            ofertas_um={fav?.ofertas_um || []}
            personas={personas}
            precio_minimo_calculado={Number(fav?.precio_minimo_calculado)}
            puntaje={fav?.puntaje}
            referencia={fav.referencia}
            tipo={fav?.tipo}
            titulo={fav?.titulo}
            permite_reservas={fav?.permite_reservas}
            porcentaje_oferta={fav?.porcentaje_oferta}
            precio_sin_descuento={fav?.precio_sin_descuento}
          />
        );
      })}
    </StyledContainer>
  );
};

export default memo(FavoriteList);
