import React from 'react';
import { Grid, Typography } from '@alquiler-argentina/demiurgo';
import { styled } from '@mui/material';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';

interface IError {
  title: string;
  primaryMessage: string;
  secondaryMessage?: string;
}

const StyledContainer = styled(Grid)`
  justify-content: center;
  align-items: center;
  text-align: center;
  pointer-events: none;
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  font-size: 24px;
`;

const StyledParagraph = styled(Typography)`
  font-size: 16px;
  max-width: 328px;
`;

const StyledSecondaryMessageWrapper = styled(Grid)`
  position: relative;
  bottom: -24px;
  padding: 16px;
`;

const StyledSecondaryMessage = styled(Typography)`
  font-size: 14px;
  line-height: 24px;
  text-align: center;
  letter-spacing: 0.15px;
  max-width: 328px;
`;

const StyledWarningAmberIcon = styled(WarningAmberIcon)`
  font-size: 5rem;
  color: #d32f2f;
`;

export default function Error({
  title,
  primaryMessage,
  secondaryMessage,
}: IError) {
  return (
    <StyledContainer container>
      <Grid item container gap={1}>
        <Grid item xs={12}>
          <StyledWarningAmberIcon />
        </Grid>
        <Grid item xs={12}>
          <StyledTitle>{title}</StyledTitle>
        </Grid>
        <Grid item container direction="column" alignItems="center">
          <Grid item>
            <StyledParagraph>{primaryMessage}</StyledParagraph>
          </Grid>
        </Grid>
      </Grid>
      {secondaryMessage && (
        <StyledSecondaryMessageWrapper item>
          <StyledSecondaryMessage variant="body1">
            {secondaryMessage}
          </StyledSecondaryMessage>
        </StyledSecondaryMessageWrapper>
      )}
    </StyledContainer>
  );
}
