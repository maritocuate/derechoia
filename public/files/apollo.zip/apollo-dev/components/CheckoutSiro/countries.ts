/* eslint-disable @typescript-eslint/indent */
import { CountryCode } from 'libphonenumber-js';

interface ICountries {
  id: string;
  pais: string;
  alpha2?:
    | CountryCode
    | {
        defaultCountry?: CountryCode | undefined;
        defaultCallingCode?: string | undefined;
        extract?: boolean | undefined;
      }
    | undefined;
}

const countries: Array<ICountries> = [
  {
    id: '1',
    pais: 'Argentina',
    alpha2: 'AR',
  },
  {
    id: '2',
    pais: 'Andorra',
    alpha2: 'AD',
  },
  {
    id: '3',
    pais: 'Emiratos Árabes Unidos',
    alpha2: 'AE',
  },
  {
    id: '4',
    pais: 'Afganistán',
    alpha2: 'AF',
  },
  {
    id: '5',
    pais: 'Antigua y Barbuda',
    alpha2: 'AG',
  },
  {
    id: '6',
    pais: 'Anguila',
    alpha2: 'AI',
  },
  {
    id: '7',
    pais: 'Albania',
    alpha2: 'AL',
  },
  {
    id: '8',
    pais: 'Armenia',
    alpha2: 'AM',
  },
  {
    id: '9',
    pais: 'Antillas Neerlandesas',
    // alpha2: 'AN',
  },
  {
    id: '10',
    pais: 'Angola',
    alpha2: 'AO',
  },
  {
    id: '11',
    pais: 'Antártida',
    // alpha2: 'AQ',
  },
  {
    id: '12',
    pais: 'Samoa Americana',
    alpha2: 'AS',
  },
  {
    id: '13',
    pais: 'Austria',
    alpha2: 'AT',
  },
  {
    id: '14',
    pais: 'Australia',
    alpha2: 'AU',
  },
  {
    id: '15',
    pais: 'Aruba',
    alpha2: 'AW',
  },
  {
    id: '16',
    pais: 'Islas Áland',
    alpha2: 'AX',
  },
  {
    id: '17',
    pais: 'Azerbaiyán',
    alpha2: 'AZ',
  },
  {
    id: '18',
    pais: 'Bosnia y Herzegovina',
    alpha2: 'BA',
  },
  {
    id: '19',
    pais: 'Barbados',
    alpha2: 'BB',
  },
  {
    id: '20',
    pais: 'Bangladesh',
    alpha2: 'BD',
  },
  {
    id: '21',
    pais: 'Bélgica',
    alpha2: 'BE',
  },
  {
    id: '22',
    pais: 'Burkina Faso',
    alpha2: 'BF',
  },
  {
    id: '23',
    pais: 'Bulgaria',
    alpha2: 'BG',
  },
  {
    id: '24',
    pais: 'Bahréin',
    alpha2: 'BH',
  },
  {
    id: '25',
    pais: 'Burundi',
    alpha2: 'BI',
  },
  {
    id: '26',
    pais: 'Benin',
    alpha2: 'BJ',
  },
  {
    id: '27',
    pais: 'San Bartolomé',
    alpha2: 'BL',
  },
  {
    id: '28',
    pais: 'Bermudas',
    alpha2: 'BM',
  },
  {
    id: '29',
    pais: 'Brunéi',
    alpha2: 'BN',
  },
  {
    id: '30',
    pais: 'Bolivia',
    alpha2: 'BO',
  },
  {
    id: '31',
    pais: 'Brasil',
    alpha2: 'BR',
  },
  {
    id: '32',
    pais: 'Bahamas',
    alpha2: 'BS',
  },
  {
    id: '33',
    pais: 'Bhután',
    alpha2: 'BT',
  },
  {
    id: '34',
    pais: 'Isla Bouvet',
    // alpha2: 'BV',
  },
  {
    id: '35',
    pais: 'Botsuana',
    alpha2: 'BW',
  },
  {
    id: '36',
    pais: 'Belarús',
    alpha2: 'BY',
  },
  {
    id: '37',
    pais: 'Belice',
    alpha2: 'BZ',
  },
  {
    id: '38',
    pais: 'Canadá',
    alpha2: 'CA',
  },
  {
    id: '39',
    pais: 'Islas Cocos',
    alpha2: 'CC',
  },
  {
    id: '40',
    pais: 'República Centro-Africana',
    alpha2: 'CF',
  },
  {
    id: '41',
    pais: 'Congo',
    alpha2: 'CG',
  },
  {
    id: '42',
    pais: 'Suiza',
    alpha2: 'CH',
  },
  {
    id: '43',
    pais: 'Costa de Marfil',
    alpha2: 'CI',
  },
  {
    id: '44',
    pais: 'Islas Cook',
    alpha2: 'CK',
  },
  {
    id: '45',
    pais: 'Chile',
    alpha2: 'CL',
  },
  {
    id: '46',
    pais: 'Camerún',
    alpha2: 'CM',
  },
  {
    id: '47',
    pais: 'China',
    alpha2: 'CN',
  },
  {
    id: '48',
    pais: 'Colombia',
    alpha2: 'CO',
  },
  {
    id: '49',
    pais: 'Costa Rica',
    alpha2: 'CR',
  },
  {
    id: '50',
    pais: 'Cuba',
    alpha2: 'CU',
  },
  {
    id: '51',
    pais: 'Cabo Verde',
    alpha2: 'CV',
  },
  {
    id: '52',
    pais: 'Islas Christmas',
    alpha2: 'CX',
  },
  {
    id: '53',
    pais: 'Chipre',
    alpha2: 'CY',
  },
  {
    id: '54',
    pais: 'República Checa',
    alpha2: 'CZ',
  },
  {
    id: '55',
    pais: 'Alemania',
    alpha2: 'DE',
  },
  {
    id: '56',
    pais: 'Yibuti',
    alpha2: 'DJ',
  },
  {
    id: '57',
    pais: 'Dinamarca',
    alpha2: 'DK',
  },
  {
    id: '58',
    pais: 'Domínica',
    alpha2: 'DM',
  },
  {
    id: '59',
    pais: 'República Dominicana',
    alpha2: 'DO',
  },
  {
    id: '60',
    pais: 'Argel',
    alpha2: 'DZ',
  },
  {
    id: '61',
    pais: 'Ecuador',
    alpha2: 'EC',
  },
  {
    id: '62',
    pais: 'Estonia',
    alpha2: 'EE',
  },
  {
    id: '63',
    pais: 'Egipto',
    alpha2: 'EG',
  },
  {
    id: '64',
    pais: 'Sahara Occidental',
    alpha2: 'EH',
  },
  {
    id: '65',
    pais: 'Eritrea',
    alpha2: 'ER',
  },
  {
    id: '66',
    pais: 'España',
    alpha2: 'ES',
  },
  {
    id: '67',
    pais: 'Etiopía',
    alpha2: 'ET',
  },
  {
    id: '68',
    pais: 'Finlandia',
    alpha2: 'FI',
  },
  {
    id: '69',
    pais: 'Fiji',
    alpha2: 'FJ',
  },
  {
    id: '70',
    pais: 'Islas Malvinas',
    alpha2: 'FK',
  },
  {
    id: '71',
    pais: 'Micronesia',
    alpha2: 'FM',
  },
  {
    id: '72',
    pais: 'Islas Faroe',
    alpha2: 'FO',
  },
  {
    id: '73',
    pais: 'Francia',
    alpha2: 'FR',
  },
  {
    id: '74',
    pais: 'Gabón',
    alpha2: 'GA',
  },
  {
    id: '75',
    pais: 'Reino Unido',
    alpha2: 'GB',
  },
  {
    id: '76',
    pais: 'Granada',
    alpha2: 'GD',
  },
  {
    id: '77',
    pais: 'Georgia',
    alpha2: 'GE',
  },
  {
    id: '78',
    pais: 'Guayana Francesa',
    alpha2: 'GF',
  },
  {
    id: '79',
    pais: 'Guernsey',
    alpha2: 'GG',
  },
  {
    id: '80',
    pais: 'Ghana',
    alpha2: 'GH',
  },
  {
    id: '81',
    pais: 'Gibraltar',
    alpha2: 'GI',
  },
  {
    id: '82',
    pais: 'Groenlandia',
    alpha2: 'GL',
  },
  {
    id: '83',
    pais: 'Gambia',
    alpha2: 'GM',
  },
  {
    id: '84',
    pais: 'Guinea',
    alpha2: 'GN',
  },
  {
    id: '85',
    pais: 'Guadalupe',
    alpha2: 'GP',
  },
  {
    id: '86',
    pais: 'Guinea Ecuatorial',
    alpha2: 'GQ',
  },
  {
    id: '87',
    pais: 'Grecia',
    alpha2: 'GR',
  },
  {
    id: '88',
    pais: 'Georgia del Sur e Islas Sandwich del Sur',
    // alpha2: 'GS',
  },
  {
    id: '89',
    pais: 'Guatemala',
    alpha2: 'GT',
  },
  {
    id: '90',
    pais: 'Guam',
    alpha2: 'GU',
  },
  {
    id: '91',
    pais: 'Guinea-Bissau',
    alpha2: 'GW',
  },
  {
    id: '92',
    pais: 'Guayana',
    alpha2: 'GY',
  },
  {
    id: '93',
    pais: 'Hong Kong',
    alpha2: 'HK',
  },
  {
    id: '94',
    pais: 'Islas Heard y McDonald',
    // alpha2: 'HM',
  },
  {
    id: '95',
    pais: 'Honduras',
    alpha2: 'HN',
  },
  {
    id: '96',
    pais: 'Croacia',
    alpha2: 'HR',
  },
  {
    id: '97',
    pais: 'Haití',
    alpha2: 'HT',
  },
  {
    id: '98',
    pais: 'Hungría',
    alpha2: 'HU',
  },
  {
    id: '99',
    pais: 'Indonesia',
    alpha2: 'ID',
  },
  {
    id: '100',
    pais: 'Irlanda',
    alpha2: 'IE',
  },
  {
    id: '101',
    pais: 'Israel',
    alpha2: 'IL',
  },
  {
    id: '102',
    pais: 'Isla de Man',
    alpha2: 'IM',
  },
  {
    id: '103',
    pais: 'India',
    alpha2: 'IN',
  },
  {
    id: '104',
    pais: 'Territorio Británico del Océano Índico',
    alpha2: 'IO',
  },
  {
    id: '105',
    pais: 'Irak',
    alpha2: 'IQ',
  },
  {
    id: '106',
    pais: 'Irán',
    alpha2: 'IR',
  },
  {
    id: '107',
    pais: 'Islandia',
    alpha2: 'IS',
  },
  {
    id: '108',
    pais: 'Italia',
    alpha2: 'IT',
  },
  {
    id: '109',
    pais: 'Jersey',
    alpha2: 'JE',
  },
  {
    id: '110',
    pais: 'Jamaica',
    alpha2: 'JM',
  },
  {
    id: '111',
    pais: 'Jordania',
    alpha2: 'JO',
  },
  {
    id: '112',
    pais: 'Japón',
    alpha2: 'JP',
  },
  {
    id: '113',
    pais: 'Kenia',
    alpha2: 'KE',
  },
  {
    id: '114',
    pais: 'Kirguistán',
    alpha2: 'KG',
  },
  {
    id: '115',
    pais: 'Camboya',
    alpha2: 'KH',
  },
  {
    id: '116',
    pais: 'Kiribati',
    alpha2: 'KI',
  },
  {
    id: '117',
    pais: 'Comoros',
    alpha2: 'KM',
  },
  {
    id: '118',
    pais: 'San Cristóbal y Nieves',
    alpha2: 'KN',
  },
  {
    id: '119',
    pais: 'Corea del Norte',
    alpha2: 'KP',
  },
  {
    id: '120',
    pais: 'Corea del Sur',
    alpha2: 'KR',
  },
  {
    id: '121',
    pais: 'Kuwait',
    alpha2: 'KW',
  },
  {
    id: '122',
    pais: 'Islas Caimán',
    alpha2: 'KY',
  },
  {
    id: '123',
    pais: 'Kazajstán',
    alpha2: 'KZ',
  },
  {
    id: '124',
    pais: 'Laos',
    alpha2: 'LA',
  },
  {
    id: '125',
    pais: 'Líbano',
    alpha2: 'LB',
  },
  {
    id: '126',
    pais: 'Santa Lucía',
    alpha2: 'LC',
  },
  {
    id: '127',
    pais: 'Liechtenstein',
    alpha2: 'LI',
  },
  {
    id: '128',
    pais: 'Sri Lanka',
    alpha2: 'LK',
  },
  {
    id: '129',
    pais: 'Liberia',
    alpha2: 'LR',
  },
  {
    id: '130',
    pais: 'Lesotho',
    alpha2: 'LS',
  },
  {
    id: '131',
    pais: 'Lituania',
    alpha2: 'LT',
  },
  {
    id: '132',
    pais: 'Luxemburgo',
    alpha2: 'LU',
  },
  {
    id: '133',
    pais: 'Letonia',
    alpha2: 'LV',
  },
  {
    id: '134',
    pais: 'Libia',
    alpha2: 'LY',
  },
  {
    id: '135',
    pais: 'Marruecos',
    alpha2: 'MA',
  },
  {
    id: '136',
    pais: 'Mónaco',
    alpha2: 'MC',
  },
  {
    id: '137',
    pais: 'Moldova',
    alpha2: 'MD',
  },
  {
    id: '138',
    pais: 'Montenegro',
    alpha2: 'ME',
  },
  {
    id: '139',
    pais: 'Madagascar',
    alpha2: 'MG',
  },
  {
    id: '140',
    pais: 'Islas Marshall',
    alpha2: 'MH',
  },
  {
    id: '141',
    pais: 'Macedonia',
    alpha2: 'MK',
  },
  {
    id: '142',
    pais: 'Mali',
    alpha2: 'ML',
  },
  {
    id: '143',
    pais: 'Myanmar',
    alpha2: 'MM',
  },
  {
    id: '144',
    pais: 'Mongolia',
    alpha2: 'MN',
  },
  {
    id: '145',
    pais: 'Macao',
    alpha2: 'MO',
  },
  {
    id: '146',
    pais: 'Martinica',
    alpha2: 'MQ',
  },
  {
    id: '147',
    pais: 'Mauritania',
    alpha2: 'MR',
  },
  {
    id: '148',
    pais: 'Montserrat',
    alpha2: 'MS',
  },
  {
    id: '149',
    pais: 'Malta',
    alpha2: 'MT',
  },
  {
    id: '150',
    pais: 'Mauricio',
    alpha2: 'MU',
  },
  {
    id: '151',
    pais: 'Maldivas',
    alpha2: 'MV',
  },
  {
    id: '152',
    pais: 'Malawi',
    alpha2: 'MW',
  },
  {
    id: '153',
    pais: 'México',
    alpha2: 'MX',
  },
  {
    id: '154',
    pais: 'Malasia',
    alpha2: 'MY',
  },
  {
    id: '155',
    pais: 'Mozambique',
    alpha2: 'MZ',
  },
  {
    id: '156',
    pais: 'Namibia',
    alpha2: 'NA',
  },
  {
    id: '157',
    pais: 'Nueva Caledonia',
    alpha2: 'NC',
  },
  {
    id: '158',
    pais: 'Níger',
    alpha2: 'NE',
  },
  {
    id: '159',
    pais: 'Islas Norkfolk',
    alpha2: 'NF',
  },
  {
    id: '160',
    pais: 'Nigeria',
    alpha2: 'NG',
  },
  {
    id: '161',
    pais: 'Nicaragua',
    alpha2: 'NI',
  },
  {
    id: '162',
    pais: 'Países Bajos',
    alpha2: 'NL',
  },
  {
    id: '163',
    pais: 'Noruega',
    alpha2: 'NO',
  },
  {
    id: '164',
    pais: 'Nepal',
    alpha2: 'NP',
  },
  {
    id: '165',
    pais: 'Nauru',
    alpha2: 'NR',
  },
  {
    id: '166',
    pais: 'Niue',
    alpha2: 'NU',
  },
  {
    id: '167',
    pais: 'Nueva Zelanda',
    alpha2: 'NZ',
  },
  {
    id: '168',
    pais: 'Omán',
    alpha2: 'OM',
  },
  {
    id: '169',
    pais: 'Panamá',
    alpha2: 'PA',
  },
  {
    id: '170',
    pais: 'Perú',
    alpha2: 'PE',
  },
  {
    id: '171',
    pais: 'Polinesia Francesa',
    alpha2: 'PF',
  },
  {
    id: '172',
    pais: 'Papúa Nueva Guinea',
    alpha2: 'PG',
  },
  {
    id: '173',
    pais: 'Filipinas',
    alpha2: 'PH',
  },
  {
    id: '174',
    pais: 'Pakistán',
    alpha2: 'PK',
  },
  {
    id: '175',
    pais: 'Polonia',
    alpha2: 'PL',
  },
  {
    id: '176',
    pais: 'San Pedro y Miquelón',
    alpha2: 'PM',
  },
  {
    id: '177',
    pais: 'Islas Pitcairn',
    // alpha2: 'PN',
  },
  {
    id: '178',
    pais: 'Puerto Rico',
    alpha2: 'PR',
  },
  {
    id: '179',
    pais: 'Palestina',
    alpha2: 'PS',
  },
  {
    id: '180',
    pais: 'Portugal',
    alpha2: 'PT',
  },
  {
    id: '181',
    pais: 'Islas Palaos',
    alpha2: 'PW',
  },
  {
    id: '182',
    pais: 'Paraguay',
    alpha2: 'PY',
  },
  {
    id: '183',
    pais: 'Qatar',
    alpha2: 'QA',
  },
  {
    id: '184',
    pais: 'Reunión',
    alpha2: 'RE',
  },
  {
    id: '185',
    pais: 'Rumanía',
    alpha2: 'RO',
  },
  {
    id: '186',
    pais: 'Serbia y Montenegro',
    alpha2: 'RS',
  },
  {
    id: '187',
    pais: 'Rusia',
    alpha2: 'RU',
  },
  {
    id: '188',
    pais: 'Ruanda',
    alpha2: 'RW',
  },
  {
    id: '189',
    pais: 'Arabia Saudita',
    alpha2: 'SA',
  },
  {
    id: '190',
    pais: 'Islas Solomón',
    alpha2: 'SB',
  },
  {
    id: '191',
    pais: 'Seychelles',
    alpha2: 'SC',
  },
  {
    id: '192',
    pais: 'Sudán',
    alpha2: 'SD',
  },
  {
    id: '193',
    pais: 'Suecia',
    alpha2: 'SE',
  },
  {
    id: '194',
    pais: 'Singapur',
    alpha2: 'SG',
  },
  {
    id: '195',
    pais: 'Santa Elena',
    alpha2: 'SH',
  },
  {
    id: '196',
    pais: 'Eslovenia',
    alpha2: 'SI',
  },
  {
    id: '197',
    pais: 'Islas Svalbard y Jan Mayen',
    alpha2: 'SJ',
  },
  {
    id: '198',
    pais: 'Eslovaquia',
    alpha2: 'SK',
  },
  {
    id: '199',
    pais: 'Sierra Leona',
    alpha2: 'SL',
  },
  {
    id: '200',
    pais: 'San Marino',
    alpha2: 'SM',
  },
  {
    id: '201',
    pais: 'Senegal',
    alpha2: 'SN',
  },
  {
    id: '202',
    pais: 'Somalia',
    alpha2: 'SO',
  },
  {
    id: '203',
    pais: 'Surinam',
    alpha2: 'SR',
  },
  {
    id: '204',
    pais: 'Santo Tomé y Príncipe',
    alpha2: 'ST',
  },
  {
    id: '205',
    pais: 'El Salvador',
    alpha2: 'SV',
  },
  {
    id: '206',
    pais: 'Siria',
    alpha2: 'SY',
  },
  {
    id: '207',
    pais: 'Suazilandia',
    alpha2: 'SZ',
  },
  {
    id: '208',
    pais: 'Islas Turcas y Caicos',
    alpha2: 'TC',
  },
  {
    id: '209',
    pais: 'Chad',
    alpha2: 'TD',
  },
  {
    id: '210',
    pais: 'Territorios Australes Franceses',
    // alpha2: 'TF',
  },
  {
    id: '211',
    pais: 'Togo',
    alpha2: 'TG',
  },
  {
    id: '212',
    pais: 'Tailandia',
    alpha2: 'TH',
  },
  {
    id: '213',
    pais: 'Tanzania',
    alpha2: 'TH',
  },
  {
    id: '214',
    pais: 'Tayikistán',
    alpha2: 'TJ',
  },
  {
    id: '215',
    pais: 'Tokelau',
    alpha2: 'TK',
  },
  {
    id: '216',
    pais: 'Timor-Leste',
    alpha2: 'TL',
  },
  {
    id: '217',
    pais: 'Turkmenistán',
    alpha2: 'TM',
  },
  {
    id: '218',
    pais: 'Túnez',
    alpha2: 'TN',
  },
  {
    id: '219',
    pais: 'Tonga',
    alpha2: 'TO',
  },
  {
    id: '220',
    pais: 'Turquía',
    alpha2: 'TR',
  },
  {
    id: '221',
    pais: 'Trinidad y Tobago',
    alpha2: 'TT',
  },
  {
    id: '222',
    pais: 'Tuvalu',
    alpha2: 'TV',
  },
  {
    id: '223',
    pais: 'Taiwán',
    alpha2: 'TW',
  },
  {
    id: '224',
    pais: 'Ucrania',
    alpha2: 'UA',
  },
  {
    id: '225',
    pais: 'Uganda',
    alpha2: 'UG',
  },
  {
    id: '226',
    pais: 'Estados Unidos de América',
    alpha2: 'US',
  },
  {
    id: '227',
    pais: 'Uruguay',
    alpha2: 'UY',
  },
  {
    id: '228',
    pais: 'Uzbekistán',
    alpha2: 'UZ',
  },
  {
    id: '229',
    pais: 'Ciudad del Vaticano',
    alpha2: 'VA',
  },
  {
    id: '230',
    pais: 'San Vicente y las Granadinas',
    alpha2: 'VC',
  },
  {
    id: '231',
    pais: 'Venezuela',
    alpha2: 'VE',
  },
  {
    id: '232',
    pais: 'Islas Vírgenes Británicas',
    alpha2: 'VG',
  },
  {
    id: '233',
    pais: 'Islas Vírgenes de los Estados Unidos de América',
    alpha2: 'VI',
  },
  {
    id: '234',
    pais: 'Vietnam',
    alpha2: 'VN',
  },
  {
    id: '235',
    pais: 'Vanuatu',
    alpha2: 'VU',
  },
  {
    id: '236',
    pais: 'Wallis y Futuna',
    alpha2: 'WF',
  },
  {
    id: '237',
    pais: 'Samoa',
    alpha2: 'WS',
  },
  {
    id: '238',
    pais: 'Yemen',
    alpha2: 'YE',
  },
  {
    id: '239',
    pais: 'Mayotte',
    alpha2: 'YT',
  },
  {
    id: '240',
    pais: 'Sudáfrica',
    alpha2: 'ZA',
  },
];

export default countries;
