/* eslint-disable @typescript-eslint/indent */
import React, { useMemo } from 'react';
import {
  Breadcrums,
  Divider,
  Grid,
  IconWithText,
  Typography,
  Valoraciones,
} from '@alquiler-argentina/demiurgo';
import { LinkProps, styled } from '@mui/material';
import DateRangeOutlinedIcon from '@mui/icons-material/DateRangeOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import { StyledImage as StyledImageImport } from '../CardValueOffer/styles';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import TotalPrice from './TotalPrice';

dayjs.locale('es');

export interface ICheckoutInfo {
  titleAlojamiento: string;
  location?: LinkProps[] | null;
  averageRating: number;
  image: string;
  reservationInfo: {
    typology: {
      title: string;
      capacity: number;
      rooms: number;
      bathrooms: number;
    };
    dates: { startDate: string; endDate: string }; // figure this
    guests: number;
    stay: number;
  };
  prices: {
    type: string;
    base: number | null;
    total: number | null;
    discounts?: {
      percentage: number | null;
      total: number | null;
    };
    advance?: number;
    rest?: number;
  };
  cleaningFee?: number;
  cargoExtra?: number;
  dayValueDiffers: boolean;
  detallePrecio: { precio: number; fecha: string }[][] | null;
  step?: number;
  cyberMondayDiscount?: number | null;
}

const StyledContainer = styled(Grid)`
  justify-content: center;
  cursor: default;
`;

const StyledTotalContainer = styled(Grid)`
  padding: 0.5rem 1rem;
  margin-top: 0.5rem;
  border-radius: 0.5rem;
  background-color: #00acc10a;
`;

export const StyledInfo = styled(Grid)(
  ({ theme }) => `
    padding-inline: 1rem;
    padding-block-end: 1.5rem;
    pointer-events: none;
    ${theme.breakpoints.up('sm')} {
      max-width: 360px;
      border-top-right-radius: 8px;
      border-top-left-radius: 8px;
      box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0.2), 0px 0px 0px 0px rgba(0, 0, 0, 0.14), 0px 3px 14px 2px rgba(0, 0, 0, 0.12);
    };
  `,
);

export const Styledimage = styled(StyledImageImport)(
  ({ theme }) => `
  min-height: 136px;
  width: 100%;
  border-radius: 0.25rem;
  margin-block-start: 1.5rem;
  cursor: default;
  ${theme.breakpoints.down('sm')} {
    width: 100%;
  };
`,
);

const StyledSpan = styled('span')`
  color: #00000099;
`;

const StyledDetails = styled(Grid)(
  ({ theme }) => `
    padding-inline: 1rem;
    height: 313px;
    ${theme.breakpoints.up('sm')} {
      height: initial;
      max-width: 360px;
      border-bottom-right-radius: 8px;
      border-bottom-left-radius: 8px;
      padding-block: 0;
      padding-block-end: 1.5rem;
      box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0.2), 0px 0px 0px 0px rgba(0, 0, 0, 0.14), 0px 3px 14px 2px rgba(0, 0, 0, 0.12);
    }
  `,
);

const StyledTextPrice = styled(Typography)`
  font-size: 0.875rem;
`;

export const StyledTitle = styled(Typography)`
  font-size: 20px;
  font-weight: 700;
`;

const ItemsDetailsPriceDiscount = styled(Typography)`
  color: #00acc1;
  font-size: 0.875rem;
`;

const ItemsDetailsCyberMonday = styled(Typography)`
  color: #7d34c4;
  font-size: 0.875rem;
`;

export const StyledIconWithText = styled(IconWithText)`
  font-size: 0.875rem;
  & svg {
    width: 16px;
    height: 16px;
    color: #00000099;
  }
`;

export const StyledSeparator = styled(Grid)`
  height: 1rem;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.04);
  z-index: 999;
`;

export default function CheckoutInfo({
  titleAlojamiento,
  location,
  image,
  averageRating,
  reservationInfo,
  cleaningFee,
  dayValueDiffers,
  prices,
  cargoExtra,
  detallePrecio,
  step,
  cyberMondayDiscount,
}: ICheckoutInfo) {
  const { t } = useTranslation(['CheckoutSIRO', 'BookingSummary']);
  const { priceToShow, noDiscount } = useMemo(
    () => ({
      priceToShow: prices.base,
      noDiscount: !prices.discounts?.percentage,
    }),
    [prices],
  );
  const cyberMondayDiscounted =
    prices.base && cyberMondayDiscount
      ? prices.base * (cyberMondayDiscount / 100)
      : 0;

  return (
    <StyledContainer container data-testid="checkoutInfo">
      <StyledInfo item container rowSpacing={1}>
        <Styledimage item featuredimage={image} />
        <Grid item container direction="column" spacing={0}>
          <Grid item>
            <StyledTitle variant="h6">{titleAlojamiento}</StyledTitle>
          </Grid>
          {location ? (
            <Grid item>
              <Breadcrums separator="/" linkAttribute={location} />
            </Grid>
          ) : null}
          {averageRating > 0 && (
            <Grid item>
              <Valoraciones
                anchor="valoracionPromedio"
                average={averageRating === null ? 0 : averageRating}
                children={0}
              />
            </Grid>
          )}
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item container spacing={0.5} direction="column">
          <Grid item>
            <StyledTextPrice fontWeight={600}>
              {reservationInfo.typology.title}
            </StyledTextPrice>
          </Grid>
          <Grid item>
            <StyledTextPrice>
              {reservationInfo.typology.capacity === 0
                ? t('maxCapacity_one', {
                    maxCapacity: reservationInfo.typology.capacity,
                  })
                : t('maxCapacity_other', {
                    maxCapacity: reservationInfo.typology.capacity,
                  })}{' '}
              • {reservationInfo.typology.rooms === 0 ? 'Monoambiente' : null}
              {reservationInfo.typology.rooms === 1
                ? t('rooms_one', { rooms: reservationInfo.typology.rooms })
                : null}
              {reservationInfo.typology.rooms > 1
                ? t('rooms_other', { rooms: reservationInfo.typology.rooms })
                : null}{' '}
              •{' '}
              {reservationInfo.typology.bathrooms === 1
                ? t('bathrooms_one', {
                    bathrooms: reservationInfo.typology.bathrooms,
                  })
                : null}
              {reservationInfo.typology.bathrooms > 1
                ? t('bathrooms_other', {
                    bathrooms: reservationInfo.typology.bathrooms,
                  })
                : null}
            </StyledTextPrice>
          </Grid>
          <Grid item container>
            <Grid item marginTop={1}>
              <StyledIconWithText
                icon={<DateRangeOutlinedIcon />}
                anchor="left"
              >
                {dayjs(reservationInfo.dates.startDate).format('DD MMM')} -{' '}
                {dayjs(reservationInfo.dates.endDate).format('DD MMM')}
              </StyledIconWithText>
            </Grid>
            <Grid item marginLeft={2} marginTop={1}>
              <StyledIconWithText
                icon={<PersonOutlineOutlinedIcon />}
                anchor="left"
              >
                {reservationInfo.guests === 0
                  ? t('guests_one', { guests: reservationInfo.guests })
                  : t('guests_other', { guests: reservationInfo.guests })}
              </StyledIconWithText>
            </Grid>
          </Grid>
        </Grid>
      </StyledInfo>
      <StyledSeparator item />
      <StyledDetails item xs={12}>
        <Grid item container direction="column" marginTop="24px">
          <Grid item>
            <Typography
              variant="h6"
              marginBottom="12px"
              sx={{ fontWeight: '600', fontSize: '20px' }}
            >
              {t('price-detail', { ns: 'BookingSummary' })}
            </Typography>
          </Grid>
          <Grid
            item
            container
            justifyContent="space-between"
            marginBottom="8px"
          >
            <Grid item alignItems="baseline">
              {dayValueDiffers ? (
                <StyledTextPrice variant="body2">
                  {t('accommodation', { ns: 'BookingSummary' })}
                </StyledTextPrice>
              ) : (
                <Grid item container>
                  <Grid item>
                    <StyledTextPrice variant="body2">
                      {t('accommodation', { ns: 'BookingSummary' })}
                    </StyledTextPrice>
                  </Grid>
                </Grid>
              )}
              {detallePrecio?.map((el, i) => {
                if (!noDiscount) {
                  return (
                    <StyledTextPrice
                      variant="body2"
                      marginLeft={0}
                      key={i}
                      marginTop={1}
                      marginBottom={1}
                    >
                      <StyledSpan>
                        {`(${formatPriceToArs(el[0].precio)} x ${el.length} 
                    ${t('nights', {
                      count: el.length,
                      nights: el.length,
                      ns: 'BookingSummary',
                    })})
                    `}
                      </StyledSpan>
                      {formatPriceToArs(el[0].precio * el.length)}
                    </StyledTextPrice>
                  );
                }
                return (
                  <StyledTextPrice
                    variant="body2"
                    marginLeft={0}
                    key={i}
                    marginTop={1}
                    marginBottom={1}
                  >
                    {`($${formatPriceNoDiscount(el[0].precio)} x ${el.length} 
                    ${t('nights', {
                      count: el.length,
                      nights: el.length,
                      ns: 'BookingSummary',
                    })})
                    $${formatPriceNoDiscount(el[0].precio * el.length)}`}
                  </StyledTextPrice>
                );
              })}
            </Grid>

            <Grid item>
              <StyledTextPrice variant="body2">
                {noDiscount
                  ? `$${formatPriceNoDiscount(priceToShow as number)}`
                  : formatPriceToArs(priceToShow as number)}
              </StyledTextPrice>
            </Grid>
          </Grid>
          {prices.discounts?.percentage &&
          prices.discounts?.percentage !== 0 ? (
            <Grid
              item
              container
              justifyContent="space-between"
              marginBottom="8px"
              color="#00ACC1"
            >
              <Grid item>
                <ItemsDetailsPriceDiscount variant="body2">
                  {t('discount', {
                    percentage: Math.trunc(prices.discounts?.percentage),
                  })}
                </ItemsDetailsPriceDiscount>
              </Grid>
              <Grid item>
                <ItemsDetailsPriceDiscount variant="body2">
                  - {formatPriceToArs(prices.discounts?.total as number)}
                </ItemsDetailsPriceDiscount>
              </Grid>
            </Grid>
          ) : null}
          {!!cyberMondayDiscount && (
            <Grid
              item
              container
              justifyContent="space-between"
              marginBottom="0.5rem"
              color="#7D34C4"
            >
              <Grid item>
                <ItemsDetailsCyberMonday variant="body2">
                  Cyber Monday {cyberMondayDiscount}% Off
                </ItemsDetailsCyberMonday>
              </Grid>
              <Grid item>
                <ItemsDetailsCyberMonday variant="body2">
                  - {formatPriceToArs(cyberMondayDiscounted)}
                </ItemsDetailsCyberMonday>
              </Grid>
            </Grid>
          )}
          {cleaningFee ? (
            <Grid
              item
              container
              justifyContent="space-between"
              marginBottom="8px"
            >
              <Grid item>
                <StyledTextPrice variant="body2">
                  {t('cleaning', { ns: 'BookingSummary' })}
                </StyledTextPrice>
              </Grid>
              <Grid item>
                <StyledTextPrice variant="body2">
                  {formatPriceToArs(cleaningFee)}
                </StyledTextPrice>
              </Grid>
            </Grid>
          ) : null}
          {cargoExtra && (
            <Grid
              item
              container
              justifyContent="space-between"
              marginBottom="8px"
            >
              <Grid item>
                <StyledTextPrice variant="body2">Otros gastos</StyledTextPrice>
              </Grid>
              <Grid item>
                <StyledTextPrice variant="body2">
                  {formatPriceToArs(cargoExtra)}
                </StyledTextPrice>
              </Grid>
            </Grid>
          )}
          {step !== 3 && (
            <Grid item>
              <Divider />
            </Grid>
          )}
          {step && step === 3 ? (
            <StyledTotalContainer>
              <TotalPrice
                prices={prices}
                noDiscount={noDiscount}
                paymentText={t('payment')}
                bookingAdvanceText={t('booking-advance')}
              />
            </StyledTotalContainer>
          ) : (
            <TotalPrice
              prices={prices}
              noDiscount={noDiscount}
              paymentText={t('payment')}
              bookingAdvanceText={t('booking-advance')}
            />
          )}
        </Grid>
      </StyledDetails>
    </StyledContainer>
  );
}
