import React from 'react';
import { Alert, Typography, styled } from '@mui/material';
import { LocalFireDepartmentOutlined } from '@mui/icons-material';
import useIsMobile from '../../hooks/useIsMobile';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';

export const StyledAlert = styled(Alert)(
  ({ theme }) => `
  border: 1px solid #FFB400;
  background-color: #FFF17614;
  color: #000000;
  font-weight: 500;
  letter-spacing: 0.15px;
  width: calc(100% - 2rem);
  margin: 1rem auto; 
  & svg {
    color: #FBC02D;
  }
  ${theme.breakpoints.up('lg')}{
    max-width: 72.25rem;
    margin: 0 1rem;
    margin-bottom: 1.5rem; 
  }
`,
);

interface IAlert {
  savings: number;
}

const AlertFomo = ({ savings }: IAlert) => {
  const isMobile = useIsMobile();
  return (
    <StyledAlert
      severity="warning"
      icon={
        <LocalFireDepartmentOutlined
          fontSize="medium"
          sx={{
            color: '#FFB400',
            fill: 'currentcolor',
            marginTop: `${isMobile ? '0.125rem' : '0'}`,
          }}
        />
      }
    >
      {isMobile && (
        <>
          <Typography>¡No te pierdas esta oferta!.</Typography>
          <Typography>
            Reservá ahora y ahorrá {formatPriceToArs(savings)}.
          </Typography>
        </>
      )}
      {!isMobile && (
        <Typography>
          ¡No te pierdas esta oferta!. Reservá ahora y ahorrá{' '}
          {formatPriceToArs(savings)}.
        </Typography>
      )}
    </StyledAlert>
  );
};

export default AlertFomo;
