import React from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  LinkProps,
  styled,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import { Grid, Typography } from '@alquiler-argentina/demiurgo';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CheckoutInfo, { StyledSeparator } from './CheckoutInfo';
import TermsAndConditions from '../TermsAndConditions';
import Terms from '../TermsAndConditions/Politics/Terms';
import Cancellation from '../TermsAndConditions/Politics/Cancellation';
import Rules from '../TermsAndConditions/Politics/Rules';
import Guarantee from '../TermsAndConditions/Politics/Guarantee';
import Payment from '../TermsAndConditions/Politics/Payment';
import { TRule } from '../../types/propiedades.types';
import CheckInCheckOut from '../TermsAndConditions/Politics/CheckInCheckOut';

interface IFirstStep {
  titleAlojamiento?: string;
  location?: LinkProps[] | null;
  image?: string;
  cargoExtra?: number;
  averageRating?: number;
  reservationInfo: {
    typology: {
      title: string;
      capacity: number;
      rooms: number;
      bathrooms: number;
    };
    dates: { startDate: string; endDate: string }; // figure this out
    guests: number;
    stay: number;
  };
  prices: {
    type: string;
    base: number | null;
    total: number | null;
    discounts?: {
      percentage: number | null;
      total: number | null;
    };
    advance?: number;
    rest?: number;
  };
  valorPagoAnticipado?: number;
  nights?: number;
  cancelacion?: string | 'gratis' | 'flexible' | 'estricta';
  cash?: boolean;
  bankTransfer?: boolean;
  creditCard?: boolean;
  coupon?: boolean;
  acepta_familias?: TRule;
  acepta_parejas?: TRule;
  acepta_grupo_jovenes?: TRule;
  apto_niños?: TRule;
  apto_bebes?: TRule;
  acepta_mascotas?: TRule;
  apto_movilidad_reducida?: TRule;
  permite_fumar?: TRule;
  permite_hacer_fiestas?: TRule;
  permite_recibir_visitas?: TRule;
  permite_musica?: TRule;
  garantia?: number;
  a_reintegrar?: boolean;
  valor_a_reintegrar?: string;
  datos_tarjeta?: boolean;
  foto_dni?: boolean;
  presentar_documento?: boolean;
  firma_contrato?: boolean;
  cleaningFee?: number;
  detallePrecio: null | [];
  horarioIngreso?: string | null;
  horarioEgreso?: string | null;
  cancelationFlexMonths?: number | null;
  cancelationFreeDays?: number | null;
  cyberMondayDiscount?: number | null;
}

const StyledSection = styled(Grid)`
  padding-inline: 1rem;
`;

const StyledAccordion = styled(Accordion)`
  border: none;
  box-shadow: none;
  padding-block: 1rem;
  border-block-end: 3px solid rgba(0, 0, 0, 0.04);
  &:last-of-type {
    border-radius: initial;
  }
`;

const StyledAccordionTitle = styled(Typography)`
  font-size: 19px;
  font-weight: 700;
`;

const StyledIcon = styled(ExpandMoreIcon)`
  font-size: 2rem;
`;

const StyledGrid = styled(Grid)`
  justify-content: space-between;
  align-items: center;
`;

export default function FirstStep({
  titleAlojamiento,
  location,
  image,
  prices,
  averageRating,
  reservationInfo,
  valorPagoAnticipado,
  nights,
  cancelacion,
  cash,
  bankTransfer,
  creditCard,
  coupon,
  acepta_familias,
  acepta_parejas,
  acepta_grupo_jovenes,
  apto_niños,
  apto_bebes,
  acepta_mascotas,
  apto_movilidad_reducida,
  permite_fumar,
  permite_hacer_fiestas,
  permite_recibir_visitas,
  permite_musica,
  garantia,
  a_reintegrar,
  valor_a_reintegrar,
  datos_tarjeta,
  foto_dni,
  presentar_documento,
  firma_contrato,
  cargoExtra,
  cleaningFee,
  detallePrecio,
  horarioIngreso,
  horarioEgreso,
  cancelationFlexMonths,
  cancelationFreeDays,
  cyberMondayDiscount,
}: IFirstStep) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const termsAndConditions = [
    {
      title: 'Condiciones de la reserva',
      body: <Terms nights={nights} valorPagoAnticipado={valorPagoAnticipado} />,
    },
    {
      title: 'Políticas de cancelación',
      body: (
        <Cancellation
          cancelacion={cancelacion}
          cancelationFlexMonths={cancelationFlexMonths}
          cancelationFreeDays={cancelationFreeDays}
        />
      ),
    },
    {
      title: 'Horarios de ingreso y egreso',
      body: (
        <CheckInCheckOut
          checkinTime={horarioIngreso}
          checkoutTime={horarioEgreso}
        />
      ),
    },
    {
      title: 'Normas del alojamiento',
      body: (
        <Rules
          permite_musica={permite_musica}
          acepta_familias={acepta_familias}
          permite_hacer_fiestas={permite_hacer_fiestas}
          permite_recibir_visitas={permite_recibir_visitas}
          apto_movilidad_reducida={apto_movilidad_reducida}
          acepta_parejas={acepta_parejas}
          acepta_grupo_jovenes={acepta_grupo_jovenes}
          acepta_mascotas={acepta_mascotas}
          permite_fumar={permite_fumar}
          apto_niños={apto_niños}
          apto_bebes={apto_bebes}
        />
      ),
    },
    {
      title: 'Políticas de garantía',
      body: (
        <Guarantee
          garantia={garantia}
          a_reintegrar={a_reintegrar}
          valor_a_reintegrar={valor_a_reintegrar}
          datos_tarjeta={datos_tarjeta}
          foto_dni={foto_dni}
          presentar_documento={presentar_documento}
          firma_contrato={firma_contrato}
        />
      ),
    },
  ];

  if (cash || bankTransfer || coupon || creditCard) {
    termsAndConditions.push({
      title: 'Formas de pago',
      body: (
        <Payment
          cash={cash}
          bankTransfer={bankTransfer}
          creditCard={creditCard}
          coupon={coupon}
        />
      ),
    });
  }
  return (
    <Grid container direction="column">
      {isMobile && (
        <CheckoutInfo
          cargoExtra={cargoExtra}
          titleAlojamiento={titleAlojamiento || ''}
          prices={prices}
          location={location}
          averageRating={averageRating || 0}
          reservationInfo={reservationInfo}
          cleaningFee={cleaningFee}
          dayValueDiffers
          image={image || ''}
          detallePrecio={detallePrecio}
          cyberMondayDiscount={cyberMondayDiscount}
        />
      )}
      {isMobile ? (
        <>
          <StyledSeparator item />
          <StyledSection item container direction="column">
            {termsAndConditions.map((term) => (
              <StyledAccordion disableGutters key={`item-${term.title}`}>
                <AccordionSummary
                  aria-controls="terms-and-conditions"
                  id="terms-and-conditions"
                >
                  <StyledGrid container>
                    <Grid item>
                      <StyledAccordionTitle>{term.title}</StyledAccordionTitle>
                    </Grid>
                    <Grid item sx={{ lineHeight: 0 }}>
                      <StyledIcon />
                    </Grid>
                  </StyledGrid>
                </AccordionSummary>
                <AccordionDetails>{term.body}</AccordionDetails>
              </StyledAccordion>
            ))}
          </StyledSection>
        </>
      ) : (
        <TermsAndConditions
          valorPagoAnticipado={valorPagoAnticipado}
          nights={nights}
          cancelacion={cancelacion}
          cash={cash}
          bankTransfer={bankTransfer}
          creditCard={creditCard}
          coupon={coupon}
          acepta_familias={acepta_familias}
          acepta_parejas={acepta_parejas}
          acepta_grupo_jovenes={acepta_grupo_jovenes}
          apto_niños={apto_niños}
          apto_bebes={apto_bebes}
          acepta_mascotas={acepta_mascotas}
          apto_movilidad_reducida={apto_movilidad_reducida}
          permite_fumar={permite_fumar}
          permite_hacer_fiestas={permite_hacer_fiestas}
          permite_recibir_visitas={permite_recibir_visitas}
          permite_musica={permite_musica}
          garantia={garantia}
          a_reintegrar={a_reintegrar}
          valor_a_reintegrar={valor_a_reintegrar}
          datos_tarjeta={datos_tarjeta}
          foto_dni={foto_dni}
          presentar_documento={presentar_documento}
          firma_contrato={firma_contrato}
          hora_ingreso={horarioIngreso}
          hora_egreso={horarioEgreso}
          cancelationFlexMonths={cancelationFlexMonths}
          cancelationFreeDays={cancelationFreeDays}
        />
      )}
    </Grid>
  );
}
