import React from 'react';
import { Grid, Typography } from '@mui/material';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';

interface ITotalPrice {
  noDiscount: boolean;
  bookingAdvanceText: string;
  paymentText: string;
  prices: {
    type: string;
    total: number | null;
    advance?: number;
    rest?: number;
  };
}

const TotalPrice = ({
  prices,
  noDiscount,
  bookingAdvanceText,
  paymentText,
}: ITotalPrice) => {
  const numberFormat = new Intl.NumberFormat('es-AR');
  return (
    <>
      <Grid item container justifyContent="space-between" marginTop="0.5rem">
        <Grid item>
          <Typography fontWeight={700} fontSize="0.875rem">
            Total ({prices.type})
          </Typography>
        </Grid>
        <Grid item>
          <Typography fontWeight={700} fontSize="0.875rem">
            {noDiscount
              ? `$${formatPriceNoDiscount(prices.total as number)}`
              : formatPriceToArs(prices.total as number)}
          </Typography>
        </Grid>
      </Grid>
      <Grid item container marginTop="0.5rem" paddingBottom={0.5}>
        <Grid item container justifyContent="space-between">
          <Grid item>
            <Typography variant="body2" fontSize="0.875rem">
              {bookingAdvanceText}
            </Typography>
          </Grid>
          <Grid item paddingBottom={0.5}>
            <Typography variant="body2" fontSize="0.875rem">
              ${numberFormat.format(prices.advance as number)}
            </Typography>
          </Grid>
        </Grid>
        <Grid item container justifyContent="space-between">
          <Grid item>
            <Typography variant="body2" fontSize="0.875rem">
              {paymentText}
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant="body2" fontSize="0.875rem">
              ${numberFormat.format(prices.rest as number)}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default TotalPrice;
