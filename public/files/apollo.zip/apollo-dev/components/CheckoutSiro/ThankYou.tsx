import React from 'react';
import { Grid, Typography } from '@alquiler-argentina/demiurgo';
import { styled } from '@mui/material';
import { useTranslation } from 'next-i18next';
import Image from 'next/legacy/image';
import imageLoader from '../../utils/helpers/imageLoaders/imageLoader';

interface IThankYou {
  id?: string | null;
  title: string;
  primaryMessage: string;
  secondaryMessage?: string;
  imageSize: number;
}

const StyledImageBox = styled(Grid)`
  justify-content: center;
  align-items: center;
  text-align: center;
  pointer-events: none;
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  font-size: 24px;
`;

const StyledParagraph = styled(Typography)`
  font-size: 16px;
  max-width: 328px;
`;

const StyledTypography = styled(Typography)`
  font-size: 14px;
  color: rgba(0, 0, 0, 0.6);
  margin-block-start: 60px;
`;

const StyledId = styled(StyledTypography)`
  font-size: 20px;
  font-weight: 700;
  margin-block-start: 0;
`;

const StyledSecondaryMessageWrapper = styled(Grid)`
  position: relative;
  bottom: -24px;
  padding: 16px;
`;

const StyledSecondaryMessage = styled(Typography)`
  font-size: 14px;
  line-height: 24px;
  text-align: center;
  letter-spacing: 0.15px;
  max-width: 328px;
`;

export default function ThankYou({
  id,
  title,
  primaryMessage,
  secondaryMessage,
  imageSize,
}: IThankYou) {
  const { t } = useTranslation('CheckoutSIRO');

  return (
    <StyledImageBox container alignItems="space-between">
      <Grid item container gap={1} justifyContent="center">
        <Grid item xs={12} minHeight={imageSize}>
          <Image
            src="/images/on-success.gif"
            width={imageSize}
            height={imageSize}
            loader={imageLoader}
            priority
          />
        </Grid>
        <Grid item xs={12}>
          <StyledTitle>{title}</StyledTitle>
        </Grid>
        <Grid item container direction="column" sx={{ alignItems: 'center' }}>
          <Grid item>
            <StyledParagraph>{primaryMessage}</StyledParagraph>
          </Grid>
          {id && (
            <Grid item>
              <StyledTypography variant="body2">{t('ticket')}</StyledTypography>
              <StyledId>{id}</StyledId>
            </Grid>
          )}
        </Grid>
      </Grid>
      {secondaryMessage && (
        <StyledSecondaryMessageWrapper item>
          <StyledSecondaryMessage variant="body1">
            {secondaryMessage}
          </StyledSecondaryMessage>
        </StyledSecondaryMessageWrapper>
      )}
    </StyledImageBox>
  );
}
