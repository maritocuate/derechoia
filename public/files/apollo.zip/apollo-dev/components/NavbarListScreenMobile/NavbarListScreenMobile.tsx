/* eslint-disable no-console */
import React from 'react';
import { Box } from '@mui/material';
import { useRouter } from 'next/router';
import NavbarMobile from '../NavbarMobile/NavbarMobile';
import BackButtonNavbarMobile from '../Buttons/BackButtonNavbarMobile';
import FiltersButtonNavbarMobile from '../Buttons/FiltersButtonNavbarMobile';
import useFilterList from '../../hooks/list/useFIlterList/useFilterList';
import { useMapList } from '../../hooks/list/useMapList';
import { usePageList } from '../../hooks/list/usePageList';

const NavbarListScreenMobile = () => {
  const router = useRouter();
  const { handleChangeViewFilterList } = useFilterList();
  const { handleSetIsOpenMapView } = useMapList();
  const { locality } = usePageList();
  const handleBack = () => {
    try {
      const { query } = router;
      delete query.map;
      delete query.lat;
      delete query.lng;
      delete query.zoom;

      router.push({ pathname: router.pathname, query }).then(
        () => {},
        () => {},
      );
    } catch (error) {
      console.error(error);
    }

    handleSetIsOpenMapView();
  };

  const handleFilters = () => {
    handleChangeViewFilterList();
  };

  return (
    <NavbarMobile
      LeftComponent={<BackButtonNavbarMobile onClick={handleBack} />}
      centerText={locality.replaceAll('-', ' ')}
      RightComponent={
        <Box marginRight={1}>
          <FiltersButtonNavbarMobile onClick={handleFilters} />
        </Box>
      }
    />
  );
};

export default NavbarListScreenMobile;
