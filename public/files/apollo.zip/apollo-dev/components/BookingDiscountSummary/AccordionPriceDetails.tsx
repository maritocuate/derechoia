/* eslint-disable @typescript-eslint/indent */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  styled,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { useTranslation } from 'next-i18next';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';

const AccordionValueDiffers = styled(Accordion)`
  border-radius: 0;
  box-shadow: none;
  .MuiButtonBase-root {
    min-height: auto !important;
    padding: 0;
    .MuiAccordionSummary-content {
      margin: 0;
    }
  }
  .MuiCollapse-root {
    .MuiAccordionDetails-root {
      padding: 0;
    }
  }
`;
const LabelMoreInfoPrice = styled(Typography)`
  font-size: 0.75rem;
  margin-left: 0.25rem;
  display: flex;
  margin-top: 0.25rem;
`;

interface AccordionPriceDetailsProps {
  priceToMap: unknown[];
  auxDiscount: number | undefined;
  totalDays: number | null;
}

const AccordionPriceDetails: React.FC<AccordionPriceDetailsProps> = ({
  priceToMap,
  auxDiscount,
  totalDays,
}) => {
  const { t } = useTranslation('BookingSummary');
  return (
    <AccordionValueDiffers>
      <AccordionSummary expandIcon={<ExpandMoreIcon />} id="panel1a-header">
        <Typography variant="body2">
          {t('accommodation')} ({totalDays}
          {totalDays && totalDays > 1 ? ' noches' : ' noche'})
        </Typography>
      </AccordionSummary>
      <AccordionDetails>
        {priceToMap.map((elem: any, ind) => {
          if (auxDiscount) {
            return (
              <LabelMoreInfoPrice key={ind}>
                {`${formatPriceToArs((elem[0].precio as number) || 0)} x
            ${elem.length as number}
            ${t('nights', {
              count: elem.length as number,
              nights: elem.length as number,
            })}`}
              </LabelMoreInfoPrice>
            );
          }
          return (
            <LabelMoreInfoPrice key={ind}>
              {`$${formatPriceNoDiscount((elem[0].precio as number) || 0)} x
              ${elem.length as number}
              ${t('nights', {
                count: elem.length as number,
                nights: elem.length as number,
              })}`}
            </LabelMoreInfoPrice>
          );
        })}
      </AccordionDetails>
    </AccordionValueDiffers>
  );
};

export default AccordionPriceDetails;
