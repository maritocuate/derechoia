/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/indent */
/* eslint-disable consistent-return */
import {
  Divider,
  Grid,
  Typography,
  Alert,
  SelectPeople,
  Tooltip,
} from '@alquiler-argentina/demiurgo';
import {
  Box,
  Divider as DividerMUI,
  styled,
  ClickAwayListener,
  LinkProps,
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import React, { memo, useMemo } from 'react';
import { useTranslation } from 'next-i18next';
import { useSelector } from 'react-redux';
import groupBy from '../../utils/helpers/groupBy';

import CheckoutSic from '../CheckoutSic';
import {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  sendCheckoutSIRODataGTM,
  TEventType,
} from '../../utils/helpers/sendDataGTM';
import { ICheckoutState } from '../../redux/checkout/types';
import InactiveBookingSummary, {
  LinkPropsExt,
} from '../InactiveBookingSummary';
import { IPrice } from '../../types/propiedades.types';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import useIsMobile from '../../hooks/useIsMobile';
import { SummaryReserveData, CaptionInput, InputDataExtra } from './styles';
import AccordionPriceDetails from './AccordionPriceDetails';

const LabelMoreInfoPrice = styled(Typography)`
  font-size: 0.75rem;
  margin-left: 0.25rem;
  display: flex;
  margin-top: 0.25rem;
`;

const BookingSummaryDesktop = styled(Grid)`
  width: 22.5rem;
  padding-top: 2rem;
  margin-right: -3.4375rem;
`;

const ItemsDetailsPriceDiscount = styled(Typography)`
  color: #00acc1;
  font-size: 0.875rem;
`;

const StyledSelectPeople = styled('div')`
  width: 95%;
  position: absolute;
  z-index: 1;
  right: 1.625rem;
  top: 1.5rem;
`;

const StyleAlert = styled(Alert)`
  margin-bottom: 1.5rem;
`;

interface ITelefonos {
  number?: string;
}

interface Props {
  blocked: boolean;
  blockedMessage: string | null;
  price?: number | null;
  startDate: string | null;
  endDate: string | null;
  cleaningFee?: number;
  cargoExtra?: number;
  dayValueDiffers: boolean;
  title?: string;
  unidad?: string;
  referencia: string;
  whatsappNumber?: string;
  telefonos?: ITelefonos[];
  name?: string;
  peopleMax?: number;
  pets?: boolean;
  basePrice: number | null;
  totalDays: number | null;
  idTipologia?: number | null;
  persons: {
    adults: number;
    children: number;
    babies: number;
    total: number;
    mascotas: boolean;
  };
  selectedDiscount: number | null;
  dataOcupaciones?: IPrice[];
  setOpenCalendar: (value: boolean) => void;
  changeProps: (key: string, value: unknown) => void;
  gtm: (eventType: TEventType) => void;
  setOpenCheckoutSic: (value: boolean) => void;
  openCheckoutSIC: boolean;
  emailPropietario: boolean | null;
  active?: boolean;
  location: LinkProps[] | null;
  hasPhoneNumber?: boolean;
  hasWhatsapp?: boolean;
}

function BookingDiscountSummary({
  title,
  unidad,
  name,
  telefonos,
  whatsappNumber,
  referencia,
  price,
  startDate,
  endDate,
  cleaningFee,
  dayValueDiffers,
  peopleMax,
  idTipologia,
  persons,
  pets,
  basePrice,
  totalDays,
  cargoExtra,
  selectedDiscount,
  blocked,
  blockedMessage,
  setOpenCalendar,
  changeProps,
  gtm,
  dataOcupaciones,
  setOpenCheckoutSic,
  openCheckoutSIC,
  emailPropietario,
  active,
  location,
  hasPhoneNumber,
  hasWhatsapp,
}: Props) {
  const { t } = useTranslation('BookingSummary');
  const isMobile = useIsMobile();
  const [selectPeople, setSelectPeople] = React.useState(false);
  const { personas, mascotas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const prices = dataOcupaciones?.find((el) => el.id === idTipologia);
  const initialValue = 0;
  const subtotalPrice = prices?.precios.descuentos[personas - 1]
    ? prices?.precios.base.reduce(
        (acc, curr) => acc + curr.precio,
        initialValue,
      )
    : 0;

  const noDates = !!(!startDate && !endDate);
  const costoLimpieza = cleaningFee || 0;
  const costoExtra = cargoExtra || 0;
  const discount = selectedDiscount || 0;
  const totalDiscount = subtotalPrice ? subtotalPrice * (discount / 100) : 0;
  const basePriceWithCosts = basePrice
    ? costoLimpieza + costoExtra + basePrice
    : basePrice;
  const detailPrice = groupBy(
    prices?.precios ? prices?.precios.base : [],
    'precio',
  );
  const auxDiscount = prices?.precios.descuentos.find(
    (el) => el.personas === personas,
  )?.descuento;
  const noDatesDiscount =
    !auxDiscount || auxDiscount === 0 ? 1 : 1 - auxDiscount / 100;
  const priceToMap = useMemo(
    () => (detailPrice ? Object.values(detailPrice) : []),
    [detailPrice],
  );
  const totalPrice = subtotalPrice
    ? Math.round(costoLimpieza + costoExtra + subtotalPrice - totalDiscount)
    : 0;

  const openSelectPeople = () => {
    setSelectPeople(true);
  };

  if (active === undefined) {
    return null;
  }

  if (!active && !isMobile) {
    return <InactiveBookingSummary location={location as LinkPropsExt[]} />;
  }

  if (openCheckoutSIC && !isMobile) {
    return (
      <CheckoutSic
        totalAmount={
          auxDiscount ? Math.round(totalPrice / 100) * 100 : totalPrice
        }
        setOpenCheckoutSic={setOpenCheckoutSic}
        telefonos={telefonos}
        name={name}
        alojamiento={title}
        unidad={unidad}
        whatsappNumber={whatsappNumber}
        referencia={referencia}
        huespedes={personas}
        mascotas={mascotas}
        gtm={gtm}
        emailPropietario={emailPropietario}
        hasPhoneNumber={hasPhoneNumber}
        hasWhatsapp={hasWhatsapp}
      />
    );
  }

  return (
    <Box data-testid="BookingSummaryContainer">
      <BookingSummaryDesktop>
        {blocked && (
          <StyleAlert severity="error">
            <Typography>{blockedMessage}</Typography>
          </StyleAlert>
        )}
        <SummaryReserveData>
          {!blocked ? (
            <Box padding="0 0.375rem">
              <CaptionInput
                variant="body1"
                fontSize="0.75rem"
                sx={{ marginBottom: '0' }}
              >
                {(endDate && startDate) !== null || basePrice === null
                  ? t('total-price')
                  : t('start-price')}
              </CaptionInput>
              <Box display="flex" alignItems="baseline" marginBottom="0.25rem">
                {subtotalPrice > 0 ? (
                  <>
                    <Typography
                      variant="body1"
                      fontWeight="700"
                      fontSize="1.25rem"
                    >
                      {noDates && basePriceWithCosts && auxDiscount
                        ? `${formatPriceToArs(
                            basePriceWithCosts * noDatesDiscount,
                          )}`
                        : null}
                      {noDates && basePriceWithCosts && !auxDiscount
                        ? `$${formatPriceNoDiscount(basePriceWithCosts)}`
                        : null}
                      {!noDates && basePriceWithCosts && auxDiscount
                        ? `${formatPriceToArs(totalPrice)}`
                        : null}
                      {!noDates && basePriceWithCosts && !auxDiscount
                        ? `$${formatPriceNoDiscount(totalPrice)}`
                        : null}
                    </Typography>
                    {startDate && endDate ? (
                      <InputDataExtra> {t('taxes-included')} </InputDataExtra>
                    ) : (
                      <Box display="flex" alignItems="flex-end">
                        <InputDataExtra marginRight={1}>
                          {t('per-night')}
                        </InputDataExtra>
                        <Tooltip
                          variant="secondary"
                          placement="top"
                          arrow
                          title={t('titleTooltip')}
                          sx={{
                            marginLeft: '0.5rem',
                          }}
                        >
                          <InfoOutlinedIcon
                            fontSize="small"
                            sx={{ color: '#0000008A' }}
                          />
                        </Tooltip>
                      </Box>
                    )}
                  </>
                ) : (
                  <Typography
                    variant="body1"
                    fontWeight="600"
                    fontSize="1.25rem"
                  >
                    {t('checkPrice')}
                  </Typography>
                )}
              </Box>
            </Box>
          ) : null}
          <Divider />
          <Box
            onClick={() => setOpenCalendar(true)}
            sx={{ cursor: 'pointer' }}
            display="flex"
            justifyContent="space-between"
            padding="0 0.5rem"
          >
            <Box width="45%" marginBottom="0.375rem">
              <CaptionInput variant="body1" fontSize="0.75rem">
                {t('arrival')}
              </CaptionInput>
              <Typography
                variant="body1"
                fontWeight="700"
                fontSize="0.8rem"
                color={!startDate ? 'GrayText' : 'initial'}
              >
                {!startDate ? t('choose-date') : startDate}
              </Typography>
            </Box>
            <DividerMUI orientation="vertical" flexItem />
            <Box width="45%" marginBottom="0.375rem">
              <CaptionInput variant="body1" fontSize="0.75rem">
                {t('exit')}
              </CaptionInput>
              <Typography
                variant="body1"
                fontWeight="700"
                fontSize="0.8rem"
                color={!endDate ? 'GrayText' : 'initial'}
              >
                {!endDate ? t('choose-date') : endDate}
              </Typography>
            </Box>
          </Box>
          <Divider />
          <Box
            onClick={openSelectPeople}
            sx={{
              cursor: 'pointer',
              paddingLeft: '0.375rem',
              paddingBottom: '0.25rem',
            }}
          >
            <CaptionInput variant="body1" fontSize="0.75rem">
              {t('guests')}
            </CaptionInput>
            <Typography variant="body1" fontWeight={700} fontSize="0.8rem">
              {personas > 1 ? `${personas} personas` : `${personas} persona`}{' '}
            </Typography>
          </Box>
          {selectPeople && (
            <ClickAwayListener onClickAway={() => setSelectPeople(false)}>
              <StyledSelectPeople>
                <SelectPeople
                  handleClose={() => setSelectPeople(false)}
                  aceptaMascotas={pets || false}
                  persons={persons}
                  changeProps={changeProps}
                  typologyMaxCapacity={peopleMax || 2}
                />
              </StyledSelectPeople>
            </ClickAwayListener>
          )}
          <Divider />
          <Box padding="0 0.375rem 0.25rem 0.375rem">
            <CaptionInput variant="body1" fontSize="0.75rem">
              {t('unit-selected')}
            </CaptionInput>
            <Typography variant="body1" fontWeight="700" fontSize="0.8rem">
              {!blocked ? unidad : 'No hay opciones disponibles'}
            </Typography>
          </Box>
        </SummaryReserveData>

        {price && startDate && endDate && !blocked && subtotalPrice > 0 && (
          <Box marginTop="1.5rem">
            <Typography
              variant="body1"
              marginBottom="0.75rem"
              sx={{ fontWeight: '600' }}
            >
              {t('price-detail')}
            </Typography>
            <Box
              display="flex"
              justifyContent="space-between"
              marginBottom="0.5rem"
            >
              <Box display="flex" alignItems="baseline">
                {dayValueDiffers ? (
                  <AccordionPriceDetails
                    priceToMap={priceToMap}
                    auxDiscount={auxDiscount}
                    totalDays={totalDays}
                  />
                ) : (
                  <>
                    <Typography variant="body2">
                      {t('accommodation')}
                    </Typography>
                    <LabelMoreInfoPrice>
                      {auxDiscount &&
                        `${formatPriceToArs(basePrice || 0)} x ${
                          totalDays || 0
                        } noches`}
                      {!auxDiscount &&
                        `${formatPriceNoDiscount(basePrice || 0)} x ${
                          totalDays || 0
                        } noches`}
                    </LabelMoreInfoPrice>
                  </>
                )}
              </Box>
              <Typography variant="body2">
                {auxDiscount
                  ? `${formatPriceToArs(subtotalPrice)}`
                  : `$${formatPriceNoDiscount(subtotalPrice)}`}
              </Typography>
            </Box>
            {selectedDiscount ? (
              <Box
                display="flex"
                justifyContent="space-between"
                marginBottom="0.5rem"
                color="#00ACC1"
              >
                <ItemsDetailsPriceDiscount variant="body2">
                  Descuento {Math.trunc(selectedDiscount)}% Off
                </ItemsDetailsPriceDiscount>
                <ItemsDetailsPriceDiscount variant="body2">
                  -
                  {totalDays !== null && basePrice !== null
                    ? formatPriceToArs(totalDiscount)
                    : null}
                </ItemsDetailsPriceDiscount>
              </Box>
            ) : null}
            {cleaningFee && (
              <Box
                display="flex"
                justifyContent="space-between"
                marginBottom="0.5rem"
              >
                <Typography variant="body2"> {t('cleaning')} </Typography>
                <Typography variant="body2">
                  {formatPriceToArs(cleaningFee)}
                </Typography>
              </Box>
            )}
            {cargoExtra && (
              <Box
                display="flex"
                justifyContent="space-between"
                marginBottom="0.5rem"
              >
                <Typography variant="body2"> Otros cargos</Typography>
                <Typography variant="body2">
                  {formatPriceToArs(cargoExtra)}
                </Typography>
              </Box>
            )}

            <Divider />
            <Box
              display="flex"
              justifyContent="space-between"
              marginTop="0.5rem"
            >
              <Typography
                variant="button"
                fontWeight="600"
                textTransform="none"
              >
                {t('total')} (ARS)
              </Typography>
              <Typography variant="button" fontWeight="600">
                {auxDiscount
                  ? `${formatPriceToArs(totalPrice)}`
                  : `$${formatPriceNoDiscount(totalPrice)}`}
              </Typography>
            </Box>
          </Box>
        )}
      </BookingSummaryDesktop>
    </Box>
  );
}

export default memo(BookingDiscountSummary);
