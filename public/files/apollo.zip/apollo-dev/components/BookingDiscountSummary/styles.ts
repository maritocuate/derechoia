import { styled, Typography, Grid } from '@mui/material';

export const SummaryReserveData = styled(Grid)`
  border: 0.0625rem solid rgba(0, 0, 0, 0.12);
  border-radius: 0.25rem;
`;

export const CaptionInput = styled(Typography)`
  color: rgba(0, 0, 0, 0.6);
  margin: 0.25rem 0;
`;

export const InputDataExtra = styled(Typography)`
  font-size: 0.75rem;
  color: rgba(0, 0, 0, 0.87);
  margin-left: 0.25rem;
`;
