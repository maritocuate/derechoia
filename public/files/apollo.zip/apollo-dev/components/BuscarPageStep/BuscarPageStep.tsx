import { Box, styled, Typography } from '@mui/material';
import React, { ReactNode } from 'react';
import Image from 'next/image';
import useIsMobile from '../../hooks/useIsMobile';
import imageLoaderHeaderDesk from '../../utils/helpers/imageLoaders/imageloaderHeaderDesk';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';

interface IBuscarStep {
  step: number;
  title: string;
  description: ReactNode;
  imageMobile?: ReactNode;
  imageDesktop?: string;
}

const StyledBox = styled(Box)(
  ({ theme }) => `
    display: flex; 
    flex-direction: column;
    gap: 1.5rem;
    ${theme.breakpoints.up('lg')}{
      flex-direction: row;
    }
  `,
);

const StyledTypography = styled(Typography)`
  display: block;
`;

const BuscarPageStep = ({
  description,
  imageMobile,
  imageDesktop,
  step,
  title,
}: IBuscarStep) => {
  const isMobile = useIsMobile();
  return (
    <StyledBox data-testid="stepContainer">
      {isMobile && imageMobile && (
        <Box
          justifyContent="center"
          width="100%"
          display="flex"
          data-testid="stepImageMobile"
        >
          {imageMobile}
        </Box>
      )}
      {!isMobile && imageDesktop && (
        <Image
          src={formatUrlWithCdnLink(imageDesktop)}
          alt={title}
          width={550}
          height={550}
          loader={({ src }) =>
            imageLoaderHeaderDesk({
              src,
              width: 388,
              height: 388,
            })
          }
          data-testid="stepImageDesktop"
          priority
        />
      )}
      <Box
        display="flex"
        flexDirection="column"
        gap="1rem"
        justifyContent={isMobile ? 'flex-start' : 'center'}
      >
        <StyledTypography
          variant="myBookingDate"
          fontSize={isMobile ? 16 : 20}
          color="#00000099"
          data-testid="stepNumber"
        >
          Paso {step}
        </StyledTypography>
        <StyledTypography
          variant="contentTitle"
          fontSize={isMobile ? 20 : 24}
          data-testid="stepTitle"
        >
          {title}
        </StyledTypography>
        {description}
      </Box>
    </StyledBox>
  );
};

export default BuscarPageStep;
