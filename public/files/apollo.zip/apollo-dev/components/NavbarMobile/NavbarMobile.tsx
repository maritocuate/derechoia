import React, { memo } from 'react';
import { Box, styled, Typography } from '@mui/material';

const NavbarContainer = styled(Box)`
  width: 100%;
  max-width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  height: 3.25rem;
  min-height: 3.25rem;
  max-height: 3.25rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.12);
`;

const LeftNavbarContainer = styled(Box)`
  padding: 0 0.5rem;
  width: fit-content;
`;

const TextNavbarContainer = styled(Box)`
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
`;

const RightNavbarContainer = styled(Box)`
  padding: 0 1rem;
  width: fit-content;
`;

const StyledTitle = styled(Typography)`
  font-weight: 600;
  font-size: 1rem;
  line-height: 1.5rem;
  color: rgba(0, 0, 0, 0.6);
`;

interface INavbarMobile {
  LeftComponent?: React.ReactNode;
  centerText?: string;
  RightComponent?: React.ReactNode;
}

const NavbarMobile = ({
  LeftComponent,
  centerText,
  RightComponent,
}: INavbarMobile) => {
  return (
    <NavbarContainer>
      {!!LeftComponent && (
        <LeftNavbarContainer>{LeftComponent}</LeftNavbarContainer>
      )}
      <TextNavbarContainer paddingLeft={!LeftComponent ? '1em' : 0}>
        <StyledTitle noWrap>{centerText}</StyledTitle>
      </TextNavbarContainer>

      {!!RightComponent && (
        <RightNavbarContainer>{RightComponent}</RightNavbarContainer>
      )}
    </NavbarContainer>
  );
};

export default memo(NavbarMobile);
