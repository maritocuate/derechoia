import React from 'react';

import { LinkProps, styled } from '@mui/material';
import {
  Breadcrums,
  Valoraciones,
  Grid,
  Typography,
  IconWithText,
} from '@alquiler-argentina/demiurgo';
import NewReleasesOutlinedIcon from '@mui/icons-material/NewReleasesOutlined';
import useLocalDomain from '../../hooks/useLocalDomain';

export interface IMainInfoAnuncio {
  BreadcrumsLocation: LinkProps[] | null;
  title: string;
  average: number;
  total: number;
  href: string;
  isNew?: boolean;
}

const StyledNewReleasesIcon = styled(NewReleasesOutlinedIcon)`
  color: #fbc02d;
`;

const StyledTypography = styled(Typography)(
  ({ theme }) => `
  font-size: 1.5rem;
  ${theme.breakpoints.up('lg')}{
    font-size: 2rem;
  }`,
);

const MainInfoAnuncio = ({
  BreadcrumsLocation,
  title,
  average,
  total,
  href,
  isNew,
}: IMainInfoAnuncio) => {
  const replaceDomainWithLocal = useLocalDomain();
  const localBreadcrums = replaceDomainWithLocal(BreadcrumsLocation);

  return (
    <Grid data-testid="main-info-anuncio" marginTop={2}>
      {isNew && total < 3 && (
        <IconWithText anchor="left" icon={<StyledNewReleasesIcon />}>
          <Typography fontWeight={600} variant="subtitle2" fontSize="1rem">
            Nuevo alojamiento
          </Typography>
        </IconWithText>
      )}
      {(isNew && total >= 3) ||
        (!isNew && total >= 3 && (
          <Valoraciones
            anchor="valoracionLink"
            average={average === null ? 0 : average}
            href={href}
          >
            {total}
          </Valoraciones>
        ))}

      <StyledTypography
        fontSize="2rem"
        mt={2}
        mb={2}
        data-testid="info-anuncio-title"
        fontWeight="700"
        variant="h1"
      >
        {title}
      </StyledTypography>
      {localBreadcrums && (
        <Breadcrums separator="/" linkAttribute={localBreadcrums} />
      )}
    </Grid>
  );
};

export default MainInfoAnuncio;
