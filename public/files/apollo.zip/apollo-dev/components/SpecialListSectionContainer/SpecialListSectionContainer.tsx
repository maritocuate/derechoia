import React from 'react';
import {
  Box,
  Button,
  Typography,
  TypographyProps,
  styled,
} from '@mui/material';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import useIsMobile from '../../hooks/useIsMobile';
import useSpecialList from './hooks/useSpecialList';
import ExtraAdsSkeleton from '../../layout/listPage/containers/ExtraAdsContainer/components/ExtraAdsSkeleton';
import { useGetFavoriteQuery } from '../../services/favorites';

const ExtraAdsSection = dynamic(
  () =>
    import(
      '../../layout/listPage/containers/ExtraAdsContainer/components/ExtraAdsSection'
    ).then((res) => res.ExtraAdsSection),
  { ssr: false },
);

interface ISpecialListContainer {
  title?: string;
  description?: string;
  urlList?: string;
  email?: string;
  isLogged?: boolean;
  handleFavoriteAds?: (
    ref: string,
    setOpenModal?: (value: boolean) => void,
  ) => void;
  setOpenModalFavorite?: (value: boolean) => void;
}

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  overflow: hidden;
  width: 100%;
  gap: 1.5rem;
  margin: 3rem 0 1rem 0;
`;

const StyledInnerBox = styled(Box)`
  ${({ theme }) => `
    margin-left: 1rem;
    ${theme.breakpoints.up('lg')} {
      margin-left: 0;
    }
  `}
`;

const StyledTitle = styled(Typography)<TypographyProps>(
  ({ theme }) => `
    font-size: 1.5rem;
    font-weight: 600;      
    ${theme.breakpoints.up('lg')} {
      font-size: 1.75rem;
      font-weight: 600;
    }
    `,
);

const StyledSubtitle = styled(Typography)(
  ({ theme }) => `
    font-size: 1rem;
    font-weight: 500;      
    ${theme.breakpoints.up('sm')} {
      font-size: 1.25rem;
      font-weight: 500;
    }
    `,
);

const StyledButtonMobileContainer = styled(Box)`
  margin-left: 1rem;
`;

const StyledButton = styled(Button)`
  &,
  &:hover {
    border-width: 0.125rem;
    font-weight: 600;
  }
`;

const SpecialListContainer = ({
  urlList,
  title,
  description,
  email,
  isLogged,
  handleFavoriteAds,
  setOpenModalFavorite,
}: ISpecialListContainer) => {
  const isMobile = useIsMobile();
  const { listData, isLoading } = useSpecialList(urlList as string);
  const isRendered = !!listData && !isLoading;
  const { data: dataFav, isFetching } = useGetFavoriteQuery(email || '', {
    skip: !isLogged,
  });
  return (
    <StyledContainer maxWidth={isMobile ? 600 : 1200}>
      <StyledInnerBox>
        <Box display="flex" justifyContent="space-between">
          <Box>
            <StyledTitle component="h2">{title}</StyledTitle>
          </Box>
          {!isMobile && (
            <Box width="12.875rem">
              <Link passHref href={urlList as string}>
                <StyledButton fullWidth variant="outlined">
                  Ver más alojamientos
                </StyledButton>
              </Link>
            </Box>
          )}
        </Box>
      </StyledInnerBox>
      <StyledInnerBox>
        <StyledSubtitle>{description}</StyledSubtitle>
      </StyledInnerBox>
      <Box>
        {isRendered ? (
          <ExtraAdsSection
            isLoadingFav={isFetching}
            dataFav={dataFav}
            isMobile={isMobile}
            handleFavorite={handleFavoriteAds}
            setOpenModalFavorite={setOpenModalFavorite}
            ads={listData}
          />
        ) : (
          <ExtraAdsSkeleton />
        )}
      </Box>
      {isMobile && (
        <StyledButtonMobileContainer width="12.875rem">
          <Link passHref href={urlList as string}>
            <StyledButton fullWidth variant="outlined">
              Ver más alojamientos
            </StyledButton>
          </Link>
        </StyledButtonMobileContainer>
      )}
    </StyledContainer>
  );
};

export default SpecialListContainer;
