export const useUrlApi = (hardcodedUrl: string) => {
  const url = new URL(hardcodedUrl);
  const { pathname } = url;
  const slug = pathname.split('/').filter(Boolean);
  const query = {
    slug,
    ...Object.fromEntries(url.searchParams.entries()),
  };

  return {
    query,
    pathname,
  };
};
