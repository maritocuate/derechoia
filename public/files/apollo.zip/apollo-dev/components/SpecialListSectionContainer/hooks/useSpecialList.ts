import { useMemo } from 'react';
import { useGetSimilarPropertiesQuery } from '../../../services/similarProperties';
import { useUrlApi } from './useUrlApi';
import { filtersValueList } from '../../../hooks/list/useRequestToApiList/utils/filtersValueList';
import { formatAllQueriesOfBrowserUrlToState } from '../../../hocs/withFormatUrlToQueryList/constant/services';
import { FormatToUrltoGetDataList } from '../../../redux/filtersListado/types';
import { transformToRequestOQP } from '../../../utils/helpers/formattersFiltersList/transformToRequestOQP/transformToRequestOQP';

const useSpecialList = (urlHardcoded: string) => {
  const router = useUrlApi(urlHardcoded);
  const paramsOfUrl = router.pathname.split('/').filter(Boolean);
  const filters = useMemo(() => filtersValueList(router.query), [router.query]);
  const urlFormatOQP = useMemo(() => {
    const listParamsOQP = formatAllQueriesOfBrowserUrlToState(
      filters,
      paramsOfUrl,
    );
    const stateOQP: FormatToUrltoGetDataList = {
      ...listParamsOQP,
      adsWihtoutPrice: false,
      pag: 1,
      isLoading: false,
      isLoadingGoToAd: false,
    };
    return transformToRequestOQP(stateOQP);
  }, [paramsOfUrl, filters]);
  const {
    data: listData,
    error,
    isLoading,
    isFetching,
    isSuccess,
  } = useGetSimilarPropertiesQuery(`${urlFormatOQP || ''}&L=4`);

  return { listData, error, isLoading, isFetching, isSuccess };
};

export default useSpecialList;
