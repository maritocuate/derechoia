import { Box, styled, Typography } from '@mui/material';
import React from 'react';
import useIsMobile from '../../hooks/useIsMobile';

const StyledBox = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  width: 100%;
  gap: 2.25rem;
`;

const BuscarPageTitle = () => {
  const isMobile = useIsMobile();
  return (
    <StyledBox data-testid="BuscarPageTitleContainer">
      <Typography
        variant="benefitsTitle"
        display="block"
        color="black"
        fontSize={isMobile ? 34 : 48}
        data-testid="BuscarPageTitleContainerTitle"
      >
        Cómo buscar alojamiento en Alquiler Argentina
      </Typography>
      <Typography
        variant="descriptionText"
        display="block"
        color="#000000DE"
        data-testid="BuscarPageTitleContainerText"
      >
        Te ofrecemos una plataforma sencilla y eficiente para encontrar tu
        próximo lugar de alojamiento temporal. Ya sea que busques una casa,
        departamento, cabaña o cualquier otro tipo de propiedad, nuestro sitio
        te brinda las herramientas necesarias para hacerlo de manera rápida y
        efectiva.
      </Typography>
    </StyledBox>
  );
};

export default BuscarPageTitle;
