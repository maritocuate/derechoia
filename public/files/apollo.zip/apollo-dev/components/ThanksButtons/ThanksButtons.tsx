import { Box, Button, styled } from '@mui/material';
import Link from 'next/link';
import React from 'react';
import useIsMobile from '../../hooks/useIsMobile';

interface IThanksButtons {
  redirectLink: string;
  redirectText: string;
  myReservationsLink: string | null;
  myReservationText: string;
}

const StyledButton = styled(Button)`
  font-size: 1rem;
  font-weight: 600;
  padding-block: 0.8rem;
  text-transform: none;
  min-width: 14.75rem;
  height: 2.625rem;
`;

const ThanksButtons = ({
  redirectLink,
  myReservationsLink,
  redirectText,
  myReservationText,
}: IThanksButtons) => {
  const isMobile = useIsMobile();
  return (
    <Box
      display="flex"
      gap={isMobile ? '0.5rem' : '1rem'}
      justifyContent="center"
      flexDirection="column"
    >
      {!!myReservationsLink && (
        <Box>
          <StyledButton fullWidth={isMobile} variant="contained">
            <Link href={myReservationsLink}>{myReservationText}</Link>
          </StyledButton>
        </Box>
      )}
      <Box>
        <StyledButton fullWidth={isMobile} variant="outlined">
          <Link href={redirectLink}>{redirectText}</Link>
        </StyledButton>
      </Box>
    </Box>
  );
};

export default ThanksButtons;
