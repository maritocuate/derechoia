/* eslint-disable react/jsx-no-target-blank */
import React from 'react';
import { Grid, styled } from '@mui/material';
import { LinksFooterProps } from '../../index.type';

const FooterLink = styled(Grid)`
  font-weight: 400;
  font-size: 1rem;
  &:hover {
    font-weight: 700;
    cursor: pointer;
  }
`;

const FooterItem = ({
  href,
  text,
  icon,
  rel,
  target = '_blank',
}: LinksFooterProps) => {
  if (icon) {
    return (
      <Grid margin="0.5rem 0">
        <a href={href} target={target} rel={rel}>
          <FooterLink display="flex">
            <Grid marginRight="7px">{icon}</Grid>
            {text}
          </FooterLink>
        </a>
      </Grid>
    );
  }
  return (
    <Grid margin="0.5rem 0">
      <a href={href} target={target} rel={rel}>
        {text}
      </a>
    </Grid>
  );
};
export default FooterItem;
