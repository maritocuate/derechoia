/* eslint-disable react/jsx-no-target-blank */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { memo } from 'react';
import { useTranslation } from 'next-i18next';
import { styled, Grid, Typography } from '@mui/material';
import dynamic from 'next/dynamic';
import useIsMobile from '../../hooks/useIsMobile';
import FooterItem from './components/FooterItem/FooterItem';
import { FOOTER_DATA, FOOTER_IMAGES } from './constants/footerData';

const Divider = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/Divider').then(
      (res) => res.default,
    ),
  {
    ssr: true,
  },
);

const FooterBackground = styled(Grid)`
  background-color: #fafafa;
  box-shadow: 0px 2px 4px -1px rgba(0, 0, 0, 0.2),
    0px 4px 5px rgba(0, 0, 0, 0.14), 0px 1px 10px rgba(0, 0, 0, 0.12);
`;

const FooterContainer = styled(Grid)(
  ({ theme }) => `
  padding-inline: 1rem;
    ${theme.breakpoints.up('md')} {
      max-width: 1200px;
      margin-block-start: 1.25rem;
      margin-inline: auto;
      padding-inline: 0;
    }
  `,
);

const FooterList = styled(Grid)(
  ({ theme }) => `
  margin-block-end: 2rem;
    ${theme.breakpoints.up('md')} {
      margin-block-end: 0;
    };
  `,
);

const FooterListTitle = styled(Typography)(
  ({ theme }) => `
  font-weight: 600;
  font-size: 1rem;
  margin-bottom: 1rem;
  ${theme.breakpoints.up('sm')}{
    margin-bottom: 2rem;
  }
`,
);

const StyledTypography = styled(Typography)(
  ({ theme }) => `
  padding: 1rem 0;
  font-size: 1rem;
  color: black;
  ${theme.breakpoints.up('sm')}{
    padding: 0;
  } 
`,
);

const CURRENT_YEAR = new Date().getFullYear();

const Footer = ({ footerList = true }) => {
  const isMobile = useIsMobile();
  const { t } = useTranslation('Footer');

  return (
    <FooterBackground>
      <FooterContainer>
        {footerList && (
          <>
            <Grid
              container
              direction="row"
              justifyContent="flex-start"
              padding={isMobile ? '0' : '3rem 0'}
              paddingTop={isMobile ? '2rem' : '3rem'}
            >
              {FOOTER_DATA.map((data, index) => (
                <FooterList item xs={12} md={2.4} key={index}>
                  <FooterListTitle>{t(data.title)}</FooterListTitle>
                  {data.items.map((item, i) => (
                    <FooterItem
                      href={item.link}
                      text={
                        typeof item.text === 'string' ? t(item.text) : item.text
                      }
                      icon={item.icon}
                      rel={item.rel}
                      key={i}
                    />
                  ))}
                </FooterList>
              ))}
            </Grid>
            <Grid
              container
              direction="row"
              margin="0 auto"
              justifyContent="space-between"
              alignItems="center"
              padding={isMobile ? 0 : '1rem 1.5rem 2.5rem 1.5rem'}
              width={isMobile ? '100%' : '34.5rem'}
            >
              {FOOTER_IMAGES.map((data, index) => (
                <FooterItem
                  href={data.link}
                  text={data.image}
                  key={index}
                  target={data.target}
                />
              ))}
            </Grid>
            <Divider />
          </>
        )}
        <Grid
          container
          direction={isMobile ? 'column-reverse' : 'row'}
          justifyContent="center"
          alignItems="center"
          padding={
            footerList
              ? '1rem 0'
              : `1rem 1rem ${isMobile ? '0rem' : '1rem'} 1rem`
          }
        >
          <StyledTypography>
            © {CURRENT_YEAR} Copyright Alquiler Argentina
          </StyledTypography>
        </Grid>
      </FooterContainer>
    </FooterBackground>
  );
};

export default memo(Footer);
