export interface LinksFooterProps {
  href: string | undefined;
  text: string | JSX.Element;
  icon?: JSX.Element;
  rel?: string;
  target?: string;
}
