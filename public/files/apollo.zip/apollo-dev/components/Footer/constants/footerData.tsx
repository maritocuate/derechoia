import Image from 'next/image';
import React from 'react';
import Instagram from '@mui/icons-material/Instagram';
import YouTubeOutlined from '../../../public/images/icons/YouTubeOutlined';
import LinkedInOutlined from '../../../public/images/icons/LinkedInOutlined';
import formatUrlWithCdnLink from '../../../utils/helpers/formatUrlWithCdnLink';
import imageLoaderHeaderDesk from '../../../utils/helpers/imageLoaders/imageloaderHeaderDesk';

interface IFooterData {
  title: string;
  items: Array<{
    icon?: JSX.Element;
    text: string | JSX.Element;
    link: string;
    rel?: string;
  }>;
}

interface IFooterImages {
  image: JSX.Element;
  link?: string;
  target?: string;
}
export const FOOTER_DATA: IFooterData[] = [
  {
    title: 'Alquiler Argentina',
    items: [
      {
        text: 'beginning',
        link: 'https://www.alquilerargentina.com/',
      },
      {
        text: 'contact',
        link: 'https://www.alquilerargentina.com/contacto.html',
      },
      {
        text: 'post',
        link: '/publicar.html',
      },
      {
        text: 'about',
        link: 'https://jobs.alquilerargentina.com/sobre-nosotros/',
        rel: 'nofollow',
      },
      {
        text: 'work',
        link: 'https://jobs.alquilerargentina.com/',
        rel: 'nofollow',
      },
    ],
  },
  {
    title: 'sections',
    items: [
      {
        text: 'offers',
        link: 'https://www.alquilerargentina.com/ofertas-imperdibles/',
      },
      {
        text: 'help',
        link: 'https://www.alquilerargentina.com/ayuda/buscar',
        rel: 'nofollow',
      },
      {
        text: 'Reseñas',
        link: 'https://www.alquilerargentina.com/resenas',
      },
      {
        text: 'Blog',
        link: 'https://www.alquilerargentina.com/blog/',
      },
      {
        text: 'Oktoberfest',
        link: 'https://www.alquilerargentina.com/evento/oktoberfest',
      },
    ],
  },
  {
    title: 'legal',
    items: [
      {
        text: 'terms',
        link: 'https://www.alquilerargentina.com/terminos-condiciones.html',
      },
      // {
      //   text: 'policies',
      //   link: '',
      // },
    ],
  },
  {
    title: 'socialMedia',
    items: [
      {
        icon: <Instagram style={{ color: 'rgba(0, 0, 0, 0.54)' }} />,
        text: 'Instagram',
        link: 'https://www.instagram.com/alquilerargentina',
        rel: 'nofollow',
      },
      {
        icon: <YouTubeOutlined />,
        text: 'Youtube',
        link: 'https://www.youtube.com/@AlquilerargentinaWeb',
        rel: 'nofollow',
      },
      {
        icon: <LinkedInOutlined />,
        text: 'Linkedin',
        link: 'https://www.linkedin.com/company/alquiler-argentina/',
        rel: 'nofollow',
      },
    ],
  },
  {
    title: 'downloadApp',
    items: [
      {
        text: (
          <Image
            src="/images/googlePlay.svg"
            width={136}
            height={41}
            alt="Google Play"
          />
        ),
        link: 'https://play.google.com/store/apps/details?id=liricus.alquilerargentina',
        rel: 'nofollow',
      },
      {
        text: (
          <Image
            src="/images/appStore.svg"
            width={136}
            height={41}
            alt="App Store"
          />
        ),
        link: 'https://apps.apple.com/ve/app/alquiler-argentina/id1588111749',
        rel: 'nofollow',
      },
    ],
  },
];

export const FOOTER_IMAGES: IFooterImages[] = [
  {
    image: (
      <Image
        src="https://www.afip.gob.ar/images/f960/DATAWEB.jpg"
        width={44}
        height={60}
        loader={({ src }) =>
          imageLoaderHeaderDesk({
            src,
            width: 44,
            height: 60,
          })
        }
        alt="QR de Data fiscal"
      />
    ),
    link: 'http://qr.afip.gob.ar/?qr=9yK0lIKHNXnLKg_Fv6kyZQ,,',
    target: '_F960AFIPInfo',
  },
  {
    image: (
      <Image
        src={formatUrlWithCdnLink('/logoPDP.png')}
        width={80}
        height={45}
        loader={({ src }) =>
          imageLoaderHeaderDesk({
            src,
            width: 80,
            height: 45,
          })
        }
        alt="Dirección nacional de proteccion de datos fiscales"
      />
    ),
    link: 'https://www.argentina.gob.ar/aaip/datospersonales/reclama/30715500287--RL-2023-131503074-APN-DNPDP#AAIP',
    target: '_blank',
  },
  {
    image: (
      <Image
        src={formatUrlWithCdnLink('/logoCACE.png')}
        width={130}
        height={78}
        loader={({ src }) =>
          imageLoaderHeaderDesk({
            src,
            width: 130,
            height: 78,
          })
        }
        alt="Cámara argentina de comercio electronico"
      />
    ),
    link: 'https://cace.org.ar/socio/alquiler-argentina/',
  },
];
