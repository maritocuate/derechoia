import { Box, Button, styled, Typography } from '@mui/material';
import React, { ReactNode } from 'react';
import Link from 'next/link';
import useIsMobile from '../../../hooks/useIsMobile';

interface IItemCta {
  title: string;
  children?: ReactNode;
  buttonText: string;
  callback?: () => void;
  redirectHome: boolean;
  disabled?: boolean;
}

const StyledBox = styled(Box)`
  width: 100%;
  padding: 2rem 1.5rem;
  display: flex;
  flex-direction: column;
  justify-content: center;
  border-radius: 0.5rem;
  background-color: #00acc114;
  gap: 1rem;
  align-items: center;
  text-align: center;
`;

const StyledTypography = styled(Typography)`
  display: block;
`;

const ItemCta = ({
  buttonText,
  callback,
  children,
  title,
  redirectHome,
  disabled,
}: IItemCta) => {
  const isMobile = useIsMobile();
  const handleClick = () => {
    if (callback) return callback();
  };
  return (
    <StyledBox data-testid="ItemCtaBuscar">
      <StyledTypography
        variant="contentTitle"
        fontSize="24"
        data-testid="ItemCtaBuscarTitle"
        sx={{ lineHeight: isMobile ? '2rem' : 'initial' }}
      >
        {title}
      </StyledTypography>
      <Box data-testid="ItemCtaBuscarChildren">{children}</Box>
      {redirectHome && (
        <Link href="/" target={isMobile ? '_self' : '_blank'}>
          <Button
            variant="contained"
            style={{ fontWeight: 600, padding: '0.5rem 1.5rem' }}
            data-testid="ItemCtaBuscarButton"
          >
            {buttonText}
          </Button>
        </Link>
      )}
      {!redirectHome && (
        <Button
          variant="contained"
          onClick={() => handleClick()}
          disabled={disabled}
          style={{ fontWeight: 600, padding: '0.5rem 1.5rem' }}
          data-testid="ItemCtaBuscarButton"
        >
          {buttonText}
        </Button>
      )}
    </StyledBox>
  );
};

export default ItemCta;
