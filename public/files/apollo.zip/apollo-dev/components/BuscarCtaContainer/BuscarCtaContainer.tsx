import { Box, styled } from '@mui/material';
import React from 'react';
import { useSelector } from 'react-redux';
import ItemCta from './components/ItemCta';
import LoginModal from '../LoginModal/LoginModal';
import { IAppStatusState } from '../../redux/appStatus/types';

const StyledBox = styled(Box)(
  ({ theme }) => `
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 1.5rem;
    ${theme.breakpoints.up('lg')}{
      flex-direction: row;
    }
  `,
);

const BuscarCtaContainer = () => {
  const { isOpenLoginModal } = useSelector(
    ({ appStatus }: { appStatus: IAppStatusState }) => appStatus,
  );
  return (
    <StyledBox>
      {isOpenLoginModal && <LoginModal />}
      <ItemCta
        title="Encontrá tu alojamiento ahora"
        buttonText="Buscar alojamiento"
        redirectHome
        key="BuscarAlojamientos"
      />
    </StyledBox>
  );
};

export default BuscarCtaContainer;
