import React, { ReactElement } from 'react';
import { Tooltip, Typography } from '@mui/material';

interface IFavoriteTooltip {
  isFavorite: boolean;
  variant: 'ficha' | 'list';
  children: ReactElement;
}

export default function FavoriteTooltip({
  children,
  isFavorite,
  variant,
}: IFavoriteTooltip) {
  return (
    <Tooltip
      title={
        isFavorite ? (
          <Typography fontSize="0.7rem">
            Quitar de <br /> favoritos
          </Typography>
        ) : (
          <Typography fontSize="0.7rem">
            Agregar a <br /> favoritos
          </Typography>
        )
      }
      arrow
      placement={variant === 'list' ? 'left' : 'bottom'}
    >
      {children}
    </Tooltip>
  );
}
