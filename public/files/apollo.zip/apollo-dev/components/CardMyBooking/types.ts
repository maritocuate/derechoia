import { BoxProps } from '@mui/material';

/* eslint-disable @typescript-eslint/indent */
type MyBookingsStatus =
  | 'confirmada'
  | 'recibida'
  | 'aceptada'
  | 'cancelada'
  | 'rechazada';

export type MyBookingSection = 'active' | 'previous' | 'canceled';

export type TMyBooking = {
  status: MyBookingsStatus;
  refCover: string;
  refName: string;
  tipologyName: string;
  unitName: string;
  amount: number;
  province: string;
  city: string;
  startDate: string;
  endDate: string;
  code: number;
  voucher?: string;
  whatsapp: string;
  email: string;
  linkFicha?: string;
  rated: boolean;
  linkReview?: string;
  reference: string;
  id: string;
  section: MyBookingSection;
  props?: BoxProps;
  similarAds?: string;
};
