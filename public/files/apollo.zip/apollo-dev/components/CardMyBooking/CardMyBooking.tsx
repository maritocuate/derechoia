import { Box, styled } from '@mui/material';
import React from 'react';
import Link from 'next/link';
import MyBookingContent from './components/MyBookingContent/MyBookingContent';
import MyBookingFooter from './components/MyBookingFooter/MyBookingFooter';
import { TMyBooking } from './types';
import MyBookingHeader from './components/MyBookingHeader/MyBookingHeader';

const StyledCardMyBooking = styled(Box)(
  ({ theme }) => `
  background-color: #fff;
  display: flex;
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 0.5rem;
  overflow: hidden;
  width: 57.5625rem;
  max-width: 100%;
  height: fit-content;
  ${theme.breakpoints.down('lg')} {
    width: 100%;
    flex-direction: column;
  }
`,
);

const StyledResponsiveDivider = styled(Box)(
  ({ theme }) => `
  min-height: 100%;
  width: 1px;
  background-color: rgba(0, 0, 0, 0.23);
  ${theme.breakpoints.down('lg')} {
    width: 100%;
    min-height: 1px;
  }
`,
);

const CardMyBooking = ({
  status,
  rated,
  email,
  startDate,
  endDate,
  city,
  refName,
  refCover,
  province,
  tipologyName,
  whatsapp,
  linkFicha,
  linkReview,
  voucher,
  section,
  code,
  props,
  similarAds,
}: TMyBooking) => {
  const baseUrl = process.env.NEXT_PUBLIC_URL;
  const reservaUrl = new URL(`/mis-reservas/${code}`, baseUrl).href;
  const MyBookingHeaderComponent = (
    <MyBookingHeader status={status} refCover={refCover} section={section} />
  );
  const MyBookingContentComponent = (
    <MyBookingContent
      status={status}
      startDate={startDate}
      endDate={endDate}
      city={city}
      refName={refName}
      province={province}
      tipologyName={tipologyName}
      section={section}
    />
  );
  return (
    <StyledCardMyBooking {...props}>
      {status === 'confirmada' ? (
        <Link href={reservaUrl} style={{ cursor: 'pointer' }} target="_blank">
          {MyBookingHeaderComponent}
        </Link>
      ) : (
        MyBookingHeaderComponent
      )}
      {status === 'confirmada' ? (
        <Link href={reservaUrl} style={{ cursor: 'pointer' }} target="_blank">
          {MyBookingContentComponent}
        </Link>
      ) : (
        MyBookingContentComponent
      )}
      <StyledResponsiveDivider />
      <MyBookingFooter
        status={status}
        voucher={voucher}
        whatsapp={whatsapp}
        email={email}
        linkFicha={linkFicha}
        linkReview={linkReview}
        section={section}
        rated={rated}
        city={city}
        province={province}
        similarAds={similarAds}
      />
    </StyledCardMyBooking>
  );
};

export default CardMyBooking;
