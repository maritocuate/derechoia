import React from 'react';
import { Box, Button, ButtonProps, Typography, styled } from '@mui/material';
import TextSnippetOutlinedIcon from '@mui/icons-material/TextSnippetOutlined';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import CachedIcon from '@mui/icons-material/Cached';
import HouseOutlined from '@mui/icons-material/HouseOutlined';
import OtherHousesOutlined from '@mui/icons-material/OtherHousesOutlined';
import Link from 'next/link';
import { MyBookingFooterContentProps } from './types';

const StyledButton = styled(Button)`
  border-width: 0.125rem;
  &:hover {
    border-width: 0.125rem;
  }
`;

const CustomButton = (props: ButtonProps) => {
  return (
    <StyledButton
      {...props}
      size="small"
      sx={{
        font: 'Plus Jakarta Sans',
        fontWeight: 600,
        fontSize: '0.813rem',
        lineHeight: '1.375rem',
        letterSpacing: '0.46px',
      }}
    />
  );
};

const MyBookingFooterContent = ({
  status,
  voucher,
  linkReview,
  linkFicha,
  section,
  rated,
  city,
  province,
  similarAds,
}: MyBookingFooterContentProps) => {
  if (section === 'previous') {
    return (
      <>
        {!rated ? (
          <Box>
            <Link href={linkReview || '/'} target="_blank">
              <CustomButton variant="outlined" startIcon={<StarBorderIcon />}>
                Calificar experiencia
              </CustomButton>
            </Link>
          </Box>
        ) : (
          <Typography variant="myBookingCardDescription">
            ¡Gracias por calificar tu experiencia!
          </Typography>
        )}
        <Box>
          <CustomButton href={linkFicha} startIcon={<CachedIcon />}>
            Volver a reservar
          </CustomButton>
        </Box>
      </>
    );
  }
  if (section === 'canceled') {
    return (
      <>
        <Typography variant="myBookingCardDescription">
          Tu reserva fue {status}
        </Typography>
        <Box>
          <CustomButton
            href={similarAds || `/${province}/${city}`}
            variant="outlined"
            startIcon={<OtherHousesOutlined />}
          >
            Ver alojamientos similares
          </CustomButton>
        </Box>
        <Box>
          <CustomButton href={linkFicha} startIcon={<HouseOutlined />}>
            Ir al anuncio
          </CustomButton>
        </Box>
      </>
    );
  }
  if (status === 'confirmada') {
    return (
      <Box>
        <CustomButton
          variant="outlined"
          href={voucher}
          startIcon={<TextSnippetOutlinedIcon />}
        >
          Ver voucher
        </CustomButton>
      </Box>
    );
  }
  if (status === 'aceptada') {
    return (
      <Typography variant="myBookingCardDescription">
        El anfitrión aceptó tu solicitud de reserva, debés realizar la seña para
        que quede confirmada.
      </Typography>
    );
  }
  return (
    <Typography variant="myBookingCardDescription">
      Enviamos tu solicitud de reserva al anfitrión. En breve tendrás una
      respuesta del alojamiento.
    </Typography>
  );
};

export default MyBookingFooterContent;
