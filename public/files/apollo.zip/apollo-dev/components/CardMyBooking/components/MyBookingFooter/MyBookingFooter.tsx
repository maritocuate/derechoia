import { Box, styled } from '@mui/material';
import React from 'react';
import { IMyBookingFooterProps } from './types';
import MyBookingFooterContent from './MyBookingFooterContent';
import MyBookingFooterActions from './MyBookingFooterActions';

const StyledCardContainer = styled(Box)(
  ({ theme }) => `
    background-color: #fff;
    display: flex;
    flex-direction: row;
    gap: 1rem;
    width: 100%;
    height: fit-content;
    align-items: center;
    min-height: 3.875rem;
    justify-content: space-between;
    padding: 1rem;
    ${theme.breakpoints.up('lg')} {
      width: 100%;
      max-width: 19rem;
      height: 12.188rem;
      align-items: flex-start;
      flex-direction: column;
      gap: 0rem;
    }
  `,
);

const StyledFooterContent = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    width: 100%;
    height: fit-content;
    gap: 0.75rem;
    ${theme.breakpoints.up('sm')} {
      width: fit-content;
    }
  `,
);

const StyledFooterActions = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const MyBookingFooter = ({
  status = 'recibida',
  voucher,
  whatsapp,
  email,
  linkFicha,
  linkReview,
  rated,
  section,
  city,
  province,
  similarAds,
}: IMyBookingFooterProps) => {
  return (
    <StyledCardContainer>
      <StyledFooterContent>
        <MyBookingFooterContent
          status={status}
          voucher={voucher}
          linkFicha={linkFicha}
          linkReview={linkReview}
          section={section}
          rated={rated}
          city={city}
          province={province}
          similarAds={similarAds}
        />
      </StyledFooterContent>
      <StyledFooterActions>
        <MyBookingFooterActions
          status={status}
          whatsapp={whatsapp}
          section={section}
          email={email}
        />
      </StyledFooterActions>
    </StyledCardContainer>
  );
};

export default MyBookingFooter;
