import React from 'react';
import { Link, Typography, styled } from '@mui/material';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import { MyBookingFooterActionsProps } from './types';
import useIsMobile from '../../../../hooks/useIsMobile';

const StyledActionsLink = styled(Link)`
  display: flex;
  gap: 0.25rem;
  align-items: center;
  text-decoration: inherit;
  color: inherit;
`;

const StyledHideOnMobileText = styled(Typography)(
  ({ theme }) => `

    text-overflow: ellipsis;
    ${theme.breakpoints.down('lg')} {
      display: none;
    }
  `,
);

const MyBookingFooterActions = ({
  status,
  whatsapp,
  email,
  section,
}: MyBookingFooterActionsProps) => {
  const isMobile = useIsMobile();
  if (status === 'confirmada' || status === 'aceptada') {
    return (
      <>
        {whatsapp && section === 'active' && (
          <StyledActionsLink
            href={`https://api.whatsapp.com/send?phone=${whatsapp}`}
          >
            <WhatsAppIcon
              color="primary"
              fontSize={isMobile ? 'medium' : 'inherit'}
              sx={!isMobile ? { position: 'relative', top: '-0.0625rem' } : {}}
            />
            <StyledHideOnMobileText variant="myBookingCardContact">
              {whatsapp}
            </StyledHideOnMobileText>
          </StyledActionsLink>
        )}
        {email && section === 'active' && !isMobile && (
          <StyledActionsLink
            href={`mailto:${email}?subject=Consulta sobre la reserva`}
          >
            <MailOutlineIcon
              color="primary"
              fontSize={isMobile ? 'medium' : 'inherit'}
            />
            <StyledHideOnMobileText variant="myBookingCardContact">
              {email.length < 40 ? email : `${email.substring(0, 39)}...`}
            </StyledHideOnMobileText>
          </StyledActionsLink>
        )}
      </>
    );
  }
  return <div />;
};

export default MyBookingFooterActions;
