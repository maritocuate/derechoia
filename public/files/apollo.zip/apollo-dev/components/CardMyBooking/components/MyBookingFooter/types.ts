/* eslint-disable @typescript-eslint/indent */
import { TMyBooking } from '../../types';

export type IMyBookingFooterProps = Pick<
  TMyBooking,
  | 'status'
  | 'voucher'
  | 'whatsapp'
  | 'email'
  | 'linkFicha'
  | 'linkReview'
  | 'rated'
  | 'section'
  | 'city'
  | 'province'
  | 'similarAds'
>;

export type MyBookingFooterContentProps = Pick<
  IMyBookingFooterProps,
  | 'status'
  | 'voucher'
  | 'linkFicha'
  | 'linkReview'
  | 'rated'
  | 'section'
  | 'city'
  | 'province'
  | 'similarAds'
>;

export type MyBookingFooterActionsProps = Pick<
  IMyBookingFooterProps,
  'status' | 'whatsapp' | 'email' | 'section'
>;
