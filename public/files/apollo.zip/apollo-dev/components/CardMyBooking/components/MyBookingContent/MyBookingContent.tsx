import { Box, Typography, styled } from '@mui/material';
import React, { useMemo } from 'react';
import CalendarTodayOutlinedIcon from '@mui/icons-material/CalendarTodayOutlined';
import { TMyBookingContentProps } from './types';

const StyledMyBookingContent = styled(Box)(
  ({ theme }) => `
  background-color: #ffffff;
  word-wrap: break-word;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  width: 25rem;
  max-width: 100%;
  height: 12.1875rem;
  max-height: 100%;
  padding: 1rem 1.5rem 1rem 1.5rem;
  ${theme.breakpoints.down('lg')} {
    justify-content: flex-start;
    padding: 1rem;
    gap: 1rem;
    width: 100%;
    min-height: 10rem;
    height: fit-content;
    max-height: fit-content;
    gap: 1rem;
  }
`,
);

const StyledCardTitle = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
`;

const MyBookingContent = ({
  city,
  endDate,
  province,
  refName,
  startDate,
  tipologyName,
  section,
}: TMyBookingContentProps) => {
  const { location, date, background, iconColor } = useMemo(
    () => ({
      location: `${city} - ${province}`,
      date:
        section === 'active'
          ? `${startDate} - ${endDate}`
          : `${startDate.slice(4)} - ${endDate.slice(4)}`,
      background: section === 'active' ? '#FBC02D14' : '#f5f5f5',
      iconColor: section === 'active' ? '#FBC02D' : 'rgba(0, 0, 0, 0.87)',
    }),
    [city, endDate, province, startDate, section],
  );
  return (
    <StyledMyBookingContent>
      <StyledCardTitle>
        <Typography variant="onlineBookintTitle">{refName}</Typography>
        <Typography variant="myBookingCardLocation">{location}</Typography>
      </StyledCardTitle>

      <Typography variant="myBookingCardDescription">{tipologyName}</Typography>
      <Box
        sx={{
          display: 'flex',
          gap: '0.25rem',
          alignItems: 'center',
          borderRadius: '0.25rem',
          width: 'fit-content',
          backgroundColor: background,
          padding: '0.25rem 0.5rem',
        }}
      >
        <CalendarTodayOutlinedIcon
          sx={{
            height: '1rem',
            width: '1rem',
            color: iconColor,
          }}
        />
        <Typography variant="myBookingDate">{date}</Typography>
      </Box>
    </StyledMyBookingContent>
  );
};

export default MyBookingContent;
