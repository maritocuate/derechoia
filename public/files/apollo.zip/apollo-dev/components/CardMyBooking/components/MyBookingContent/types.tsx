/* eslint-disable @typescript-eslint/indent */
import { TMyBooking } from '../../types';

export type TMyBookingContentProps = Pick<
  TMyBooking,
  | 'status'
  | 'refName'
  | 'province'
  | 'city'
  | 'tipologyName'
  | 'startDate'
  | 'endDate'
  | 'section'
>;
