import React from 'react';
import { Box, Typography, styled, useTheme } from '@mui/material';
import Image from 'next/image';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import ListAltOutlinedIcon from '@mui/icons-material/ListAltOutlined';
import CancelOutlined from '@mui/icons-material/CancelOutlined';
import { TMyBookingHeader } from './types';
import imageLoaderCardAd from '../../../../utils/helpers/imageLoaders/imageLoaderCardAd';
import useIsMobile from '../../../../hooks/useIsMobile';

const StyledHeaderContainer = styled(Box)(
  ({ theme }) => `
    position: relative;
    box-sizing: 'border-box';
    width: 212px;
    height: 195px;
    ${theme.breakpoints.down('lg')} {
      width: 100%;
      height: 160px;
    }
`,
);

const StyledBookingStatus = styled(Box)`
  display: flex;
  align-items: center;
  gap: 0.125rem;
  border-radius: 0.25rem;
  position: absolute;
  top: 0.5rem;
  left: 0.5rem;
  z-index: 10;
  background: rgba(250, 250, 250);
  padding: 0.25rem 0.5rem;
`;

const StyledTypography = styled(Typography)`
  position: relative;
  top: 0.0625rem;
  text-transform: capitalize;
`;

const MyBookingHeader = ({ status, refCover, section }: TMyBookingHeader) => {
  const theme = useTheme();
  const isMobile = useIsMobile();
  const color = theme.palette.primary.main;
  const showBadge = section === 'active' || section === 'canceled';
  return (
    <StyledHeaderContainer>
      {showBadge && (
        <StyledBookingStatus>
          {status === 'confirmada' && (
            <CheckCircleOutlineIcon
              sx={{
                color,
                fontSize: '1.25rem',
              }}
            />
          )}
          {status === 'aceptada' && (
            <ListAltOutlinedIcon
              sx={{
                color,
                fontSize: '1.25rem',
              }}
            />
          )}
          {status === 'recibida' && (
            <AccessTimeOutlinedIcon
              sx={{
                color,
                fontSize: '1.25rem',
              }}
            />
          )}
          {(status === 'cancelada' || status === 'rechazada') && (
            <CancelOutlined
              sx={{
                color: theme.palette.error.main,
                fontSize: '1.25rem',
              }}
            />
          )}
          <StyledTypography variant="myBookingCardTag">
            {status !== 'recibida' ? status : 'Solicitada'}
          </StyledTypography>
        </StyledBookingStatus>
      )}
      <Image
        src={refCover}
        alt="propiedad img"
        loader={({ src }) => imageLoaderCardAd({ src, width: 600 })}
        style={{
          objectFit: 'cover',
          maxHeight: isMobile ? '10rem' : '195px',
          maxWidth: isMobile ? '35.5rem' : '212px',
          top: 0,
          left: 0,
        }}
        priority
        sizes="100%"
        fill
      />
    </StyledHeaderContainer>
  );
};

export default MyBookingHeader;
