/* eslint-disable @typescript-eslint/indent */
import { TMyBooking } from '../../types';

export type TMyBookingHeader = Pick<
  TMyBooking,
  'status' | 'refCover' | 'section'
>;
