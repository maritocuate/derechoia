/* eslint-disable @typescript-eslint/indent */
import React, { memo } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';

interface ISeoListado {
  pageTitle: string;
  pageDescription?: string;
}

const GlobalStructuredData = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  url: 'https://www.alquilerargentina.com',
  logo: formatUrlWithCdnLink('/logoaa.png'),
  sameAs: [
    'https://www.facebook.com/alquilerargentina',
    'https://www.youtube.com/user/AlquilerArgentinaWeb',
    'https://twitter.com/AlqArgentina',
    'https://plus.google.com/+AlquilerargentinaWeb',
  ],
  contactPoint: [
    {
      '@type': 'ContactPoint',
      telephone: '+540810-888-0845',
      contactType: 'customer service',
    },
  ],
  address: [
    {
      '@type': 'PostalAddress',
      streetAddress: 'Lisandro de la Torre 101',
      addressLocality: 'Villa Carlos Paz',
      addressCountry: 'AR',
    },
  ],
};

const SeoTitleContainer = ({ pageTitle, pageDescription }: ISeoListado) => {
  const router = useRouter();
  const url = `${String(process.env.NEXT_PUBLIC_URL)}${router.asPath.replace(
    '/',
    '',
  )}`;
  return (
    <Head>
      <link
        rel="shortcut icon"
        href="https://www.alquilerargentina.com/imagenes/favicon.png"
        type="image/png"
      />
      <meta charSet="utf-8" />
      <meta name="og:locale" content="es_LA" />
      <meta name="og:title" content={pageTitle} />
      <meta name="og:type" content="place" />
      <meta name="og:url" content={url} />
      <meta name="og:description" content={pageDescription || pageTitle} />
      <meta name="og:site_name" content="Alquiler Argentina" />
      <meta property="og:image" content={formatUrlWithCdnLink('/logoaa.png')} />
      <meta property="fb:app_id" content="193400040680800" />
      <meta property="fb:admins" content="100001734925397,777313376 " />
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"
      />
      <meta name="author" content="Alquiler Argentina" />
      <meta name="geo.region" content="AR" />
      <meta name="description" content={pageTitle} />
      <link rel="canonical" href={url} />
      <meta name="robots" content="index, follow" />
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(GlobalStructuredData),
        }}
      />
      <title>{pageTitle}</title>
    </Head>
  );
};

export default memo(SeoTitleContainer);
