import React from 'react';
import { Box, Button, Typography, styled } from '@mui/material';
import EmptySeens from '../SVG/EmptySeens';

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100%;
  gap: 1.5rem;
`;

const StyledTextContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  text-align: center;
  width: 100%;
  max-width: 30rem;
`;

const SeenEmptyState = () => {
  return (
    <StyledContainer>
      <EmptySeens />
      <StyledTextContainer>
        <Typography variant="contentTitle">Tu lista está vacía</Typography>
        <Typography variant="descriptionText">
          Comenzá a mirar alojamientos y organizá ese viaje que tanto esperás.
        </Typography>
      </StyledTextContainer>
      <Button variant="primaryButtonLarge" href="/" size="medium">
        Realizar una búsqueda
      </Button>
    </StyledContainer>
  );
};

export default SeenEmptyState;
