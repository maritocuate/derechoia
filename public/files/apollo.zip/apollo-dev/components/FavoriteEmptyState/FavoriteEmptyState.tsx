import React from 'react';
import { Box, Button, Typography, styled } from '@mui/material';
import NoFavorites from '../SVG/NoFavorite';

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100%;
  gap: 1.5rem;
`;

const StyledTextContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  text-align: center;
  width: 100%;
  max-width: 30rem;
`;

const FavoriteEmptyState = () => {
  return (
    <StyledContainer>
      <NoFavorites />
      <StyledTextContainer>
        <Typography variant="contentTitle">
          Tu lista de favoritos está vacía
        </Typography>
        <Typography variant="descriptionText">
          Comenzá a guardar tus alojamientos preferidos para tenerlos a mano
          cuando los necesites.
        </Typography>
      </StyledTextContainer>
      <Button variant="primaryButtonLarge" href="/" size="medium">
        Ir al inicio
      </Button>
    </StyledContainer>
  );
};

export default FavoriteEmptyState;
