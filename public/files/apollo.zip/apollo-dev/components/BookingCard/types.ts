export interface BookingPageProps {
  title: string;
  location: string;
}

export interface BookingCardProps {
  booking: Booking;
  hotelDetails: HotelDetails;
  actions: Actions;
}

export interface Actions {
  goAlojamiento: string;
  goVoucher: string;
  goMaps: string;
}

export interface HotelDetails {
  name: string;
  location: string;
}

export interface Booking {
  checkIn: string;
  checkOut: string;
  roomType: string;
  maxPeople: number;
  rooms: number;
  bathrooms: number;
  confirmationCode: string;
  imageUrl: string;
  anteriores: boolean;
}

export interface LocationProps {
  address: string;
  mapsUrl: string;
}

export interface ChecksProps {
  checkIn: string;
  checkOut: string;
}

export interface RoomsProps {
  roomType: string;
  maxPeople: number;
  rooms: number;
  bathrooms: number;
  confirmationCode: string;
  accommodationLink: string;
  voucherLink: string;
  anteriores: boolean;
}
