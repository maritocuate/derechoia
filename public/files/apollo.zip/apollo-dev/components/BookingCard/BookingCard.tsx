import React from 'react';
import { styled, Box } from '@mui/material';
import Thumbnail from './components/Thumbnail';
import Rooms from './components/Rooms';
import Checks from './components/Checks';
import Location from './components/Location';
import useIsMobile from '../../hooks/useIsMobile';
import { BookingCardProps } from './types';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    align-items: start;
    ${theme.breakpoints.up('lg')}{
        display: flex;
        flex-direction: row;
        height: 17rem;
        max-width: 74rem;
        border: 0.125rem solid #E0E0E0;
        border-radius: 0.5rem;
    }`,
);
const StyledBody = styled(Box)(
  ({ theme }) => `
    width: 100%;
    flex-grow: 0;
    ${theme.breakpoints.up('lg')}{
      display: flex;
      flex-direction: column;
      flex-grow: 1;
      width: auto;
      height: 100%;
    }`,
);

const BookingCard = ({ booking, hotelDetails, actions }: BookingCardProps) => {
  const isMobile = useIsMobile();

  const {
    checkIn,
    checkOut,
    imageUrl,
    maxPeople,
    rooms,
    bathrooms,
    confirmationCode,
    anteriores,
  } = booking;
  const { name, location } = hotelDetails;
  const { goAlojamiento, goVoucher, goMaps } = actions;

  return (
    <StyledContainer>
      <Thumbnail imageUrl={imageUrl} />

      <StyledBody>
        <Checks checkIn={checkIn} checkOut={checkOut} />
        {!isMobile && (
          <Rooms
            roomType={name}
            maxPeople={maxPeople}
            rooms={rooms}
            bathrooms={bathrooms}
            confirmationCode={confirmationCode}
            accommodationLink={goAlojamiento}
            voucherLink={goVoucher}
            anteriores={anteriores}
          />
        )}
      </StyledBody>
      <Location address={location} mapsUrl={goMaps} />
    </StyledContainer>
  );
};

export default BookingCard;
