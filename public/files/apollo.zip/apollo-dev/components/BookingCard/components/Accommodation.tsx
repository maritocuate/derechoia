import React from 'react';
import { styled, Box, Typography, Link } from '@mui/material';
import { RemoveRedEyeOutlined } from '@mui/icons-material';
import { getRoomCopy } from '../../../utils/helpers/getRoomCopy';

interface AccommodationProps {
  roomType: string;
  maxPeople: number;
  rooms: number;
  bathrooms: number;
  accommodationLink: string;
}

const StyledSection = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1rem;
    position: relative;
    padding: 1rem;
    padding-bottom: 2.5rem;
    border-bottom: 0.1rem solid #E0E0E0;
    ${theme.breakpoints.up('lg')}{
      padding: 0;
      border: none;
    }`,
);
const StyledTitle = styled(Typography)(
  ({ theme }) => `
    padding-top: 1rem;
    ${theme.breakpoints.up('lg')}{
      display: none;
    }`,
);
const StyledLink = styled(Link)(
  ({ theme }) => `
    display: flex;
    gap: 0.5rem;
    color: #00ACC1;       
    text-decoration: none;
    ${theme.breakpoints.up('lg')}{
      align-items: center;
      position: absolute;
      right: 0;
      bottom: 0.1rem;
    }`,
);

const Accommodation = ({
  roomType,
  maxPeople,
  rooms,
  bathrooms,
  accommodationLink,
}: AccommodationProps) => {
  const roomCopy = getRoomCopy(rooms);
  const roomsDisplay = rooms > 0 ? `${rooms} ${roomCopy}` : roomCopy;
  const bathroomCopy = `${bathrooms === 1 ? 'baño' : 'baños'}`;
  return (
    <>
      <StyledTitle variant="textPostDesktop">
        Detalle del alojamiento
      </StyledTitle>
      <StyledSection>
        <Typography variant="seeMoreAdsText">{roomType}</Typography>
        <Typography variant="orderText">
          {maxPeople} personas máx. • {roomsDisplay} • {bathrooms}{' '}
          {bathroomCopy}
        </Typography>
        <StyledLink href={accommodationLink} target="_blank">
          <RemoveRedEyeOutlined fontSize="small" />
          <Typography fontWeight={600} fontSize="0.875rem">
            Ver Alojamiento
          </Typography>
        </StyledLink>
      </StyledSection>
    </>
  );
};

export default Accommodation;
