import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import { PlaceOutlined } from '@mui/icons-material';
import Link from 'next/link';
import useIsMobile from '../../../hooks/useIsMobile';
import { LocationProps } from '../types';
import CopyToClipboardButton from '../../CopyToClipboardButton/CopyToClipboardButton';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    position: relative;
    padding: 2.5rem 1rem;
    margin-right: 1rem;
    border-bottom: 0.1rem solid #E0E0E0;
    width: 100%;
    ${theme.breakpoints.up('lg')}{
      min-height: 16rem;
      border-bottom: none;
      margin: 0;
      width: 23.8rem;
      height: 100%;
      padding: 1rem 1.5rem;
      border-left: 0.0625rem solid rgba(0, 0, 0, 0.12);
    }
  `,
);

const StyledLink = styled(Link)(
  ({ theme }) => `
  ${theme.breakpoints.up('lg')}{
    position: absolute;
    bottom: 1.5rem;
  }
`,
);

const Location = ({ address, mapsUrl }: LocationProps) => {
  const isMobile = useIsMobile();

  return (
    <StyledContainer>
      <Box display="flex" alignItems="center">
        <PlaceOutlined color="primary" />
        <Typography variant="textPostDesktop">Ubicación</Typography>
      </Box>

      <Typography variant="descriptionText">{address}</Typography>

      {!isMobile && (
        <CopyToClipboardButton
          buttonText="Copiar dirección"
          copyText={address}
          confirmationText="Dirección copiada"
        />
      )}

      <StyledLink href={mapsUrl} target="_blank">
        <Typography variant="linkReviews">Abrir en Google Maps</Typography>
      </StyledLink>
    </StyledContainer>
  );
};

export default Location;
