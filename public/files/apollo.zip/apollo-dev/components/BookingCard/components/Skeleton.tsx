import React from 'react';
import { styled, Box, Skeleton } from '@mui/material';

const StyledContainer = styled(Box)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  [theme.breakpoints.up('lg')]: {
    flexDirection: 'row',
    height: '17rem',
    maxWidth: '72rem',
    gap: theme.spacing(1),
    border: `0.125rem solid ${theme.palette.grey[300]}`,
    borderRadius: theme.shape.borderRadius,
  },
}));

const StyledVerticalDivisor = styled(Box)(({ theme }) => ({
  width: theme.spacing(0.25),
  backgroundColor: theme.palette.grey[300],
  height: '100%',
}));

const BookingCardSkeleton = () => {
  return (
    <StyledContainer>
      <Box display="flex" gap={1} padding={2}>
        <Skeleton variant="rectangular" width={207} height={237} />
      </Box>
      <StyledVerticalDivisor />
      <Box sx={{ flexGrow: 1 }}>
        <Box display="flex" gap={1} padding="1rem 0.5rem">
          <Skeleton variant="circular" width={24} height={24} />
          <Box display="flex" flexDirection="column" gap={2}>
            <Skeleton variant="text" width={150} height={20} />
            <Skeleton variant="text" width={150} height={20} />
          </Box>
        </Box>
        <Box
          display="flex"
          flexDirection="column"
          gap={2}
          padding="1.2rem 0.7rem"
        >
          <Skeleton variant="text" width={300} height={20} />
          <Skeleton variant="text" width={300} height={20} />
          <Skeleton variant="text" width={300} height={20} />
          <Skeleton variant="text" width={300} height={20} />
        </Box>
      </Box>
      <StyledVerticalDivisor />
      <Box sx={{ minWidth: { xs: 'unset', lg: '23rem' }, padding: 2 }}>
        <Skeleton variant="text" width={150} height={30} />
        <Skeleton variant="text" width={300} height={25} sx={{ mt: 3 }} />
        <Skeleton variant="text" width={300} height={25} />
      </Box>
    </StyledContainer>
  );
};

export default BookingCardSkeleton;
