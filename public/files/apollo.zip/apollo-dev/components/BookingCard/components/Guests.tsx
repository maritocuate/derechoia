import React from 'react';
import { styled, Box, Typography, Link } from '@mui/material';
import {
  PersonOutlineOutlined,
  TextSnippetOutlined,
} from '@mui/icons-material';

interface GuestsProps {
  maxPeople: number;
  confirmationCode: string;
  voucherLink: string;
  anteriores: boolean;
}

const StyledSection = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1rem;
    position: relative;
    padding: 1rem;
    padding-bottom: 2.5rem;
    border-bottom: 0.1rem solid #E0E0E0;
    ${theme.breakpoints.up('lg')}{
      padding: 0;
      border: none;
    }`,
);
const StyledTitle = styled(Typography)(
  ({ theme }) => `
    padding-top: 1rem;
    ${theme.breakpoints.up('lg')}{
      display: none;
    }`,
);
const StyledLink = styled(Link)(
  ({ theme }) => `
    display: flex;
    gap: 0.5rem;
    color: #00ACC1;  
    text-decoration: none;
    ${theme.breakpoints.up('lg')}{
      align-items: center;
      position: absolute;
      right: 0;
      bottom: 0.1rem;
    }`,
);

const Guests = ({
  maxPeople,
  confirmationCode,
  voucherLink,
  anteriores,
}: GuestsProps) => {
  return (
    <>
      <StyledTitle variant="textPostDesktop">Detalle de la reserva</StyledTitle>
      <StyledSection>
        <Box display="flex" gap="0.3rem" alignItems="center">
          <Typography variant="seeMoreAdsText">Huespedes:</Typography>
          <PersonOutlineOutlined fontSize="small" sx={{ color: '#A0A0A0' }} />
          <Typography variant="descriptionText">{maxPeople}</Typography>
        </Box>
        <Typography variant="descriptionText">
          <strong>Código de confirmación:</strong> {confirmationCode}
        </Typography>
        {!anteriores && (
          <StyledLink href={voucherLink} target="_blank">
            <TextSnippetOutlined fontSize="small" />
            <Typography fontWeight={600} fontSize="0.875rem">
              Ver Voucher
            </Typography>
          </StyledLink>
        )}
      </StyledSection>
    </>
  );
};

export default Guests;
