import React from 'react';
import { Box, styled } from '@mui/material';
import Image from 'next/image';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    gap: 0.5rem;
    padding-top: 0.5rem;
    width: 100%;
    ${theme.breakpoints.up('lg')}{
      padding: 1rem;
      justify-content: center;
      align-items: center;
      max-width: 15rem;
      height: 100%;
      border-right: 0.0625rem solid rgba(0, 0, 0, 0.12);
    }`,
);
const StyledImage = styled(Image)(
  ({ theme }) => `
    border-radius: 0.5rem;
    margin: 1rem 0;
    object-fit: cover;
    width: 100%;
    height: 16rem;
    ${theme.breakpoints.up('lg')}{
      border-radius: 0.25rem;
      margin: 0;
      width: 13.1rem;
      height: 14.7rem;
    }`,
);

const Thumbnail = ({ imageUrl }: { imageUrl: string }) => {
  return (
    <StyledContainer data-testid="booking-thumbnail">
      <StyledImage
        src={imageUrl}
        alt="thumbnail"
        width={0}
        height={0}
        sizes="100vw"
      />
    </StyledContainer>
  );
};

export default Thumbnail;
