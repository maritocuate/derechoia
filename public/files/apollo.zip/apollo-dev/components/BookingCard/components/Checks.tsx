import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import { CalendarTodayOutlined } from '@mui/icons-material';
import { ChecksProps } from '../types';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    gap: 0.5rem;
    padding: 1rem 0 1.6rem 0;
    border-bottom: 0.1rem solid #E0E0E0;  
    ${theme.breakpoints.up('lg')}{
      margin: 0 1.5rem;
      padding-bottom: 1rem;
    }`,
);

const Checks = ({ checkIn, checkOut }: ChecksProps) => {
  return (
    <StyledContainer data-testid="booking-checks">
      <CalendarTodayOutlined color="primary" />
      <Box display="flex" flexDirection="column" gap="0.5rem">
        <Typography variant="descriptionText">
          <strong>Ingreso:</strong> {checkIn}
        </Typography>
        <Typography variant="descriptionText">
          <strong>Egreso:</strong> {checkOut}
        </Typography>
      </Box>
    </StyledContainer>
  );
};

export default Checks;
