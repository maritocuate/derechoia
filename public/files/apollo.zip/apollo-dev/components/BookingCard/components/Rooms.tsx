import React from 'react';
import { Box, styled } from '@mui/material';
import { RoomsProps } from '../types';
import useIsMobile from '../../../hooks/useIsMobile';
import Guests from './Guests';
import Accommodation from './Accommodation';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
    padding: 1rem;
    padding-left: 0.5rem;
    ${theme.breakpoints.up('lg')}{
      padding: 1rem 1.5rem 1.5rem 1.5rem;
      justify-content: space-between;
      flex-grow: 1;
      gap: 0;
    }`,
);

const Rooms = ({
  roomType,
  maxPeople,
  rooms,
  bathrooms,
  confirmationCode,
  accommodationLink,
  voucherLink,
  anteriores,
}: RoomsProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer>
      {!isMobile && (
        <>
          <Box sx={{ order: anteriores ? 2 : 1 }}>
            <Accommodation
              roomType={roomType}
              maxPeople={maxPeople}
              rooms={rooms}
              bathrooms={bathrooms}
              accommodationLink={accommodationLink}
            />
          </Box>
          <Box sx={{ order: anteriores ? 1 : 2 }}>
            <Guests
              maxPeople={maxPeople}
              confirmationCode={confirmationCode}
              voucherLink={voucherLink}
              anteriores={anteriores}
            />
          </Box>
        </>
      )}
    </StyledContainer>
  );
};

export default Rooms;
