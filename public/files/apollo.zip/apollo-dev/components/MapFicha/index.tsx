import React from 'react';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import { icon } from 'leaflet';
import { styled } from '@mui/material';

const AAMarker = icon({
  iconUrl: '/images/markerAA.png',
  iconSize: [30, 41],
  popupAnchor: [0, -40],
  iconAnchor: [30 / 2, 41],
}); // Personalized Marker

export interface IMapResume {
  lat: number;
  long: number;
}

const StyledMap = styled(MapContainer)(
  ({ theme }) => `
  height: 220px;
  ${theme.breakpoints.up('sm')}{
    height: 360px;
  }
  max-width: 1360px;
  border-radius: 8px;
`,
);

export default function MapaFicha({ lat, long }: IMapResume) {
  return (
    <div
      style={{
        height: '100%',
        width: '100%',
        backgroundColor: 'red',
      }}
    >
      <StyledMap
        maxZoom={20}
        zoom={15}
        center={[lat, long]}
        scrollWheelZoom={false}
        style={{ height: '360px' }}
      >
        <Marker position={[lat, long]} icon={AAMarker} />

        <TileLayer
          attribution='Powered by <a rel="nofollow" href="https://www.geoapify.com/" target="_blank">Geoapify</a> | © OpenStreetMap <a rel="nofollow" href="https://www.openstreetmap.org/copyright" target="_blank">contributors</a>'
          url={`https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${String(
            process.env.NEXT_PUBLIC_GEOAPIFY_KEY,
          )}`}
        />
      </StyledMap>
    </div>
  );
}

// This component will not have a test yet, because whit this library a mock test is needed
