import React, { memo, useCallback } from 'react';
import { LatLngTuple } from 'leaflet';
import MyLocationButton from '../../../Buttons/MyLocationButton';

const NearMeButton = ({
  callback,
}: {
  callback: (center: LatLngTuple) => void;
}) => {
  const handleClick = useCallback(() => {
    if (navigator.geolocation) {
      return navigator.geolocation.getCurrentPosition(
        (position) => {
          if (position?.coords?.latitude && position?.coords?.longitude)
            callback([position?.coords?.latitude, position?.coords?.longitude]);
        },
        (error) => {
          // eslint-disable-next-line no-console
          console.error(error);
        },
      );
    }
  }, [callback]);

  return <MyLocationButton onPress={handleClick} />;
};

export default memo(NearMeButton);
