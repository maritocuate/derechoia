import React, { memo } from 'react';
import { useTranslation } from 'next-i18next';
import { Box, Typography, styled } from '@mui/material';
import Link from 'next/link';
import CardDestination from '../CardDestination';
import { IDestination } from '../../types/home.types';
import FormatUrl from '../../utils/helpers/FormatUrl';
import useIsMobile from '../../hooks/useIsMobile';

const DestinationsContainer = styled(Box)(
  ({ theme }) => `
        width: 100vw;
        margin-top: 1.75rem;
        height: 380px;
        overflow-y: hidden;
        padding-left: 1rem;
        margin-bottom: 3rem;
        ${theme.breakpoints.up('lg')}{
          max-width: 1200px;
          height: unset;
          padding-left: 0rem;
          margin-bottom: 0rem;
        }
    `,
);

const StyledBox = styled(Box)(
  ({ theme }) => `
        display: flex;
        flex-wrap: no-wrap;
        width: 100%;
        overflow: scroll;
        scroll-behavior: smooth;
        gap: 1.5rem;
        padding-right: 1rem;
        ${theme.breakpoints.up('lg')}{
            flex-wrap: wrap;
            overflow: hidden;
            justify-content: space-between;
            padding-right: 0rem;
        }
    `,
);

export const StlyedTypography = styled(Typography)(
  ({ theme }) => `
    margin-bottom: 1.5rem;
    font-size: 1.25rem;
    font-weight: 1000;
    ${theme.breakpoints.up('sm')}{
        margin-bottom: 1.5rem;
        font-size: 1.5rem;
        font-weight: 600;        
    }
    `,
);

function MostBookDestinations({ mostBooked }: IDestination) {
  const { t } = useTranslation('MostBookedDestinations');
  const isMobile = useIsMobile();
  return (
    <DestinationsContainer>
      <StlyedTypography variant="h5" marginTop="1.5rem">
        {t('title')}
      </StlyedTypography>
      <StyledBox>
        {!mostBooked && null}
        {mostBooked?.map((el) => (
          <Link
            key={`${el.cityV4}-key`}
            href={`/${FormatUrl(el.provinceV4)}/${FormatUrl(el.cityV4)}/`}
          >
            <CardDestination
              city={el.city}
              province={el.province}
              url={el.url}
              amount={el.amount}
              isMobile={isMobile}
            />
          </Link>
        ))}
      </StyledBox>
    </DestinationsContainer>
  );
}

export default memo(MostBookDestinations);
