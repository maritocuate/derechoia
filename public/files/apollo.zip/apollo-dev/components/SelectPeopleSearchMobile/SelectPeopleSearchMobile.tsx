import React, { memo } from 'react';

import dynamic from 'next/dynamic';

const SelectPeople = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/SelectPeople').then(
      (mod) => mod.default,
    ),
  { ssr: false },
);

const Dialog = dynamic(
  () => import('@mui/material/Dialog').then((mod) => mod.default),
  { ssr: false },
);

interface SelectPeopleSearchProps {
  adults: number;
  peoples: number;
  babies: number;
  children: number;
  pets: boolean;
  handleChangePersons: (key: string, val: unknown) => void;
  setOpenSelectPeopleModal: (newValue: boolean) => void;
  openSelectPeopleModal: boolean;
}

const SelectPeopleSearchMobile = ({
  adults,
  peoples,
  babies,
  children,
  pets,
  handleChangePersons,
  setOpenSelectPeopleModal,
  openSelectPeopleModal,
}: SelectPeopleSearchProps) => {
  return (
    <Dialog
      open={openSelectPeopleModal}
      onClose={(_, reason) =>
        reason === 'backdropClick' && setOpenSelectPeopleModal(false)
      }
    >
      <SelectPeople
        handleClose={setOpenSelectPeopleModal}
        aceptaMascotas={pets}
        persons={{
          adults,
          babies,
          children,
          mascotas: pets,
          total: peoples,
        }}
        changeProps={handleChangePersons}
        typologyMaxCapacity={0}
      />
    </Dialog>
  );
};

export default memo(SelectPeopleSearchMobile);
