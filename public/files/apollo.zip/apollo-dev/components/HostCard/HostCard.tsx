import React from 'react';
import { Box, Button, ButtonProps, styled } from '@mui/material';
import { LocalPhoneOutlined, EmailOutlined } from '@mui/icons-material';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import Link from 'next/link';
import { ContactType, HostCardProps } from './types';
import HostCardHeader from './components/HostCardHeader';
import HostCardContact from './components/HostCardContact';

const StyledHostCardContainer = styled(Box)(
  ({ theme }) => `
    border-radius: 0.5rem;
    padding: 1.5rem 0.5rem 3.5rem 0.5rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    width: 100%;
    border-bottom: 0.1rem solid #E0E0E0;
    ${theme.breakpoints.up('lg')}{
      border: 1px solid rgba(0, 0, 0, 0.23);
      padding: 2rem 1.5rem;
      width: 24rem;
    }`,
);
const StyledButton = styled(Button)`
  border-width: 0.125rem;
  height: 2.5rem;
  width: 100%;
  top: 0.5rem;
  &:hover {
    border-width: 0.125rem;
  }
`;
const CustomButton = (props: ButtonProps) => {
  return (
    <StyledButton
      {...props}
      size="small"
      sx={{
        font: 'Plus Jakarta Sans',
        fontWeight: 600,
        fontSize: '0.813rem',
        lineHeight: '1.375rem',
        letterSpacing: '0.46px',
      }}
    />
  );
};

const HostCard = ({
  host,
  contactData,
  anteriores,
  linkReview,
}: HostCardProps) => {
  const getIcon = (type: ContactType) => {
    switch (type) {
      case 'phone':
        return <LocalPhoneOutlined color="primary" fontSize="small" />;
      case 'whatsapp':
        return <WhatsAppIcon color="primary" fontSize="small" />;
      case 'email':
        return <EmailOutlined color="primary" fontSize="small" />;
      default:
        return null;
    }
  };

  return (
    <StyledHostCardContainer>
      <HostCardHeader name={host.name} imageUrl={host.imageUrl} />

      {!anteriores &&
        contactData.map((contact, index) => (
          <HostCardContact
            id={index}
            data={contact.data}
            icon={getIcon(contact.type)}
            type={contact.type}
          />
        ))}

      {anteriores && (
        <Box>
          <Link href={linkReview || '/'} target="_blank">
            <CustomButton variant="outlined" startIcon={<StarBorderIcon />}>
              Calificar experiencia
            </CustomButton>
          </Link>
        </Box>
      )}
    </StyledHostCardContainer>
  );
};

export default HostCard;
