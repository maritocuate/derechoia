export type ContactType = 'phone' | 'whatsapp' | 'email';

export type Contact = {
  type: ContactType;
  data: string;
};

export type Host = {
  name: string;
  imageUrl?: string;
};

export interface HostCardProps {
  host: Host;
  contactData: Contact[];
  anteriores: boolean;
  linkReview?: string;
}

export type HostCardHeaderProps = Host;

export interface HostCardContactProps {
  id: number;
  data: string;
  icon: JSX.Element | null;
  type: ContactType;
}
