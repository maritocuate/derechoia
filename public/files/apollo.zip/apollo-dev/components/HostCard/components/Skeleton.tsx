import React from 'react';
import { Skeleton, styled, Box } from '@mui/material';

const StyledHostCardContainer = styled(Box)(`
    border: 1px solid rgba(0, 0, 0, 0.23);
    border-radius: 0.5rem;
    padding: 2rem 1.5rem;
    display: flex;
    flex-direction: column;
    gap: 1rem;
    max-width: 24rem;
`);

const StyledContact = styled(Box)(`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
`);

const StyledContainer = styled(Box)(`
    display: flex;
    align-items: center;
    gap: 1rem;
    font-weight: 600;
    font-size: 1.25rem;
    margin-bottom: 1rem;
`);

const HostCardHeaderSkeleton = () => {
  return (
    <StyledContainer>
      <Skeleton variant="circular" width={40} height={40} />
      <Skeleton variant="text" width="50%" height={40} />
    </StyledContainer>
  );
};

const HostCardContactSkeleton = () => {
  return (
    <StyledContact>
      <Skeleton variant="circular" width={15} height={15} />
      <Skeleton variant="text" width="40%" />
    </StyledContact>
  );
};

const HostCardSkeleton = () => {
  return (
    <StyledHostCardContainer>
      <HostCardHeaderSkeleton />
      <HostCardContactSkeleton />
      <HostCardContactSkeleton />
      <HostCardContactSkeleton />
    </StyledHostCardContainer>
  );
};

export default HostCardSkeleton;
