import React, { useMemo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import Link from 'next/link';
import { HostCardContactProps } from '../types';
import useIsMobile from '../../../hooks/useIsMobile';

const StyledContact = styled(Box)(`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  overflow: hidden;
`);

const getContactLink = (type: string, data: string) => {
  switch (type) {
    case 'email':
      return `mailto:${data}?subject=Consulta sobre la reserva`;
    case 'whatsapp':
      return `https://api.whatsapp.com/send?phone=${data}`;
    case 'phone':
      return `tel:${data}`;
    default:
      return '';
  }
};

interface ContactContentProps {
  id: number;
  icon: React.ReactNode;
  data: string;
}
const ContactContent: React.FC<ContactContentProps> = ({ id, icon, data }) => (
  <StyledContact key={id}>
    {icon}
    <Typography>{data}</Typography>
  </StyledContact>
);

const HostCardContact = ({ id, data, icon, type }: HostCardContactProps) => {
  const isMobile = useIsMobile();
  const contactLink = useMemo(
    () => getContactLink(type as string, data),
    [type, data],
  );

  return type === 'phone' && !isMobile ? (
    <ContactContent id={id} icon={icon} data={data} />
  ) : (
    <Link href={contactLink}>
      <ContactContent id={id} icon={icon} data={data} />
    </Link>
  );
};

export default HostCardContact;
