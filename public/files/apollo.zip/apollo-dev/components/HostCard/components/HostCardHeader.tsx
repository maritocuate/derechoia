import React from 'react';
import { Avatar, Box, styled } from '@mui/material';
import { HostCardHeaderProps } from '../types';

const StyledContainer = styled(Box)(`
    display: flex;
    align-items: center;
    gap: 1rem;
    font-weight: 600;
    font-size: 1.25rem;
    margin-bottom: 1rem;
`);

const HostCardHeader = ({ name, imageUrl }: HostCardHeaderProps) => {
  return (
    <StyledContainer data-testid="host-header">
      {imageUrl ? (
        <Avatar
          src={`${
            process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
          }${imageUrl}?p=propietario_sm`}
          alt="Anfitrion"
        />
      ) : (
        <Avatar>{`${name[0]}`}</Avatar>
      )}
      Anfitrión: {name}
    </StyledContainer>
  );
};

export default HostCardHeader;
