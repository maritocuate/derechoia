/* eslint-disable react/no-array-index-key */
import React from 'react';

import { useTranslation } from 'next-i18next';
import { styled } from '@mui/material';
import {
  Typography,
  IconWithText,
  Grid,
  Button,
} from '@alquiler-argentina/demiurgo';

interface IAmenitie {
  icon: JSX.Element;
  text: string;
}
interface IAmenities {
  ameneties: IAmenitie[];
  setIsOpenModalAmenities: (value: boolean) => void;
  isOpenModalAmenities: boolean;
}
const StyledText = styled(IconWithText)(
  ({ theme }) => `
  justify-content: center;
  underline: none;
  ${theme.breakpoints.down('sm')} {
    & svg {
      width: 32px;
      height: 32px;
    }
  }
`,
);

const StyledButton = styled(Button)`
  padding: 10px 0;
  &:hover {
    background-color: transparent;
  }
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  font-size: 24px;
`;

const StyledTypographButtonModal = styled(Typography)`
  text-transform: none;
  text-decoration: underline;
  padding: 0.2rem;
`;

export default function FeaturedAmenities({
  ameneties,
  setIsOpenModalAmenities,
  isOpenModalAmenities,
}: IAmenities) {
  const { t } = useTranslation('FeaturedAmenities');
  const handleOpen = () => {
    setIsOpenModalAmenities(!isOpenModalAmenities);
  };
  return (
    <Grid
      container
      gap={2}
      maxWidth="900px"
      direction="column"
      justifyContent="center"
      alignItems="flex-start"
    >
      <Grid item>
        <StyledTitle variant="h2">{t('title')}</StyledTitle>
      </Grid>
      <Grid
        container
        wrap="wrap"
        justifyContent="center"
        alignItems="center"
        rowGap={2}
      >
        {ameneties.map(
          ({ icon, text }, index) =>
            index < 6 && (
              <Grid item xs={4} md={2} key={index}>
                <StyledText icon={icon} anchor="bottom">
                  {text === 'Aire Acondicionado' ? 'Aire Acond.' : text}
                </StyledText>
              </Grid>
            ),
        )}
      </Grid>
      <Grid item>
        <StyledButton color="inherit" onClick={handleOpen}>
          <StyledTypographButtonModal
            variant="body2"
            fontSize="1rem"
            fontWeight="700"
          >
            {t('TextBtn')}
          </StyledTypographButtonModal>
        </StyledButton>
      </Grid>
    </Grid>
  );
}
