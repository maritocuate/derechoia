import React, { useState } from 'react';
import {
  Box,
  Button,
  Drawer,
  IconButton,
  Typography,
  styled,
} from '@mui/material';
import { ChevronLeft } from '@mui/icons-material';
import dynamic from 'next/dynamic';
import themeAA from '../../styles/theme';

const FaqsSection = dynamic(()=> import('./components/FaqsSection'));

interface IChatFaqs {
  open?: boolean;
  reference: string;
  handleReserve: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  price: number;
}

const StyledBox = styled(Box)(
  ({ theme }) => `
  padding: 1.5rem;
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: flex-start;
  ${theme.breakpoints.up('lg')}{
    width: 25rem;
  }
`,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
  position: absolute;
  top: 1rem;  
  display: flex;
  align-items: center;
  left: 0;
  background-color: white;
  z-index: 2;
  width: 100vw;
  top: 0;
  padding-top: 0.5rem;
  ${theme.breakpoints.up('lg')}{
    width: 100%
  }
`,
);

const StyledButton = styled(Button)`
  margin-top: 1rem;
  width: 100%;
  border: 2px solid;
  font-weight: 600;
  &:hover {
    border: 2px solid;
  }
`;

const ChatFAQS = ({ open, reference, handleReserve, price }: IChatFaqs) => {
  const [isOpen, setIsOpen] = useState(open);
  const handleClose = () => {
    setIsOpen(false);
  };
  const handleOpen = () => {
    setIsOpen(true);
  };
  return (
    <>
      <StyledButton onClick={handleOpen} size="large" variant="outlined">
        Consultar
      </StyledButton>
      <Drawer open={isOpen} onClose={handleClose} anchor="right">
        <StyledBox>
          <StyledTitle
            variant="textPostDesktop"
            color={themeAA.palette.primary.main}
          >
            <IconButton color="primary" onClick={handleClose}>
              <ChevronLeft fontSize="large" />
            </IconButton>
            Consultas frecuentes
          </StyledTitle>
          <FaqsSection
            reference={reference}
            handleReserve={(e) => handleReserve(e)}
            price={price}
          />
          <Button variant="contained" fullWidth onClick={handleReserve}>
            <Typography fontWeight={600}>Reservar</Typography>
          </Button>
        </StyledBox>
      </Drawer>
    </>
  );
};

export default ChatFAQS;
