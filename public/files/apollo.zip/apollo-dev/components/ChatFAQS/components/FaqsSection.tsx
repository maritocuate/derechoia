import { Avatar, Box, Button, Typography, styled } from '@mui/material';
import React, { useState } from 'react';
import dayjs from 'dayjs';
import dynamic from 'next/dynamic';
import useBookingSummaryMobile from '../../../hooks/alojamientos/useBookingSummaryMobile';
import { formatPriceToArs } from '../../../utils/helpers/formatPriceToArs';

const ItemFAQS = dynamic(() => import('./ItemFAQS'));

interface IFaqsSection {
  reference: string;
  handleReserve: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
  price: number;
}
interface IFaqs {
  faq: string;
  answer: string;
  id: number;
}

export const FAQS: IFaqs[] = [
  {
    faq: '¿El alojamiento tiene disponibilidad?',
    answer: '',
    id: 1,
  },
  {
    faq: '¿El precio publicado es el precio final?',
    answer: '',
    id: 2,
  },
  {
    faq: '¿Cuál es el horario de check-in y check-out?',
    answer: '',
    id: 3,
  },
  {
    faq: '¿El alojamiento acepta mascotas?',
    answer: '',
    id: 4,
  },
  {
    faq: '¿El alojamiento tiene cochera?',
    answer: '',
    id: 5,
  },
];

const StyledFaqsContainer = styled(Box)`
  width: 100%;
  gap: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: flex-start;
  height: fit-content;
  margin-bottom: 1rem;
  padding-top: 1rem;
  border-top: 1px solid rgba(0, 0, 0, 0.2);
`;

const StyledButton = styled(Button)`
  margin: 0;
  padding: 0;
  position: relative;
  bottom: 0.125rem;
  text-decoration: underline;
  display: block;
  &:hover {
    textdecoration: underline;
    background-color: none;
  }
`;

const FaqsSection = ({ reference, handleReserve, price }: IFaqsSection) => {
  const [askedFAQS, setAskedFAQS] = useState<IFaqs[]>([]);
  const [showAnswer, setShowAnswer] = useState<{ [key: number]: boolean }>({});
  const {
    isAllBlocked,
    startDate,
    endDate,
    checkin,
    checkout,
    petsFaqs,
    parking,
  } = useBookingSummaryMobile(reference);

  const filteredFAQS = FAQS.filter((faq) => {
    if (faq.id === 4) {
      return petsFaqs === 0 || petsFaqs === 1;
    }
    if (faq.id === 5) {
      return parking === 1 || parking === 2;
    }
    return true;
  });

  const handleFaqs = (id: number) => {
    const faqIndex = filteredFAQS.findIndex((faq) => faq.id === id);
    let answer = '';

    switch (id) {
      case 1:
        answer = isAllBlocked
          ? 'No, el alojamiento no tiene disponibilidad.'
          : `Sí 👏, el alojamiento está disponible desde el ${dayjs(
            startDate,
          ).format('DD/MM/YY')} hasta el ${dayjs(endDate).format(
            'DD/MM/YY',
          )}. !! Reserva`;
        break;
      case 2:
        answer = `Sí, el costo de tu estadía es de ${formatPriceToArs(
          price,
        )}, ¡No habrá cargos extra! 👌. !! Reserva`;
        break;
      case 3:
        answer = `El check-in es a partir del ${dayjs(startDate).format(
          'DD/MM/YY',
        )} a las ${checkin || ''}hs y el check-out es el día ${dayjs(
          endDate,
        ).format('DD/MM/YY')} a las ${checkout || ''}hs 🚀. !! Reserva`;
        break;
      case 4:
        answer = petsFaqs === 1
          ? 'Sí, este alojamiento acepta mascotas 🐶'
          : 'No, este alojamiento no acepta mascotas. !! Reserva';
        break;
      case 5:
        answer = parking === 1
          ? 'Sí, el alojamiento dispone de cochera 🚘 '
          : 'No, este alojamiento no dispone de cochera. !! Reserva';
        break;
      default:
        answer = 'Información no disponible.';
    }

    const updatedFaq = { ...FAQS[faqIndex], answer };
    setAskedFAQS((prevAskedFAQS) => [...prevAskedFAQS, updatedFaq]);
    setShowAnswer((prev) => ({ ...prev, [id]: false }));

    setTimeout(() => {
      setShowAnswer((prev) => ({ ...prev, [id]: true }));
    }, 2000);
  };

  return (
    <>
      {askedFAQS &&
        askedFAQS.map((el) => (
          <Box
            key={el.id}
            display="flex"
            flexDirection="column"
            margin="1rem 0"
            gap="0.25rem"
            width="100%"
          >
            <Box display="flex" justifyContent="flex-end" marginLeft="2rem">
              <Typography fontWeight={600} fontSize={14}>
                {el.faq}
              </Typography>
            </Box>
            <Box
              display="flex"
              justifyContent="flex-start"
              gap="0.5rem"
              marginRight="2rem"
            >
              <Avatar
                sx={{ width: 24, height: 24 }}
                src="/images/logo192.png"
              />
              <Typography fontSize={14} key={String(showAnswer[el.id])}>
                {showAnswer[el.id] ? el.answer.split('!!')[0] : '...'}
                {showAnswer[el.id] && el.answer.includes('Reserva') && (
                  <StyledButton variant="text" onClick={handleReserve}>
                    Reserva ahora
                  </StyledButton>
                )}
              </Typography>
            </Box>
          </Box>
        ))}
      <StyledFaqsContainer>
        {filteredFAQS.map((el) => (
          <ItemFAQS
            key={el.id}
            question={el.faq}
            id={el.id}
            callback={() => handleFaqs(el.id)}
          />
        ))}
      </StyledFaqsContainer>
    </>
  );
};

export default FaqsSection;
