import React, { useState } from 'react';
import { Button, Typography, styled } from '@mui/material';

interface IItemFAQS {
  question: string;
  callback?: (value: number) => void;
  id: number;
}

const StyledButton = styled(Button)`
  border: 1px solid gray;
  color: black;
`;

const ItemFAQS = ({ question, callback, id }: IItemFAQS) => {
  const [disabled, setDisabled] = useState(false);
  const handleClick = () => {
    setDisabled(true);
    if (callback) callback(id);
  };
  return (
    <StyledButton disabled={disabled} onClick={handleClick} variant="outlined">
      <Typography fontSize={14} fontWeight={600}>
        {question}
      </Typography>
    </StyledButton>
  );
};

export default ItemFAQS;
