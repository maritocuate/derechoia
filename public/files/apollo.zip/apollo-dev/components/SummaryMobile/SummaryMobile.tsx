'use client';

import React, { memo, useCallback } from 'react';
import { Grid } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import BookingSummaryMobile from '../BookingSummaryMobile';
import useBookingSummaryMobile from '../../hooks/alojamientos/useBookingSummaryMobile';
import { ICheckoutState } from '../../redux/checkout/types';
import useCalendarHandler from '../../hooks/alojamientos/useCalendarHandler';
import ModalCalendarMobile from '../ModalCalendarMobile';

import { changeDates, handleOpenCalendar } from '../../redux/checkout/slice';

const SummaryMobile = ({ referencia }: { referencia: string }) => {
  const dispatch = useDispatch();

  const {
    activa,
    blockedDays,
    isAllBlocked,
    lastBlockedMessage,
    persons,
    handleChangePersons,
    allowPets,
    maxPeopleAllowed,
  } = useBookingSummaryMobile(referencia);

  const {
    reserva: { startDate, endDate },
    isOpenCalendar,
  } = useSelector(({ checkout }: { checkout: ICheckoutState }) => checkout);

  const { handleChangeDates, blockLessThanMinStay, listDate } =
    useCalendarHandler({
      referencia,
    });

  const setOpenCalendar = useCallback(
    (newState: boolean) => {
      dispatch(handleOpenCalendar({ isOpenCalendar: newState }));
    },
    [dispatch],
  );

  const handleResetCalendar = useCallback(() => {
    if (!endDate || !startDate) {
      dispatch(
        changeDates({
          startDate: null,
          endDate: null,
        }),
      );
    }
    setOpenCalendar(false);
  }, [dispatch, endDate, setOpenCalendar, startDate]);

  return (
    <Grid item container>
      {!!activa && (
        <BookingSummaryMobile
          blockedMessage={lastBlockedMessage}
          blocked={isAllBlocked}
          blockedDays={blockedDays}
          persons={persons}
          guests={persons.total}
          active={activa}
          pets={allowPets}
          changeProps={handleChangePersons}
          startDate={startDate || ''}
          endDate={endDate || ''}
          onChange={handleChangeDates}
          peopleMax={maxPeopleAllowed}
          setOpenCalendar={setOpenCalendar}
          handleResetCalendar={handleResetCalendar}
          openCalendar={isOpenCalendar}
        />
      )}
      {isOpenCalendar && (
        <ModalCalendarMobile
          openCalendar={isOpenCalendar}
          startDate={startDate}
          endDate={endDate}
          setOpenCalendar={setOpenCalendar}
          onChange={handleChangeDates}
          blockedDays={[...listDate, ...blockLessThanMinStay]}
          handleClose={handleResetCalendar}
        />
      )}
    </Grid>
  );
};

export default memo(SummaryMobile);
