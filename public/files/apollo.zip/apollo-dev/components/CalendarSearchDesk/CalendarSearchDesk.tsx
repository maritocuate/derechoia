import React, { memo, useEffect, useMemo, useRef, useState } from 'react';
import Popover, { PopoverProps } from '@mui/material/Popover';
import { Box, styled } from '@mui/material';
import dayjs from 'dayjs';
import Tooltip from '@alquiler-argentina/demiurgo/components/Tooltip';
import Calendar from '@alquiler-argentina/demiurgo/components/Calendar';
import { LicenseInfo } from '@mui/x-date-pickers-pro';
import ItemContainer from '../Search/components/ItemContainer/ItemContainer';
import { StyledTypographyInput } from '../Search/components/StyledTypographyInput/StyledTypographyInput';
import { CalendarSearchProps } from '../Search/components/CalendarSearch/type';

LicenseInfo.setLicenseKey(String(process.env.NEXT_PUBLIC_CALENDAR_KEY));

const popoverCalendarProps: Partial<PopoverProps> = {
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'right',
  },
  transformOrigin: {
    vertical: 'top',
    horizontal: 'right',
  },
};

const StyledPopoverCalendar = styled(Popover)(
  'margin-top: 0.188rem; & .MuiPaper-root { max-width: 100%; }',
) as typeof Popover;

const CalendarSearchDesk = ({
  isDisable,
  isOpenCalendar,
  startDate,
  endDate,
  onClickOpenCalendar,
  handleChangeDates,
  onClose,
  tooltip,
}: CalendarSearchProps) => {
  const [calendarStyle, setCalendarStyle] = useState('-150px');
  const ref = useRef(null);
  const startDateFormated = useMemo(() => dayjs(startDate), [startDate]);
  const endDateFormated = useMemo(() => dayjs(endDate), [endDate]);

  useEffect(() => {
    if (startDate && !endDate) {
      setCalendarStyle('0');
    }
    if (!isOpenCalendar) {
      setCalendarStyle('-150px');
    }
  }, [startDate, endDate, isOpenCalendar]);

  return (
    <>
      <ItemContainer
        label="Llegada"
        borderPosition="right"
        onClick={() => {
          onClickOpenCalendar(true);
        }}
        position="relative"
      >
        <Tooltip
          title="Elegí las fechas de llegada y de salida para ver el precio exacto"
          open={tooltip}
          arrow
          variant="secondary"
          placement="bottom"
          PopperProps={{
            sx: {
              top: '-11px !important',
              left: '3% !important',
              zIndex: '12',
            },
          }}
        >
          <StyledTypographyInput
            color={!startDate ? 'rgba(0, 0, 0, 0.33)' : undefined}
          >
            {!startDate && !endDate
              ? 'Elegir fecha'
              : startDateFormated?.format('DD/MM/YYYY')}
          </StyledTypographyInput>
        </Tooltip>
      </ItemContainer>
      <Box ref={ref}>
        <ItemContainer
          label="Salida"
          borderPosition="right"
          onClick={() => {
            onClickOpenCalendar(true);
          }}
        >
          <StyledTypographyInput
            color={!endDate ? 'rgba(0, 0, 0, 0.33)' : undefined}
          >
            {endDate ? endDateFormated?.format('DD/MM/YYYY') : 'Elegir fecha'}
          </StyledTypographyInput>
        </ItemContainer>
      </Box>
      {/* Popover */}
      <StyledPopoverCalendar
        {...popoverCalendarProps}
        open={isOpenCalendar}
        disableScrollLock
        sx={{
          transform: `translateX(${calendarStyle})`,
          transition: 'transform 0.2s ease-in-out',
        }}
        anchorEl={ref.current}
        onClose={() => {
          onClickOpenCalendar(false);
          onClose();
        }}
        marginThreshold={null}
      >
        <Calendar
          startDate={startDateFormated}
          endDate={endDateFormated}
          actions={[`${!isDisable ? 'accept' : 'disabled'}`]}
          onChange={handleChangeDates}
          handleClose={() => onClickOpenCalendar(false)}
          blockedDays={[]}
        />
      </StyledPopoverCalendar>
    </>
  );
};

export default memo(CalendarSearchDesk);
