import React from 'react';
import { useTranslation } from 'next-i18next';
import { Typography, Grid } from '@mui/material';
import NoResultsSVG from './svg';

export default function NoResults() {
  const { t } = useTranslation('NoResults');
  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      direction="column"
    >
      <Grid item>
        <NoResultsSVG color="#00ACC1" />
      </Grid>
      <Grid item>
        <Grid container spacing={0.7} direction="column" textAlign="center">
          <Grid item>
            <Typography fontWeight={600} variant="h5">
              {t('title')}
            </Typography>
          </Grid>
          <Grid item>
            <Typography variant="body2">{t('subtitle')}</Typography>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
}
