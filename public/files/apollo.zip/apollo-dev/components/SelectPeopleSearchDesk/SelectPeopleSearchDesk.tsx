/* eslint-disable @typescript-eslint/indent */
import SelectPeople from '@alquiler-argentina/demiurgo/components/SelectPeople';
import {
  Popover,
  PopoverProps,
  PopoverVirtualElement,
  styled,
} from '@mui/material';
import React, { memo } from 'react';

interface SelectPeopleSearchProps {
  adults: number;
  peoples: number;
  babies: number;
  children: number;
  pets: boolean;
  handleChangePersons: (key: string, val: unknown) => void;
  setOpenSelectPeopleModal: (newValue: boolean) => void;
  openSelectPeopleModal: boolean;
  anchorEl?:
    | Element
    | (() => Element)
    | PopoverVirtualElement
    | (() => PopoverVirtualElement)
    | null
    | undefined;
}

const StyledPopoverSelectPeople = styled(Popover)`
  & {
    margin-top: 0.188rem;
  }
  & .MuiPaper-root .MuiCard-root {
    width: 360px;
  }
` as typeof Popover;

const popoverSelectPeopleProps: Partial<PopoverProps> = {
  anchorOrigin: {
    vertical: 'bottom',
    horizontal: 'right',
  },
  transformOrigin: {
    vertical: 'top',
    horizontal: 'right',
  },
};

const SelectPeopleSearchDesk = ({
  adults,
  peoples,
  babies,
  children,
  pets,
  handleChangePersons,
  setOpenSelectPeopleModal,
  openSelectPeopleModal,
  anchorEl,
}: SelectPeopleSearchProps) => {
  return (
    <StyledPopoverSelectPeople
      {...popoverSelectPeopleProps}
      open={openSelectPeopleModal}
      disableScrollLock
      anchorEl={anchorEl}
      onClose={() => setOpenSelectPeopleModal(false)}
      marginThreshold={null}
    >
      <SelectPeople
        handleClose={setOpenSelectPeopleModal}
        aceptaMascotas={pets}
        persons={{
          adults,
          babies,
          children,
          mascotas: pets,
          total: peoples,
        }}
        changeProps={handleChangePersons}
        typologyMaxCapacity={0}
      />
    </StyledPopoverSelectPeople>
  );
};

export default memo(SelectPeopleSearchDesk);
