import { useRouter } from 'next/router';
import React, { useState, ReactNode } from 'react';
import { PopoverProps, Box } from '@mui/material';
import WhatsApp from '@mui/icons-material/WhatsApp';
import MailOutlineOutlined from '@mui/icons-material/MailOutlineOutlined';
import LinkOutlined from '@mui/icons-material/LinkOutlined';
import { List, IconWithText, Typography } from '@alquiler-argentina/demiurgo';
import { useTranslation } from 'next-i18next';
import Snackbar from '@alquiler-argentina/demiurgo/components/Snackbar';
import FacebookOutlined from '../../public/images/icons/FacebookOutlined';
import { StyledButton, StyledPopover, StyledLink } from './styles';

interface IBox {
  text: ReactNode;
  icon: ReactNode;
}

const handleCopy = (
  setState: React.Dispatch<React.SetStateAction<boolean>>,
) => {
  setState(true);
  navigator.clipboard.writeText(window.location.href).then(
    () => {
      setState(true);
    },
    (err) => {
      throw err;
    },
  );
};

const BoxContainer = ({ text, icon }: IBox) => (
  <Box padding="8px">
    <IconWithText icon={icon} anchor="left">
      <Typography variant="body1" paddingLeft="0.7rem">
        {text}
      </Typography>
    </IconWithText>
  </Box>
);

function PopoverShare({ ...props }: PopoverProps) {
  const [openSnackBar, setOpenAlert] = useState(false);
  const { t } = useTranslation('PopoverShare');
  const handleClose = () => {
    setOpenAlert(false);
  };
  const route = useRouter();

  const mailContent = {
    to: '',
    subject: t('subject'),
    body: `${t('body')} \r \r`,
  };

  const socialMedia = [
    {
      text: 'Facebook',
      icon: <FacebookOutlined color="#00BCD4" />,
      link: 'https://www.facebook.com/share.php?u=',
      onClick: null,
    },
    {
      text: 'WhatsApp',
      icon: <WhatsApp color="primary" />,
      link: 'https://api.whatsapp.com/send?text=',
      onClick: null,
    },
    {
      text: t('email'),
      icon: <MailOutlineOutlined color="primary" />,
      link: `mailto:${mailContent.to}?subject=${
        mailContent.subject
      }&body=${encodeURIComponent(mailContent.body)}`,
      onClick: null,
    },
    {
      text: t('link'),
      icon: <LinkOutlined color="primary" />,
      link: null,
      onClick: handleCopy,
    },
  ];

  const content = socialMedia.map(({ text, icon, link, onClick }) => ({
    primaryContent: link ? (
      <StyledButton>
        <StyledLink
          rel="nofollow"
          target="_blank"
          href={
            route.asPath
              ? `${link}https://www.alquilerargentina.com${route.asPath}`
              : `${link}https://www.alquilerargentina.com`
          }
          underline="none"
          color="none"
          borderRadius="4px"
          width="100%"
        >
          <BoxContainer icon={icon} text={t(text)} />
        </StyledLink>
      </StyledButton>
    ) : (
      onClick && (
        <StyledButton onClick={() => onClick(setOpenAlert)}>
          <BoxContainer icon={icon} text={t(text)} />
        </StyledButton>
      )
    ),
  }));
  return (
    <>
      <StyledPopover elevation={4} {...props}>
        <List content={[...content]} />
      </StyledPopover>
      <Snackbar
        open={openSnackBar}
        onClose={handleClose}
        severity="success"
        message={t('copiedLink')}
      />
    </>
  );
}

export default PopoverShare;
