import { useState } from 'react';

const useHandePopoverShare = () => {
  const [isOpenPopover, setIsOpenPopover] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  const handlePopoverOpen = async (event?: React.MouseEvent<HTMLElement>) => {
    if (event) setAnchorEl(event.currentTarget);
    setIsOpenPopover(true);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
    setIsOpenPopover(false);
  };
  return {
    isOpenPopover,
    anchorEl,
    handlePopoverOpen,
    handlePopoverClose,
  };
};

export default useHandePopoverShare;
