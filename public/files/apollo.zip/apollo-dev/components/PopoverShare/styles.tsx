import { Popover, styled } from '@mui/material';
import { Link, Button } from '@alquiler-argentina/demiurgo';

export const StyledButton = styled(Button)`
  text-transform: none;
  padding: 0;
  width: 100%;
  color: unset;
  justify-content: flex-start;
  &:hover {
    background: rgba(0, 0, 0, 0.04);
    border-radius: 4px;
  }
`;

export const StyledPopover = styled(Popover)`
  & .MuiPaper-root {
    border-radius: 8px;
    padding: 16px;
    margin-top: 6px;
  }
`;

export const StyledLink = styled(Link)`
  cursor: pointer;
  &:hover {
    background: rgba(0, 0, 0, 0.04);
    border-radius: 4px;
  }
`;
