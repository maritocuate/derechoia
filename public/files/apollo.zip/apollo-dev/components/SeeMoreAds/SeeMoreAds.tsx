import { Box, Button, ButtonProps, Typography, styled } from '@mui/material';
import React from 'react';

interface SeeMoreAdsProps {
  title: string;
  buttonProps?: ButtonProps;
  onClick: () => void;
  textButton?: string;
}

const textButtonDefault = 'Ver más anuncios';
const defaultButtonProps: Partial<ButtonProps> = {
  variant: 'contained',
  color: 'secondary',
  size: 'large',
};

const StyledContainer = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 1rem;
  gap: 1.5rem;
  border-radius: 4px;
  border: 1px solid rgba(0, 0, 0, 0.23);
  
  ${theme.breakpoints.up('lg')} {
    flex-direction: row;
    justify-content: flex-end;
    padding: 1.5rem 2.2rem 1.5rem 0;
    gap: 6.25rem;
  }

`,
);
const StyledTypography = styled(Typography)(
  ({ theme }) => `
  text-align: center;
${theme.breakpoints.up('lg')}{
  width: 45%;
}`,
);

const SeeMoreAds = ({
  title,
  buttonProps = defaultButtonProps,
  onClick,
  textButton = textButtonDefault,
}: SeeMoreAdsProps) => {
  return (
    <StyledContainer>
      <StyledTypography variant="seeMoreAdsText">{title}</StyledTypography>
      <Button {...buttonProps} onClick={onClick}>
        <Typography fontSize="1rem" fontWeight={600}>
          {textButton}
        </Typography>
      </Button>
    </StyledContainer>
  );
};

export default SeeMoreAds;
