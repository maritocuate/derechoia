import { Box, styled, Typography } from '@mui/material';
import React, { ReactNode } from 'react';
// import dynamic from 'next/dynamic';
import useIsMobile from '../../hooks/useIsMobile';

// const Feedback = dynamic(()=> import('../Feedback/Feedback'));

interface IBuscarPageSection {
  children: ReactNode;
}

const StyledBox = styled(Box)(
  ({ theme }) => `  
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 4rem;
    padding: 2rem 1rem;
    margin-top: 3rem;
    margin-bottom: 3rem;
    border-radius: 0.5rem;
    background-color: white;
    box-shadow: 0px 3px 14px 0px #0000001F;
    ${theme.breakpoints.up('lg')}{
      padding: 3rem;
      gap: 0;
      margin-bottom: 3.75rem;
      margin-top: 5rem;
    }
  `,
);

const BuscarPageSection = ({ children }: IBuscarPageSection) => {
  const isMobile = useIsMobile();
  return (
    <StyledBox data-testid="BuscarPageSection">
      <Typography
        variant="benefitsTitle"
        display="block"
        fontSize={isMobile ? 24 : 34}
        data-testid="BuscarPageSectionTitle"
        marginBottom="2rem"
      >
        ¡Seguí estos simples pasos y encontrá el alojamiento ideal para tu
        viaje!
      </Typography>
      {children}
      {/* <Box
        display='flex'
        justifyContent={isMobile ? 'flex-start' : 'flex-end'}
        data-testid='BuscarPageSectionFeedback'
      >
        <Feedback 
          callback={()=>{}}
          initialValue={false}
          text='¿Te resultó útil?'
        />
      </Box> */}
    </StyledBox>
  );
};

export default BuscarPageSection;
