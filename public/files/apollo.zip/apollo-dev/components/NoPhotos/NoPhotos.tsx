import ImageOutlined from '@mui/icons-material/ImageOutlined';
import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import useIsMobile from '../../hooks/useIsMobile';
import { calculateSizes } from '../../utils/helpers/calculateSizes';

const StyledContainer = styled(Box)`
  border-radius: 0.5rem;
  background-color: rgba(235, 235, 235, 1);
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
`;
const StyledIcon = styled(ImageOutlined)`
  font-size: 1.12rem;
  color: rgba(0, 0, 0, 0.54);
`;

const StyledTypography = styled(Typography)`
  font-size: 0.87rem;
  color: rgba(0, 0, 0, 0.6);
`;

const NoPhotos = ({ modalOpen }: { modalOpen?: boolean }) => {
  const isMobile = useIsMobile();
  const { height, width } = calculateSizes(isMobile, modalOpen || false);
  return (
    <StyledContainer height={height} width={width}>
      <Box>
        <StyledIcon />
      </Box>
      <Box>
        <StyledTypography>Sin fotos</StyledTypography>
      </Box>
    </StyledContainer>
  );
};

export default NoPhotos;
