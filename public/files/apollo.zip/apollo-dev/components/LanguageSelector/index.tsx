import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { useTranslation } from 'next-i18next';

export default function LanguageSelector() {
  const { t } = useTranslation('common');
  const { locales, asPath } = useRouter();
  return (
    <>
      <p>{t('language-selector.title')}</p>
      <ul>
        {locales &&
          locales.map((language) => (
            <li key={language}>
              <Link href={asPath} locale={language}>
                {language}
              </Link>
            </li>
          ))}
      </ul>
    </>
  );
}
