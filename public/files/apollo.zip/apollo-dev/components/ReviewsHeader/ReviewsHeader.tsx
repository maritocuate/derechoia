import { Box, Rating, styled, Typography } from '@mui/material';
import React from 'react';
import useIsMobile from '../../hooks/useIsMobile';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    letter-spacing: 0.02rem;
    margin: 1rem 1.2rem 2rem 1.2rem;
    ${theme.breakpoints.up('lg')}{
        gap: 0.5rem;
        margin: 4.5rem 0 4rem 0;
    }`,
);
const StyledRaiting = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    ${theme.breakpoints.up('lg')}{
        margin: -0.5rem 0 1.5rem 0;
        flex-direction: row;
    }`,
);
const StyledAverage = styled(Box)(
  ({ theme }) => `
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.7rem 0;
    ${theme.breakpoints.up('lg')}{
        gap: 1.1rem;
    }`,
);

interface ReviewsHeaderProps {
  averageRating: number;
  totalReviewCount: number;
}

export default function ReviewsHeader({
  averageRating,
  totalReviewCount,
}: ReviewsHeaderProps) {
  const isMobile = useIsMobile();

  return (
    <StyledContainer>
      <Typography
        component="h1"
        variant={isMobile ? 'benefitsText' : 'benefitsTitle'}
        color="#000000"
      >
        Qué opinan los turistas sobre Alquiler Argentina en Google
      </Typography>

      <StyledRaiting gap="1rem">
        <StyledAverage>
          <Typography
            variant="titleSectionPostMobile"
            color="rgba(0, 0, 0, 0.60)"
          >
            {averageRating}
          </Typography>
          <Rating size="large" value={4.7} readOnly />
        </StyledAverage>

        <Typography
          color="rgba(0, 0, 0, 0.60)"
          variant="textPostDesktop"
          display="flex"
          alignItems="center"
        >
          {totalReviewCount} opiniones
        </Typography>
      </StyledRaiting>
    </StyledContainer>
  );
}
