import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import useIsMobile from '../../hooks/useIsMobile';

interface HolidayTitleProps {
  title?: string;
  description?: string;
}

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    padding: 3rem 1rem;
    gap: 1.5rem;
    ${theme.breakpoints.up('lg')}{
      gap: 1rem;
      padding: 4rem 0;
    }`,
);

const HolidayTitle = ({ title, description }: HolidayTitleProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer maxWidth={isMobile ? 600 : 1200}>
      <Typography
        component="h2"
        variant={isMobile ? 'benefitsText' : 'benefitsTitle'}
        color="#000000"
      >
        {title}
      </Typography>
      <Typography
        variant={isMobile ? 'descriptionText' : 'authTitle'}
        fontWeight={500}
      >
        {description}
      </Typography>
    </StyledContainer>
  );
};

export default HolidayTitle;
