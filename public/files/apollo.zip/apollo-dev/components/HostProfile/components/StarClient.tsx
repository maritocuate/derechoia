import { LocalPoliceOutlined } from '@mui/icons-material';
import { Box, styled, Typography } from '@mui/material';
import React from 'react';

const StyledContainer = styled(Box)`
  display: flex;
  gap: 0.375rem;
  padding: 0.5rem;
  border-radius: 0.5rem;
  background-color: #fbc02d0a;
`;

const StarClient = () => {
  return (
    <StyledContainer gap="0.375rem" display="flex">
      <Box>
        <LocalPoliceOutlined color="secondary" />
      </Box>
      <Box>
        <Box>
          <Typography variant="starClientTitle">Anfitrión estrella</Typography>
        </Box>
        <Box maxWidth="36.125rem">
          <Typography variant="starClientText">
            Son anfitriones que se destacan por brindar una experiencia
            brillante: se esfuerzan para responder con rapidez y ofrecer a sus
            huéspedes una estadía maravillosa desde el primer contacto.
          </Typography>
        </Box>
      </Box>
    </StyledContainer>
  );
};

export default StarClient;
