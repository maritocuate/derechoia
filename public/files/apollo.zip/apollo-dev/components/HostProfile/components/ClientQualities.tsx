import React from 'react';
import { Box, Typography } from '@mui/material';
import { buildQualities } from '../../../utils/helpers/hostProfile/buildQualities';

interface IClientQualitiesProps {
  starClient: boolean;
  maxSpeedOfAction: boolean;
  maxConfirmedPercentage: boolean;
  clientAntiquity: number;
  isMobile: boolean;
}

const ClientQualities = ({
  starClient,
  maxSpeedOfAction,
  maxConfirmedPercentage,
  clientAntiquity,
  isMobile,
}: IClientQualitiesProps) => {
  const qualities = buildQualities(
    maxSpeedOfAction,
    maxConfirmedPercentage,
    starClient,
    clientAntiquity,
  );
  return (
    <Box
      display="flex"
      justifyContent="space-between"
      flexDirection={isMobile ? 'column' : 'row'}
      gap={isMobile ? '0.5rem' : 0}
    >
      {qualities.map((quality, index) => (
        <Box
          key={index}
          gap="0.5rem"
          display="flex"
          flexDirection={qualities.length > 1 && !isMobile ? 'column' : 'row'}
          alignItems={isMobile || qualities.length === 1 ? 'center' : 'normal'}
        >
          <Box width={isMobile ? '2rem' : 'none'}>
            <Typography
              textAlign={isMobile ? 'center' : 'initial'}
              fontSize={isMobile ? '0.875rem' : '1rem'}
              fontWeight={600}
            >
              {quality.value}
            </Typography>
          </Box>
          <Box>
            <Typography fontSize={isMobile ? '0.875rem' : '0.875rem'}>
              {quality.description}
            </Typography>
          </Box>
        </Box>
      ))}
    </Box>
  );
};

export default ClientQualities;
