import React from 'react';
import GppGoodOutlinedIcon from '@mui/icons-material/GppGoodOutlined';
import {
  List,
  ListItem,
  ListItemText,
  Avatar,
  ListItemAvatar,
  styled,
} from '@mui/material';
import { useTranslation } from 'next-i18next';
import { Typography } from '@alquiler-argentina/demiurgo';

interface IHostProfile {
  name: string;
  lastname?: string;
  profilePhoto?: string;
  referencia?: string;
}

const StyledDiv = styled('div')`
  padding: 0;
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 8px;
`;

const StyledTypography = styled(Typography)(
  ({ theme }) => `
  margin-bottom: 4px;
  font-weight: 600;
  font-size: 20px;
  ${theme.breakpoints.down('sm')}{
    font-size: 16px;
  }
`,
);

export default function HostProfile({
  name,
  lastname,
  profilePhoto,
  referencia,
}: IHostProfile) {
  const { t } = useTranslation('HostProfile');
  const nameInitial = name.substring(0, 1);
  const lastnameInital = lastname ? lastname.substring(0, 1) : '';
  return (
    <StyledDiv>
      <List disablePadding>
        <ListItem>
          <ListItemAvatar>
            {profilePhoto && referencia ? (
              <Avatar
                src={`${
                  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
                }_propiedades_/${referencia}/${profilePhoto}?p=propietario_sm`}
                alt="Anfitrion"
              />
            ) : (
              <Avatar>{`${nameInitial}${lastnameInital}`}</Avatar>
            )}
          </ListItemAvatar>
          <ListItemText
            disableTypography
            primary={
              <StyledTypography variant="h2">
                {t('title')}
                {lastname ? `${name} ${lastname}` : name}
              </StyledTypography>
            }
            secondary={
              <Typography color="primary" variant="body2">
                {t('subtitle')}
              </Typography>
            }
          />
          <GppGoodOutlinedIcon color="primary" />
        </ListItem>
      </List>
    </StyledDiv>
  );
}
