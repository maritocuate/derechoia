import React from 'react';
import GppGoodOutlinedIcon from '@mui/icons-material/GppGoodOutlined';
import { Avatar, styled, Box, Divider } from '@mui/material';
import { useTranslation } from 'next-i18next';
import { Typography } from '@alquiler-argentina/demiurgo';
import ClientQualities from '../components/ClientQualities';
import StarClient from '../components/StarClient';
import { IHostProfile } from '../../../containers/HostProfileContainer/types/hostProfile.types';

const StyledBox = styled(Box)`
  padding: 1rem;
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 0.5rem;
  max-width: 56.25rem;
`;

const StyledSpan = styled('span')`
  font-weight: 500;
`;

export default function NewHostProfileDesktop({
  name,
  profilePhoto,
  clientAntiquity,
  maxSpeedOfAction,
  maxConfirmedPercentage,
  isStarClient,
  formattedClientAntiquity,
  isMobile,
}: IHostProfile) {
  const { t } = useTranslation('HostProfile');
  const nameInitial = name.substring(0, 1);
  return (
    <StyledBox>
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        flexDirection="row"
      >
        <Box
          display="flex"
          gap="1rem"
          alignItems={isStarClient ? 'center' : 'flex-start'}
        >
          <Box>
            {profilePhoto ? (
              <Avatar src={profilePhoto} alt="Anfitrion" />
            ) : (
              <Avatar>{`${nameInitial}`}</Avatar>
            )}
          </Box>
          <Box display="flex" flexDirection="column">
            <Box>
              <Typography variant="hostProfileTitle">
                {t('title')}
                {name}
              </Typography>
            </Box>
            {!isStarClient && (
              <Box>
                <Typography variant="hostProfileSubtitle">
                  <StyledSpan>{formattedClientAntiquity.number}</StyledSpan>
                  {formattedClientAntiquity.text}
                </Typography>
              </Box>
            )}
          </Box>
        </Box>
        <Box
          display="flex"
          flexDirection={isStarClient ? 'row-reverse' : 'column'}
          textAlign={isStarClient ? 'inherit' : 'end'}
        >
          <Box marginRight={isStarClient ? '0' : '0.5rem'}>
            <GppGoodOutlinedIcon color="primary" />
          </Box>
          <Box>
            <Typography variant="hostProfileVerified">
              {isStarClient ? 'Verificado' : 'Anfitrión verificado'}
            </Typography>
          </Box>
        </Box>
      </Box>
      {isStarClient && (
        <Box marginLeft="3.5rem">
          <StarClient />
        </Box>
      )}
      {maxConfirmedPercentage || maxSpeedOfAction ? (
        <>
          <Box marginTop={isStarClient ? '1rem' : '1.5rem'} marginBottom="1rem">
            <Divider />
          </Box>
          <ClientQualities
            maxConfirmedPercentage={maxConfirmedPercentage}
            maxSpeedOfAction={maxSpeedOfAction}
            clientAntiquity={clientAntiquity}
            starClient={isStarClient}
            isMobile={isMobile}
          />
        </>
      ) : null}
    </StyledBox>
  );
}
