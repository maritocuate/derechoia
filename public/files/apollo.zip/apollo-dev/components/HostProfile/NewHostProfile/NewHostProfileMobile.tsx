import { Avatar, Box, Divider, styled, Typography } from '@mui/material';
import GppGoodOutlinedIcon from '@mui/icons-material/GppGoodOutlined';
import React from 'react';
import { useTranslation } from 'react-i18next';
import { IHostProfile } from '../../../containers/HostProfileContainer/types/hostProfile.types';
import getClientAntiquity from '../../../utils/helpers/hostProfile/getClientAntiquity';
import StarClient from '../components/StarClient';
import ClientQualities from '../components/ClientQualities';

const StyledBox = styled(Box)`
  padding: 1rem;
  border: 1px solid rgba(0, 0, 0, 0.23);
  border-radius: 0.5rem;
  max-width: 56.25rem;
`;

const StyledSpan = styled('span')`
  font-weight: 500;
`;

const NewHostProfileMobile = ({
  name,
  profilePhoto,
  clientAntiquity,
  maxSpeedOfAction,
  maxConfirmedPercentage,
  isStarClient,
  isMobile,
}: IHostProfile) => {
  const { t } = useTranslation('HostProfile');
  const nameInitial = name.substring(0, 1);
  const formattedClientAntiquity = getClientAntiquity(clientAntiquity);
  return (
    <StyledBox>
      <Box display="flex" gap="1rem">
        <Box>
          {profilePhoto ? (
            <Avatar src={profilePhoto} alt="Anfitrion" />
          ) : (
            <Avatar>{`${nameInitial}`}</Avatar>
          )}
        </Box>
        <Box display="flex" flexDirection="column" gap="0.25rem">
          <Box>
            <Typography variant="hostProfileTitle">
              {t('title')}
              {name}
            </Typography>
          </Box>
          {!isStarClient && (
            <Box>
              <Typography variant="hostProfileSubtitle">
                <StyledSpan>{formattedClientAntiquity.number}</StyledSpan>
                {formattedClientAntiquity.text}
              </Typography>
            </Box>
          )}
          <Box display="flex" flexDirection="row" gap="0.3rem">
            <Box>
              <GppGoodOutlinedIcon color="primary" />
            </Box>
            <Box>
              <Typography variant="hostProfileVerified">
                {isStarClient ? 'Verificado' : 'Anfitrión verificado'}
              </Typography>
            </Box>
          </Box>
        </Box>
      </Box>
      {isStarClient && (
        <Box marginTop="0.5rem">
          <StarClient />
        </Box>
      )}
      {maxConfirmedPercentage || maxSpeedOfAction ? (
        <>
          <Box marginTop="1rem" marginBottom="1rem">
            <Divider />
          </Box>
          <ClientQualities
            maxConfirmedPercentage={maxConfirmedPercentage}
            maxSpeedOfAction={maxSpeedOfAction}
            clientAntiquity={clientAntiquity}
            starClient={isStarClient}
            isMobile={isMobile}
          />
        </>
      ) : null}
    </StyledBox>
  );
};

export default NewHostProfileMobile;
