import { useMapEvents } from 'react-leaflet';

const LeafletClickHandler = ({ callback }: { callback: () => void }) => {
  useMapEvents({
    click: () => {
      if (callback) callback();
    },
  });
  return null;
};

export default LeafletClickHandler;
