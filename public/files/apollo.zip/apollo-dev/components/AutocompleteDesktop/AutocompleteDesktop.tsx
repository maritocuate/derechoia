import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import { TextField, styled } from '@mui/material';
import Box from '@mui/material/Box';
import Tooltip from '@alquiler-argentina/demiurgo/components/Tooltip';
import AutocompleteMui, {
  createFilterOptions,
} from '@mui/material/Autocomplete';
import ItemContainer from '../Search/components/ItemContainer/ItemContainer';
import type { AutoCompleteProps } from '../Search/components/Autocomplete/index.type';
import { IOption } from '../../redux/search/type';
import { GroupComponent } from '../Search/components/Autocomplete/components/GroupComponent/GroupComponet';
import { textDestinationFormatter } from '../Search/utils/helpers';
import useUserSession from '../../hooks/userSession/useUserSession';

const OptionWrapped = dynamic(
  () =>
    import(
      '../Search/components/Autocomplete/components/OptionWrapped/OptionWrapped'
    ),
  { ssr: true },
);
const StyledText = styled(TextField)`
  display: flex;
  font-size: 0.8rem;
  & .MuiOutlinedInput-notchedOutline {
    border: none;
  }
  ,
  & .MuiInputBase-input {
    display: flex;
    height: 100%;
    align-items: flex-end;
    font-size: 0.875rem;
    color: rgba(0, 0, 0, 0.87);
    font-weight: 600;
  }
  & .MuiOutlinedInput-root .MuiAutocomplete-input {
    padding: 0;
  }
  & .MuiOutlinedInput-root {
    padding: 0;
  }
`;

const StyledAutocomplete = styled(AutocompleteMui)`
  display: flex;
  align-items: flex-end;
  height: 100%;
` as typeof AutocompleteMui;

const groupBy = ({ groupText }: IOption): string => {
  if (typeof groupText !== 'string') return '';
  return groupText;
};
const filterOptions = createFilterOptions<IOption>({
  limit: 5,
  stringify: textDestinationFormatter,
});
const AutoCompleteDesktop = ({
  value,
  inputValue,
  options,
  setValue,
  setInputValue,
  isLoading,
  tooltip,
  onOpen,
}: AutoCompleteProps) => {
  const { logedText } = useUserSession();

  return (
    <ItemContainer label="Destino" isAutoComplete borderPosition="right">
      <Tooltip
        title="Ingresá un destino para empezar a buscar"
        open={tooltip}
        variant="secondary"
        placement="top"
        arrow
        PopperProps={{
          sx: {
            '&': {
              width: 'auto !important',
              textAlign: 'left',
              fontWeight: 500,
              transform: 'translate(558px, -365px)',
              zIndex: '12',
              marginBottom: '.625rem !important',
            },
            '& div': { maxWidth: 'fit-content !important', mb: '0 !important' },
          },
        }}
      >
        <Box>
          <StyledAutocomplete
            value={value}
            isOptionEqualToValue={(option, val) => typeof option === typeof val}
            getOptionLabel={textDestinationFormatter}
            onChange={(_e, newValue) => {
              return (
                !!newValue &&
                setValue(
                  newValue,
                  newValue?.groupText !== 'Búsquedas recientes',
                )
              );
            }}
            inputValue={inputValue}
            onInputChange={setInputValue}
            groupBy={groupBy}
            options={options}
            filterOptions={filterOptions}
            renderInput={(params) => (
              <StyledText {...params} placeholder={logedText} />
            )}
            renderOption={(props, optionsProps) => (
              <OptionWrapped optionsProps={optionsProps} props={props} />
            )}
            renderGroup={(props) => (
              <GroupComponent
                children={props.children}
                group={props.group}
                key={props.key}
              />
            )}
            ListboxProps={{
              style: {
                maxHeight: '100%',
              },
            }}
            popupIcon={null}
            componentsProps={{
              popper: {
                placement: 'bottom-start',
                style: { width: '469px' },
                modifiers: [
                  {
                    name: 'offset',
                    options: {
                      offset: [-6, 12],
                    },
                  },
                ],
              },
            }}
            disableClearable={inputValue.length < 1}
            clearText=""
            noOptionsText="Sin resultados"
            loading={isLoading}
            loadingText="Cargando..."
            autoSelect={!!inputValue}
            onOpen={onOpen || undefined}
          />
        </Box>
      </Tooltip>
    </ItemContainer>
  );
};

export default memo(AutoCompleteDesktop);
