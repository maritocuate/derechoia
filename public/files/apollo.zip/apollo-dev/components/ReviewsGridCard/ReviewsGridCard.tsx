import React from 'react';
import { Avatar, Box, Rating, styled, Typography } from '@mui/material';
import Image from 'next/image';
import { Reviews } from '../../types/publicar.types';
import { getRandomColor } from '../../utils/helpers/getRandomColor';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    position: relative;
    display: flex;
    flex-direction: column;
    align-content: center;
    width: 100%;
    height: 22rem;
    padding: 3rem 1rem;
    background-color: #ffffff;
    border-radius: 0.5rem;
    box-shadow: 0 0.375rem 0.625rem 0.05rem rgba(0, 0, 0, 0.14);
    margin: 0 1rem 4rem 1rem;
    ${theme.breakpoints.up('md')} {
        width: 18rem;
        height: 22rem;
        margin: 0 0 4rem 0;
    }   
    ${theme.breakpoints.up('lg')} {
        width: 23.25rem;
        height: 19.7rem;
        margin-bottom: 5.5rem;
    }`,
);
const StyledAvatar = styled(Avatar)`
  position: absolute;
  top: -1.5em;
  left: 1rem;
`;
const StyledIcon = styled(Image)`
  position: absolute;
  top: 1em;
  right: 1rem;
`;
const StyledReview = styled(Typography)`
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 5;
  -webkit-box-orient: vertical;
  max-height: 7.5rem;
  line-height: 1.5rem;
`;

interface ReviewsGridCardProps {
  userReview: Reviews;
}

export default function ReviewsGridCard({ userReview }: ReviewsGridCardProps) {
  const { name, photo, date, review } = userReview;

  return (
    <StyledContainer>
      <StyledAvatar
        alt={name}
        src={photo}
        sx={{
          width: '4rem',
          height: '4rem',
          bgcolor: getRandomColor(),
        }}
      >
        <Typography variant="h3" fontSize="2rem">
          {name.charAt(0)}
        </Typography>
      </StyledAvatar>

      <Box display="flex" flexDirection="column" gap="0.8rem">
        <StyledIcon
          src="/images/googleg.svg"
          alt="google"
          width={24}
          height={24}
        />
        <Typography variant="textPostDesktop">{name}</Typography>
        <Typography color="rgba(0, 0, 0, 0.60)" variant="modalText">
          {date}
        </Typography>
        <Rating size="small" value={5} readOnly />
        <StyledReview variant="modalText">{review}</StyledReview>
      </Box>
    </StyledContainer>
  );
}
