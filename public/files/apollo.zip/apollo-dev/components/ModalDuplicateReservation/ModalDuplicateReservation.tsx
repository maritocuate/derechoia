import React from 'react';
import { useTranslation } from 'next-i18next';
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Divider,
  Typography,
  Box,
  styled,
} from '@mui/material';
import Close from '@mui/icons-material/Close';
import WarningAmber from '@mui/icons-material/WarningAmber';
import useIsMobile from '../../hooks/useIsMobile';

interface IModalDuplicateReservation {
  date?: string;
  hour?: string;
  open: boolean;
  onClose: () => void;
  onContinue: () => void;
  place?: string;
}

const StyledDialogContent = styled(DialogContent)`
  display: flex;
  flex-direction: column;
`;

const StyledDialogAction = styled(DialogActions)`
  flex-direction: column;
  justify-content: center;
`;

const StyledButton = styled(Button)`
  height: 2.625rem;
  width: 14.75rem;
`;

const ModalDuplicateReservation = ({
  date,
  hour,
  open,
  onClose,
  onContinue,
  place,
}: IModalDuplicateReservation) => {
  const isMobile = useIsMobile();
  const { t } = useTranslation('ModalDuplicateReservation');

  return (
    <Dialog open={open}>
      <Box width={isMobile ? '20.5rem' : '35rem'}>
        <DialogTitle
          display="flex"
          justifyContent="space-between"
          padding="1.5rem"
        >
          <Typography fontSize="1.25rem" fontWeight={700} lineHeight="2rem">
            {t('header-title')}
          </Typography>
          <IconButton data-testid="close-button" onClick={onClose}>
            <Close />
          </IconButton>
        </DialogTitle>
        <Divider />
        <Box textAlign="center" paddingY="2.5rem" paddingX="1rem">
          <StyledDialogContent>
            <Box>
              <WarningAmber color="primary" sx={{ fontSize: 56 }} />
            </Box>
            <Typography margin="1.5rem 0 1rem 0" variant="modalContentTitle">
              {t('content-title')}
            </Typography>
            <Typography variant="modalText">
              {t('content-text', { date, hour, place })}
            </Typography>
          </StyledDialogContent>
          <StyledDialogAction>
            <StyledButton onClick={onClose}>
              <Typography variant="modalButtonText">
                {t('button-text')}
              </Typography>
            </StyledButton>
            <StyledButton variant="contained" onClick={onContinue}>
              <Typography variant="modalButtonText">
                {t('button-contained-text')}
              </Typography>
            </StyledButton>
          </StyledDialogAction>
        </Box>
      </Box>
    </Dialog>
  );
};

export default ModalDuplicateReservation;
