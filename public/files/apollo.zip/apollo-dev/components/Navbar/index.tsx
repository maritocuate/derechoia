import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import Grid from '@mui/material/Grid';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import FavoriteBorderOutlined from '@mui/icons-material/FavoriteBorderOutlined';
import PersonOutlineOutlined from '@mui/icons-material/PersonOutlineOutlined';
import SearchOutlined from '@mui/icons-material/SearchOutlined';
import styled from '@emotion/styled';
import Link from 'next/link';
import themeAA from '../../styles/theme';

interface IStyledIcons {
  selected: boolean;
}

const navbarOptions = [
  {
    path: 'listado/',
    icon: <SearchOutlined />,
    textTranslation: 'search',
    id: 1,
  },
  {
    path: 'favoritos/',
    icon: <FavoriteBorderOutlined />,
    textTranslation: 'favorites',
    id: 2,
  },
  {
    path: '',
    icon: <PersonOutlineOutlined />,
    textTranslation: 'my-profile',
    id: 3,
  },
];

const NavbarContainer = styled(Grid)`
  width: 100%;
  height: 56px;
  position: sticky;
  bottom: 0;
  left: 0;
  background-color: #fff;
  flex-direction: row;
  justify-content: space-around;
`;

const StyledIconWithText = styled(IconWithText)<IStyledIcons>(
  ({ selected }) => `
  color: #818181;
  & .MuiSvgIcon-root {
    color: ${selected ? themeAA.palette.primary.main : 'inherit'};
  }
`,
);

const StyledIconContainer = styled(Grid)`
  cursor: pointer;
`;

export default function Navbar() {
  const [selected, setSelected] = useState(0);
  const { t } = useTranslation('Navbar');
  const handleSelect = (value: number) => {
    setSelected(value);
  };
  return (
    <NavbarContainer container>
      {navbarOptions.map((item) => (
        <Link
          href={`${String(process.env.NEXT_PUBLIC_URL_API)}${item.path}`}
          key={item.id}
        >
          <StyledIconContainer onClick={() => handleSelect(item.id)} item>
            <StyledIconWithText
              selected={selected === item.id}
              icon={item.icon}
              anchor="bottom"
            >
              {t(item.textTranslation)}
            </StyledIconWithText>
          </StyledIconContainer>
        </Link>
      ))}
    </NavbarContainer>
  );
}
