import React from 'react';
import { VARIANTS as VARIANTS_MODAL } from '@alquiler-argentina/demiurgo/components/Modal';
import {
  styled,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormGroup,
  Typography,
} from '@mui/material';
import RadioButtonChecked from '@mui/icons-material/RadioButtonChecked';
import { useTranslation } from 'next-i18next';
import dynamic from 'next/dynamic';
import themeAA from '../../styles/theme';
import { IOrder } from '../Order/index.type';

const Modal = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/Modal').then(
      (module) => module.default,
    ),
  { ssr: false },
);

const StyledRadioButtonChecked = styled(RadioButtonChecked)`
  width: 24px;
  margin: 15px 25px;
  color: ${themeAA.palette.primary.main};
`;

const StyledFormGroup = styled(FormGroup)`
  margin: 25px;
  font-size: 16px;
`;

const StyledTypography = styled(Typography)`
  font-size: 16px;
`;

const StyledFormControlLabel = styled(FormControlLabel)`
  font-weight: 400;
  letter-spacing: 0.15px;
  font-size: 40px;
`;

export default function Order({
  setOpenOrder,
  openOrder,
  propValue,
  orderOptions,
  handleClickMenuItem,
}: Omit<IOrder, 'selectedProp'>) {
  const { t } = useTranslation('Order');
  const handleCloseOrder = () => {
    setOpenOrder(false);
  };

  return (
    <Modal
      variant={VARIANTS_MODAL.MODAL}
      title={t('order')}
      onClose={handleCloseOrder}
      handleClose={handleCloseOrder}
      open={openOrder}
      fullScreen
      paddingContent="0"
    >
      <StyledFormGroup>
        <RadioGroup
          aria-labelledby="radio-buttons-order"
          name="radio-buttons-group-order"
        >
          {orderOptions.map((e, i) => (
            <StyledFormControlLabel
              value={e.orderValue}
              control={<Radio />}
              checked={
                propValue === e.orderValue ?? <StyledRadioButtonChecked />
              }
              onChange={handleClickMenuItem}
              label={<StyledTypography>{t(e.orderName)}</StyledTypography>}
              key={i}
            />
          ))}
        </RadioGroup>
      </StyledFormGroup>
    </Modal>
  );
}
