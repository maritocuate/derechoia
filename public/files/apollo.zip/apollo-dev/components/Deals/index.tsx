/* eslint-disable @typescript-eslint/indent */
/* eslint-disable react/no-array-index-key */
import React, { useState } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import {
  Box,
  Divider,
  IconButton,
  styled,
  Typography,
  Grid,
} from '@mui/material';

import LocalFireDepartmentOutlinedIcon from '@mui/icons-material/LocalFireDepartmentOutlined';
import DateRangeOutlinedIcon from '@mui/icons-material/DateRangeOutlined';
import AttachMoneyOutlinedIcon from '@mui/icons-material/AttachMoneyOutlined';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import ConfirmationNumberOutlinedIcon from '@mui/icons-material/ConfirmationNumberOutlined';
import ExpandMore from '@mui/icons-material/ExpandMore';
import ExpandLess from '@mui/icons-material/ExpandLess';

import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import useIsMobile from '../../hooks/useIsMobile';

const LastMinute = styled(Box)`
  background: rgba(251, 192, 45, 0.04);
  border-radius: 0.5rem;
  padding: 1rem;
  margin-bottom: 1rem;
  display: flex;
  border: 1px solid #f9a825;
`;

const TitleWithText = styled(Box)`
  display: flex;
`;

const StyledLocalFireDepartmentOutlinedIcon = styled(
  LocalFireDepartmentOutlinedIcon,
)`
  color: #f9a825;
  margin-top: 0.188rem;
  margin-right: 0.625rem;
`;

const StyledConfirmationNumberOutlinedIcon = styled(
  ConfirmationNumberOutlinedIcon,
)(
  ({ theme }) => `
  margin-right: 0.625rem;
  margin-top: 0.188rem;
  color: ${theme.palette.primary.main};
`,
);

const MainTitle = styled(Typography)`
  font-weight: 700;
  font-size: 1.25rem;
`;

const ContainerDividerVertical = styled(Box)`
  display: flex;
  margin-left: 3.75rem;
  margin-right: 2.5rem;
`;

const MainSubTitle = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  font-weight: 600;
  font-size: 1rem;
`;

const ContainerItemsWIthTextYellow = styled(Box)`
  display: flex;
  align-items: center;
  padding-bottom: 1rem;
  border-bottom: 1px solid #fbc02d4d;
`;

const ContainerItemsWIthTextBlue = styled(Box)`
  display: flex;
  align-items: center;
  padding-bottom: 0.5rem;
  margin-bottom: 1rem;
  border-bottom: 1px solid #00acc14d;
`;

const TextTaxInclues = styled(Typography)`
  letter-spacing: 0.4px;
  color: rgba(0, 0, 0, 0.6);
  font-size: 0.75rem;
`;

const StayFlexible = styled(Box)`
  background: rgba(0, 172, 193, 0.04);
  border-radius: 0.5rem;
  padding: 1rem;
  display: flex;
  border: 1px solid #00acc1;
`;
const StyledIconWithText = styled(IconWithText)`
  & .MuiTypography-root {
    font-weight: 700;
    cursor: pointer;
    color: rgba(0, 0, 0, 0.54);
    text-decoration: underline rgba(0, 0, 0, 0.6);
  }
`;

const StyledIconWithTextGrey = styled(IconWithText)`
  & svg {
    color: #0000008a;
  }
`;

const StyledExpandLessIcon = styled(ExpandLess)`
  color: #000000;
`;

const StyledExpandMoreIcon = styled(ExpandMore)`
  color: #000000;
`;

const StyleIconButton = styled(IconButton)`
  border-radius: 0.5rem;
  padding: 0px;
  &:hover {
    background-color: transparent;
  }
`;

const TextConditions = styled(Typography)`
  margin-bottom: 1rem;
  font-weight: 400;
  font-size: 0.75rem;
  color: #000;
`;

interface ILastMinute {
  fecha_ingreso: Date;
  fecha_egreso: Date;
  capacidad: number;
  precio: number;
}

interface IStayFlexibleItems {
  cantidad_noches: number;
  cantidad_personas: number;
  precio: number;
}

interface IStayFlexible {
  fecha_inicio?: Date;
  fecha_fin?: Date;
  agregado_extra?: string;
  valido_feriado?: boolean;
  oferta_flexible_items?: IStayFlexibleItems[];
}

interface IDealsProps {
  itemsLastMinute: ILastMinute[] | [];
  itemsStayFlexible: IStayFlexible[] | [];
}

interface ILastMinuteOffer {
  offer: [] | ILastMinute[];
}

interface IFlexibleOffer {
  offer: IStayFlexible;
}

function LastMinuteOffer({ offer }: ILastMinuteOffer) {
  const { t } = useTranslation('Deals');
  const isMobile = useIsMobile();

  const daysTranslation = (item: { fecha_ingreso: Date; fecha_egreso: Date }) =>
    `${dayjs(item.fecha_egreso).diff(item.fecha_ingreso, 'days')} ${t('night', {
      night: dayjs(item.fecha_egreso).diff(item.fecha_ingreso, 'days'),
      count: dayjs(item.fecha_egreso).diff(item.fecha_ingreso, 'days'),
    })}`;

  return (
    <LastMinute flexDirection={isMobile ? 'column' : 'row'}>
      <TitleWithText
        alignItems={isMobile ? 'center' : 'normal'}
        marginBottom={isMobile ? '1rem' : '0'}
      >
        <StyledLocalFireDepartmentOutlinedIcon />
        <MainTitle
          variant="h6"
          color="#F9A825"
          width={isMobile ? '100%' : '70px'}
        >
          {t('last')} {!isMobile && <br />} {t('minute')}
        </MainTitle>
      </TitleWithText>
      <ContainerDividerVertical>
        <Divider orientation="vertical" flexItem color="#FBC02D" />
      </ContainerDividerVertical>
      <Box width="100%">
        {offer?.map((item, index) => (
          <Box marginBottom="0.75rem" key={index}>
            <MainSubTitle variant="subtitle1" marginBottom="0.5rem">
              <>
                {t('host_from')}{' '}
                {dayjs(item.fecha_ingreso).format('DD/MM/YYYY')} {t('at')}{' '}
                {dayjs(item.fecha_egreso).format('DD/MM/YYYY')}
              </>
            </MainSubTitle>
            <ContainerItemsWIthTextYellow>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<DateRangeOutlinedIcon />}
              >
                <Typography variant="body2" width={isMobile ? '70px' : '100px'}>
                  {daysTranslation(item)}
                </Typography>
              </StyledIconWithTextGrey>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<PersonOutlineOutlinedIcon />}
              >
                <Typography variant="body2" width={isMobile ? '80px' : '100px'}>
                  {item.capacidad} {t('people')}
                </Typography>
              </StyledIconWithTextGrey>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<AttachMoneyOutlinedIcon />}
              >
                <Typography variant="subtitle2" fontWeight="600">
                  {formatPriceToArs(item.precio)}
                </Typography>
              </StyledIconWithTextGrey>
            </ContainerItemsWIthTextYellow>
          </Box>
        ))}
        <Box>
          <TextTaxInclues variant="caption">
            {t('final_price_including_taxes')}
          </TextTaxInclues>
        </Box>
      </Box>
    </LastMinute>
  );
}

function FlexibleOffer({ offer }: IFlexibleOffer) {
  const { t } = useTranslation('Deals');
  const isMobile = useIsMobile();

  const [collapse, setCollapse] = useState(false);
  const handleCollapse = () => {
    setCollapse(!collapse);
  };

  const title = `${t('book_now_and_stay_in_between_the')} ${dayjs(
    offer?.fecha_inicio,
  ).format('DD/MM/YYYY')} ${t('and_the')} ${dayjs(offer?.fecha_fin).format(
    'DD/MM/YYYY',
  )}`;

  return (
    <StayFlexible flexDirection={isMobile ? 'column' : 'row'}>
      <TitleWithText
        alignItems={isMobile ? 'center' : 'normal'}
        marginBottom={isMobile ? '1rem' : '0'}
      >
        <StyledConfirmationNumberOutlinedIcon />
        <MainTitle
          variant="h6"
          color="#00ACC1"
          width={isMobile ? '100%' : '70px'}
        >
          {t('stay')} {!isMobile && <br />} {t('flexible')}
        </MainTitle>
      </TitleWithText>
      <ContainerDividerVertical>
        <Divider orientation="vertical" flexItem color="#00ACC1" />
      </ContainerDividerVertical>
      <Box width="100%">
        <Box marginBottom="0.75rem">
          <MainSubTitle variant="subtitle1" marginBottom="1.5rem">
            {title}
          </MainSubTitle>
          {offer.oferta_flexible_items?.map((item, index) => (
            <ContainerItemsWIthTextBlue key={index}>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<DateRangeOutlinedIcon />}
              >
                <Typography variant="body2" width={isMobile ? '70px' : '100px'}>
                  {item.cantidad_noches}{' '}
                  {t('night', {
                    night: item.cantidad_noches,
                    count: item.cantidad_noches,
                  })}
                </Typography>
              </StyledIconWithTextGrey>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<PersonOutlineOutlinedIcon />}
              >
                <Typography variant="body2" width={isMobile ? '80px' : '100px'}>
                  {item.cantidad_personas} {t('people')}
                </Typography>
              </StyledIconWithTextGrey>
              <StyledIconWithTextGrey
                anchor="left"
                icon={<AttachMoneyOutlinedIcon />}
              >
                <Typography variant="subtitle2" fontWeight="600">
                  {formatPriceToArs(item.precio)}
                </Typography>
              </StyledIconWithTextGrey>
            </ContainerItemsWIthTextBlue>
          ))}
          <Box>
            {offer.agregado_extra !== '' ? (
              <Typography variant="body2" marginBottom="1rem">
                • {offer.agregado_extra}
              </Typography>
            ) : null}
          </Box>
          <Box>
            <Box display={collapse ? 'block' : 'none'}>
              <TextConditions>
                (*)
                {offer.valido_feriado
                  ? t('if_valid_for_holiday')
                  : t('not_valid_for_holiday')}
                {t('codition1')}
              </TextConditions>
              <TextConditions>{t('codition2')}</TextConditions>
            </Box>
            <StyleIconButton onClick={handleCollapse}>
              <StyledIconWithText
                anchor="right"
                icon={
                  collapse ? <StyledExpandLessIcon /> : <StyledExpandMoreIcon />
                }
              >
                <Typography>
                  {collapse ? t('hide_conditions') : t('see_conditions')}
                </Typography>
              </StyledIconWithText>
            </StyleIconButton>
          </Box>
        </Box>
      </Box>
    </StayFlexible>
  );
}

export default function Deals({
  itemsLastMinute,
  itemsStayFlexible,
}: IDealsProps) {
  return (
    <Grid container direction="column" rowSpacing={5}>
      {itemsLastMinute && Object.keys(itemsLastMinute).length > 0 ? (
        <Grid item>
          <LastMinuteOffer offer={itemsLastMinute} />
        </Grid>
      ) : null}
      {itemsStayFlexible
        ? itemsStayFlexible.map((offer) => (
            <Grid item>
              <FlexibleOffer offer={offer} />
            </Grid>
          ))
        : null}
    </Grid>
  );
}
