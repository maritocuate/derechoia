import React, { memo } from 'react';
import SEO from '../SEO';
import useSeoAlojamientos from './hooks/useSeoAlojamientos';

const SEOAlojamientos = ({
  referencia,
  testProperty,
}: {
  referencia: string;
  testProperty?: boolean;
}) => {
  const { seoData } = useSeoAlojamientos({ referencia, testProperty });

  return (
    <SEO
      title={seoData?.seoTitle || ''}
      description={seoData?.seoDesciption || ''}
      image={seoData?.photoStructuredData}
      keywords={seoData?.seoKeywords || ''}
      url={seoData?.link}
      jsonStructuredData={seoData?.jsonStructuredData}
      metaRobots={seoData?.metaRobots}
    />
  );
};

export default memo(SEOAlojamientos);
