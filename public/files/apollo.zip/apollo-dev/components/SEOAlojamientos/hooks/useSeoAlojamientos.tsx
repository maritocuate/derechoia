/* eslint-disable @typescript-eslint/indent */
/* eslint-disable arrow-body-style */
import { useMemo } from 'react';
import { useSelector } from 'react-redux';
import dayjs from 'dayjs';
import { useGetPropiedadQuery } from '../../../services/propiedades';
import { hasGarageOrPool } from '../../../utils/helpers/hasGarageOrPool';
import { IFichaSecondCharge } from '../../../redux/ficha/types';
import photosForSchema from '../../../utils/helpers/SEO/photosForSchema';
import typeForSchema from '../../../utils/helpers/SEO/typeForSchema';
import amenitiesForSchema from '../../../utils/helpers/SEO/amenitiesForSchema';

const CDN_ENV = process.env.NEXT_PUBLIC_IMAGE_CDN || '';

const useSeoAlojamientos = ({
  referencia,
  testProperty,
}: {
  referencia: string;
  testProperty?: boolean;
}) => {
  const { data } = useGetPropiedadQuery(
    { referencia, test: testProperty },
    { skip: !referencia },
  );
  const phoneNumbers = useSelector(
    ({ fichaSecondCharge }: { fichaSecondCharge: IFichaSecondCharge }) =>
      fichaSecondCharge?.bookingData?.phoneNumbers,
  );
  const metaRobots =
    data && data.es_test ? 'NOINDEX, NOFOLLOW' : 'INDEX, FOLLOW';
  const seoData = useMemo(() => {
    if (!data) return null;

    const {
      titulo,
      tipo,
      link_absoluto: link,
      precio_minimo: precioMinimo,
      foto_listado: fotoListado,
      nombre_pais: nombrePais,
      nombre_provincia: nombreProvincia,
      nombre_localidad: nombreLocalidad,
      capacidad_min: capacidadMin,
      ag_cochera: agCochera,
      ag_pileta: agPileta,
      referencia: ref,
      acepta_mascotas: aceptaMascotas,
    } = data;
    const locationWithGarageOrPool = hasGarageOrPool({
      agCochera,
      agPileta,
    });

    const seoTitle = `${titulo}, ${tipo} en ${nombreLocalidad}
            para ${capacidadMin} personas con ${locationWithGarageOrPool} - ${ref} - El mejor precio`;
    const seoDesciption = `Alquilá ${tipo} en ${nombreLocalidad}: ${tipo} en ${nombreLocalidad}, ${tipo} desde $${precioMinimo}`;
    const seoKeywords = `${tipo} , ${ref} , alquiler , temporario ,${nombreLocalidad} , ${nombreProvincia}, ${nombrePais}`;
    const photoStructuredData = `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/${ref}/${fotoListado}`;

    const arrayOfPhotos = photosForSchema(data, CDN_ENV, photoStructuredData);
    const additionalType = typeForSchema(data?.tipo || '');
    const amenities = amenitiesForSchema(data?.agregados, !!aceptaMascotas);

    const review =
      data?.comentarios?.map((elem) => {
        return {
          type: 'Review',
          author: {
            '@type': 'Person',
            name: elem.nombre_apellido,
          },
          datePublished: dayjs(elem.fecha_hora).format('YYYY-MM-DD'),
          description: elem.comentario,
          reviewRating: {
            '@type': 'Rating',
            ratingValue: elem.valoracion,
            bestRating: 5,
            worstRating: 1,
          },
        };
      }) || [];

    const [firstPhone] = phoneNumbers || [];

    const brand = data
      ? `AlquilerArgentina - ${tipo} en ${nombreLocalidad}`
      : '';
    const maxRoom =
      data && data.tipologias
        ? Math.max(...data.tipologias.map((tipologia) => tipologia.dormitorios))
        : 0;
    const maxBathrooms =
      data && data.tipologias
        ? Math.max(...data.tipologias.map((tipologia) => tipologia.banios))
        : 0;

    const jsonStructuredData = {
      '@context': 'https://schema.org',
      '@type': 'VacationRental',
      telephone: firstPhone?.telefonoWeb || '',
      priceRange: data?.precio_minimo,
      additionalType,
      containsPlace: {
        '@type': 'Accommodation',
        additionalType: 'EntirePlace',
        occupancy: {
          '@type': 'QuantitativeValue',
          value: data?.capacidad_max,
        },
        numberOfBathroomsTotal: maxBathrooms,
        numberOfBedrooms: maxRoom,
        amenityFeature: amenities,
      },
      image: arrayOfPhotos,
      url: data?.link_absoluto,
      name: data?.titulo,
      description: seoDesciption,
      identifier: data?.referencia,
      brand,
      geo: {
        '@type': 'GeoCoordinates',
        latitude: data?.lat,
        longitude: data?.lng,
      },
      address: {
        '@type': 'PostalAddress',
        addressLocality: data?.nombre_localidad,
        addressCountry: data?.nombre_pais,
      },
      aggregateRating: data?.comentarios?.length
        ? {
            '@type': 'AggregateRating',
            worstRating: '1',
            ratingValue: data?.puntaje,
            bestRating: '5',
            ratingCount: data?.comentarios.length,
          }
        : null,
      review,
    };

    return {
      seoTitle,
      seoDesciption,
      seoKeywords,
      metaRobots,
      photoStructuredData,
      link,
      jsonStructuredData,
    };
  }, [data, phoneNumbers, metaRobots]);

  return { seoData };
};

export default useSeoAlojamientos;
