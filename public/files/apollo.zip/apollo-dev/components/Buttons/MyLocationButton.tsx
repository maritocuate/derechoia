import React from 'react';
import MyLocationOutlinedIcon from '@mui/icons-material/MyLocationOutlined';
import { Fab } from '@mui/material';

const MyLocationButton = ({ onPress }: { onPress: () => void }) => {
  return (
    <Fab
      aria-label="add"
      size="small"
      sx={{
        backgroundColor: '#fff',
        boxShadow: '0px 2px 2px 1px rgba(0, 0, 0, 0.14)',
        zIndex: 3,
      }}
      onClick={(e) => {
        e.stopPropagation();
        e.preventDefault();
        if (onPress) onPress();
      }}
    >
      <MyLocationOutlinedIcon />
    </Fab>
  );
};

export default MyLocationButton;
