import React from 'react';
import { Box, styled } from '@mui/material';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';

const CustomBackIconContainer = styled(Box)`
  padding: 0.5rem 0.6rem 0.5rem 1.1rem;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 20%;
  cursor: pointer;
`;

const BackButtonNavbarMobile = ({ onClick }: { onClick?: () => void }) => {
  const handlePress = () => {
    if (onClick) onClick();
  };

  return (
    <CustomBackIconContainer onClick={handlePress}>
      <ArrowBackIosIcon
        sx={{
          height: '1rem',
          width: '1rem',
          color: 'rgba(0, 0, 0, 0.6)',
        }}
      />
    </CustomBackIconContainer>
  );
};

export default BackButtonNavbarMobile;
