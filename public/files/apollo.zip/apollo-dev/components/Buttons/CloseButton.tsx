/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { Button, styled } from '@mui/material';
import CrossSVG from '../SVG/CrossSVG';

const StyledButtonRoot = styled(Button)(
  ({ buttonVariant }: { buttonVariant: 'contained' | 'transparent' }) => `
    background: ${
      buttonVariant === 'contained' ? 'rgba(0, 0, 0, 0.4)' : 'transparent'
    };
    border-radius: 4px;
    min-width: 28px;
    width: 28px;
    height: 28px;
    &:hover {
      background: ${
        buttonVariant === 'contained'
          ? 'rgba(0, 0, 0, 0.6)'
          : 'rgba(0, 0, 0, 0.2)'
      };
  `,
);
const CloseButton = ({
  variant = 'contained',
  handleClose = () => {},
}: {
  variant?: 'contained' | 'transparent';
  handleClose?: () => void;
}) => (
  <StyledButtonRoot onClick={handleClose} buttonVariant={variant}>
    <CrossSVG
      fill={variant === 'transparent' ? 'rgba(0, 0, 0, 0.54)' : 'white'}
      height={variant === 'transparent' ? 14 : 12}
      width={variant === 'transparent' ? 14 : 12}
    />
  </StyledButtonRoot>
);

export default CloseButton;
