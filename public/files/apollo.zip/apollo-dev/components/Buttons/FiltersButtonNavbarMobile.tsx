import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';

const FilterContainer = styled(Box)`
  width: fit-content;
  padding: 0.2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  cursor: pointer;
`;

const StyledAction = styled(Typography)`
  font-weight: 600;
  font-size: 0.9rem;
  line-height: 1.5rem;
  color: #00acc1;
`;

const FiltersButtonNavbarMobile = ({ onClick }: { onClick?: () => void }) => {
  const handlePress = () => {
    if (onClick) onClick();
  };
  return (
    <FilterContainer onClick={handlePress}>
      <FilterAltOutlinedIcon
        sx={{
          color: '#00ACC1',
          height: '1.5rem',
        }}
      />
      <StyledAction>Filtrar</StyledAction>
    </FilterContainer>
  );
};

export default FiltersButtonNavbarMobile;
