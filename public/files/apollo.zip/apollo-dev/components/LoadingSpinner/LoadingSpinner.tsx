import React from 'react';
import { styled } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';

const StyledSpinnerContainer = styled(Box)`
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0;
  padding: 0;
`;

const LoadingSpinner = () => {
  return (
    <StyledSpinnerContainer>
      <CircularProgress />
    </StyledSpinnerContainer>
  );
};

export default LoadingSpinner;
