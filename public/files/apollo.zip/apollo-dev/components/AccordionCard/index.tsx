import React, { useState, useCallback } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import Divider from '@alquiler-argentina/demiurgo/components/Divider';
import { Box, styled, Collapse, Grid, Typography } from '@mui/material';
import IconArrow from '../../utils/helpers/AccordionCard/IconArrow';
import { Item } from '../../types/holiday.types';

interface AccordionCardProps {
  title: string;
  content: Item[];
}

const StyledIconWithText = styled(IconWithText)`
  cursor: pointer;
  justify-content: space-between !important;
  margin-bottom: 1rem;
`;
const StyledTypography = styled(Typography)`
  margin-bottom: 1rem;
`;
const StyledTitle = styled(Typography)`
  font-weight: 700;
  font-size: 1.3rem;
`;
const StyledContainer = styled(Box)(
  ({ theme }) => `
    border: 1px solid rgba(0, 0, 0, 0.23);
    padding: 2rem;
    margin: 0 1rem;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 2rem;
  ${theme.breakpoints.up('lg')}{
    margin: 0;
  }
`,
);

function AccordionCard({ title, content }: AccordionCardProps) {
  const [answers, setAnswers] = useState<boolean[]>(() =>
    content.map(() => false),
  );

  const toggleAnswer = useCallback((index: number) => {
    setAnswers((prevAnswers) =>
      prevAnswers.map((value, i) => (i === index ? !value : value)),
    );
  }, []);

  return (
    <StyledContainer>
      <StyledTitle variant="textPostDesktop">{title}</StyledTitle>
      <Grid gap={2} container direction="column">
        {content.map((faq, index) => (
          <Grid item key={index}>
            <StyledIconWithText
              icon={<IconArrow isOpen={answers[index]} />}
              onClick={() => toggleAnswer(index)}
              anchor="right"
            >
              <Typography variant="h2" fontWeight={600} fontSize="1rem">
                {faq.question}
              </Typography>
            </StyledIconWithText>
            <Collapse in={answers[index]}>
              <StyledTypography>{faq.answer}</StyledTypography>
            </Collapse>
            {index < content.length - 1 && <Divider />}
          </Grid>
        ))}
      </Grid>
    </StyledContainer>
  );
}

export default AccordionCard;
