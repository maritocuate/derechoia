import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import { ExtraAdsSection } from '../../layout/listPage/containers/ExtraAdsContainer/components/ExtraAdsSection';
import useIsMobile from '../../hooks/useIsMobile';
import { ISimilarPropertyDataFormatted } from '../../types/similarProperties.types';

const StyledContainer = styled(Box)`
  margin-bottom: 2.5rem;
  margin-top: 2.5rem;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const StyledInnerBox = styled(Box)`
  ${({ theme }) => `
    margin-left: 1rem;
    ${theme.breakpoints.up('lg')} {
      margin-left: 0;
    }
  `}
`;

const StyledTypography = styled(Typography)`
  ${({ theme }) => `
    margin-bottom: 2.5rem;
    font-weight: 600;
    font-size: 1.25rem;
    ${theme.breakpoints.up('lg')} {
      font-size: 1.5rem;
    }
  `}
`;

interface ISimilarPropertiesContainerProps {
  data: ISimilarPropertyDataFormatted[];
}

const SimilarPropertiesContainer = ({
  data,
}: ISimilarPropertiesContainerProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer>
      <StyledInnerBox>
        <StyledTypography>
          Alojamientos similares a tu búsqueda
        </StyledTypography>
      </StyledInnerBox>
      <Box>
        <ExtraAdsSection
          noFav
          isLoadingFav={false}
          isMobile={isMobile}
          ads={data}
        />
      </Box>
    </StyledContainer>
  );
};

export default SimilarPropertiesContainer;
