import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import { Box, Button, Typography, styled } from '@mui/material';
import ErrorOutlineOutlined from '@mui/icons-material/ErrorOutlineOutlined';

const StyledContent = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 2.5rem;
`;

const StyledModalTitle = styled(DialogTitle)(
  ({ theme }) => `
      height: 4rem;
      ${theme.breakpoints.up('sm')} {
        height: 5rem;
      }
    `,
);

const StyledContainer = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  gap: 1.5rem;
`;

const StyledIconButton = styled(IconButton)(
  ({ theme }) => `
      top: 10;
      ${theme.breakpoints.up('sm')} {
        top: 20;
      }
    `,
);

const StyledTextContainer = styled(Box)(
  ({ theme }) => `
      width: 17.5rem;
      text-align: center;
      ${theme.breakpoints.up('sm')} {
        width: 32rem;
      }
    `,
);

const StyledErrorOutlineOutlined = styled(ErrorOutlineOutlined)(
  ({ theme }) => `
      font-size: 4.125rem;
      ${theme.breakpoints.up('sm')} {
        font-size: 5rem;
      }
    `,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
      font-weight: 600;
      font-size: 1.25rem;
  
      ${theme.breakpoints.up('sm')} {
        font-size: 1.5rem;
      }
    `,
);

export default function AdminModal({ onClose }: { onClose: () => void }) {
  return (
    <Dialog onClose={onClose} open>
      <StyledModalTitle>
        <StyledIconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
          }}
        >
          <CloseIcon />
        </StyledIconButton>
      </StyledModalTitle>
      <DialogContent sx={{ padding: '1.5rem' }} dividers>
        <StyledContent>
          <StyledContainer>
            <Box>
              <StyledErrorOutlineOutlined color="primary" />
            </Box>
            <Box textAlign="center">
              <StyledTitle fontWeight={600}>
                La carga de anuncios no está disponible
              </StyledTitle>
            </Box>
            <StyledTextContainer>
              <Typography fontWeight={400} fontSize="1rem">
                Estás accediendo como usuario administrador y para publicar un
                alojamiento debés ingresar con una cuenta de anfitrión
              </Typography>
            </StyledTextContainer>
          </StyledContainer>
          <Box width="14.75rem">
            <Button
              variant="contained"
              size="large"
              fullWidth
              onClick={onClose}
            >
              Entendido
            </Button>
          </Box>
        </StyledContent>
      </DialogContent>
    </Dialog>
  );
}
