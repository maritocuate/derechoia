import React, { ReactNode } from 'react';
import { styled, Divider as DividerMUI, Typography, Grid } from '@mui/material';

interface IContainer {
  title?: ReactNode;
  children: ReactNode;
  divider?: boolean;
}
const StyledDivider = styled(DividerMUI)`
  width: 100%;
`;
const StyledTypographyPolitics = styled(Typography)`
  padding-block-end: 2rem;
  font-weight: 700;
  font-size: 1.25rem;
`;
function Container({ title, children, divider }: IContainer) {
  return (
    <Grid container direction="column">
      <Grid item container direction="column" padding="2.5rem 0">
        <Grid item>
          <StyledTypographyPolitics variant="h2">
            {title}
          </StyledTypographyPolitics>
        </Grid>
        <Grid item width="100%">
          {children}
        </Grid>
      </Grid>
      {divider && <StyledDivider />}
    </Grid>
  );
}

export default Container;
