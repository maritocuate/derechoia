/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { Typography, IconWithText } from '@alquiler-argentina/demiurgo';
import { Box } from '@mui/material';
import OfflineBoltOutlined from '@mui/icons-material/OfflineBoltOutlined';
import { useTranslation } from 'next-i18next';

interface IGuarante {
  garantia?: number;
  a_reintegrar?: boolean;
  valor_a_reintegrar?: string;
  datos_tarjeta?: boolean;
  foto_dni?: boolean;
  presentar_documento?: boolean;
  firma_contrato?: boolean;
}

function Guarantee({
  garantia,
  a_reintegrar,
  valor_a_reintegrar,
  datos_tarjeta,
  foto_dni,
  presentar_documento,
  firma_contrato,
}: IGuarante) {
  const { t } = useTranslation('TermsAndConditions');
  const garantias = {
    list: [
      {
        value: a_reintegrar
          ? `AR $${valor_a_reintegrar || ''} ${t('garantias.efectivo')}`
          : null,
      },
      {
        value: datos_tarjeta ? `${t('garantias.tarjeta')}` : null,
      },
      {
        value: foto_dni ? `${t('garantias.foto-docs')}` : null,
      },
      {
        value: presentar_documento ? `${t('garantias.docs')}` : null,
      },
      {
        value: firma_contrato ? `${t('garantias.contrato')}` : null,
      },
    ],
  };
  return (
    <Box padding="0 1rem" data-testid="guarantee">
      <Box marginBottom="12px">
        <IconWithText
          anchor="left"
          icon={<OfflineBoltOutlined color="primary" />}
        >
          <Typography variant="body1" fontWeight={600}>
            {garantia ? t('garantias.title') : t('garantias.negative-tittle')}
          </Typography>
        </IconWithText>
      </Box>
      {garantias.list.map((str, index) => (
        <Typography variant="body1" key={index} marginBottom="12px">
          {str.value}
        </Typography>
      ))}
    </Box>
  );
}

export default Guarantee;
