/* eslint-disable @typescript-eslint/no-unused-vars */
import React from 'react';
import { Typography, IconWithText, Grid } from '@alquiler-argentina/demiurgo';
import { styled, useTheme } from '@mui/material';
import { useTranslation } from 'next-i18next';
import AccessibilityOutlined from '@mui/icons-material/AccessibilityOutlined';
import CheckOutlined from '@mui/icons-material/CheckOutlined';
import CloseOutlined from '@mui/icons-material/CloseOutlined';

import { TRule } from '../../../types/propiedades.types';
import useIsMobile from '../../../hooks/useIsMobile';

interface IRules {
  permite_fumar?: TRule;
  permite_hacer_fiestas?: TRule;
  permite_recibir_visitas?: TRule;
  permite_musica?: TRule;
  acepta_familias?: TRule;
  acepta_parejas?: TRule;
  acepta_grupo_jovenes?: TRule;
  acepta_mascotas?: TRule;
  apto_niños?: TRule;
  apto_bebes?: TRule;
  apto_movilidad_reducida?: TRule;
}

type TRulesArray = { value: string }[];

interface IRulesArray {
  acepta: TRulesArray;
  no_acepta: TRulesArray;
  apto: TRulesArray;
  no_apto: TRulesArray;
}

const StyledRulesContainer = styled(Grid)`
  padding: 0 1rem;
  min-width: 100%;
`;

const StyledRuleContainer = styled(Grid)(
  ({ theme }) => `
  width: 100%;
  ${theme.breakpoints.up('md')} {
    width: 31%;
  }
`,
);

const StyledRuleWrapper = styled(Grid)`
  flex-direction: column;
  align-items: flex-start;
  justify-items: flex-start;
  margin-block-end: 20px;
`;

const StyledRuleTitle = styled(Typography)`
  font-weight: 600;
`;

const StyledGridItem = styled(Grid)`
  padding-block-start: 1rem;
`;

const StyledRuleBody = styled(Typography)`
  margin-block-end: 12px;
`;

function Rules({
  acepta_familias,
  acepta_parejas,
  acepta_grupo_jovenes,
  apto_niños,
  apto_bebes,
  acepta_mascotas,
  apto_movilidad_reducida,
  permite_fumar,
  permite_hacer_fiestas,
  permite_recibir_visitas,
  permite_musica,
}: IRules) {
  const { t } = useTranslation('TermsAndConditions');
  const theme = useTheme();
  const isMobile = useIsMobile();

  const rules: IRulesArray = {
    acepta: [], // initializing acepta array
    no_acepta: [], // initializing no_acepta array
    apto: [], // initializing no_acepta array
    no_apto: [], // initializing no_apto array
  };

  // building up the rules object
  switch (acepta_familias) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.acepta.familias')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.acepta.familias')}` });
      break;
  }

  switch (acepta_parejas) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.acepta.parejas')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.acepta.parejas')}` });
      break;
  }

  switch (acepta_grupo_jovenes) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.acepta.grupos-de-jovenes')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.acepta.grupos-de-jovenes')}` });
      break;
  }

  switch (acepta_mascotas) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.acepta.mascotas')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.acepta.mascotas')}` });
      break;
  }

  switch (permite_fumar) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.acepta.fumar')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.acepta.fumar')}` });
      break;
  }

  switch (permite_hacer_fiestas) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.no_acepta.fiestas')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.no_acepta.fiestas')}` });
      break;
  }

  switch (permite_recibir_visitas) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.no_acepta.visitas')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.no_acepta.visitas')}` });
      break;
  }

  switch (permite_musica) {
    case null:
      break;
    case 0:
      rules.no_acepta.push({ value: `${t('rules.no_acepta.musica')}` });
      break;
    default:
      rules.acepta.push({ value: `${t('rules.no_acepta.musica')}` });
      break;
  }

  if (apto_bebes) {
    rules.apto.push({ value: `${t('rules.apto.bebes')}` });
  } else {
    rules.no_apto.push({ value: `${t('rules.apto.bebes')}` });
  }

  if (apto_niños) {
    rules.apto.push({ value: `${t('rules.apto.ninios')}` });
  } else {
    rules.no_apto.push({ value: `${t('rules.apto.ninios')}` });
  }

  if (apto_movilidad_reducida) {
    rules.apto.push({ value: `${t('rules.apto.movilidad-reducida')}` });
  } else {
    rules.no_apto.push({ value: `${t('rules.apto.movilidad-reducida')}` });
  }

  return (
    <StyledRulesContainer
      direction={isMobile ? 'column' : 'row'}
      columnSpacing={6}
      container
      data-testid="rules"
    >
      {rules.apto.length > 0 ? (
        <Grid item container xs={isMobile ? 12 : 4}>
          <StyledRuleContainer xs={12} item>
            <StyledRuleWrapper container>
              <Grid item>
                <IconWithText
                  anchor="left"
                  icon={<AccessibilityOutlined color="primary" />}
                >
                  <StyledRuleTitle variant="body1">
                    {t('rules.apto.title')}
                  </StyledRuleTitle>
                </IconWithText>
              </Grid>
              <StyledGridItem item>
                {rules.apto.map((item, index) => (
                  <StyledRuleBody key={index} variant="body1">
                    {item.value}
                  </StyledRuleBody>
                ))}
              </StyledGridItem>
            </StyledRuleWrapper>
          </StyledRuleContainer>
          {!isMobile && rules.no_apto.length > 0 ? (
            <StyledRuleContainer item xs={12}>
              <StyledRuleWrapper container sx={{ marginBlockEnd: '0' }}>
                <Grid item>
                  <IconWithText
                    anchor="left"
                    icon={<AccessibilityOutlined color="error" />}
                  >
                    <StyledRuleTitle variant="body1">
                      {t('rules.no_apto.title')}
                    </StyledRuleTitle>
                  </IconWithText>
                </Grid>
                <StyledGridItem item>
                  {rules.no_apto.map((item, index) => (
                    <StyledRuleBody key={index} variant="body1">
                      {item.value}
                    </StyledRuleBody>
                  ))}
                </StyledGridItem>
              </StyledRuleWrapper>
            </StyledRuleContainer>
          ) : null}
        </Grid>
      ) : null}
      {isMobile && rules.no_apto.length > 0 ? (
        <StyledRuleContainer item>
          <StyledRuleWrapper container>
            <Grid item>
              <IconWithText
                anchor="left"
                icon={<AccessibilityOutlined color="error" />}
              >
                <StyledRuleTitle variant="body1">
                  {t('rules.no_apto.title')}
                </StyledRuleTitle>
              </IconWithText>
            </Grid>
            <StyledGridItem item>
              {rules.no_apto.map((item, index) => (
                <StyledRuleBody key={index} variant="body1">
                  {item.value}
                </StyledRuleBody>
              ))}
            </StyledGridItem>
          </StyledRuleWrapper>
        </StyledRuleContainer>
      ) : null}
      {rules.acepta.length > 0 ? (
        <StyledRuleContainer item>
          <StyledRuleWrapper container>
            <Grid item>
              <IconWithText
                anchor="left"
                icon={<CheckOutlined color="primary" />}
              >
                <StyledRuleTitle variant="body1">
                  {t('rules.acepta.title')}
                </StyledRuleTitle>
              </IconWithText>
            </Grid>
            <StyledGridItem item>
              {rules.acepta.map((item, index) => (
                <StyledRuleBody key={index} variant="body1">
                  {item.value}
                </StyledRuleBody>
              ))}
            </StyledGridItem>
          </StyledRuleWrapper>
        </StyledRuleContainer>
      ) : null}
      {rules.no_acepta.length > 0 ? (
        <StyledRuleContainer item>
          <StyledRuleWrapper container sx={{ marginBlockEnd: '0' }}>
            <Grid item>
              <IconWithText
                anchor="left"
                icon={<CloseOutlined color="error" />}
              >
                <StyledRuleTitle variant="body1">
                  {t('rules.no_acepta.title')}
                </StyledRuleTitle>
              </IconWithText>
            </Grid>
            <StyledGridItem item>
              {rules.no_acepta.map((item, index) => (
                <StyledRuleBody key={index} variant="body1">
                  {item.value}
                </StyledRuleBody>
              ))}
            </StyledGridItem>
          </StyledRuleWrapper>
        </StyledRuleContainer>
      ) : null}
    </StyledRulesContainer>
  );
}

export default Rules;
