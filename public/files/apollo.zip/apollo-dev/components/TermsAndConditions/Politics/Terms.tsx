import React from 'react';
import { Typography, IconWithText } from '@alquiler-argentina/demiurgo';
import { Box } from '@mui/material';
import { useTranslation } from 'next-i18next';
import MonetizationOnOutlined from '@mui/icons-material/MonetizationOnOutlined';
import HotelOutlined from '@mui/icons-material/HotelOutlined';
import InsertInvitationOutlined from '@mui/icons-material/InsertInvitationOutlined';
import useIsMobile from '../../../hooks/useIsMobile';

interface ITerms {
  nights?: number;
  valorPagoAnticipado?: number;
  antelacion?: number;
}

function Terms({ nights, valorPagoAnticipado, antelacion }: ITerms) {
  const { t } = useTranslation('TermsAndConditions');
  const isMobile = useIsMobile();

  return (
    <Box
      display="flex"
      flexDirection={!isMobile ? 'row' : 'column'}
      width="100%"
      data-testid="terms"
    >
      <Box display="flex" flexDirection="column" width="100%" padding="0 1rem">
        <IconWithText
          icon={<MonetizationOnOutlined color="primary" />}
          anchor="left"
        >
          <Typography variant="body1" fontWeight={600}>
            {t('Pago anticipado')}
          </Typography>
        </IconWithText>
        <Box>
          <Typography variant="body1" margin="12px 0">
            {valorPagoAnticipado}
            {t('Seña')}
          </Typography>
        </Box>
      </Box>
      <Box width="100%" padding="0 1rem" marginTop={isMobile ? 2 : 0}>
        <IconWithText icon={<HotelOutlined color="primary" />} anchor="left">
          <Typography variant="body1" fontWeight={600}>
            {t('Estadía mínima')}
          </Typography>
        </IconWithText>
        <Box margin="0.75rem 0 0 0">
          <Typography variant="body1">
            {nights}
            {nights && nights > 1
              ? ` ${t('numero-noches.plural')}`
              : ` ${t('numero-noches.singular')}`}{' '}
          </Typography>
        </Box>
      </Box>
      {antelacion !== undefined && antelacion !== 0 ? (
        <Box
          display="flex"
          flexDirection="column"
          width="100%"
          padding={isMobile ? '1rem 0 0 1rem' : '0'}
          marginTop={isMobile ? 2 : 0}
        >
          <IconWithText
            icon={
              <InsertInvitationOutlined
                color="primary"
                sx={
                  !isMobile ? { position: 'relative', top: '-14px' } : undefined
                }
              />
            }
            anchor="left"
          >
            <Typography variant="subtitle1" fontWeight={600}>
              {t('titulo-antelacion')}
            </Typography>
          </IconWithText>
          <Box>
            <Typography variant="body1" margin="12px 0">
              {antelacion} {t('antelacion', { count: antelacion, antelacion })}
            </Typography>
          </Box>
        </Box>
      ) : null}
    </Box>
  );
}

export default Terms;
