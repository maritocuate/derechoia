import React from 'react';
import { Typography } from '@alquiler-argentina/demiurgo';
import { Box, Grid } from '@mui/material';
import { useTranslation } from 'next-i18next';
import EventRepeatOutlined from '@mui/icons-material/EventRepeatOutlined';
import EventAvailableOutlined from '@mui/icons-material/EventAvailableOutlined';
import EventBusyOutlined from '@mui/icons-material/EventBusyOutlined';

interface ICancelacion {
  cancelacion?: string | 'gratis' | 'flexible' | 'estricta';
  cancelationFlexMonths?: number | null;
  cancelationFreeDays?: number | null;
}
interface IPolityCancel {
  type: ICancelacion['cancelacion'];
  title: string;
  booking: string;
  icon: JSX.Element;
  text: string;
  textSecondary?: string | null;
}

function Cancellation({
  cancelacion,
  cancelationFreeDays,
  cancelationFlexMonths,
}: ICancelacion) {
  const { t } = useTranslation('TermsAndConditions');
  const cancellation: IPolityCancel[] = [
    {
      type: 'gratis',
      title: `${t('tipo-cancelación.cancelación-gratuita.tittle')}`,
      booking: `${t('tipo-cancelación.cancelación-gratuita.subtitle')}`,
      icon: <EventAvailableOutlined color="primary" />,
      text: `${t('tipo-cancelación.cancelación-gratuita.text')}`,
      textSecondary: `${t(
        'tipo-cancelación.cancelación-gratuita.textSecondary',
        { days: cancelationFreeDays },
      )}`,
    },
    {
      type: 'flexible',
      title: `${t('tipo-cancelación.cancelación-flexible.tittle')}`,
      booking: `${t('tipo-cancelación.cancelación-flexible.subtitle')}`,
      icon: <EventRepeatOutlined color="primary" />,
      text: `${t('tipo-cancelación.cancelación-flexible.text')}`,
      textSecondary: `${t(
        'tipo-cancelación.cancelación-flexible.textSecondary',
        { months: cancelationFlexMonths },
      )}`,
    },
    {
      type: 'estricta',
      title: `${t('tipo-cancelación.cancelación-estricta.tittle')}`,
      booking: `${t('tipo-cancelación.cancelación-estricta.subtitle')}`,
      icon: <EventBusyOutlined color="primary" />,
      text: `${t('tipo-cancelación.cancelación-estricta.text')}`,
      textSecondary: `${t(
        'tipo-cancelación.cancelación-estricta.textSecondary',
      )}`,
    },
  ];
  const cancelType = cancellation.filter(
    (polity) => polity.type === cancelacion,
  );
  return (
    <Box
      display="flex"
      flexDirection="column"
      padding="0 1rem"
      data-testid="cancelation"
    >
      {cancelType[0] ? (
        <>
          <Box display="flex" flexDirection="row">
            {cancelType[0].icon}
            <Grid container flexDirection="column" marginLeft="4px">
              <Typography
                variant="body1"
                fontWeight={600}
                position="relative"
                top="-4px"
              >
                {t(cancelType[0].title)}
              </Typography>
              <Typography
                variant="body1"
                marginBottom="12px"
                position="relative"
                top="-6px"
              >
                {cancelType[0].booking}
              </Typography>
            </Grid>
          </Box>
          <Box display="flex" width="100%" flexDirection="column">
            <Typography variant="body1" marginBottom="12px">
              {t(cancelType[0].text)}
            </Typography>
          </Box>
          {cancelType[0].textSecondary && (
            <Box display="flex" width="100%" flexDirection="column">
              <Typography variant="body1" marginBottom="12px">
                {t(cancelType[0].textSecondary)}
              </Typography>
            </Box>
          )}
        </>
      ) : (
        <Typography variant="body1" marginBottom="12px">
          {t('no-cancellation-policy')}
        </Typography>
      )}
    </Box>
  );
}

export default Cancellation;
