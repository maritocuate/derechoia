/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { styled } from '@mui/material';
import { Typography, IconWithText, Grid } from '@alquiler-argentina/demiurgo';
import LoginOutlinedIcon from '@mui/icons-material/LoginOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import { useTranslation } from 'next-i18next';
import useIsMobile from '../../../hooks/useIsMobile';

interface ICheckInCheckOut {
  checkinTime?: string | null;
  checkoutTime?: string | null;
}

interface ICheckInCheckOutEmptyState {
  message: string;
}

const StyledContainer = styled(Grid)`
  padding-inline: 1rem;
`;

const StyledIconWithText = styled(IconWithText)`
  font-weight: 700;
`;

const StyledTypography = styled(Typography)(
  ({ theme }) => `
  max-width: 296px;
  ${theme.breakpoints.up('md')} {
    max-width: initial;
  };
`,
);

function CheckInCheckOutEmptyState({ message }: ICheckInCheckOutEmptyState) {
  return (
    <StyledContainer container direction="column">
      <Grid item>
        <StyledTypography variant="body1">{message}</StyledTypography>
      </Grid>
    </StyledContainer>
  );
}

function CheckInCheckOut({ checkinTime, checkoutTime }: ICheckInCheckOut) {
  const { t } = useTranslation('TermsAndConditions');
  const isMobile = useIsMobile();

  if (!checkinTime && !checkoutTime) {
    return (
      <CheckInCheckOutEmptyState
        message={t('check-in-check-out.empty-state-message')}
      />
    );
  }

  return (
    <StyledContainer
      container
      direction={isMobile ? 'column' : 'row'}
      rowSpacing={isMobile ? 4 : 0}
      data-testid="checkTime"
    >
      <Grid item container direction="column" rowSpacing={1.5} xs={3.9}>
        <Grid item>
          <StyledIconWithText
            anchor="left"
            icon={<LoginOutlinedIcon color="primary" />}
          >
            {t('check-in-check-out.check-in')}
          </StyledIconWithText>
        </Grid>
        <Grid item>
          <Typography variant="body1">
            {checkinTime
              ? `${checkinTime} hs`
              : t('check-in-check-out.inquiry')}
          </Typography>
        </Grid>
      </Grid>
      <Grid item container direction="column" rowSpacing={1.5} xs={3.9}>
        <Grid item>
          <StyledIconWithText
            anchor="left"
            icon={<LogoutOutlinedIcon color="primary" />}
          >
            {t('check-in-check-out.check-out')}
          </StyledIconWithText>
        </Grid>
        <Grid item>
          <Typography variant="body1">
            {checkoutTime
              ? `${checkoutTime} hs`
              : t('check-in-check-out.inquiry')}
          </Typography>
        </Grid>
      </Grid>
    </StyledContainer>
  );
}

export default CheckInCheckOut;
