import React from 'react';
import { Typography, IconWithText, List } from '@alquiler-argentina/demiurgo';
import { Box, styled } from '@mui/material';
import { useTranslation } from 'next-i18next';
import AccountBalanceOutlined from '@mui/icons-material/AccountBalanceOutlined';
import ConfirmationNumberOutlined from '@mui/icons-material/ConfirmationNumberOutlined';
import CreditCardOutlined from '@mui/icons-material/CreditCardOutlined';
import MonetizationOnOutlined from '@mui/icons-material/MonetizationOnOutlined';

interface IPaymentProps {
  cash?: boolean;
  bankTransfer?: boolean;
  creditCard?: boolean;
  coupon?: boolean;
  promotionText?: string | null;
  es_troya?: boolean;
}
interface IPaymentContent {
  id?: number;
  text: string;
  icon: JSX.Element;
}

const StyledBox = styled(Box)`
  display: flex;
  flex-direction: column;
  position: relative;
  top: -1rem;
`;

const StyledTypography = styled(Typography)`
  font-family: 'Plus Jakarta Sans';
`;

function Payment({
  cash,
  bankTransfer,
  creditCard,
  coupon,
  promotionText,
  es_troya,
}: IPaymentProps) {
  const { t } = useTranslation('TermsAndConditions');
  const formasDePago: IPaymentContent[] = [
    {
      id: 0,
      text: t('pago.efectivo'),
      icon: <MonetizationOnOutlined color="primary" />,
    },
    {
      id: 1,
      text: `${t('pago.transferencia-bancaria')}`,
      icon: <AccountBalanceOutlined color="primary" />,
    },
    {
      id: 2,
      text: `${t('pago.tarjeta-de-credito-o-debito')}`,
      icon: <CreditCardOutlined color="primary" />,
    },
    {
      id: 3,
      text: `${t('pago.cupon-de-pago')}`,
      icon: <ConfirmationNumberOutlined color="primary" />,
    },
  ];
  const availablePayment: IPaymentContent[] = [
    cash,
    bankTransfer,
    creditCard,
    coupon,
  ].reduce((acc: IPaymentContent[], ele, index) => {
    if (ele) {
      acc.push({
        text: formasDePago[index].text,
        icon: formasDePago[index].icon,
      });
    }
    return acc;
  }, []);

  return (
    <StyledBox data-testid="payment">
      <List
        content={availablePayment.map(({ text, icon }) => ({
          primaryContent: (
            <Box marginBottom="0">
              <IconWithText anchor="left" icon={icon}>
                <StyledTypography variant="body1">
                  {t(`${text}`)}
                </StyledTypography>
              </IconWithText>
            </Box>
          ),
        }))}
      />
      {promotionText && !es_troya ? (
        <StyledTypography whiteSpace="pre-wrap" marginLeft={2} variant="body2">
          {promotionText}
        </StyledTypography>
      ) : null}
    </StyledBox>
  );
}

export default Payment;
