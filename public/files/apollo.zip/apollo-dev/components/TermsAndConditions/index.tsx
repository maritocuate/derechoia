import React from 'react';
import { Grid } from '@mui/material';

import { useTranslation } from 'next-i18next';

import Container from './Container';
import Terms from './Politics/Terms';
import Cancellation from './Politics/Cancellation';
import Rules from './Politics/Rules';
import Guarantee from './Politics/Guarantee';
import Payment from './Politics/Payment';
import { TRule } from '../../types/propiedades.types';
import CheckInCheckOut from './Politics/CheckInCheckOut';

export interface ITermsConditions {
  valorPagoAnticipado?: number;
  nights?: number;
  cancelacion?: string | 'gratis' | 'flexible' | 'estricta';
  cash?: boolean;
  bankTransfer?: boolean;
  creditCard?: boolean;
  coupon?: boolean;
  acepta_familias?: TRule;
  acepta_parejas?: TRule;
  acepta_grupo_jovenes?: TRule;
  apto_niños?: TRule;
  apto_bebes?: TRule;
  acepta_mascotas?: TRule;
  apto_movilidad_reducida?: TRule;
  permite_fumar?: TRule;
  permite_hacer_fiestas?: TRule;
  permite_recibir_visitas?: TRule;
  permite_musica?: TRule;
  garantia?: number;
  a_reintegrar?: boolean;
  valor_a_reintegrar?: string;
  datos_tarjeta?: boolean;
  foto_dni?: boolean;
  presentar_documento?: boolean;
  firma_contrato?: boolean;
  promotionText?: string | null;
  antelacion?: number;
  hora_ingreso?: string | null;
  hora_egreso?: string | null;
  cancelationFlexMonths?: number | null;
  cancelationFreeDays?: number | null;
  es_troya?: boolean;
}

function TermsAndConditions({
  valorPagoAnticipado,
  nights,
  cancelacion,
  cash,
  bankTransfer,
  creditCard,
  coupon,
  acepta_familias,
  acepta_parejas,
  acepta_grupo_jovenes,
  apto_niños,
  apto_bebes,
  acepta_mascotas,
  apto_movilidad_reducida,
  permite_fumar,
  permite_hacer_fiestas,
  permite_recibir_visitas,
  permite_musica,
  garantia,
  a_reintegrar,
  valor_a_reintegrar,
  datos_tarjeta,
  foto_dni,
  presentar_documento,
  firma_contrato,
  promotionText,
  antelacion,
  hora_ingreso,
  hora_egreso,
  cancelationFlexMonths,
  cancelationFreeDays,
  es_troya,
}: ITermsConditions) {
  const { t } = useTranslation('TermsAndConditions');
  return (
    <Grid item container>
      <Container title={t('Condiciones de la reserva')} divider>
        <Terms
          nights={nights}
          valorPagoAnticipado={valorPagoAnticipado}
          antelacion={antelacion}
        />
      </Container>
      <Container title={t('Política de cancelación')} divider>
        <Cancellation
          cancelationFlexMonths={cancelationFlexMonths}
          cancelationFreeDays={cancelationFreeDays}
          cancelacion={cancelacion}
        />
      </Container>
      <Container title={t('Normas del alojamiento')} divider>
        <Rules
          permite_musica={permite_musica}
          acepta_familias={acepta_familias}
          permite_hacer_fiestas={permite_hacer_fiestas}
          permite_recibir_visitas={permite_recibir_visitas}
          apto_movilidad_reducida={apto_movilidad_reducida}
          acepta_parejas={acepta_parejas}
          acepta_grupo_jovenes={acepta_grupo_jovenes}
          acepta_mascotas={acepta_mascotas}
          permite_fumar={permite_fumar}
          apto_niños={apto_niños}
          apto_bebes={apto_bebes}
        />
      </Container>
      <Container title={t('check-in-check-out.title')} divider>
        <CheckInCheckOut
          checkinTime={hora_ingreso}
          checkoutTime={hora_egreso}
        />
      </Container>
      <Container
        title={t('politica-de-garantia')}
        divider={cash || bankTransfer || coupon || creditCard}
      >
        <Guarantee
          garantia={garantia}
          a_reintegrar={a_reintegrar}
          valor_a_reintegrar={valor_a_reintegrar}
          datos_tarjeta={datos_tarjeta}
          foto_dni={foto_dni}
          presentar_documento={presentar_documento}
          firma_contrato={firma_contrato}
        />
      </Container>
      {cash || bankTransfer || coupon || creditCard ? (
        <Container title={t('formas-de-pago')}>
          <Payment
            cash={cash}
            bankTransfer={bankTransfer}
            creditCard={creditCard}
            coupon={coupon}
            promotionText={promotionText}
            es_troya={es_troya}
          />
        </Container>
      ) : null}
    </Grid>
  );
}

export default TermsAndConditions;
