/* eslint-disable @typescript-eslint/indent */
import React, { ChangeEvent, useState } from 'react';
import { Grid, IconWithText, Input } from '@alquiler-argentina/demiurgo';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import ContactMailOutlinedIcon from '@mui/icons-material/ContactMailOutlined';
import {
  FormControl,
  MenuItem,
  Typography,
  styled,
  useMediaQuery,
  useTheme,
} from '@mui/material';
import emailValidator from '../../utils/helpers/emailValidator';
import countries from '../CheckoutSiro/countries';
import passportValidator from '../../utils/helpers/passportValidator';
import { isValidInternationalPhoneNumber } from '../../utils/helpers/isValidInternationalPhoneNumber';

interface IUserFormDiscount {
  datosPersonales: {
    nombre: string;
    apellido: string;
    tipo_identificacion: string | null;
    identificacion: string | number | null;
    nombre_pais: string | null;
    idPais?: number;
    email: string;
    telefono: string | null;
    additionalComment?: string | null;
  };
  inputError: {
    nombre: boolean | string;
    apellido: boolean | string;
    identificacion: boolean | string;
    telefono: boolean | string;
    email: boolean | string;
    tipoIdentificacion: boolean | string;
  };
  dispatchOnChange: ({
    field,
    value,
  }: {
    field: string;
    value: string;
  }) => void;
  dispatchSetError: ({
    field,
    value,
  }: {
    field: string;
    value: boolean;
  }) => void;
}
export const StyledContainer = styled(Grid)(
  ({ theme }) => `
  padding-top: 1rem;
  ${theme.breakpoints.up('sm')} {
    max-width: 44.5rem;
    background-color: #ffffff;
    margin-inline-end: 1rem;
  }
`,
);

const StyledSection = styled(Grid)(
  ({ theme }) => `
  padding-inline: 1rem;
  padding-block-start: 1.5rem;
  padding-block-end: 1.3rem;
  background-color: #ffffff;
  border-radius: 0.5rem;
  padding-left: 0;
  ${theme.breakpoints.up('sm')} {
    padding-block-end: 2rem;
  }
`,
);
const StyledTitle = styled(Grid)`
  margin-block-end: 1rem;
`;

export const StyledInputNumber = styled(Input)(
  ({ theme }) => `
  & input::-webkit-outer-spin-button,
  & input::-webkit-inner-spin-button {
    display: none;
  }
  & input[type='number'] {
    moz-appearance: textfield;
  }
  ${theme.breakpoints.up('lg')} {
    width: 18rem;
    margin-left: 0.75rem;
    background-color: white;
  }
`,
);

const StyledIconWithText = styled(IconWithText)`
  font-size: 1.25rem;
  font-weight: 700;
  & svg {
    fill: #00bcd4;
    width: 1.6rem;
    height: 1.6rem;
    margin-inline-end: 0.3125rem;
  }
`;

const StyledInput = styled(Input)(
  ({ theme }) => `
  background: white;
  ${theme.breakpoints.up('sm')} {
    width: 25rem;
  }
`,
);

const StyledHelpertText = styled(Typography)`
  max-width: 25rem;
  color: #ef6b6b;
  font-size: 0.75rem;
  font-weight: 400;
  margin: 0.188rem 0.875rem;
`;

export const StyledInputPhone = styled(Input)(
  ({ theme }) => `
  & input::-webkit-outer-spin-button, & input::-webkit-inner-spin-button {
    display: none;
  }
  & input[type=number] {
    moz-appearance: textfield;
  };
  background: white;
  ${theme.breakpoints.up('sm')} {
    width: 25rem;
  };
`,
);

export const StyledInputDNI = styled(Input)(
  ({ theme }) => `
  background: white;
  ${theme.breakpoints.up('sm')} {
    width: 6.25rem;
  }
`,
);

const StyledSubtitle = styled(Typography)`
  font-size: 0.875rem;
  color: #00000099;
  margin-bottom: 0.5rem;
`;

export const StyledFormControl = styled(FormControl)(
  ({ theme }) => `
  background: white;
  ${theme.breakpoints.up('sm')} {
    width: 6.25rem;
  }
`,
);

export default function UserFormDiscount({
  datosPersonales,
  inputError,
  dispatchOnChange,
  dispatchSetError,
}: IUserFormDiscount) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const {
    nombre,
    apellido,
    tipo_identificacion: tipoIdentificacion,
    identificacion,
    idPais,
    email,
    telefono,
  } = datosPersonales;
  const {
    nombre: nameError,
    apellido: lastnameError,
    identificacion: idError,
    telefono: phoneError,
    tipoIdentificacion: tipoIdentificacionError,
    email: emailError,
  } = inputError;

  const [inputWidth, setInputWidth] = useState('auto');

  const handleMenuOpen = () => {
    const inputElement = document.getElementById('country');
    if (inputElement) {
      setInputWidth(`${inputElement.offsetWidth}px`);
    }
  };

  const handleOnChange = (event: ChangeEvent<HTMLInputElement>) => {
    const regex = /^[a-zA-Z\s\u00C0-\u00FF´]*$/;

    if (event.target.name === 'nombre' || event.target.name === 'apellido') {
      if (!regex.test(event.target.value)) return;
    }
    dispatchOnChange({
      field: event.target.name,
      value: event.target.value,
    });
  };

  const handleValidationId = () => {
    if (tipoIdentificacion === 'DNI') {
      dispatchSetError({
        field: 'identificacion',
        value: Number(identificacion) < 1000000,
      });
    } else {
      dispatchSetError({
        field: 'identificacion',
        value: !passportValidator(identificacion as string),
      });
    }
  };
  const isValidPhone = isValidInternationalPhoneNumber(
    telefono && telefono.length > 2 ? telefono : '000',
    idPais || 1,
  );
  const handleOnClick = () => {
    dispatchOnChange({
      field: 'identificacion',
      value: '',
    });
  };
  return (
    <StyledContainer container direction="column" gap={2}>
      <StyledSection item container direction="column">
        <StyledTitle gap="0.2rem" item container direction="column">
          <Grid item>
            <StyledIconWithText
              anchor="left"
              icon={<PersonOutlineOutlinedIcon />}
            >
              Datos del titular
            </StyledIconWithText>
          </Grid>
          <Grid item>
            <StyledSubtitle variant="body2">
              Todos los campos son requeridos
            </StyledSubtitle>
          </Grid>
        </StyledTitle>
        <Grid item container direction="column" rowSpacing={1.5}>
          <Grid item>
            <StyledInput
              fullWidth={isMobile}
              label="Nombre"
              type="text"
              name="nombre"
              error={!!nameError}
              value={nombre}
              onChange={handleOnChange}
              onBlur={(e) => {
                dispatchSetError({
                  field: e.target.name,
                  value: nombre.length < 2,
                });
              }}
              onFocus={() => {
                dispatchSetError({
                  field: 'nombre',
                  value: false,
                });
              }}
              data-testid="inputName"
            >
              {nombre}
            </StyledInput>
            {!!nameError && <StyledHelpertText>{nameError}</StyledHelpertText>}
          </Grid>
          <Grid item>
            <StyledInput
              fullWidth={isMobile}
              label="Apellido"
              type="text"
              name="apellido"
              value={apellido}
              error={!!lastnameError}
              onChange={handleOnChange}
              onBlur={(e) => {
                dispatchSetError({
                  field: e.target.name,
                  value: apellido.length < 2,
                });
              }}
              onFocus={() => {
                dispatchSetError({
                  field: 'apellido',
                  value: false,
                });
              }}
              data-testid="inputSubname"
            >
              {apellido}
            </StyledInput>
          </Grid>
          {!!lastnameError && (
            <StyledHelpertText>{lastnameError}</StyledHelpertText>
          )}
          <Grid item>
            <Grid container spacing={isMobile ? 2 : 0} direction="row">
              <Grid item xs={isMobile ? 5 : 'auto'}>
                <StyledFormControl fullWidth={isMobile}>
                  <StyledInputDNI
                    select
                    label="Tipo"
                    variant="outlined"
                    name="tipo_identificacion"
                    id="id-type"
                    error={tipoIdentificacionError === true}
                    value={tipoIdentificacion}
                    defaultValue={tipoIdentificacion}
                    onChange={handleOnChange}
                    onBlur={() => {
                      dispatchSetError({
                        field: 'tipoIdentificacion',
                        value: !tipoIdentificacion,
                      });
                    }}
                    onFocus={() => {
                      dispatchSetError({
                        field: 'tipoIdentificacion',
                        value: false,
                      });
                    }}
                    data-testid="inputIDType"
                  >
                    <MenuItem value="DNI" onClick={handleOnClick}>
                      DNI
                    </MenuItem>
                    <MenuItem value="Pasaporte" onClick={handleOnClick}>
                      Número de pasaporte
                    </MenuItem>
                  </StyledInputDNI>
                </StyledFormControl>
              </Grid>
              <Grid
                item
                xs={isMobile ? 7 : 'auto'}
                width={isMobile ? 'auto' : '18.75rem'}
              >
                <StyledInputNumber
                  fullWidth={isMobile}
                  label="Número documento"
                  type={tipoIdentificacion === 'DNI' ? 'number' : 'text'}
                  name="identificacion"
                  error={!!idError}
                  value={identificacion}
                  onChange={handleOnChange}
                  onBlur={handleValidationId}
                  onFocus={() => {
                    dispatchSetError({
                      field: 'identificacion',
                      value: false,
                    });
                  }}
                  data-testid="inputID"
                >
                  {identificacion}
                </StyledInputNumber>
                {!!idError && <StyledHelpertText>{idError}</StyledHelpertText>}
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <FormControl fullWidth>
              <StyledInput
                select
                variant="outlined"
                id="country"
                defaultValue={1}
                label="País de residencia"
                value={idPais}
                onMouseDown={handleMenuOpen}
                data-testid="inputCountry"
                SelectProps={{
                  MenuProps: {
                    PaperProps: {
                      style: {
                        maxHeight: 200,
                        width: inputWidth,
                        marginTop: '0.5rem',
                        left: '1.9375rem',
                        overflowY: 'auto',
                      },
                    },
                  },
                }}
              >
                {countries.map((data) => (
                  <MenuItem
                    sx={{ width: '100%' }}
                    value={data.id}
                    onClick={() =>
                      dispatchOnChange({ field: 'idPais', value: data.id })
                    }
                    key={data.id}
                  >
                    {data.pais}
                  </MenuItem>
                ))}
              </StyledInput>
            </FormControl>
          </Grid>
        </Grid>
      </StyledSection>
      <StyledSection item container direction="column">
        <StyledTitle item container gap="0.2rem" direction="column">
          <Grid item>
            <StyledIconWithText
              anchor="left"
              icon={<ContactMailOutlinedIcon />}
            >
              Información de contacto
            </StyledIconWithText>
          </Grid>
          <Grid item>
            <StyledSubtitle variant="body2">
              Todos los campos son requeridos
            </StyledSubtitle>
          </Grid>
        </StyledTitle>
        <Grid item container direction="column" spacing={1.5}>
          <Grid item>
            <StyledInputPhone
              fullWidth={isMobile}
              error={!!phoneError}
              label="Número de telefóno"
              type="number"
              value={telefono}
              name="telefono"
              onChange={handleOnChange}
              onBlur={(e) => {
                dispatchSetError({
                  field: e.target.name,
                  value: !isValidPhone,
                });
              }}
              onFocus={() => {
                dispatchSetError({
                  field: 'telefono',
                  value: false,
                });
              }}
              data-testid="inputPhone"
            >
              {telefono}
            </StyledInputPhone>
          </Grid>
          <Grid item>
            <StyledInput
              fullWidth={isMobile}
              label="Correo electrónico"
              type="email"
              error={!!emailError}
              value={email}
              inputProps={{ style: { textTransform: 'lowercase' } }}
              name="email"
              onChange={handleOnChange}
              onBlur={(e) => {
                dispatchSetError({
                  field: e.target.name,
                  value: !emailValidator(email),
                });
              }}
              onFocus={() => {
                dispatchSetError({
                  field: 'email',
                  value: false,
                });
              }}
              data-testid="inputEmail"
            >
              {email}
            </StyledInput>
            {!!emailError && (
              <StyledHelpertText>{emailError}</StyledHelpertText>
            )}
          </Grid>
        </Grid>
      </StyledSection>
    </StyledContainer>
  );
}
