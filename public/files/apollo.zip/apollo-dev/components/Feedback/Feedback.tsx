import React, { useState } from 'react';
import { Box, IconButton, Typography } from '@mui/material';
import {
  ThumbDownAlt,
  ThumbDownOffAlt,
  ThumbUpAlt,
  ThumbUpOffAlt,
} from '@mui/icons-material';

interface IFeedback {
  initialValue: boolean | null;
  text: string;
  callback: (value: boolean) => void;
}

const Feedback = ({ initialValue, text, callback }: IFeedback) => {
  const [valoration, setValoration] = useState(initialValue);
  const handleThumbUp = () => {
    setValoration(true);
    callback(true);
  };
  const handleThumbDown = () => {
    setValoration(false);
    callback(false);
  };
  return (
    <Box>
      <Box display="flex" flexDirection="row" alignItems="center">
        <Typography
          variant="titleSeMoreDestinationMobile"
          marginRight="1.5rem"
          data-testid="feedbackText"
        >
          {text}
        </Typography>
        <Box data-testid="iconsContainer">
          <IconButton
            aria-label="thumbs up"
            color="primary"
            onClick={handleThumbUp}
            size="large"
            data-testid="thumbUpIcon"
          >
            {valoration ? (
              <ThumbUpAlt fontSize="inherit" />
            ) : (
              <ThumbUpOffAlt fontSize="inherit" />
            )}
          </IconButton>
          <IconButton
            aria-label="thumbs down"
            color="primary"
            onClick={handleThumbDown}
            size="large"
            data-testid="thumbDownIcon"
          >
            {!valoration && valoration !== null ? (
              <ThumbDownAlt fontSize="inherit" />
            ) : (
              <ThumbDownOffAlt fontSize="inherit" />
            )}
          </IconButton>
        </Box>
      </Box>
    </Box>
  );
};

export default Feedback;
