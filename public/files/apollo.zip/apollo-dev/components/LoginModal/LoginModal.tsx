import React, { useState } from 'react';
import { Box, Dialog, styled } from '@mui/material';
import { useDispatch } from 'react-redux';
import { AUTH_VIEWS } from '../../constants/login/authViews';
import AuthContainer from '../../layout/login/containers/AuthContainer';
import { closeLoginModal } from '../../redux/appStatus/slice';
import useIsMobile from '../../hooks/useIsMobile';

const StyledModal = styled(Dialog)`
  display: flex;
  align-items: center;
  justify-content: center;
  & .MuiDialog-container {
    width: 100%;
  }
`;

const StyledBox = styled(Box)`
  border-radius: 0.3rem;
  overflow: hidden;
  display: flex;
  align-items: center;
  background-color: #fff;
`;

const LoginModal = () => {
  const [activeView, setActiveView] = useState(AUTH_VIEWS.LOGIN_EMAIL);
  const dispatch = useDispatch();
  const isMobile = useIsMobile();
  return (
    <StyledModal scroll="body" open>
      <StyledBox
        minHeight={isMobile ? '100%' : '34.3rem'}
        width={isMobile ? '100%' : '25rem'}
      >
        <AuthContainer
          handleClose={() => {
            dispatch(closeLoginModal());
            setActiveView(AUTH_VIEWS.LOGIN_EMAIL);
          }}
          activeView={activeView}
          setActiveView={setActiveView}
        />
      </StyledBox>
    </StyledModal>
  );
};

export default LoginModal;
