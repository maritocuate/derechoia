/* eslint-disable @typescript-eslint/indent */
import {
  Card,
  FormControlLabel,
  styled,
  Grid,
  Typography,
} from '@mui/material';
import PortraitOutlinedIcon from '@mui/icons-material/PortraitOutlined';
import BedroomParentOutlinedIcon from '@mui/icons-material/BedroomParentOutlined';
import BathroomOutlinedIcon from '@mui/icons-material/BathroomOutlined';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import themeAA from '../../styles/theme';

interface IRadio {
  ischecked: number;
}

interface IImage {
  featuredimage: string;
}

interface ICard {
  ischecked: number;
  isblocked: number;
}

const localPalette = {
  gray: 'rgba(0, 0, 0, 0.6)',
  black: 'rgba(0, 0, 0, 0.87)',
  iconGray: 'rgba(0, 0, 0, 0.54)',
};

export const StyledCard = styled(Card)<ICard>(
  ({ ischecked, isblocked, theme }) => ` 
    border-radius: .5rem;
    border: ${
      ischecked && !isblocked
        ? `2px solid ${theme.palette.primary.main}`
        : '2px solid rgba(0, 0, 0, 0.23)'
    };
    min-height: 12.5em;
    filter: ${isblocked ? 'grayscale(.9)' : 'none'};
    ${theme.breakpoints.up('lg')} {
      display: flex;
      aling-items: center;
      flex-basis: 0;
    };
  `,
);

export const StyledGrid = styled(Grid)(
  ({ theme }) => `
    padding: 1rem;
    ${theme.breakpoints.down('lg')} {
      margin: 1.063rem;
      padding: 0;
      &:first-of-type {
        padding-inline-start: 0;
      };
    };
    ${theme.breakpoints.up('lg')} {
      &:first-of-type {
        display: block;
      };
    };
  `,
);

export const StyledImage = styled(Grid)<IImage>(
  ({ theme, featuredimage }) => `
    cursor: pointer;
    width: 10rem;
    min-height: 7.5rem;
    border-radius: .25rem;
    background-image: url(${featuredimage});
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    ${theme.breakpoints.down('lg')} {
      width: 6rem;
      maxHeight: 7.75rem;
    };
  `,
);

export const StyledTitle = styled(Typography)`
  cursor: pointer;
  font-size: 1em;
  font-weight: 600;
  text-decoration: underline;
  margin-right: 1rem;
`;

export const StyledIconWithText = styled(IconWithText)`
  color: ${localPalette.black};
  font-size: 0.875em;
  & .muilink-root {
    color: ${localPalette.black};
  }
  & svg {
    fill: ${localPalette.iconGray};
  }
`;

export const StyledIconWithTextDisabled = styled(IconWithText)`
  color: ${localPalette.iconGray};
  font-size: 0.875em;
  & .muilink-root {
    color: ${localPalette.iconGray};
  }
  & svg {
    fill: ${localPalette.iconGray};
  }
`;

export const StyledPortraitOutlinedIcon = styled(PortraitOutlinedIcon)`
  height: 1rem;
  width: 1rem;
`;

export const StyledBedroomParentOutlinedIcon = styled(
  BedroomParentOutlinedIcon,
)`
  height: 1rem;
  width: 1rem;
`;

export const StyledBathroomOutlinedIcon = styled(BathroomOutlinedIcon)`
  height: 1rem;
  width: 1rem;
`;

export const StyledPriceTag = styled(Typography)`
  font-size: 1.25em;
  white-space: nowrap;
`;

export const StyledDiscount = styled(Typography)`
  font-weight: 500;
  color: ${themeAA.palette.primary.main};
  font-size: 0.875em;
`;

export const StyledSavings = styled(StyledDiscount)`
  color: ${localPalette.gray};
  text-decoration: line-through;
`;

export const StyledSelector = styled(FormControlLabel)<IRadio>(
  ({ ischecked, theme }) => `
      & span {
        color: ${ischecked ? `${theme.palette.primary.main}` : 'initial'};
        font-weight: 600;
      }
      & span: {
        &:last-of-type {
          font-weight: 600;
          color: ${ischecked ? `${theme.palette.primary.main}` : 'initial'};
        };
      };
      ${theme.breakpoints.down('lg')} {
        display: flex;
        justify-content: flex-end;
        & span: {
          &:first-of-type {
            padding-block-start: 1rem;
            padding-block-end: .25rem;
          };
        };
      };
  `,
);

export const StyledAddition = styled(StyledDiscount)`
  color: ${localPalette.gray};
  position: relative;
  top: 2px;
`;
