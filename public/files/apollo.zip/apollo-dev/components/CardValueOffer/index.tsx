/* eslint-disable @typescript-eslint/indent */
/* eslint-disable arrow-body-style */
import React, { useState, BaseSyntheticEvent } from 'react';
import Image from 'next/legacy/image';
import { Grid, Divider, Radio, Skeleton, Typography } from '@mui/material';
import Tooltip from '@alquiler-argentina/demiurgo/components/Tooltip';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { useTranslation } from 'next-i18next';
import { useSelector } from 'react-redux';
import CancelOutlined from '@mui/icons-material/CancelOutlined';
import MonetizationOnOutlined from '@mui/icons-material/MonetizationOnOutlined';
import {
  StyledAddition,
  StyledCard,
  StyledDiscount,
  StyledGrid,
  StyledIconWithText,
  StyledPortraitOutlinedIcon,
  StyledBedroomParentOutlinedIcon,
  StyledBathroomOutlinedIcon,
  StyledTitle,
  StyledPriceTag,
  StyledSavings,
  StyledSelector,
  StyledIconWithTextDisabled,
} from './styles';
import calculateDateRange from '../../utils/helpers/calculateDateRange';
import ModalTipologia from '../ModalTipologia';
import { ICheckoutState } from '../../redux/checkout/types';
import imageLoader from '../../utils/helpers/imageLoaders/imageLoader';
import { IBlockMessage } from '../../utils/helpers/getBlockMessages';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import useIsMobile from '../../hooks/useIsMobile';
import NoPhotos from '../NoPhotos/NoPhotos';
import getDiscount from '../../utils/helpers/getDiscounts';

interface IImage {
  id: number;
  alt: string;
  src: string;
}
export interface ICardValueOfferInfo {
  featuredImage: string | null;
  title: string;
  utilities: {
    capacity: number;
    rooms: number;
    bathrooms: number;
  };
  offerInfo: { icon: OffertIconsKeys; text: string }[];
  dateRange?: string[];
  prices: {
    type: string;
    basePrice: number | null;
    discounts?: {
      [key: string]: { percentage: number };
    };
  };
  guests: number;
  blocked: IBlockMessage;
  legacyTypologyId: number | null;
  active?: boolean;
  cyberMondayDiscount?: number | null;
}

interface ICardValueOfferFunctions {
  descripcion?: string;
  fotos?: IImage[];
  setSelectUnity: (value: number | null) => void;
  setSelectDiscount: (value: number | null) => void;
  setSelectPrice: (value: number | null) => void;
  selected: boolean;
  isLoading: boolean;
}
const OFFERT_ICONS = {
  canceled: <CancelOutlined sx={{ width: '1rem', height: '1rem' }} />,
  monetized: <MonetizationOnOutlined sx={{ width: '1rem', height: '1rem' }} />,
} as const;

export type OffertIconsKeys = keyof typeof OFFERT_ICONS;

export default function CardValueOffer({
  featuredImage,
  offerInfo,
  title,
  dateRange,
  utilities,
  prices,
  guests,
  blocked,
  descripcion,
  fotos,
  legacyTypologyId,
  setSelectUnity,
  setSelectPrice,
  setSelectDiscount,
  selected,
  isLoading,
  active,
  cyberMondayDiscount,
}: ICardValueOfferInfo & ICardValueOfferFunctions) {
  const { t } = useTranslation('CardValueOffer');
  const isMobile = useIsMobile();
  const [isOpenModalTipology, setOpenViewModal] = useState(false);
  const handleClickTitle = () => {
    setOpenViewModal(true);
  };
  const handleClose = () => {
    setOpenViewModal(false);
  };

  // <-------------- Offer logic -------------->

  const { personas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );

  let bookedDays = 0;
  if (dateRange) {
    bookedDays = calculateDateRange(dateRange[0], dateRange[1]);
  }

  let discountPercentage: number | null = null;
  if (prices.discounts && personas) {
    discountPercentage =
      prices.discounts[personas]?.percentage !== 0
        ? // eslint-disable-next-line no-unsafe-optional-chaining
          prices.discounts[personas]?.percentage / 100
        : 0;
  }
  const cyberMondayDiscountDecimal =
    cyberMondayDiscount && bookedDays > 0 ? cyberMondayDiscount / 100 : 0;

  discountPercentage = (discountPercentage || 0) + cyberMondayDiscountDecimal;
  let savings: number | null = null;
  if (bookedDays > 0 && prices.basePrice && discountPercentage) {
    savings = Math.round(prices.basePrice * discountPercentage);
  }

  let totalAmount: number | null = null;
  if (
    prices.basePrice &&
    prices.discounts &&
    savings &&
    guests === personas &&
    prices.discounts[personas]
  ) {
    totalAmount = Math.round(prices.basePrice - savings);
  } else if (
    prices.basePrice &&
    prices.discounts &&
    prices.discounts[personas]
  ) {
    totalAmount = Math.round(prices.basePrice);
  }
  // <-------------- Offer logic -------------->
  if (isLoading) {
    return (
      <Skeleton
        animation="wave"
        width={isMobile ? 339 : 800}
        height={isMobile ? 344 : 235}
      />
    );
  }
  return (
    <StyledCard
      elevation={0}
      ischecked={selected ? 1 : 0}
      isblocked={blocked.estado || !active ? 1 : 0}
    >
      <Grid container direction={isMobile ? 'column' : 'row'}>
        <StyledGrid
          item
          container
          spacing={isMobile ? 1 : 0}
          direction={isMobile ? 'row' : 'column'}
          xs={isMobile ? 1 : 2.9}
          flexWrap="nowrap"
          width="100%"
        >
          {featuredImage ? (
            <Image
              loader={imageLoader}
              onClick={handleClickTitle}
              src={featuredImage}
              alt="Tipologia"
              width={160}
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              height="100%"
              objectFit="cover"
              style={{ borderRadius: '8px', cursor: 'pointer' }}
            />
          ) : (
            <NoPhotos />
          )}
          <Grid
            item
            container
            xs={9}
            spacing={isMobile ? 0.5 : 0}
            sx={{
              paddingBlockStart: '0.5rem',
            }}
          >
            {isMobile && (
              <Grid item sx={{ marginBlockEnd: '.5rem' }}>
                <StyledTitle
                  onClick={handleClickTitle}
                  color={blocked.estado || !active ? 'GrayText' : 'unset'}
                  variant="h2"
                >
                  {title}
                </StyledTitle>
              </Grid>
            )}
            <Grid
              item
              container
              direction="column"
              spacing={0.5}
              justifyContent="flex-end"
              sx={{ height: 'fit-content' }}
            >
              <Grid item>
                {blocked.estado || !active ? (
                  <StyledIconWithTextDisabled
                    icon={<StyledPortraitOutlinedIcon />}
                    anchor="left"
                  >
                    {t('capacity', {
                      capacity: utilities.capacity,
                      count: utilities.capacity,
                    })}
                  </StyledIconWithTextDisabled>
                ) : (
                  <StyledIconWithText
                    icon={<StyledPortraitOutlinedIcon />}
                    anchor="left"
                  >
                    {t('capacity', {
                      capacity: utilities.capacity,
                      count: utilities.capacity,
                    })}
                  </StyledIconWithText>
                )}
              </Grid>
              <Grid item>
                {blocked.estado || !active ? (
                  <StyledIconWithTextDisabled
                    icon={<StyledBedroomParentOutlinedIcon />}
                    anchor="left"
                  >
                    {utilities.rooms === 0 ? 'Monoambiente' : null}
                    {utilities.rooms === 1
                      ? t('rooms_one', { numOfRooms: utilities.rooms })
                      : null}
                    {utilities.rooms > 1
                      ? t('rooms_other', { numOfRooms: utilities.rooms })
                      : null}
                  </StyledIconWithTextDisabled>
                ) : (
                  <StyledIconWithText
                    icon={<StyledBedroomParentOutlinedIcon />}
                    anchor="left"
                  >
                    {utilities.rooms === 0 ? 'Monoambiente' : null}
                    {utilities.rooms === 1
                      ? t('rooms_one', { numOfRooms: utilities.rooms })
                      : null}
                    {utilities.rooms > 1
                      ? t('rooms_other', { numOfRooms: utilities.rooms })
                      : null}
                  </StyledIconWithText>
                )}
              </Grid>
              <Grid item>
                {blocked.estado || !active ? (
                  <StyledIconWithTextDisabled
                    icon={<StyledBathroomOutlinedIcon />}
                    anchor="left"
                  >
                    {t('bathrooms', {
                      numOfBathrooms: utilities.bathrooms,
                      count: utilities.bathrooms,
                    })}
                  </StyledIconWithTextDisabled>
                ) : (
                  <StyledIconWithText
                    icon={<StyledBathroomOutlinedIcon />}
                    anchor="left"
                  >
                    {t('bathrooms', {
                      numOfBathrooms: utilities.bathrooms,
                      count: utilities.bathrooms,
                    })}
                  </StyledIconWithText>
                )}
              </Grid>
            </Grid>
          </Grid>
        </StyledGrid>
        <Divider
          orientation={isMobile ? 'horizontal' : 'vertical'}
          flexItem={!isMobile}
        />
        <StyledGrid
          item
          container
          direction="column"
          gap={1.5}
          xs={isMobile ? 12 : 5.5}
        >
          {!isMobile && (
            <Grid item sx={{ marginBlockEnd: '.5rem' }}>
              <StyledTitle
                color={blocked.estado || !active ? 'GrayText' : 'unset'}
                variant="h2"
                style={{ cursor: 'pointer' }}
                onClick={handleClickTitle}
              >
                {title}
              </StyledTitle>
            </Grid>
          )}

          {(blocked.estado || !active) &&
            offerInfo.map(({ text, icon }) => (
              <StyledIconWithTextDisabled
                icon={OFFERT_ICONS[icon]}
                anchor="left"
                key={text}
              >
                {text}
              </StyledIconWithTextDisabled>
            ))}
          {!(blocked.estado || !active) &&
            offerInfo.map(({ text, icon }) => {
              return (
                <StyledIconWithText
                  icon={OFFERT_ICONS[icon]}
                  anchor="left"
                  key={text}
                >
                  {text}
                </StyledIconWithText>
              );
            })}
        </StyledGrid>
        <Divider
          orientation={isMobile ? 'horizontal' : 'vertical'}
          flexItem={!isMobile}
        />
        <StyledGrid
          item
          container
          xs={isMobile ? 12 : 3.5}
          onClick={() => {
            if (!blocked.estado) {
              setSelectUnity(legacyTypologyId);
              setSelectPrice(prices.basePrice);
              setSelectDiscount(
                prices.discounts && guests === personas
                  ? prices.discounts[guests]?.percentage
                  : 0,
              );
            }
            return undefined;
          }}
          sx={!blocked.estado && !isMobile ? { cursor: 'pointer' } : undefined}
        >
          <Grid
            item
            container
            xs={isMobile ? 6 : 12}
            direction="column"
            justifyContent={isMobile ? 'center' : 'none'}
          >
            {!!active && !blocked.estado && savings && guests === personas && (
              <StyledSavings>
                {formatPriceToArs(prices.basePrice || 0)}
              </StyledSavings>
            )}
            {blocked.estado && totalAmount && prices.basePrice && (
              <StyledDiscount>{formatPriceToArs(totalAmount)}</StyledDiscount>
            )}
            <Grid item container alignItems="center" gap={1}>
              <Grid
                item
                display="flex"
                justifyItems="center"
                alignItems="center"
                gap={1.5}
              >
                {!dateRange &&
                  prices.basePrice &&
                  totalAmount &&
                  !blocked.estado &&
                  !!active && (
                    <StyledAddition>{t('starting_price')}</StyledAddition>
                  )}
                <StyledPriceTag
                  color={blocked.estado || !active ? 'GrayText' : 'unset'}
                  sx={{
                    fontWeight: !blocked.estado && !totalAmount ? '500' : '600',
                  }}
                >
                  {blocked.estado || !active ? 'No disponible' : null}
                  {totalAmount &&
                  !dateRange &&
                  discountPercentage &&
                  !blocked.estado &&
                  active
                    ? `${formatPriceToArs(
                        totalAmount * (1 - discountPercentage) || 0,
                      )}`
                    : null}
                  {totalAmount &&
                  !discountPercentage &&
                  !dateRange &&
                  !blocked.estado &&
                  active
                    ? `$${formatPriceNoDiscount(totalAmount || 0)}`
                    : null}
                  {totalAmount &&
                  dateRange &&
                  discountPercentage &&
                  !blocked.estado &&
                  active
                    ? `${formatPriceToArs(totalAmount)}`
                    : null}
                  {totalAmount &&
                  dateRange &&
                  !discountPercentage &&
                  !blocked.estado &&
                  active
                    ? `$${formatPriceNoDiscount(totalAmount)}`
                    : null}
                  {!blocked.estado && !totalAmount && active
                    ? 'Precio a consultar'
                    : null}
                </StyledPriceTag>
                {!dateRange && !blocked.estado && totalAmount && !!active ? (
                  <Tooltip
                    variant="secondary"
                    placement="top"
                    arrow
                    title={t('tooltip')}
                    enterTouchDelay={isMobile ? 0 : 700}
                    leaveTouchDelay={isMobile ? 4000 : 0}
                    onClick={(event: BaseSyntheticEvent) => {
                      event.stopPropagation();
                    }}
                  >
                    <InfoOutlinedIcon />
                  </Tooltip>
                ) : null}
              </Grid>
              {!blocked.estado &&
              active &&
              bookedDays > 0 &&
              ((prices.discounts &&
                prices.discounts[guests] &&
                prices.discounts[guests].percentage !== 0) ||
                !!cyberMondayDiscount) &&
              guests === personas &&
              totalAmount ? (
                <StyledDiscount>
                  {getDiscount(prices, guests, cyberMondayDiscount)}% Off
                </StyledDiscount>
              ) : null}
            </Grid>

            {!blocked.estado && active ? (
              <Typography variant="body2">
                {!blocked.estado && active && totalAmount ? t('stay') : null}
                {t('people', {
                  guests: personas,
                  count: personas,
                })}
              </Typography>
            ) : (
              <Typography
                variant="body2"
                color="GrayText"
                width={isMobile ? '250px' : 'initial'}
              >
                {!active
                  ? 'El anuncio se encuentra inactivo'
                  : blocked.mensajeTipologia}
              </Typography>
            )}
          </Grid>
          {!blocked.estado && !!active && (
            <Grid item xs={isMobile ? 6 : 12} alignSelf="flex-end">
              <StyledSelector
                ischecked={selected ? 1 : 0}
                value={selected ? t('selected') : t('select')}
                control={
                  <Radio
                    checked={selected}
                    icon={<RadioButtonUncheckedIcon />}
                    checkedIcon={<CheckCircleIcon />}
                  />
                }
                label={selected ? t('selected') : t('select')}
                labelPlacement={isMobile ? 'bottom' : 'end'}
              />
            </Grid>
          )}
        </StyledGrid>
        {isOpenModalTipology && (
          <ModalTipologia
            bathAmount={utilities.bathrooms}
            isOpenModalTipology={isOpenModalTipology}
            handleClose={handleClose}
            imgsCarousel={fotos}
            hostName={title}
            roomAmount={utilities.rooms}
            peopleAmount={utilities.capacity}
            descriptionHost={descripcion}
          />
        )}
      </Grid>
    </StyledCard>
  );
}
