import { Box, Typography, styled } from '@mui/material';
import React from 'react';

interface IPostNumber {
  mainText: string;
  secondaryText: string;
}

const StyledContainer = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  text-align: center;
  justify-content: center;
  align-content: center;
  align-items: center;
  width: 100%;
  box-shadow: 0px 3px 14px 0px rgba(0, 0, 0, 0.12);
  border-radius: 0.5rem;
  padding: 1.5rem;
  background-color: #fff;
  ${theme.breakpoints.up('sm')}{
    width: 100%;
    max-width: 37.5rem;
    height: 14.5rem;
    padding: 2rem 1.5rem;
  }
`,
);

const StyledNumber = styled(Typography)(
  ({ theme }) => `
    font-family: "Plus Jakarta Sans";
    font-size: 3.75rem;
    line-height: 120%; 
    letter-spacing: -0.03125rem;
    ${theme.breakpoints.up('sm')}{
      font-family: "Plus Jakarta Sans";
      font-size: 4.375rem;
      font-style: normal;
      font-weight: 800;
      line-height: 116.7%;
      letter-spacing: -0.09375rem;
    }
  `,
);

const PostNumber = ({ mainText, secondaryText }: IPostNumber) => {
  return (
    <StyledContainer data-testid="post-number-container">
      <Box>
        <StyledNumber
          data-testid="post-number-main"
          variant="postNumber"
          fontWeight="bold"
        >
          {mainText}
        </StyledNumber>
      </Box>
      <Box>
        <Typography
          data-testid="post-number-secundary"
          variant="postNumberText"
        >
          {secondaryText}
        </Typography>
      </Box>
    </StyledContainer>
  );
};

export default PostNumber;
