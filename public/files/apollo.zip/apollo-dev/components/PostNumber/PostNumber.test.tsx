import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import PostNumber from './PostNumber';

const testData = {
  mainText: '+20',
  secondaryText: 'Visitas por año',
};

describe('PostNumber', () => {
  it('renders with main and secondary text', () => {
    render(
      <PostNumber
        mainText={testData.mainText}
        secondaryText={testData.secondaryText}
      />,
    );
    const container = screen.getByTestId('post-number-container');
    const mainNumber = screen.getByTestId('post-number-main');
    const secondaryText = screen.getByTestId('post-number-secundary');
    expect(container).toBeInTheDocument();
    expect(mainNumber).toHaveTextContent(testData.mainText);
    expect(secondaryText).toHaveTextContent(testData.secondaryText);
  });
});
