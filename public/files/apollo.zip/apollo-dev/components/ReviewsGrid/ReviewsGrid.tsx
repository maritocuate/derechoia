import React from 'react';
import { Box, styled } from '@mui/material';
import { Reviews } from '../../types/publicar.types';
import ReviewsGridCard from '../ReviewsGridCard/ReviewsGridCard';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin: 4rem 0;
    ${theme.breakpoints.up('md')} {
        justify-content: space-between;
    }`,
);

interface ReviewsGridProps {
  reviews: Reviews[];
}

export default function ReviewsGrid({ reviews }: ReviewsGridProps) {
  return (
    <StyledContainer>
      {reviews &&
        reviews.map((review, index) => (
          <ReviewsGridCard key={index} userReview={review} />
        ))}
    </StyledContainer>
  );
}
