import React from 'react';
import Link from 'next/link';
import { Box, Button, Typography, styled } from '@mui/material';
import EmptyStateActiveBookingsSVG from '../SVG/EmptyStateActiveBookingsSVG';

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    align-items: center;
    min-height: 22.5rem; 
    margin-bottom: 1.5rem; 
    gap: 0.5rem;
    padding: 0.5rem;
    text-align: center;
    ${theme.breakpoints.up('lg')}{
      min-height: 24.75rem;
      margin: 10rem auto;
      gap: 1rem;
    }
`,
);

const EmptyStateBookings = () => {
  return (
    <StyledContainer data-testid="ContainerEmptyState">
      <EmptyStateActiveBookingsSVG />
      <Typography variant="contentTitle" data-testid="TitleEmptyState">
        Tu lista de reservas está vacía
      </Typography>
      <Typography
        variant="modalText"
        data-testid="SubtitleEmptyState"
        marginBottom="0.5rem"
      >
        Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.
      </Typography>
      <Link href="/">
        <Button variant="contained" data-testid="ButtonEmptyState">
          <Typography variant="seeMoreAdsText" fontSize={15}>
            Realizar una búsqueda
          </Typography>
        </Button>
      </Link>
    </StyledContainer>
  );
};

export default EmptyStateBookings;
