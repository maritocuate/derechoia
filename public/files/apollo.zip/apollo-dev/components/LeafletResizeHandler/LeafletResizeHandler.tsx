import { useMap } from 'react-leaflet';

const LeafletResizeHandler = () => {
  const map = useMap();

  setTimeout(() => {
    map?.invalidateSize({
      pan: false,
    });
  }, 1000);

  return null;
};

export default LeafletResizeHandler;
