/* eslint-disable @typescript-eslint/indent */
import React, { memo, useCallback, useMemo } from 'react';
import { Grid, styled, useMediaQuery, useTheme } from '@mui/material';
import { useTranslation } from 'react-i18next';
import { Button, Typography } from '@alquiler-argentina/demiurgo';
import dynamic from 'next/dynamic';
import * as Sentry from '@sentry/nextjs';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import LodgingBadgeList from '../LodgingBadgeList/LodgingBadgeList';
import DescriptionAnuncio from '../DescriptionAnuncio';
import LodgingAmenities from '../LodgingAmenities/LodgingAmenities';
import Deals from '../Deals';
import { useGetPropiedadQuery } from '../../services/propiedades';
import useFormatAmenities from './hooks/useFormatAmenities';
import BookingTipologiesList from '../BookingTipologiesList/BookingTipologiesList';
import SummaryMobile from '../SummaryMobile/SummaryMobile';
import ValorationContainer from '../ValorationContainer';
import LocationAnuncio from '../LocationAnuncio';
import TosFicha from '../ToSFicha/TosFicha';
import useBookingSummaryDesktop from '../../hooks/alojamientos/useBookingSummaryDesktop';
import { IFichaSecondCharge } from '../../redux/ficha/types';
import { ICheckoutState } from '../../redux/checkout/types';
import groupBy from '../../utils/helpers/groupBy';
import { fillMountAndSenia } from '../../redux/checkout/slice';
import calculateRevenuePercentage from '../../utils/helpers/calculateRevenuePercentage';
import calculateDateRange from '../../utils/helpers/calculateDateRange';
import {
  sendBeginCheckoutSIRODataGTM,
  sendCheckoutSIRODataGTM,
} from '../../utils/helpers/sendDataGTM';
import determinateCheckoutRoute from '../../utils/helpers/determinateCheckoutRoute';
import HostProfileContainer from '../../containers/HostProfileContainer/HostProfileContainer';

const ChatFAQS = dynamic(() => import('../ChatFAQS/ChatFAQS'));

const StyledSubtitle = styled(Typography)`
  font-weight: 700;
  font-size: 24px;
`;

const StyledMobileContactButton = styled(Button)`
  margin: 0 auto;
  margin-block-start: 1.875rem;
  width: 100%;
  text-transform: none;
  font-weight: 600;
`;

const StyledClarification = styled(Typography)`
  margin-top: 0.5rem;
  margin-bottom: 1.5rem;
`;

const SHOW_FOMO = Math.random() > 0.5;

const LodgingData = ({
  referencia,
  testProperty,
  handleOpenCheckoutSic,
  vwoKey,
}: {
  referencia: string;
  testProperty?: boolean;
  handleOpenCheckoutSic: () => void;
  vwoKey: number;
}) => {
  const { t } = useTranslation('CheckoutSic');
  const theme = useTheme();
  const router = useRouter();
  const newHostProfile = router.query?.sm === 'v' || vwoKey === 2;
  const dispatch = useDispatch();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { data } = useGetPropiedadQuery(
    { referencia, test: testProperty },
    { skip: !referencia },
  );
  const {
    isAllBlocked,
    startDate,
    endDate,
    propiedades,
    bookingSenia,
    bookingCleaningFee,
    bookingOtherFee,
    selectedDiscount,
    bookingTitle,
    bookingIsSIRO,
  } = useBookingSummaryDesktop(referencia);

  const { selectedTipology } = useSelector(
    ({ fichaSecondCharge }: { fichaSecondCharge: IFichaSecondCharge }) =>
      fichaSecondCharge,
  );

  const { personas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );

  const prices = propiedades?.find((el) => el.id === selectedTipology?.id);
  const initialValue = 0;
  const subtotalPrice = prices?.precios.descuentos[personas - 1]
    ? prices?.precios.base.reduce(
        (acc, curr) => acc + curr.precio,
        initialValue,
      )
    : 0;
  const discount = selectedDiscount || 0;
  const totalDiscount = subtotalPrice ? subtotalPrice * (discount / 100) : 0;
  const detailPrice = groupBy(
    prices?.precios ? prices?.precios.base : [],
    'precio',
  );

  const auxDiscount = prices?.precios.descuentos.find(
    (el) => el.personas === personas,
  )?.descuento;
  const priceToMap = useMemo(
    () => (detailPrice ? Object.values(detailPrice) : []),
    [detailPrice],
  );
  const totalPrice = subtotalPrice
    ? Math.round(
        (bookingCleaningFee || 0) +
          (bookingOtherFee || 0) +
          subtotalPrice -
          totalDiscount,
      )
    : 0;
  const seniaTotal = bookingSenia ? totalPrice * (bookingSenia / 100) : 0;
  const arrangedStartDate = startDate?.split('/').reverse().join('-');
  const arrangedEndDate = endDate?.split('/').reverse().join('-');
  const nextRoute = determinateCheckoutRoute(
    discount,
    SHOW_FOMO,
    testProperty || false,
  );

  const handleGTMTrigger = useCallback(
    (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
      e.preventDefault();

      const totalPriceRounded = auxDiscount
        ? Math.round(totalPrice / 100) * 100
        : totalPrice;

      const payload = {
        monto: totalPriceRounded,
        senia: seniaTotal,
        precioBase: subtotalPrice,
        descuento: discount,
        detallePrecio: priceToMap as [],
        isImmediate:
          !!data?.aceptacion_inmediata || data?.cm_integrated != null,
      };
      dispatch(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        fillMountAndSenia(payload),
      );

      if (
        referencia &&
        bookingTitle &&
        arrangedStartDate &&
        arrangedEndDate &&
        payload.monto
      ) {
        const revenuePercentage = calculateRevenuePercentage(
          data?.es_destacado,
          data?.es_destacado_gold,
        );
        const revenue = !bookingIsSIRO ? 0 : payload.monto * revenuePercentage;
        const tax = revenue - revenue / 1.21;

        const beginCheckoutData = {
          reference: referencia,
          title: bookingTitle,
          currency: 'ARS',
          stay: calculateDateRange(arrangedStartDate, arrangedEndDate),
          revenueWithTax: revenue + tax,
          tax,
          revenue,
        };

        sendCheckoutSIRODataGTM({ referencia, titulo: bookingTitle }, 1);
        sendBeginCheckoutSIRODataGTM(beginCheckoutData);
      }
      router
        .push(nextRoute)
        .then(() => {})
        .catch((error) => {
          Sentry.captureException(error);
        });
    },
    [
      auxDiscount,
      totalPrice,
      seniaTotal,
      subtotalPrice,
      discount,
      priceToMap,
      data?.aceptacion_inmediata,
      data?.cm_integrated,
      data?.es_destacado_gold,
      data?.es_destacado,
      dispatch,
      referencia,
      bookingTitle,
      arrangedStartDate,
      arrangedEndDate,
      router,
      nextRoute,
      bookingIsSIRO,
    ],
  );
  const { amenities, dataAmenities } = useFormatAmenities({
    amenities: data?.agregados,
  });
  return (
    <Grid
      item
      container
      xs={!isMobile ? 8 : 12}
      component="article"
      rowSpacing={8}
      maxWidth={isMobile ? '600px' : '1200px'}
      marginBottom={isMobile ? 1 : 0}
    >
      <Grid item container rowSpacing={5}>
        <Grid item container xs={12} component="article">
          {data?.formatedData?.badgeList &&
            data?.formatedData?.badgeList?.length > 0 && (
              <LodgingBadgeList
                badgesListkeys={data?.formatedData?.badgeList}
              />
            )}
        </Grid>
        {data?.formatedData?.description && (
          <Grid item xs={12} component="article">
            <DescriptionAnuncio descripcion={data?.formatedData?.description} />
          </Grid>
        )}
        {data?.formatedData?.hostProfile && (
          <Grid item xs={12} component="article">
            <HostProfileContainer
              reference={data?.formatedData?.hostProfile?.reference}
              name={data?.formatedData?.hostProfile?.name}
              profilePhoto={data?.formatedData?.hostProfile?.profilePhoto}
              clientAntiquity={
                data?.formatedData?.hostProfile?.clientAntiquity || 0
              }
              maxSpeedOfAction={
                data?.formatedData?.hostProfile?.maxSpeedOfAction || false
              }
              maxConfirmedPercentage={
                data?.formatedData?.hostProfile?.maxConfirmedPercentage || false
              }
              newHostProfile={newHostProfile}
            />
          </Grid>
        )}
      </Grid>
      <Grid item xs={12} component="article">
        <LodgingAmenities amenities={amenities} dataAmenities={dataAmenities} />
      </Grid>
      {data?.formatedData?.offerts?.hasOfferts && (
        <Grid item container gap={3}>
          <Grid item xs={12}>
            <StyledSubtitle variant="h2">Ofertas imperdibles</StyledSubtitle>
            <StyledClarification variant="body1" whiteSpace="pre-wrap">
              Tené en cuenta que el precio no se verá reflejado en la
              plataforma. Para acceder a la oferta, deberás contactarte con el
              anfitrión.
            </StyledClarification>
          </Grid>
          <Grid item xs={12}>
            <Deals
              itemsLastMinute={data?.formatedData?.offerts?.lastMinute}
              itemsStayFlexible={data?.formatedData?.offerts?.flex}
            />
          </Grid>
        </Grid>
      )}
      <Grid item container gap={3}>
        {isMobile && (
          <Grid item container>
            <SummaryMobile referencia={referencia} />
          </Grid>
        )}
        <Grid item>
          <BookingTipologiesList
            cyberMondayDiscount={data?.porcentaje_oferta}
          />
        </Grid>
      </Grid>

      {!!(
        isMobile &&
        !data?.es_troya &&
        data?.permite_reservas &&
        data?.activa
      ) && (
        <StyledMobileContactButton
          variant="outlined"
          size="large"
          onClick={handleOpenCheckoutSic}
          disabled={isAllBlocked}
        >
          {t('title')}
        </StyledMobileContactButton>
      )}

      {!!(
        isMobile &&
        !!data?.es_troya &&
        startDate &&
        endDate &&
        data?.activa &&
        !isAllBlocked &&
        router.query?.sm === 'a'
      ) && (
        <ChatFAQS
          reference={referencia}
          handleReserve={handleGTMTrigger}
          price={totalPrice}
        />
      )}

      {!!data?.comentarios && (
        <Grid item xs={12} id="valoraciones">
          <ValorationContainer
            valorationTotal={Number(data?.puntaje)}
            ratingsData={data?.comentarios}
            hostName={data?.nombre_contacto}
            valorationsIA={data?.valoration_resume_ia}
            refID={data?.id_propiedad_legacy}
          />
        </Grid>
      )}
      <Grid item xs={12}>
        <LocationAnuncio
          mapProps={{
            lat: data?.lat ? data?.lat : 0,
            long: data?.lng ? data?.lng : 0,
          }}
          reference={data?.referencia ? data?.referencia : ''}
          ubication={`${
            data?.nombre_provincia ? data?.nombre_provincia : ''
          }, ${data?.nombre_localidad ? data?.nombre_localidad : ''}`}
        />
      </Grid>
      <Grid item container>
        <TosFicha referencia={referencia} />
      </Grid>
    </Grid>
  );
};

export default memo(LodgingData);
