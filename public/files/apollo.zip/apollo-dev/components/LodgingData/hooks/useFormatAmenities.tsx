/* eslint-disable arrow-body-style */
import React, { useMemo } from 'react';
import DirectionsCarFilledOutlinedIcon from '@mui/icons-material/DirectionsCarFilledOutlined';
import PoolIcon from '@mui/icons-material/Pool';
import WifiIcon from '@mui/icons-material/Wifi';
import OutdoorGrillOutlined from '@mui/icons-material/OutdoorGrillOutlined';
import DryCleaningOutlined from '@mui/icons-material/DryCleaningOutlined';
import ParkOutlined from '@mui/icons-material/ParkOutlined';
import FireplaceOutlined from '@mui/icons-material/FireplaceOutlined';
import KitchenOutlined from '@mui/icons-material/KitchenOutlined';
import LocalHotelOutlinedIcon from '@mui/icons-material/LocalHotelOutlined';
import PersonalVideoIcon from '@mui/icons-material/PersonalVideo';

import {
  IAgregados,
  AgregadosState,
  AgregadosTipos,
} from '../../../types/propiedades.types';
import CookingIcon from '../../../public/images/icons/CookingIcon';
import AirConditionIcon from '../../../public/images/icons/AirConditionIcon';

export interface IFormatedAmenity {
  icon: JSX.Element;
  text: string;
}

export interface IDataAmenity {
  status: AgregadosState;
  amenities: string;
  amenitiesType: AgregadosTipos;
}

const useFormatAmenities = ({
  amenities = [],
}: {
  amenities?: IAgregados[] | undefined;
}) => {
  const formatedData = useMemo(() => {
    const formatedAmenities: IFormatedAmenity[] = [];

    amenities.forEach((elem) => {
      if (elem.estado !== AgregadosState.DISPONIBLE) {
        return;
      }
      switch (elem.agregado) {
        case 'Cochera':
          formatedAmenities.push({
            icon: (
              <DirectionsCarFilledOutlinedIcon
                color="action"
                fontSize="large"
              />
            ),
            text: 'Cochera',
          });
          break;
        case 'Pileta':
          formatedAmenities.push({
            icon: <PoolIcon color="action" fontSize="large" />,
            text: 'Pileta',
          });
          break;
        case 'Internet':
          formatedAmenities.push({
            icon: <WifiIcon color="action" fontSize="large" />,
            text: 'Wi-Fi',
          });
          break;
        case 'Ropa De Cama':
          formatedAmenities.push({
            icon: <LocalHotelOutlinedIcon color="action" fontSize="large" />,
            text: 'Ropa de cama',
          });
          break;
        case 'Televisión':
          formatedAmenities.push({
            icon: <PersonalVideoIcon color="action" fontSize="large" />,
            text: 'Televisión',
          });
          break;
        case 'Asador':
          formatedAmenities.push({
            icon: <OutdoorGrillOutlined color="action" fontSize="large" />,
            text: 'Asador',
          });
          break;
        case 'Ropa Blanca':
          formatedAmenities.push({
            icon: <DryCleaningOutlined color="action" fontSize="large" />,
            text: 'Ropa Blanca',
          });
          break;
        case 'Parque':
          formatedAmenities.push({
            icon: <ParkOutlined color="action" fontSize="large" />,
            text: 'Parque',
          });
          break;
        case 'Calefacción':
          formatedAmenities.push({
            icon: <FireplaceOutlined color="action" fontSize="large" />,
            text: 'Calefacción',
          });
          break;
        case 'Heladera':
          formatedAmenities.push({
            icon: <KitchenOutlined color="action" fontSize="large" />,
            text: 'Heladera',
          });
          break;
        case 'Cocina':
          formatedAmenities.push({
            icon: <CookingIcon />,
            text: 'Cocina',
          });
          break;
        case 'Aire Acondicionado':
          formatedAmenities.push({
            icon: <AirConditionIcon />,
            text: 'Aire Acondicionado',
          });
          break;
        default:
          break;
      }
    });

    const dataAmenities: IDataAmenity[] =
      amenities.map((elem) => {
        return {
          status: elem.estado,
          amenities: elem.agregado,
          amenitiesType: elem.agregado_tipo,
          observacions: elem.observacion,
        };
      }) || [];

    return {
      amenities: formatedAmenities,
      dataAmenities,
    };
  }, [amenities]);
  return {
    ...formatedData,
  };
};

export default useFormatAmenities;
