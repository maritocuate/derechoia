import React from 'react';
import { Box, styled, Typography } from '@mui/material';
import useIsMobile from '../../hooks/useIsMobile';

interface BookingHeaderProps {
  title: string;
  location: string;
}

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1rem;
    ${theme.breakpoints.up('lg')}{
      gap: 0.7rem;
    }`,
);

const BookingHeader = ({ title, location }: BookingHeaderProps) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer>
      <Typography
        variant={isMobile ? 'bookingLoginTitle' : 'bannerTitle'}
        color="rgb(0, 0, 0, 0.87)"
      >
        {title}
      </Typography>
      <Typography variant={isMobile ? 'orderText' : 'textPostDesktop'}>
        {location}
      </Typography>
    </StyledContainer>
  );
};

export default BookingHeader;
