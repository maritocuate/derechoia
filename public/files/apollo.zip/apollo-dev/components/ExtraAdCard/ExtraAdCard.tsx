import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import Link from 'next/link';
import { IExtraCard } from '../../types/listado.type';
import useIsMobile from '../../hooks/useIsMobile';
import { useLoadingCardAdList } from '../../containers/CardAdContainer/Hook/useLoadingCardAdList/useLoadingCardAdList';
import HeaderExtraCard from './items/HeaderExtraCard';
import MainExtraCard from './items/MainExtraCard';
import FooterExtraCard from './items/FooterExtraCard';

const CardItem = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/CardItem'),
  { ssr: true },
);

function ExtraCardAd({
  noFav,
  title,
  location,
  lodgingType,
  capacity,
  image,
  valoration,
  adType,
  favorite,
  link,
  isLoadingFav,
  reference,
  precioMin,
  priceWithoutDiscount,
  cyberMondayDiscount,
  price,
  handleFavorite,
  setOpenModalFavorite,
}: IExtraCard) {
  const isMobile = useIsMobile();
  const { changeLoadingListToAd } = useLoadingCardAdList();
  const handleFavoriteAd = () => {
    if (handleFavorite) handleFavorite(reference, setOpenModalFavorite);
  };
  return (
    <Link
      href={link}
      target={isMobile ? '_top' : '_blank'}
      style={{
        WebkitTapHighlightColor: 'transparent',
        textDecoration: 'none',
        color: 'unset',
      }}
      onClick={() => {
        if (isMobile) changeLoadingListToAd(true);
      }}
    >
      <CardItem
        width={isMobile ? '17.5rem' : '17.938rem'}
        direction="column"
        bgcolor="white"
        firstComponent={
          <HeaderExtraCard
            image={image}
            handleFavorite={handleFavoriteAd}
            isFavorite={favorite || false}
            noFav={noFav}
            isFeatured={adType === 'Destacado'}
            isGold={adType === 'Gold'}
            isLoadingFav={isLoadingFav}
            cyberMonday={!!cyberMondayDiscount}
          />
        }
        secondComponent={
          <MainExtraCard
            title={title}
            subtitle={location}
            valoration={Number(valoration.value)}
            capacity={capacity}
            propertyType={lodgingType}
            amountReviews={valoration.amount}
          />
        }
        thirdComponent={
          <FooterExtraCard
            cyberMondayPercentage={cyberMondayDiscount}
            price={precioMin || price?.total}
            priceWithDiscount={priceWithoutDiscount || 0}
          />
        }
      />
    </Link>
  );
}
export default memo(ExtraCardAd);
