import { Box, styled, Button } from '@mui/material';
import React, { useMemo } from 'react';
import BookmarkBorder from '@mui/icons-material/BookmarkBorder';
import WorkspacePremium from '@mui/icons-material/WorkspacePremium';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import FavoriteOutlined from '@mui/icons-material/FavoriteOutlined';
import dynamic from 'next/dynamic';
import Image from 'next/image';
import useIsMobile from '../../../hooks/useIsMobile';
import FavoriteTooltip from '../../FavoriteTooltip';
import CyberMondayIcon from '../../CyberMondayIcon/CyberMondayIcon';

const IconWithText = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/IconWithText').then(
      (res) => res.default,
    ),
  { ssr: false },
);

const Icon = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/Icon').then(
      (res) => res.default,
    ),
  { ssr: false },
);

type AccommodationFlagsTypes = 'isFeatured' | 'isGold' | 'isFavorite';

type AccommodationFlags = Record<AccommodationFlagsTypes, boolean>;

export interface HeaderCardProps extends AccommodationFlags {
  image: string;
  isLoadingFav?: boolean;
  handleFavorite: () => void;
  noFav?: boolean;
  cyberMonday?: boolean;
}

const ButtonsContainer = styled(Box)`
  display: flex;
  gap: 0.5rem;
  z-index: 10;
`;

const StyledBoxFavorite = styled(Button)`
  background: rgba(255, 255, 255, 0.8);
  border-radius: 4px;
  min-width: 1.75rem;
  width: 1.75rem;
  height: 1.75rem;
  &:hover {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)),
      rgba(255, 255, 255, 0.8);
  }
`;

const StyledBadgeContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const StyledBadgeItem = styled(Box)`
  display: flex;
  width: fit-content;
  height: 1.75rem;
  background-color: #fafafa;
  padding: 0.125rem 0.5rem 0.125rem 0.375rem;
  border-radius: 4px;
  z-index: 10;
`;

const StyledImageContainer = styled(Box)`
  height: 12.188rem;
  position: relative;
  top: 0;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
`;

const StyledContainerAbsolute = styled(Box)`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  position: absolute;
  top: 0;
  padding: 0.5rem;
`;

const flagsList = [
  {
    children: 'Destacado',
    icon: <BookmarkBorder color="primary" fontSize="small" />,
  },
  {
    children: 'Gold',
    icon: <WorkspacePremium color="secondary" fontSize="small" />,
  },
  {
    children: 'Premium',
    icon: <Icon name="Crown" color="#EC5A5A" size="small" />,
  },
];

function HeaderExtraCard({
  isFeatured,
  isGold,
  isFavorite,
  isLoadingFav,
  handleFavorite,
  image,
  noFav,
  cyberMonday,
}: HeaderCardProps) {
  const isMobile = useIsMobile();
  const flags = useMemo(() => [isFeatured, isGold], [isFeatured, isGold]);
  return (
    <Box position="relative" width="100%">
      <StyledImageContainer>
        <Image
          style={{
            borderTopRightRadius: '0.5rem',
            borderTopLeftRadius: '0.5rem',
          }}
          src={`${image}?w=300&h=195`}
          width={isMobile ? 280 : 300}
          height={195}
          alt="image"
        />
      </StyledImageContainer>
      <StyledContainerAbsolute>
        <StyledBadgeContainer>
          {flags.map((flag, indexPosition) =>
            flag && !noFav ? (
              <StyledBadgeItem key={`badgeItem-${indexPosition}`}>
                <IconWithText
                  children={flagsList[indexPosition].children}
                  icon={flagsList[indexPosition].icon}
                  anchor="left"
                />
              </StyledBadgeItem>
            ) : null,
          )}
        </StyledBadgeContainer>
        {!noFav && (
          <ButtonsContainer
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
            }}
          >
            <FavoriteTooltip variant="list" isFavorite={isFavorite}>
              <StyledBoxFavorite
                onClick={!isLoadingFav ? handleFavorite : () => {}}
              >
                {isFavorite ? (
                  <FavoriteOutlined fontSize="small" color="primary" />
                ) : (
                  <FavoriteBorder
                    fontSize="small"
                    htmlColor="rgba(0, 0, 0, 0.8)"
                  />
                )}
              </StyledBoxFavorite>
            </FavoriteTooltip>
          </ButtonsContainer>
        )}
      </StyledContainerAbsolute>
      {cyberMonday && (
        <Box position="absolute" top={110} left={isMobile ? 180 : 190}>
          <CyberMondayIcon />
        </Box>
      )}
    </Box>
  );
}

export default HeaderExtraCard;
