import React, { useMemo } from 'react';
import { Box, styled, Typography } from '@mui/material';
import { formatPriceToArs } from '../../../utils/helpers/formatPriceToArs';
import BadgeCyberMonday from '../../CardAd/components/Footer/components/BadgeCyberMonday';

interface IFooterCard {
  priceWithDiscount?: number;
  price?: number | null;
  cyberMondayPercentage?: number | null;
}

const StyledCardContentPrice = styled(Box)(
  `
    &:last-child{
¿      width: 100%;
    }
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    position: relative;
  `,
);

const StyledPriceOut = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.6);
`;
const StyledSpanPriceOut = styled(Typography)`
  font-weight: 400;
  font-size: 0.84rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.6);
  text-decoration: line-through;
  margin-left: 0.3rem;
`;

const StyledPrice = styled(Typography)`
  font-weight: 700;
  font-size: 1.25rem;
  line-height: 1.563rem;
  color: rgba(0, 0, 0, 0.87);
  margin-bottom: 0.25rem;
`;

const StyledPerNight = styled(Typography)`
  font-weight: 400;
  font-size: 0.8rem;
  color: rgba(0, 0, 0, 0.87);
`;

const StyleBoxPrice = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: row;
    column-gap: 4px;
    align-items: baseline;
    ${theme.breakpoints.down(340)} {
      flex-direction: column;
    }
  `,
);

const FooterExtraCard = ({
  priceWithDiscount,
  price,
  cyberMondayPercentage,
}: IFooterCard) => {
  const priceWithDiscountFormatted = useMemo(() => {
    if (!priceWithDiscount) return '';
    return formatPriceToArs(priceWithDiscount);
  }, [priceWithDiscount]);

  const priceFormatted = useMemo(() => {
    if (!price) return '';
    return formatPriceToArs(price);
  }, [price]);
  return (
    <StyledCardContentPrice
      height="5.063rem"
      padding={cyberMondayPercentage ? '0.5rem 1rem' : '1rem'}
    >
      <Box>
        {!!priceFormatted && (
          <Box display="flex" alignItems="center">
            <StyledPriceOut variant="body2"> Desde </StyledPriceOut>
            {!!priceWithDiscount && (
              <StyledSpanPriceOut>
                {priceWithDiscountFormatted}
              </StyledSpanPriceOut>
            )}
            {!!cyberMondayPercentage && (
              <Box marginLeft="0.75rem">
                <BadgeCyberMonday discount={cyberMondayPercentage} />
              </Box>
            )}
          </Box>
        )}

        <StyleBoxPrice>
          <StyledPrice variant="body2">
            {price ? `${priceFormatted}` : 'Precio a consultar'}
          </StyledPrice>
          {!!price && (
            <StyledPerNight variant="body2">
              por noche, 2 personas
            </StyledPerNight>
          )}
        </StyleBoxPrice>
      </Box>
    </StyledCardContentPrice>
  );
};

export default FooterExtraCard;
