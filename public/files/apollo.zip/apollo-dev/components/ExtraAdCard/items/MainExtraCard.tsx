import { Box, styled, Typography } from '@mui/material';
import React from 'react';
import dynamic from 'next/dynamic';
import useIsMobile from '../../../hooks/useIsMobile';

const Valoraciones = dynamic(() =>
  import('@alquiler-argentina/demiurgo/components/Valoraciones').then(
    (res) => res.default,
  ),
);

interface IMainCard {
  title: string;
  subtitle: string;
  valoration: number;
  capacity: number;
  propertyType: string;
  amountReviews: number;
  reccommended?: boolean;
}

const StyledCardContentTitle = styled(Box)`
  display: flex;
  flex-direction: column;
  padding: 1rem;
`;

const StyledBoxValoration = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  margin-top: .5rem;
  ${theme.breakpoints.up('lg')} {
    margin-top: 0;

  }
`,
);

const StyledTitleFirst = styled(Typography)`
  font-weight: 600;
  font-size: 1rem;
  line-height: 1.5rem;
  color: rgba(0, 0, 0, 0.87);
  margin-bottom: 0.25rem;
`;
const StyledTitleSecond = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.87);
`;

const StyledTextAmountGuests = styled(Typography)`
  letter-spacing: 0.011rem;
  font-size: 0.875rem;
`;

const StyledValoraciones = styled(Valoraciones)`
  display: flex;
  margin-right: 0.313rem;
  align-items: flex-end;
  & p {
    display: flex;
    margin: 0;
    margin-block: 0;
    margin-inline: 0;
    font-weight: 700;
    height: 100%;
    font-size: 0.875rem;
  }
`;

const StyledBoxTitles = styled(Box)`
  margin-bottom: 0.25rem;
`;

const MainExtraCard = ({
  title,
  subtitle,
  valoration,
  capacity,
  amountReviews,
  reccommended,
  propertyType,
}: IMainCard) => {
  const isMobile = useIsMobile();
  return (
    <StyledCardContentTitle
      height="10rem"
      width={!isMobile && reccommended ? '19.0625rem' : '17.5rem'}
    >
      <StyledBoxTitles>
        <StyledTitleFirst variant="h3">{title}</StyledTitleFirst>
        <StyledTitleSecond variant="body2">{subtitle}</StyledTitleSecond>
      </StyledBoxTitles>
      <StyledBoxValoration>
        {valoration && amountReviews >= 3 ? (
          <Box display="flex" alignItems="flex-end" mb="0.25rem">
            <StyledValoraciones
              average={valoration}
              anchor="valoracionPromedio"
              children={0}
            />
            <Typography variant="body2" lineHeight="1.5" mb="0.001rem">
              · {amountReviews} valoraciones
            </Typography>
          </Box>
        ) : null}
        <Box gap={0.5} flexDirection="column" display="flex" alignItems="left">
          <StyledTextAmountGuests variant="h3" lineHeight="1.5">
            {`${propertyType} hasta ${capacity} personas`}
          </StyledTextAmountGuests>
        </Box>
      </StyledBoxValoration>
    </StyledCardContentTitle>
  );
};
export default MainExtraCard;
