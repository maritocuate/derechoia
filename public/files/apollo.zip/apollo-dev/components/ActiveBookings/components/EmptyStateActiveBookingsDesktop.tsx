import React from 'react';
import { Box, Button, Typography, styled } from '@mui/material';
import Link from 'next/link';
import EmptyStateActiveBookingsSVG from '../../SVG/EmptyStateActiveBookingsSVG';

const StyledContainer = styled(Box)`
  display: flex;
  max-width: 57.625rem;
`;

const StyledBox = styled(Box)`
  display: flex;
  flex-direction: column;
  max-width: 57.625rem;
  gap: 0.5rem;
  padding: 3rem 2rem;
`;

const StyledButton = styled(Button)`
  margin-top: 0.5rem;
  width: 13.375rem;
`;

const EmptyStateActiveBookingsDesktop = () => {
  return (
    <StyledContainer data-testid="ContainerEmptyState">
      <EmptyStateActiveBookingsSVG />
      <StyledBox>
        <Typography
          variant="contentTitle"
          paddingRight={8}
          data-testid="TitleEmptyState"
        >
          Tu lista de reservas activas está vacía
        </Typography>
        <Typography variant="modalText" data-testid="SubtitleEmptyState">
          Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.
        </Typography>
        <Link href="/">
          <StyledButton variant="contained" data-testid="ButtonEmptyState">
            <Typography variant="seeMoreAdsText" fontSize={15}>
              Realizar una búsqueda
            </Typography>
          </StyledButton>
        </Link>
      </StyledBox>
    </StyledContainer>
  );
};

export default EmptyStateActiveBookingsDesktop;
