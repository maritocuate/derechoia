import React from 'react';
import { Box, Button, Typography, styled } from '@mui/material';
import Link from 'next/link';

const StyledBox = styled(Box)`
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: 0.5rem;
  border: 1px solid #0000003b;
  border-radius: 0.5rem;
  padding: 1rem;
  margin-bottom: 1rem;
`;

const StyledButton = styled(Button)`
  margin-top: 0.5rem;
  width: 13.375rem;
`;

const EmptyStateActiveBookingsMobile = () => {
  return (
    <StyledBox data-testid="ContainerEmptyState">
      <Typography
        variant="textPostDesktop"
        paddingRight={8}
        data-testid="TitleEmptyState"
      >
        Tu lista de reservas activas está vacía
      </Typography>
      <Typography variant="modalText" data-testid="SubtitleEmptyState">
        Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.
      </Typography>
      <Link href="/">
        <StyledButton variant="contained" data-testid="ButtonEmptyState">
          <Typography variant="seeMoreAdsText" fontSize={15}>
            Realizar una búsqueda
          </Typography>
        </StyledButton>
      </Link>
    </StyledBox>
  );
};

export default EmptyStateActiveBookingsMobile;
