import React, { memo } from 'react';
import { Box, styled } from '@mui/material';
import { VistosList } from '../../types/vistos.type';
import ViewCard from '../ViewCard/ViewCard';
import { useGetFavoriteQuery } from '../../services/favorites';
import useUserSession from '../../hooks/userSession/useUserSession';

export interface ViewListProps {
  vistos: VistosList['data'];
  personas: number;
  changeFavorite: (referencia: string) => void;
}

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  width: fit-content;
  height: fit-content;
  gap: 2.2rem;
  width: 100%;
`;

const ViewList = ({
  vistos = [],
  personas = 1,
  changeFavorite,
}: ViewListProps) => {
  const {
    user: { email },
    isLogged,
  } = useUserSession();
  const { data: dataFav, isFetching } = useGetFavoriteQuery(email || '', {
    skip: !isLogged,
  });
  return (
    <StyledContainer>
      {vistos?.map((visto, key) => {
        const isFav =
          dataFav && isLogged ? !!dataFav[visto?.referencia] : false;
        return (
          <ViewCard
            isFav={isFav}
            key={key}
            cancelacion={visto?.cancelacion}
            cant_puntaje={Number(visto?.cant_puntaje)}
            capacidad_max={visto?.capacidad_max}
            cantidadUnidades={visto?.cantidadUnidades || 0}
            es_destacado={!!visto?.es_destacado}
            es_destacado_gold={!!visto?.es_destacado_gold}
            es_troya={!!visto?.es_troya}
            fecha_carga={visto?.fecha_carga}
            foto_listado={visto?.foto_listado}
            fotos={visto?.fotos || []}
            handleFavorite={changeFavorite}
            isLoadingFav={isFetching}
            link={visto?.link}
            nombre_localidad={visto?.nombre_localidad}
            ofertas_flexibles={visto?.ofertasFlexibles || []}
            ofertas_um={visto?.ofertas_um || []}
            personas={personas}
            precio_minimo_calculado={Number(visto?.precio_minimo_calculado)}
            puntaje={visto?.puntaje}
            referencia={visto.referencia}
            tipo={visto?.tipo}
            titulo={visto?.titulo}
            permite_reservas={visto?.permite_reservas}
            porcentaje_oferta={visto?.porcentaje_oferta}
            precio_sin_descuento={visto?.precio_sin_descuento}
          />
        );
      })}
    </StyledContainer>
  );
};

export default memo(ViewList);
