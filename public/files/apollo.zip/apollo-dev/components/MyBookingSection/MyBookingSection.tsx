import { Box, Typography, styled, Collapse, IconButton } from '@mui/material';
import React, { useState } from 'react';
import { IconWithText } from '@alquiler-argentina/demiurgo';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import CardMyBooking from '../CardMyBooking/CardMyBooking';
import { TMyBooking } from '../CardMyBooking/types';
import useIsMobile from '../../hooks/useIsMobile';

interface BookingSectionProps {
  title: string;
  bookingInfo: TMyBooking[];
  isCanceledSection?: boolean;
}

const StyledBox = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    gap: 1rem;
    margin-top: 3rem;
    margin-bottom: 2rem;
    ${theme.breakpoints.up('lg')}{
      width: 100%;
      gap: 1.5rem;
      margin-bottom: 2.5rem;
    }
`,
);

const StyledIconWithText = styled(IconWithText)`
  & .MuiTypography-root {
    font-weight: 700;
    cursor: pointer;
    color: rgba(0, 0, 0, 0.87);
    text-decoration: underline rgba(0, 0, 0, 0.87);
  }
`;

const StyledIconButton = styled(IconButton)`
  padding: 16px 0;
  border-radius: 8px;
  &: hover {
    background-color: transparent;
  }
`;

const MyBookingSection = ({
  bookingInfo,
  title,
  isCanceledSection,
}: BookingSectionProps) => {
  const isMobile = useIsMobile();
  const [showMore, setShowMore] = useState(false);

  const handleShowMore = () => {
    setShowMore(!showMore);
  };

  const visibleBookings = isCanceledSection
    ? bookingInfo.slice(0, 5)
    : bookingInfo;
  const collapsedBookings = isCanceledSection ? bookingInfo.slice(5) : [];

  return (
    <StyledBox>
      <Typography
        variant={isMobile ? 'bookingSectionTitleMobile' : 'bookingSectionTitle'}
      >
        {title}
      </Typography>
      {visibleBookings.map((props, index) => (
        <CardMyBooking {...props} key={`${index}${props.id}`} />
      ))}
      {isCanceledSection && collapsedBookings.length > 0 && (
        <>
          <Collapse in={showMore}>
            {collapsedBookings.map((info, index) => (
              <CardMyBooking
                {...info}
                key={`${index + 5}${info.id}`}
                props={{
                  style: { marginBottom: `${isMobile ? '1.5rem' : '1rem'}` },
                }}
              />
            ))}
          </Collapse>
          <StyledIconButton
            onClick={handleShowMore}
            style={{ justifyContent: 'flex-start' }}
            size="medium"
          >
            <StyledIconWithText
              anchor="right"
              icon={
                showMore ? (
                  <ExpandLess fontSize="small" />
                ) : (
                  <ExpandMore fontSize="small" />
                )
              }
            >
              <Typography>
                {showMore ? 'Mostrar menos' : 'Mostrar más'}
              </Typography>
            </StyledIconWithText>
          </StyledIconButton>
        </>
      )}
    </StyledBox>
  );
};

export default MyBookingSection;
