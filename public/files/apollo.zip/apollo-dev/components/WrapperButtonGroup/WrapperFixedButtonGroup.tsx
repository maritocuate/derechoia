import { Box, Divider, styled } from '@mui/material';
import React, { ReactNode } from 'react';

const StyledFixedContainerMobile = styled(Box)(
  ({ theme }) => `
      position: fixed;
      bottom: 1rem;
      display: flex;
      justify-content: space-evenly;
      width: calc(100vw - 2rem);
      max-width: 35.5rem;
      height: 2.625rem;
      padding: 0;
      align-items: center;
      background-color: ${theme.palette.primary.main};
      border-radius: 0.5rem;
      margin: 0 auto;
      z-index: 1000;
      .MuiButtonBase-root {
        color: #FFFFFF;
      }
    `,
);

const StyledDivider = styled(Divider)`
  background-color: #ffffff;
  width: 1px;
  height: 1.5rem;
`;

const StyledChildrenContainer = styled(Box)`
  display: flex;
  justify-content: center;
  padding: 0;
`;

const WrapperFixedButtonGroup = ({
  children,
  childrenWidth,
}: {
  children: ReactNode[];
  childrenWidth: number;
}) => {
  return (
    <Box display="flex" width="100%" padding="0 1rem">
      <StyledFixedContainerMobile>
        {children.map((child, index) => {
          return (
            <React.Fragment key={`${index}-mobileButtonGroups`}>
              <StyledChildrenContainer width={`${childrenWidth}%`}>
                {child}
              </StyledChildrenContainer>
              {index !== 2 && <StyledDivider orientation="vertical" />}
            </React.Fragment>
          );
        })}
      </StyledFixedContainerMobile>
    </Box>
  );
};

export default WrapperFixedButtonGroup;
