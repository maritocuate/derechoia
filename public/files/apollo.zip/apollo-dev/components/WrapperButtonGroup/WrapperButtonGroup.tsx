import { Box, BoxProps, Divider, styled } from '@mui/material';
import React, { ReactNode } from 'react';
import WrapperFixedButtonGroup from './WrapperFixedButtonGroup';

const StyledFilterContainerMobile = styled(Box)(
  ({ theme }) => `
    display: flex;
    justify-content: space-evenly;
    width: 100%;
    padding: 0;
    border: 1px solid;
    border-color: ${theme.palette.primary.main};
    border-radius: 0.25rem;
    margin: 1rem 0 1rem 0;
  `,
);

const StyledDivider = styled(Divider)(
  ({ theme }) => `
   background-color: ${theme.palette.primary.main};
  `,
);

const StyledChildrenContainer = styled(Box)`
  display: flex;
  justify-content: center;
  padding: 0;
`;

const WrapperButtonGroup = ({
  children,
  containerProps,
  isLocalityList,
}: {
  children: ReactNode | ReactNode[];
  containerProps?: BoxProps;
  isLocalityList?: boolean;
}) => {
  const isArray = Array.isArray(children);
  const childrenWidth = isArray ? 100 / children.length : 100;

  if (isArray && isLocalityList) {
    return (
      <WrapperFixedButtonGroup
        children={children}
        childrenWidth={childrenWidth}
      />
    );
  }

  return (
    <Box display="flex" width="100%" padding="0 1rem" {...containerProps}>
      <StyledFilterContainerMobile>
        {!isArray && children}
        {isArray &&
          children.map((child, index) => {
            return (
              <React.Fragment key={`${index}-mobileButtonGroups`}>
                {index !== 0 && <StyledDivider orientation="vertical" />}
                <StyledChildrenContainer width={`${childrenWidth}%`}>
                  {child}
                </StyledChildrenContainer>
              </React.Fragment>
            );
          })}
      </StyledFilterContainerMobile>
    </Box>
  );
};

export default WrapperButtonGroup;
