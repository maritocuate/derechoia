import { Box, styled } from '@mui/material';
import Image from 'next/image';
import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import { useCarousel } from './hooks/useCarousel';
import { Foto } from '../../types/listado.type';
import { ItemCarousel } from './components/ItemCarousel/ItemCarousel';
import imageLoaderCardAd from '../../utils/helpers/imageLoaders/imageLoaderCardAd';

const DotsContainer = dynamic(
  () => import('./components/DotsContainer/DotsContainer'),
  { ssr: false },
);

interface CarouselCardAdMobileProps {
  images: Foto[];
  referencia: string;
  priorityImage?: true;
}
const StyledContainerMaster = styled(Box)`
  position: relative;
  overflow: hidden;
  width: 100%;
  height: 200px;
`;

const StyledContainerChildren = styled(Box)`
  position: relative;
  flex: 0 0 100%;
  transition: transform 2s ease-in-out;
  height: 100%;
  width: 100%;
`;

const CarouselCardMobile = ({
  images,
  referencia,
  priorityImage,
}: CarouselCardAdMobileProps) => {
  const { handleTouchStart, handleTouchEnd, currentIndex, activate } =
    useCarousel(images.length);
  return (
    <StyledContainerMaster
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      <StyledContainerChildren>
        <ItemCarousel
          currentIndex={currentIndex}
          indexElement={0}
          lengthElements={images.length}
          key={`${referencia}-${images[0].nombreArchivo}${images[0].id}`}
        >
          <Image
            src={`${
              process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
            }_propiedades_/${referencia}/${images[0].nombreArchivo}`}
            alt={images[0].descripcion}
            placeholder="blur"
            loader={({ src }) => imageLoaderCardAd({ src, width: 320 })}
            style={{ objectFit: 'cover' }}
            blurDataURL={`${
              process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
            }_propiedades_/${referencia}/${images[0].nombreArchivo}`}
            priority={priorityImage ? true : undefined}
            sizes="100%"
            fill
          />
        </ItemCarousel>
        {activate &&
          images.slice(1).map((image, positionIndex, array) => (
            <ItemCarousel
              currentIndex={currentIndex}
              indexElement={positionIndex + 1}
              lengthElements={array.length}
              key={`${referencia}-${image.nombreArchivo}${image.id}`}
            >
              <Image
                src={`${
                  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
                }_propiedades_/${referencia}/${image.nombreArchivo}`}
                alt={image.descripcion}
                placeholder="blur"
                loader={({ src }) => imageLoaderCardAd({ src, width: 320 })}
                style={{ objectFit: 'cover' }}
                blurDataURL={`${
                  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
                }_propiedades_/${referencia}/${image.nombreArchivo}`}
                sizes="100%"
                fill
              />
            </ItemCarousel>
          ))}
        <DotsContainer itemsLength={images.length} itemActive={currentIndex} />
      </StyledContainerChildren>
    </StyledContainerMaster>
  );
};

export default memo(CarouselCardMobile);

// si un imagen está activa debe tener transformX(0)
// la anterior a dicha foto debe tener transformX(-100%)
// la siguiente a dicha foto debe tener transformX(100%)
// si la primera imagen está activa, la última tendra transformX(-100%)
// si la ultima imagen está activa, la primera tendra transformX(100%)
