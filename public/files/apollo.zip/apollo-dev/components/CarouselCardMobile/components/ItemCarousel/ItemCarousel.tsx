import React from 'react';
import { Box } from '@mui/material';
import applyStyleRules from '../../utils/helpers/applyStyleRules';

interface ItemCarouselProps extends React.HTMLAttributes<HTMLDivElement> {
  currentIndex: number;
  indexElement: number;
  lengthElements: number;
}

export const ItemCarousel = ({
  currentIndex,
  indexElement,
  lengthElements,
  children,
}: ItemCarouselProps) => {
  return (
    <Box
      width="100%"
      height="100%"
      sx={{
        display: 'none',
        position: 'absolute',
        flex: '0 0 100%',
        transition: 'transform 0.3s ease-in-out',
        ...applyStyleRules({ currentIndex, indexElement, lengthElements }),
      }}
    >
      {children}
    </Box>
  );
};

// si un imagen está activa debe tener transformX(0)
// la anterior a dicha foto debe tener transformX(-100%)
// la siguiente a dicha foto debe tener transformX(100%)
// si la primera imagen está activa, la última tendra transformX(-100%)
// si la ultima imagen está activa, la primera tendra transformX(100%)

// if currentIndex === indexElement => transformX(0)
// if currentIndex === indexElement + 1 => transformX(100%)
// if currentIndex === indexElement - 1 => transformX(-100%)

// if currentIndex === img.length - 1 => indexElement === 0 => transformX(+100%)
// if currentIndex ===  0 => indexElement === img.length - 1 => transformX(-100%)
