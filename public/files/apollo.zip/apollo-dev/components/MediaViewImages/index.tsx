/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import Image from 'next/image';
import { Grid, Typography, Divider } from '@alquiler-argentina/demiurgo';
import { useTranslation } from 'next-i18next';
import {
  Tabs,
  Tab,
  styled,
  ImageList,
  ImageListItem,
  IconButton,
  DialogContent,
  Box,
  Dialog,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { StyledModalTitle, StyledModalTitleWrapper } from '../ModalNews';
import Slider, { IImg } from '../Slider';
import { calculateWidth } from '../../utils/helpers/mediaViewImages/calculateWidth';
import TabPanel from './components/TabPanel';
import useScreenWidth from '../../hooks/mediaViewImages/useScreenWidth';
import useIsMobile from '../../hooks/useIsMobile';

export interface IImage {
  img: string;
  alt: string;
  loading: 'lazy';
}

interface IMediaViewPropsForImages {
  imagelist: IImage[];
}

export interface IImagesTypology {
  src: string;
  alt: string;
}

export interface IPhotosTypology {
  title: string;
  fotos: IImg[];
}

interface IMediaViewImages extends IMediaViewPropsForImages {
  featuredImage?: string;
  video?: string;
  iframe?: string;
  openViewImage: boolean;
  imagesTypologys?: IPhotosTypology[];
  setOpenViewImage: (value: boolean) => void;
  open: boolean;
  setOpen: (value: boolean) => void;
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export const StyledContainer = styled(Dialog)(
  ({ theme }) => `
  margin-inline: -0.5rem;
  z-index: 10000;
  ${theme.breakpoints.up('lg')} {
    margin-inline: 0;
    & .MuiPaper-root {
      height: 880px;
    }
  }
`,
);

const StyledIFrame360 = styled('iframe')(
  ({ theme }) => `
    height: 80vh;
    border-radius: 8px;
    cursor:pointer;
  ${theme.breakpoints.up('sm')}{
    height: 400px;
  }
`,
);
const StyledIFrameVideo = styled('iframe')(`
    border-radius: 8px;
`);

const StyledImageList = styled(ImageList)(
  ({ theme }) => `
  margin-block-start: 0.5rem;
${theme.breakpoints.up('sm')}{
  width: 100%;
  place-items: center;
  cursor: pointer;
  margin-block-start: 8px;
}
`,
);

const StyledImageTypologies = styled(Grid)(
  ({ theme }) => `
${theme.breakpoints.up('sm')}{
  width: 100%;
  place-items: center;
}
`,
);

const StyledTypography = styled(Typography)`
  text-transform: none;
`;

const StyledTypographyTypology = styled(Typography)`
  text-transform: none;
  margin-top: 1rem;
`;
const StyledGrid = styled(Grid)`
  cursor: pointer;
`;
const StyledGridNotTab = styled(Grid)`
  cursor: pointer;
  flex-direction: column;
  padding: 1rem;
  &::after {
    content: '';
    display: flex;
    width: 100%;
    height: 1rem;
    position: sticky;
    bottom: 0;
    background: white;
  }
`;
const StyledContentWrapper = styled(DialogContent)`
  padding: 0;
  overflow-x: hidden;
`;

const StyledModalTitleWrapperMediaViewImages = styled(StyledModalTitleWrapper)`
  padding: 16px;
  padding-inline: 24px;
`;

const StyledTabPanel = styled(TabPanel)(
  ({ theme }) => `
  padding: 8px;
  padding-inline: 1rem;
  padding-block-end: 0px;
  ${theme.breakpoints.up('lg')} {
    padding: 1.5625rem;
    padding-block-end: 0px;
  }
`,
);

const StyledBottomEdge = styled(Grid)(
  ({ theme }) => `
  height: 8px;
  background: white;
  position: sticky;
  bottom: 0;
  ${theme.breakpoints.up('sm')} {
    height: 16px;
  }
`,
);

const StyledImage = styled(Image)`
  border-radius: 8px;
  object-fit: cover;
`;

export default function MediaViewImages({
  video,
  iframe,
  imagelist,
  openViewImage,
  setOpenViewImage,
  featuredImage,
  imagesTypologys,
  open,
  setOpen,
}: IMediaViewImages) {
  const isDesktop = !useIsMobile();
  const { t } = useTranslation('MediaViewImages');
  const [value, setValue] = React.useState(0);
  const [active, setActive] = React.useState(0);
  const [imagesTypo, setImagesTypo] = React.useState<IImg[] | undefined>(
    undefined,
  );
  const screenWidth = useScreenWidth();
  const gridImagesWidth = (screenWidth - 24) / 2;
  const gridImagesHeight = gridImagesWidth * 0.7;

  const [arrayAllImgs, setArrayAllImgs] = React.useState<IImg[]>([
    {
      src: '',
      loading: 'lazy',
      alt: '',
    },
  ]);

  // images
  const imageNotRepeat = [
    { img: featuredImage || '', loading: 'lazy', alt: '' },
    ...imagelist,
  ].filter(
    (imgElemnt, index, self) =>
      index === self.findIndex((el) => !!el.img && el.img === imgElemnt.img),
  );

  const images: IImg[] = imageNotRepeat.map((el) => ({
    src: el.img,
    loading: 'lazy',
    alt: el.alt,
  }));
  React.useEffect(() => {
    if (imagesTypologys !== undefined) {
      setArrayAllImgs(imagesTypologys.map((el) => el.fotos).flat());
    }
  }, [imagesTypologys]);

  const handleCloseSlider = () => {
    setOpen(!open);
    setImagesTypo(undefined);
  };

  const handleClose = () => {
    setOpenViewImage(false);
    // Without the timeout, you can see the tabs automatically change before closing the modal
    setTimeout(() => {
      setValue(0);
    }, 300);
  };

  const handleCloseModal = (_: React.SyntheticEvent, rason: string) => {
    if (rason === 'escapeKeyDown') return;
    handleClose();
  };

  const handleChange = (_: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <>
      {open && (
        <Slider
          open={open}
          imagesList={
            imagesTypo === undefined ? images.concat(arrayAllImgs) : imagesTypo
          }
          handleCloseSlider={handleCloseSlider}
          active={active}
        />
      )}

      <StyledContainer
        open={openViewImage}
        PaperProps={isDesktop ? { sx: { maxWidth: '880px' } } : undefined}
        onClose={handleCloseModal}
        fullScreen={!isDesktop}
      >
        <StyledModalTitleWrapperMediaViewImages variant="h6">
          <StyledModalTitle>{t('title')}</StyledModalTitle>
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </StyledModalTitleWrapperMediaViewImages>
        <Divider />
        <StyledContentWrapper>
          <Grid container height="700px">
            {!iframe && !video ? (
              <StyledGridNotTab>
                <Box
                  display="flex"
                  paddingBottom={images.length === 1 ? '1rem' : undefined}
                  columnGap=".5rem"
                >
                  {!!featuredImage && (
                    <Box
                      display="flex"
                      onClick={() => {
                        setOpen(true);
                        setActive(0);
                      }}
                    >
                      <StyledImage
                        src={featuredImage}
                        alt={`photo${featuredImage}`}
                        width={calculateWidth(
                          isDesktop,
                          images.length,
                          screenWidth,
                        )}
                        height={isDesktop ? 400 : screenWidth * 0.6}
                      />
                    </Box>
                  )}
                  {isDesktop && images.length >= 3 && (
                    <Box
                      display="flex"
                      flexDirection="column"
                      justifyContent="space-between"
                      rowGap=".5rem"
                    >
                      <StyledImage
                        src={images[1].src}
                        width={isDesktop ? 269 : gridImagesWidth}
                        height={isDesktop ? 196 : gridImagesHeight}
                        alt={`photo${images[1].src}`}
                        onClick={() => {
                          setOpen(true);
                          setActive(1);
                        }}
                      />
                      <StyledImage
                        src={images[2].src}
                        width={isDesktop ? 269 : gridImagesWidth}
                        height={isDesktop ? 196 : gridImagesHeight}
                        alt={`photo${images[2].src}`}
                        onClick={() => {
                          setOpen(true);
                          setActive(2);
                        }}
                      />
                    </Box>
                  )}
                </Box>

                {images.length > 3 && (
                  <StyledImageList
                    cols={isDesktop ? 3 : 2}
                    onClick={() => setOpen(true)}
                    gap={8}
                  >
                    {images.slice(isDesktop ? 3 : 1).map((item, index) => (
                      <ImageListItem key={`img-${index}`}>
                        <StyledImage
                          src={item.src}
                          width={isDesktop ? 269 : gridImagesWidth}
                          height={isDesktop ? 196 : gridImagesHeight}
                          alt={item.alt}
                          onClick={() => {
                            setActive(index + 3);
                          }}
                        />
                      </ImageListItem>
                    ))}
                  </StyledImageList>
                )}
                {imagesTypologys?.map(
                  (item, index) =>
                    !!item.fotos?.length && (
                      <StyledImageTypologies item key={index}>
                        <StyledTypographyTypology variant="body1">
                          {item.title}
                        </StyledTypographyTypology>
                        <StyledImageList cols={isDesktop ? 3 : 2} gap={8}>
                          {item.fotos.map((itemFoto, innerIndex) => (
                            <ImageListItem
                              key={innerIndex}
                              onClick={() => {
                                setImagesTypo(item.fotos);
                                setOpen(true);
                                setActive(innerIndex);
                              }}
                            >
                              <StyledImage
                                src={itemFoto.src}
                                alt={itemFoto.alt}
                                width={isDesktop ? 269 : gridImagesWidth}
                                height={isDesktop ? 196 : gridImagesHeight}
                              />
                            </ImageListItem>
                          ))}
                        </StyledImageList>
                      </StyledImageTypologies>
                    ),
                )}
              </StyledGridNotTab>
            ) : (
              <Grid item container>
                <Grid item xs={12}>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="media-tab"
                    sx={
                      !isDesktop
                        ? { paddingLeft: '1rem', marginLeft: '.5rem' }
                        : null
                    }
                  >
                    <Tab
                      label={
                        <StyledTypography>{t('pictures')}</StyledTypography>
                      }
                      {...a11yProps(0)}
                    />
                    {video && (
                      <Tab
                        label={
                          <StyledTypography>{t('videos')}</StyledTypography>
                        }
                        {...a11yProps(1)}
                      />
                    )}
                    {iframe && (
                      <Tab
                        label={<StyledTypography>360°</StyledTypography>}
                        {...a11yProps(2)}
                      />
                    )}
                  </Tabs>
                </Grid>
                {value === 0 && (
                  <StyledTabPanel value={value} index={0}>
                    <StyledGrid container justifyContent="center">
                      <Box
                        display="flex"
                        justifyContent="center"
                        width="100%"
                        columnGap=".5rem"
                      >
                        {!!featuredImage && (
                          <Box
                            display="flex"
                            onClick={() => {
                              setActive(() => 0);
                              setOpen(true);
                            }}
                          >
                            <StyledImage
                              src={featuredImage}
                              alt={`photo${featuredImage}`}
                              width={calculateWidth(
                                isDesktop,
                                images.length,
                                screenWidth,
                              )}
                              height={isDesktop ? 400 : screenWidth * 0.6}
                            />
                          </Box>
                        )}
                        {isDesktop && images.length >= 3 && (
                          <Box
                            display="flex"
                            flexDirection="column"
                            justifyContent="space-between"
                            rowGap=".5rem"
                          >
                            <StyledImage
                              src={images[1].src}
                              alt={`photo${images[1].src}`}
                              width={269}
                              height={196}
                              onClick={() => {
                                setOpen(true);
                                setActive(1);
                              }}
                            />
                            <StyledImage
                              src={images[2].src}
                              alt={`photo${images[2].src}`}
                              width={269}
                              height={196}
                              onClick={() => {
                                setOpen(true);
                                setActive(2);
                              }}
                            />
                          </Box>
                        )}
                      </Box>

                      <StyledImageList
                        cols={isDesktop ? 3 : 2}
                        onClick={() => setOpen(true)}
                        gap={8}
                      >
                        {images.slice(isDesktop ? 3 : 1).map((item, index) => (
                          <ImageListItem key={`img-${index}`}>
                            <StyledImage
                              src={item.src}
                              width={isDesktop ? 269 : gridImagesWidth}
                              height={isDesktop ? 196 : gridImagesHeight}
                              alt={item.alt}
                              onClick={() => {
                                setActive(index + 3);
                              }}
                            />
                          </ImageListItem>
                        ))}
                      </StyledImageList>
                      {imagesTypologys?.map(
                        (item, index) =>
                          !!item.fotos.length && (
                            <StyledImageTypologies item key={index}>
                              <StyledTypography
                                marginLeft={isDesktop ? '1rem' : ''}
                                variant="body1"
                              >
                                {item.title}
                              </StyledTypography>
                              <StyledImageList gap={8} cols={isDesktop ? 3 : 2}>
                                {item.fotos.map((itemFoto, innerIndex) => (
                                  <ImageListItem
                                    key={innerIndex}
                                    onClick={() => {
                                      setImagesTypo(() => item.fotos);
                                      setActive(() => innerIndex);
                                      setOpen(true);
                                    }}
                                  >
                                    <StyledImage
                                      src={itemFoto.src}
                                      width={isDesktop ? 269 : gridImagesWidth}
                                      height={
                                        isDesktop ? 196 : gridImagesHeight
                                      }
                                      alt={itemFoto.alt}
                                    />
                                  </ImageListItem>
                                ))}
                              </StyledImageList>
                            </StyledImageTypologies>
                          ),
                      )}
                    </StyledGrid>
                    <StyledBottomEdge item />
                  </StyledTabPanel>
                )}
                {video && value === 1 && (
                  <StyledTabPanel
                    sx={{
                      height: '544px',
                      display: 'flex',
                      alignItems: 'center',
                    }}
                    value={value}
                    index={1}
                  >
                    <Box display="flex" height="100%" alignItems="center">
                      <StyledIFrameVideo
                        width={isDesktop ? '848px' : '100%'}
                        height="400"
                        src={video}
                        frameBorder="0"
                        allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="Video"
                      />
                    </Box>
                    <StyledBottomEdge item />
                  </StyledTabPanel>
                )}
                {iframe && (value === 2 || value === 1) && (
                  <StyledTabPanel value={value} index={!video ? 1 : 2}>
                    <ImageList sx={{ marginBlock: 0, width: '100%' }}>
                      <ImageListItem
                        sx={{
                          width: isDesktop ? '100%' : '95vw',
                        }}
                      >
                        <StyledIFrame360
                          allowFullScreen
                          width={isDesktop ? '848px' : '100%'}
                          src={iframe}
                          frameBorder="0"
                          title="360"
                        />
                      </ImageListItem>
                    </ImageList>
                    <StyledBottomEdge item />
                  </StyledTabPanel>
                )}
              </Grid>
            )}
          </Grid>
        </StyledContentWrapper>
      </StyledContainer>
    </>
  );
}
