import React, { useState } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import { Collapse, Grid, styled, IconButton, Typography } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { useTranslation } from 'next-i18next';

const StyledIconWithText = styled(IconWithText)`
  & .MuiTypography-root {
    font-weight: 700;
    cursor: pointer;
    color: rgba(0, 0, 0, 0.87);
    text-decoration: underline rgba(0, 0, 0, 0.87);
  }
`;

const StyledContainer = styled(Grid)`
  max-width: 1360px;
`;

const StyledExpandLessIcon = styled(ExpandLessIcon)`
  color: #000000;
`;

const StyledExpandMoreIcon = styled(ExpandMoreIcon)`
  color: #000000;
`;

const StyledDescription = styled(Typography)`
  font-family: 'Plus Jakarta Sans';
  overflow-wrap: break-word;
`;

const StyledTitle = styled(Typography)(
  ({ theme }) => `
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 16px;
  ${theme.breakpoints.down('sm')}{
    font-size: 20px;
  }
`,
);

const StyledIconButton = styled(IconButton)`
  padding: 16px 0;
  border-radius: 8px;
  &: hover {
    background-color: transparent;
  }
`;

interface Props {
  descripcion: string;
}

export default function DescriptionAnuncio({ descripcion }: Props) {
  const { t } = useTranslation('DescriptionAnuncio');
  const [collapse, setCollapse] = useState(false);
  const handleCollapse = () => {
    setCollapse(!collapse);
  };
  const toShow =
    descripcion.length > 238
      ? `${descripcion.substring(0, 238)}...`
      : descripcion;
  const paragraphs = collapse ? descripcion : toShow;
  return (
    <StyledContainer container flexDirection="column">
      <StyledTitle variant="h2">Sobre el alojamiento</StyledTitle>
      <Grid width="100%" item>
        <StyledDescription whiteSpace="pre-wrap" variant="body1">
          {paragraphs}
        </StyledDescription>
      </Grid>
      {descripcion.length > 238 && (
        <Grid width="100%" item>
          <Collapse in={collapse} orientation="vertical" />
          <StyledIconButton onClick={handleCollapse}>
            <StyledIconWithText
              anchor="right"
              icon={
                collapse ? <StyledExpandLessIcon /> : <StyledExpandMoreIcon />
              }
            >
              <StyledDescription>
                {collapse ? t('mostrar-menos') : t('mostrar-mas')}
              </StyledDescription>
            </StyledIconWithText>
          </StyledIconButton>
        </Grid>
      )}
    </StyledContainer>
  );
}
