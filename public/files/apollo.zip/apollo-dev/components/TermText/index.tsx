import React from 'react';
import { Typography, List } from '@alquiler-argentina/demiurgo';
import { styled, Box } from '@mui/material';

import term from './term.json';

type TList = { p: string; list: string[] };

interface ITerminos {
  title: string;
  text: (string | TList)[];
}

const StyledTypography = styled(Typography)(
  ({ theme }) => `
    font-weight: 700;
    color: ${theme.palette.text.primary};
    line-height: 1.25rem;
  `,
);

const StyledTypographyText = styled(Typography)(
  ({ theme }) => `
    color: ${theme.palette.text.primary};
    size: 1rem;
    line-height: 1.5rem;
    letter-spacing: 0.15px;
  `,
);

function TermText() {
  const content: ITerminos[] = Object.values(term);

  return (
    <>
      {content.map(({ title, text }, key) => (
        <Box component="article" key={`content-${key}`}>
          <StyledTypography variant="h6">{title}</StyledTypography>
          <Box component="section">
            {text.map((paragraph, index) => {
              if (typeof paragraph === 'string')
                return <p key={`p-${index}`}>{paragraph}</p>;
              if (typeof paragraph === 'object') {
                const { p, list } = paragraph;
                return (
                  <>
                    <StyledTypographyText variant="body1" key={`key-${index}`}>
                      {p}
                    </StyledTypographyText>
                    <List
                      key={`list-${index}`}
                      content={list.map((el, ind) => ({
                        primaryContent: <Typography key={ind}>{el}</Typography>,
                      }))}
                    />
                  </>
                );
              }
              return null;
            })}
          </Box>
        </Box>
      ))}
    </>
  );
}
export default TermText;
