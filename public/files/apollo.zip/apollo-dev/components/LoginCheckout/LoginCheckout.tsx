import { Box, Button, Typography, styled } from '@mui/material';
import React from 'react';

const StyledContainer = styled(Box)`
  display: inline-flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
  padding: 1.5rem 0.5rem;
  background-color: #00acc10a;
  border-radius: 0.5rem;
`;

const LoginCheckout = ({ onClick }: { onClick: () => void }) => {
  return (
    <StyledContainer>
      <Box>
        <Typography variant="bookingLoginTitle">
          ¡Iniciá sesión y disfrutá de estos beneficios!
        </Typography>
      </Box>
      <Box>
        <Typography fontSize="1rem">
          • Gestioná todas tus reservas fácilmente.
        </Typography>
        <Typography fontSize="1rem">
          • Recibí ofertas y descuentos exclusivos.
        </Typography>
      </Box>
      <Box width="14.75rem">
        <Button
          onClick={onClick}
          fullWidth
          variant="contained"
          color="primary"
          size="large"
        >
          Ingresar
        </Button>
      </Box>
    </StyledContainer>
  );
};

export default LoginCheckout;
