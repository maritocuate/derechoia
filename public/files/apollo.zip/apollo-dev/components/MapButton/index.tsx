import React from 'react';
import { styled, Grid } from '@mui/material';
import { useTranslation } from 'next-i18next';
import MapOutlined from '@mui/icons-material/MapOutlined';
import { LoadingButton } from '@mui/lab';

interface IMapButton {
  handleOpenMap: (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
  ) => void;
  isLoading: boolean;
}

const BackgroundButton = styled(Grid)(
  `
  background-image: url( '/images/MapaListado.png');
  background-size: cover;
  height: 9.25rem;
  width: 100%;
  border-radius: 0.5rem;
  margin-top: 1.56rem;
`,
);

const StyledButton = styled(LoadingButton)(
  `
  position: relative;
  background-color: #FFFFFF;
  border: 2px solid;
  font-weight: 600;
  &:hover {
    background-color: #FFFFFF;
    &::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 172, 193, 0.1);
    }
  }
  `,
);

export default function MapButton({ handleOpenMap, isLoading }: IMapButton) {
  const { t } = useTranslation('MapButton');
  return (
    <BackgroundButton alignItems="center" justifyContent="center" container>
      <Grid item>
        <StyledButton
          size="large"
          color="primary"
          startIcon={<MapOutlined />}
          onClick={handleOpenMap}
          variant="outlined"
          loading={isLoading}
          disabled={isLoading}
          loadingPosition="center"
        >
          {!isLoading ? t('title') : ''}
        </StyledButton>
      </Grid>
    </BackgroundButton>
  );
}
