import React from 'react';
import { Box, Typography, styled } from '@mui/material';
import NoFavoritesWithFilters from '../SVG/NoFavoritesWithFilters';

const StyledContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 1.5rem;
`;

const StyledTextContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  text-align: center;
  width: 100%;
  max-width: 30rem;
`;

const FiltersEmptyState = () => {
  return (
    <StyledContainer>
      <NoFavoritesWithFilters />
      <StyledTextContainer>
        <Typography variant="contentTitle">
          No se encontraron resultados
        </Typography>
        <Typography variant="descriptionText">
          Intentá de nuevo modificando los criterios de búsqueda.
        </Typography>
      </StyledTextContainer>
    </StyledContainer>
  );
};

export default FiltersEmptyState;
