import React, { useState } from 'react';
import {
  Divider,
  Grid,
  IconWithText,
  Typography,
} from '@alquiler-argentina/demiurgo';
import Modal, {
  VARIANTS as VARIANTS_MODAL,
} from '@alquiler-argentina/demiurgo/components/Modal';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import MailOutlineOutlinedIcon from '@mui/icons-material/MailOutlineOutlined';
import PaymentOutlinedIcon from '@mui/icons-material/PaymentOutlined';
import {
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  styled,
  ButtonBase,
} from '@mui/material';
import { useTranslation } from 'react-i18next';
import { useSelector } from 'react-redux';
import TermText from '../TermText';
import { ICheckoutState } from '../../redux/checkout/types';
import useIsMobile from '../../hooks/useIsMobile';

interface ICheckoutDiscount {
  paymentMethods: { value: string | null; label: string; idPayment: number }[];
  paymentAmount: { type: string; advance: number; rest: number; total: number };
  name: string;
  setPaymentId: (value: number) => void;
  paymentId: number;
}

const StyledSection = styled(Grid)`
  padding-left: 0;
`;

const StyledTitleWrapper = styled(Grid)`
  margin-block-start: 1.5rem;
  margin-block-end: 1.3rem;
`;

const StyledTitle = styled(Typography)`
  font-weight: 700;
  font-size: 1.25rem;
`;

const StyledInfo = styled(Grid)`
  font-size: 1rem;
  max-width: 35.3125rem;
`;

const StyledIconWithTextItem = styled(IconWithText)`
  & svg {
    fill: rgba(0, 0, 0, 0.54);
    align-self: flex-start;
    margin-block-start: 0.3rem;
    width: 1.25rem;
    height: 1.25rem;
    position: relative;
    bottom: 0.125rem;
    left: -0.125rem;
  }
`;

const StyledStrong = styled('strong')(
  ({ theme }) => `
  font-size: 0.875rem;
  color: ${theme.palette.text.primary};
  text-decoration: underline;
  vertical-align: initial;`,
);

const StyledIconWithText = styled(IconWithText)`
  font-size: 1.25rem;
  font-weight: 700;
  & svg {
    fill: #00bcd4;
    width: 1.6rem;
    height: 1.6rem;
    margin-inline-end: 0.3125rem;
  }
`;

const StyledSubtitle = styled(Typography)`
  font-size: 1rem;
  margin-block-start: 0.5rem;
`;

const StyledRadioInputSection = styled(Grid)`
  padding-inline-start: 1rem;
`;

const StyledRadioGroup = styled(RadioGroup)`
  margin-block: 1.6rem;
`;

const StyledRadioOption = styled(FormControlLabel)`
  & span {
    font-size: 1rem;
  }
`;

const StyledAmounts = styled(Grid)`
  justify-content: space-between;
  font-size: 1rem;
`;

const StyledTotalAmount = styled(StyledAmounts)`
  font-weight: 700;
`;

const StyledTermsAndConditions = styled(Typography)`
  font-size: 0.875rem;
  line-height: 143%;
  margin-block-start: 2.5rem;
  margin-block-end: 2rem;
`;

const StyledTotalMobileContainer = styled(Grid)`
  padding: 0.5rem;
  border-radius: 0.5rem;
`;

export default function CheckoutDiscount({
  setPaymentId,
  paymentMethods,
  paymentAmount,
  name,
  paymentId,
}: ICheckoutDiscount) {
  const isMobile = useIsMobile();
  const { isImmediate } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const { t } = useTranslation('CheckoutSIRO');
  const [isOpenTermAndConditionsModal, setIsOpenTermAndConditionsModal] =
    useState(false);
  return (
    <Grid container direction="column" data-testid="thirdStep">
      <StyledSection item container>
        <StyledTitleWrapper item xs={12}>
          <StyledTitle variant="h6" data-testid="almostDone">
            ¡Ya casi estás, {name}!
          </StyledTitle>
        </StyledTitleWrapper>
        <StyledInfo item container direction="column" rowSpacing={1}>
          <Grid item>
            <StyledIconWithTextItem
              anchor="left"
              icon={<AccessTimeOutlinedIcon />}
            >
              {isImmediate ? (
                <span>
                  Una vez que realices la solicitud, la reserva{' '}
                  <strong>será aceptada inmediatamente.</strong>
                </span>
              ) : (
                <span>
                  El anfitrión tendrá{' '}
                  <strong>14 horas para aceptar la reserva.</strong>
                </span>
              )}
            </StyledIconWithTextItem>
          </Grid>
          <Grid item>
            <StyledIconWithTextItem
              anchor="left"
              icon={<MailOutlineOutlinedIcon />}
            >
              {isImmediate ? (
                <span>
                  Recibirás por correo electrónico los{' '}
                  <strong>datos para realizar el pago </strong>
                  del adelanto
                </span>
              ) : (
                <span>
                  Una vez que acepte tu solicitud, recibirás por correo
                  electrónico los <strong>datos para realizar el pago</strong>{' '}
                  del adelanto.
                </span>
              )}
            </StyledIconWithTextItem>
          </Grid>
          <Grid item>
            <StyledIconWithTextItem
              anchor="left"
              icon={<PaymentOutlinedIcon />}
            >
              <span>
                A partir de ese momento, tendrás 24 horas para efectuar el pago
                y <strong>enviar el comprobante</strong>.
              </span>
            </StyledIconWithTextItem>
          </Grid>
        </StyledInfo>
      </StyledSection>
      <StyledSection
        item
        container
        direction="column"
        sx={{ marginBlockStart: '3rem' }}
      >
        {paymentMethods.length > 0 ? (
          <Grid item container direction="column">
            <Grid item data-testid="prepayment">
              <StyledIconWithText anchor="left" icon={<PaymentOutlinedIcon />}>
                Medios de pago
              </StyledIconWithText>
            </Grid>
            <Grid item>
              <StyledSubtitle variant="body1">
                Elegí cómo pagar la seña para reservar
              </StyledSubtitle>
            </Grid>
            <StyledRadioInputSection item>
              <FormControl>
                <StyledRadioGroup
                  aria-labelledby="payment-methods"
                  name="payment-methods"
                  data-testid="payment-methods"
                >
                  {paymentMethods.map(
                    (paymentOption) =>
                      paymentOption.value && (
                        <StyledRadioOption
                          value={paymentOption.value}
                          control={<Radio />}
                          label={paymentOption.label}
                          onClick={() => setPaymentId(paymentOption.idPayment)}
                          key={paymentOption.value}
                          checked={paymentOption.idPayment === paymentId}
                        />
                      ),
                  )}
                </StyledRadioGroup>
              </FormControl>
            </StyledRadioInputSection>
          </Grid>
        ) : null}
        {isMobile && (
          <StyledTotalMobileContainer item container rowSpacing={1}>
            <StyledAmounts item container>
              <Grid item>
                <Typography fontSize="0.875rem">
                  Adelanto para reservar
                </Typography>
              </Grid>
              <Grid item data-testid="prepaymentAmount">
                <Typography fontSize="0.875rem">
                  {t('$'.concat('{{val, number}}'), {
                    val: paymentAmount.advance,
                  })}
                </Typography>
              </Grid>
            </StyledAmounts>
            <StyledAmounts item container>
              <Grid item>
                <Typography fontSize="0.875rem">Saldo al ingresar </Typography>
              </Grid>
              <Grid item data-testid="subAmount">
                <Typography fontSize="0.875rem">
                  {t('$'.concat('{{val, number}}'), {
                    val: paymentAmount.rest,
                  })}
                </Typography>
              </Grid>
            </StyledAmounts>
            <Grid item xs={12}>
              <Divider />
            </Grid>
            <StyledTotalAmount item container>
              <Grid item>
                <Typography fontWeight={600} fontSize="0.875rem">
                  Total ({paymentAmount.type})
                </Typography>
              </Grid>
              <Grid item data-testid="totalAmount">
                <Typography fontWeight={600} fontSize="0.875rem">
                  {t('$'.concat('{{val, number}}'), {
                    val: paymentAmount.total,
                  })}
                </Typography>
              </Grid>
            </StyledTotalAmount>
          </StyledTotalMobileContainer>
        )}
        <Grid item>
          <StyledTermsAndConditions variant="body2" data-testid="terms">
            Al seleccionar el botón “solicitar reserva” estoy aceptando las
            Normas del alojamiento y los
            <ButtonBase
              onClick={() => setIsOpenTermAndConditionsModal(true)}
              component="span"
              sx={{
                display: 'inline',
                position: 'static',
                verticalAlign: 'bottom',
                padding: '0 0.3rem',
              }}
            >
              <StyledStrong>Términos y condiciones</StyledStrong>
            </ButtonBase>
            de Alquiler Argentina.
          </StyledTermsAndConditions>
        </Grid>
      </StyledSection>
      <Modal
        title="Términos y condiciones"
        variant={VARIANTS_MODAL.MODAL}
        open={isOpenTermAndConditionsModal}
        handleClose={() => setIsOpenTermAndConditionsModal(false)}
        fullScreen={isMobile}
      >
        <TermText />
      </Modal>
    </Grid>
  );
}
