/* eslint-disable @typescript-eslint/indent */
import React, { memo, useMemo, useState } from 'react';
import dynamic from 'next/dynamic';

import {
  Alert,
  Grid,
  Box,
  Dialog,
  Divider,
  styled,
  Typography,
} from '@mui/material';
import { useTranslation } from 'next-i18next';
import dayjs, { Dayjs } from 'dayjs';
import { DateRange } from '@mui/lab';
import ModalCalendarMobile from '../ModalCalendarMobile/index';

const SelectPeople = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/SelectPeople'),
  { ssr: false },
);

require('dayjs/locale/es');

dayjs.locale('es');

const StyleBoxContainer = styled(Box)`
  display: flex;
  flex-direction: row;
  border: 1px solid rgba(0, 0, 0, 0.12);
  border-radius: 4px;
  width: 100%;
`;

const StyleInputs = styled(Box)`
  width: 50%;
  padding: 5px 8px;
`;

const LabelInputs = styled(Typography)`
  font-weight: 400;
  font-size: 12px;
  letter-spacing: 0.4px;
`;

const StyleTextInputs = styled(Grid)`
  font-weight: 600;
  font-size: 16px;
`;

const StyleAlert = styled(Alert)`
  margin-top: 24px;
  width: 100%;
`;

interface IBookingSummaryMobile {
  startDate: string;
  endDate: string;
  guests: number;
  blocked: boolean;
  blockedDays: string[];
  blockedMessage: string | null;
  peopleMax?: number;
  pets?: boolean;
  persons: {
    adults: number;
    children: number;
    babies: number;
    total: number;
    mascotas: boolean;
  };
  onChange: (e: DateRange<Dayjs>) => void;
  changeProps: (key: string, value: unknown) => void;
  active?: boolean;
  openCalendar: boolean;
  handleResetCalendar: () => void;
  setOpenCalendar: (newState: boolean) => void;
}

const BookingSummaryMobile = ({
  startDate,
  endDate,
  guests,
  peopleMax,
  pets,
  persons,
  blocked,
  blockedDays,
  blockedMessage,
  onChange,
  changeProps,
  active,
  openCalendar,
  setOpenCalendar,
  handleResetCalendar,
}: IBookingSummaryMobile) => {
  const { t } = useTranslation('BookingSummaryMobile');
  const [openSelectPeople, setOpenSelectPeople] = useState(false);

  const startDateFormated = useMemo(
    () => (startDate === '' ? null : dayjs(startDate).format('DD MMM')),
    [startDate],
  );

  const endDateFormated = useMemo(
    () => (endDate === '' ? null : dayjs(endDate).format('DD MMM')),
    [endDate],
  );

  if (!active) return null;
  return (
    <>
      <StyleBoxContainer>
        <StyleInputs
          onClick={() => setOpenCalendar(true)}
          data-testid="guests-input"
        >
          <LabelInputs>{t('stay')}</LabelInputs>
          <StyleTextInputs>
            {!startDateFormated && !endDateFormated ? (
              <Typography color="GrayText" fontWeight="600">
                {t('pick-date')}
              </Typography>
            ) : (
              <Typography
                color={
                  startDateFormated || endDateFormated ? 'initial' : 'GrayText'
                }
                fontWeight="600"
              >
                {startDateFormated || t('pick-date')} -{' '}
                {endDateFormated || t('pick-date')}
              </Typography>
            )}
          </StyleTextInputs>
        </StyleInputs>
        <Divider orientation="vertical" />
        <StyleInputs onClick={() => setOpenSelectPeople(true)}>
          <LabelInputs> {t('guests')} </LabelInputs>
          <StyleTextInputs>
            {guests ? t('people', { count: guests, people: guests }) : ''}
          </StyleTextInputs>
        </StyleInputs>
      </StyleBoxContainer>
      {blocked && (
        <StyleAlert severity="error">
          <Typography>{blockedMessage}</Typography>
        </StyleAlert>
      )}
      {openCalendar && (
        <ModalCalendarMobile
          openCalendar={openCalendar}
          startDate={startDate}
          endDate={endDate}
          setOpenCalendar={setOpenCalendar}
          onChange={onChange}
          blockedDays={blockedDays}
          handleClose={handleResetCalendar}
        />
      )}
      {openSelectPeople && (
        <Dialog sx={{ borderRadius: '8px' }} fullWidth open={openSelectPeople}>
          <SelectPeople
            handleClose={setOpenSelectPeople}
            aceptaMascotas={pets || false}
            persons={persons}
            changeProps={changeProps}
            typologyMaxCapacity={peopleMax || 2}
          />
        </Dialog>
      )}
    </>
  );
};

export default memo(BookingSummaryMobile);
