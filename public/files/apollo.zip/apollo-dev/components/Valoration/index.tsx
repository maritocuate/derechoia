import React, { useMemo } from 'react';
import {
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Grid,
  styled,
  Box,
} from '@mui/material';
import Ratings from '@alquiler-argentina/demiurgo/components/Rating';
import { Typography, Avatar } from '@alquiler-argentina/demiurgo';
import { useTranslation } from 'next-i18next';
import { IValoration } from '../../types/valoration.type';
import AnswerItem from './components/AnswerItem/AnswerItem';

interface IValorationType extends IValoration {
  hostName: string;
  modalOpen?: boolean;
}

const StyledText = styled(Typography)`
  line-height: 0.9;
  font-weight: 600;
  font-size: 1.12rem;
  text-transform: capitalize;
`;

const StyledListItem = styled(ListItemText)`
  margin-bottom: 0;
`;

export default function Valoration({
  anio_estadia,
  comentario,
  foto,
  mes_estadia,
  nombre_apellido,
  replica = '',
  valoracion,
  hostName,
  modalOpen,
}: IValorationType) {
  const { t } = useTranslation('Valoration');
  const nameInitial = useMemo(
    () => nombre_apellido.substring(0, 1).toLocaleUpperCase(),
    [nombre_apellido],
  );

  const lastnameInital = useMemo(() => {
    const splitName = nombre_apellido.split(' ');
    const lastname = splitName[1] ? splitName[1] : '';
    return lastname !== '' ? lastname.substring(0, 1).toLocaleUpperCase() : '';
  }, [nombre_apellido]);
  const months = useMemo(
    () => [
      t('jan'),
      t('feb'),
      t('mar'),
      t('apr'),
      t('may'),
      t('jun'),
      t('jul'),
      t('aug'),
      t('sep'),
      t('oct'),
      t('nov'),
      t('dec'),
    ],
    [t],
  );
  const month = useMemo(() => months[mes_estadia - 1], [mes_estadia, months]);

  return (
    <Box>
      <List style={{ paddingBottom: 0 }}>
        <ListItem disablePadding alignItems="flex-start">
          <ListItemAvatar>
            {foto ? (
              <Avatar src={foto} />
            ) : (
              <Avatar
                sx={{ backgroundColor: '#FBC02D' }}
              >{`${nameInitial}${lastnameInital}`}</Avatar>
            )}
          </ListItemAvatar>
          <Grid container alignItems="flex-start" flexDirection="column">
            <Grid item>
              <StyledListItem
                disableTypography
                primary={
                  <StyledText variant="body1">{nombre_apellido}</StyledText>
                }
                secondary={
                  <Typography variant="caption" color="#575757">
                    {month} {t('de')} {String(anio_estadia)}
                  </Typography>
                }
              />
            </Grid>
            <Grid item>
              <Ratings size="small" readOnly value={valoracion} />
            </Grid>
          </Grid>
        </ListItem>
      </List>
      <Typography paddingRight="1rem" variant="body1" fontSize="1rem">
        {comentario.substring(0, 1).toLocaleUpperCase() + comentario.slice(1)}
      </Typography>
      {replica ? (
        <AnswerItem
          modalOpen={modalOpen}
          hostName={
            t('rep') +
            hostName.substring(0, 1).toLocaleUpperCase() +
            hostName.slice(1)
          }
          answer={
            replica
              ? replica.substring(0, 1).toLocaleUpperCase() + replica.slice(1)
              : ''
          }
        />
      ) : null}
    </Box>
  );
}
