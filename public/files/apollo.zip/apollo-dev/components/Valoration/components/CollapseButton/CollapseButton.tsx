import KeyboardArrowDownOutlined from '@mui/icons-material/KeyboardArrowDownOutlined';
import KeyboardArrowUpOutlined from '@mui/icons-material/KeyboardArrowUpOutlined';
import { Box, styled } from '@mui/material';
import React from 'react';

interface ICollapseButton {
  handleCollapseToggle: () => void;
  isCollapsed: boolean;
}

const StyledContainer = styled(Box)`
  cursor: pointer;
  display: flex;
  gap: 0.25rem;
  align-items: center;
  text-decoration: underline;
  font-weight: 600;
  font-size: 1rem;
`;

const CollapseButton = ({
  handleCollapseToggle,
  isCollapsed,
}: ICollapseButton) => {
  const iconsStyles = { fontSize: '1rem', color: 'rgba(0, 0, 0, 0.54)' };
  return (
    <StyledContainer
      overflow="hidden"
      display="inline-block"
      whiteSpace="nowrap"
      alignContent="end"
      data-testid="toggle-button"
      onClick={handleCollapseToggle}
      width="8.313rem"
    >
      Mostrar {!isCollapsed ? 'más' : 'menos'}
      {isCollapsed ? (
        <KeyboardArrowUpOutlined sx={iconsStyles} />
      ) : (
        <KeyboardArrowDownOutlined sx={iconsStyles} />
      )}
    </StyledContainer>
  );
};

export default CollapseButton;
