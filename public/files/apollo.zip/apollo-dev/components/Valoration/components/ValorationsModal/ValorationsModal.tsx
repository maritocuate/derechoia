import {
  Box,
  Dialog,
  DialogContent,
  DialogTitle,
  Divider,
  IconButton,
  Typography,
  styled,
} from '@mui/material';
import React from 'react';
import Close from '@mui/icons-material/Close';
import useIsMobile from '../../../../hooks/useIsMobile';
import ValorationsList from '../ValorationsList/ValorationsList';
import { IValoration } from '../../../../types/valoration.type';

interface IValorationsModal {
  openModal: boolean;
  setOpenModal: (value: boolean) => void;
  handleOpen: () => void;
  ratingsData: IValoration[];
  title: string;
  hostName: string;
}

const StyledContainer = styled(Dialog)(
  ({ theme }) => `
    margin-inline: -1rem;
    z-index: 999999;
    ${theme.breakpoints.up('sm')} {
      margin-inline: 0;
      & .MuiPaper-root {
        height: 55rem;
      }
    }
  `,
);

const StyledContentWrapper = styled(DialogContent)(
  ({ theme }) => `
    padding-inline: 1.5rem;
    padding-top:0;
    ${theme.breakpoints.up('sm')}{
        padding-inline: 0;
        display: flex; 
        flex-wrap: wrap; 
        padding: 0 1.5rem;  
    }
  `,
);

const StyledModalTitleWrapper = styled(DialogTitle)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
`;

const ValorationsModal = ({
  openModal,
  setOpenModal,
  handleOpen,
  ratingsData,
  title,
  hostName,
}: IValorationsModal) => {
  const isMobile = useIsMobile();
  return (
    <StyledContainer
      open={openModal}
      PaperProps={{ sx: { maxWidth: '48.125rem' } }}
      fullScreen={isMobile}
      onClose={() => {
        setOpenModal(false);
      }}
    >
      <StyledModalTitleWrapper variant="h6" margin={isMobile ? '0 1rem' : '0'}>
        <Typography
          fontSize="1.25rem"
          fontWeight={700}
          marginLeft={isMobile ? 0 : 1}
        >
          {title}
        </Typography>
        <IconButton onClick={handleOpen}>
          <Close />
        </IconButton>
      </StyledModalTitleWrapper>
      <Divider />
      <StyledContentWrapper>
        {ratingsData.map((rating, i) => (
          <Box
            key={i}
            padding={isMobile ? 3 : 2}
            position="relative"
            width="100%"
            left="-1rem"
            paddingBottom={isMobile ? 0 : 2}
          >
            <ValorationsList
              modalOpen={openModal}
              nombre_apellido={rating.nombre_apellido}
              comentario={rating.comentario}
              valoracion={rating.valoracion}
              replica={rating.replica}
              anio_estadia={rating.anio_estadia}
              mes_estadia={rating.mes_estadia}
              hostName={hostName}
            />
          </Box>
        ))}
      </StyledContentWrapper>
    </StyledContainer>
  );
};

export default ValorationsModal;
