import QuestionAnswerOutlined from '@mui/icons-material/QuestionAnswerOutlined';
import { Box, Icon, Typography, styled } from '@mui/material';
import React, { memo, useState } from 'react';
import CollapseButton from '../CollapseButton/CollapseButton';
import useIsMobile from '../../../../hooks/useIsMobile';

interface AnswerItemProps {
  hostName: string;
  answer: string;
  modalOpen?: boolean;
}

const StyledIcon = styled(Icon)`
  margin-right: 0.313rem;
  color: rgba(0, 0, 0, 0.54);
`;
const StyledContainer = styled(Box)`
  background-color: rgba(251, 192, 45, 0.08);
  margin-top: 1rem;
  padding: 0.75rem 1rem;
`;

const truncateText = (text: string, maxLength: number) => {
  if (text.length <= maxLength) {
    return text;
  }
  const truncatedText = text.substring(0, maxLength - 3);
  const lastSpaceIndex = truncatedText.lastIndexOf(' ');
  if (lastSpaceIndex === -1) {
    return truncatedText;
  }
  return `${truncatedText.substring(0, lastSpaceIndex)} ...`;
};

const AnswerItem = ({ hostName, answer, modalOpen }: AnswerItemProps) => {
  const [expanded, setExpanded] = useState(false);
  const isMobile = useIsMobile();
  const truncationLength =
    (modalOpen && !isMobile && 116) || (isMobile && 135) || 130;
  const truncatedAnswer = truncateText(answer, truncationLength);
  const handleExpandClick = () => {
    setExpanded(!expanded);
  };
  const shouldTruncate =
    (isMobile && answer.length > 135) || (!isMobile && answer.length > 150);

  const paragraphs = shouldTruncate && !expanded ? truncatedAnswer : answer;
  return (
    <StyledContainer
      marginLeft={isMobile ? '1rem' : '1.5rem'}
      bgcolor="rgba(251, 192, 45, 0.08)"
      display="flex"
      borderRadius="0.5rem"
    >
      <StyledIcon>
        <QuestionAnswerOutlined />
      </StyledIcon>
      <Box>
        <Typography variant="subtitle1" fontWeight={600} fontSize="1rem">
          {`${hostName}:`}
        </Typography>
        <Box
          display="flex"
          flexDirection={isMobile ? 'column' : 'row'}
          justifyContent="space-between"
          alignItems={isMobile ? 'flex-start' : 'flex-end'}
          gap="0.5rem"
        >
          <Box>
            <Typography
              marginTop=".5rem"
              variant="body1"
              fontSize="1rem"
              fontWeight={400}
            >
              {paragraphs}
            </Typography>
          </Box>
          {shouldTruncate ? (
            <Box>
              <CollapseButton
                handleCollapseToggle={handleExpandClick}
                isCollapsed={expanded}
              />
            </Box>
          ) : null}
        </Box>
      </Box>
    </StyledContainer>
  );
};

export default memo(AnswerItem);
