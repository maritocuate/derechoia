import { Box, Divider, styled } from '@mui/material';
import React from 'react';
import { IValoration } from '../../../../types/valoration.type';
import Valoration from '../..';
import useIsMobile from '../../../../hooks/useIsMobile';

interface IValorationsList extends IValoration {
  hostName: string;
  modalOpen?: boolean;
}

const StyledDivider = styled(Box)`
  margin-top: 2.5rem;
`;

const ValorationsList = ({
  anio_estadia,
  comentario,
  mes_estadia,
  nombre_apellido,
  replica,
  valoracion,
  hostName,
  modalOpen,
}: IValorationsList) => {
  const isMobile = useIsMobile();
  return (
    <Box>
      <Valoration
        modalOpen={modalOpen}
        nombre_apellido={nombre_apellido}
        comentario={comentario}
        valoracion={valoracion}
        replica={replica}
        anio_estadia={anio_estadia}
        mes_estadia={mes_estadia}
        hostName={hostName}
      />
      {isMobile && (
        <StyledDivider>
          <Divider />
        </StyledDivider>
      )}
    </Box>
  );
};

export default ValorationsList;
