import { IconButton, Typography, styled } from '@mui/material';
import React from 'react';

const StyledIconButton = styled(IconButton)`
  border-radius: 0.25rem;
  padding-right: 0.938rem;
  &:hover {
    background-color: transparent;
  }
`;

const StyledTypography = styled(Typography)`
  font-family: 'Plus Jakarta Sans';
  font-weight: 700;
  text-decoration: underline rgba(0, 0, 0, 0.87);
  color: rgba(0, 0, 0, 0.87);
`;

const ShowAllButton = ({
  handleClick,
  text,
}: {
  handleClick: () => void;
  text: string;
}) => {
  return (
    <StyledIconButton onClick={handleClick}>
      <StyledTypography>{text}</StyledTypography>
    </StyledIconButton>
  );
};

export default ShowAllButton;
