import { Box, Typography } from '@mui/material';
import React from 'react';

const NoValorations = () => {
  return (
    <Box marginTop="1rem" data-testid="valoration-resume">
      <Typography fontSize="1rem">
        Este alojamiento aún no tiene comentarios. Sé una de las primeras
        personas en contar tu experiencia.
      </Typography>
    </Box>
  );
};

export default NoValorations;
