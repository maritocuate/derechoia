import React, { ReactNode } from 'react';
import { Box, Typography } from '@mui/material';

type Color = 'primary' | 'secondary';

interface BadgeOffersProps {
  color: Color;
  children: ReactNode;
  icon: ReactNode;
}

const getBgColor = (color: Color) => {
  if (color === 'secondary') {
    return 'rgba(251, 192, 45, 0.08)';
  }
  // if primary
  return 'rgba(128, 222, 234, 0.08)';
};

const getBorderColor = (color: Color) => {
  if (color === 'secondary') {
    return 'rgba(251, 192, 45, 1)';
  }
  // if primary
  return 'rgba(128, 222, 234, 1)';
};

const BadgeOffers = ({ icon, color, children }: BadgeOffersProps) => {
  return (
    <Box
      display="flex"
      alignItems="center"
      bgcolor={getBgColor(color)}
      height="1.75rem"
      justifyContent="flex-end"
      gap="0.125rem"
      padding=" 0.125rem 0.5rem 0.125rem 0.375rem"
      width="fit-content"
      border={`1px solid ${getBorderColor(color)}`}
      marginTop=".75rem"
      borderRadius="4px"
      data-testid="badgeOffers-container"
    >
      {!!icon && (
        <Box display="flex" data-testid="badgeOffers-icon">
          {icon}
        </Box>
      )}
      {!!children && (
        <Typography
          fontSize="1rem"
          letterSpacing="-0.5px"
          data-testid="badgeOffers-typography"
        >
          {children}
        </Typography>
      )}
    </Box>
  );
};

export default BadgeOffers;
