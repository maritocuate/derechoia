import React, { useMemo } from 'react';
import Image from 'next/image';
import { useTranslation } from 'react-i18next';
import { Box, styled } from '@mui/material';
import Done from '@mui/icons-material/Done';
import { Grid, Typography } from '@alquiler-argentina/demiurgo';
import useIsMobile from '../../hooks/useIsMobile';
import MaxWidthDesktopWrapper from '../MaxWidthDesktopWrapper/MaxWidthDesktopWrapper';

const StyledContainerDesktop = styled(Box)`
  padding: 7.5rem 0 5rem 0;
  justify-content: center;
  align-items: center;
  display: flex;
  flex-direction: column;
`;
const StyledSeccionContainer = styled(Box)(
  ({ theme }) => `      
    ${theme.breakpoints.up('sm')}{
      width: 100%;
      max-width: 72.5rem;
      display: flex;
      margin: auto;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
  `,
);
const WorkTogether = () => {
  const isMobile = useIsMobile();
  const { t } = useTranslation('WorkTogether');
  const info = useMemo(() => [t('itemOne'), t('itemTwo'), t('itemThree')], [t]);

  if (isMobile) {
    return (
      <Box
        p="3rem 1.5rem"
        maxWidth={isMobile ? 600 : 'initial'}
        margin="0 auto"
      >
        <Box textAlign="center">
          <Typography variant="titleSectionPostMobile" color="primary">
            {t('title')}
          </Typography>
        </Box>
        <Image
          src="/images/TrabajamosJuntosMobile.svg"
          alt="Trabajamos Juntos"
          width={328}
          height={328}
        />
        {info.map((data, index) => (
          <Box
            display="flex"
            key={index}
            mb={index === info.length ? '0' : '1.5rem'}
          >
            <Done color="primary" fontSize="large" />
            <Typography ml="1rem" variant="textPostMobile">
              {data}
            </Typography>
          </Box>
        ))}
      </Box>
    );
  }

  return (
    <StyledSeccionContainer>
      <MaxWidthDesktopWrapper>
        <StyledContainerDesktop>
          <Typography color="primary" variant="titleSectionPostDestkop">
            {t('title')}
          </Typography>
          <Grid container>
            <Grid item lg={8} md={8} xs={12} margin="auto">
              {info.map((data, index) => (
                <Box display="flex" my="0.5rem" key={index}>
                  <Done color="primary" fontSize="large" />
                  <Typography ml="1.5rem" variant="textPostDesktop">
                    {data}
                  </Typography>
                </Box>
              ))}
            </Grid>
            <Grid
              item
              height="26.875rem"
              width="26.875rem"
              lg={4}
              md={4}
              xs={12}
            >
              <Image
                src="/images/TrabajamosJuntosDesktop.svg"
                alt="Trabajamos Juntos"
                width={430}
                height={430}
              />
            </Grid>
          </Grid>
        </StyledContainerDesktop>
      </MaxWidthDesktopWrapper>
    </StyledSeccionContainer>
  );
};

export default WorkTogether;
