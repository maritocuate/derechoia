/* eslint-disable @typescript-eslint/indent */
import React, { memo, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Box, BoxProps, styled } from '@mui/material';
import { useSelector, useDispatch } from 'react-redux';
import Link from 'next/link';
import { StlyedTypography } from '../MostBookedDestinations/MostBookedDestinations';
import LastSearchItem from '../LastSearchItem/LastSearchItem';
import { ILastSearchState } from '../../redux/lastSearchs/type';
import { cleanOldDatesSearchs } from '../../redux/lastSearchs/slice';
import formatUrlHome from '../../utils/helpers/formatUrlHome';
import { isServer } from '../../constants/commons';

interface BoxStyle extends BoxProps {
  fullsearch: string;
}

const LastSearchsContainer = styled(Box)(
  ({ theme }) => `
      width: 100vw;
      margin-top: 4rem;
      height: 380px;
      overflow-y: hidden;
      padding-left: 1rem;
      height: 160px;
      overflow-y: hidden;
      ${theme.breakpoints.up('lg')}{
        max-width: 1200px;
        margin-top: 4rem;
        height: unset;
        padding-left: 0rem;
      }
  `,
);

const StyledBoxSearchs = styled(Box)<BoxStyle>(
  ({ theme, fullsearch }) => `
    display: flex;
    flex-wrap: no-wrap;
    widht: 100%;
    overflow: scroll;
    scroll-behavior: smooth;
    justify-content: flex-start;
    padding-bottom: 5rem;
    padding-right: 2rem;
    ${theme.breakpoints.up('lg')}{
        padding-bottom: 0;
        padding-right: 0;
        flex-wrap: wrap;
        overflow: hidden;
        justify-content: ${
          fullsearch === 'true' ? 'space-between' : 'flex-start'
        };
    }
      `,
);

function LastSearchList() {
  const { t } = useTranslation('LastSearch');
  const dispatch = useDispatch();
  const { destinations } = useSelector(
    ({ lastSearchs }: { lastSearchs: ILastSearchState }) => lastSearchs,
  );
  useEffect(() => {
    if (!isServer) {
      dispatch(cleanOldDatesSearchs());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (destinations.length === 0) {
    return null;
  }
  return (
    <LastSearchsContainer>
      <StlyedTypography variant="h5">{t('title')}</StlyedTypography>
      <StyledBoxSearchs
        fullsearch={destinations?.length === 4 ? 'true' : 'false'}
      >
        {destinations.map((el, index) => (
          <Link
            href={formatUrlHome({
              city: el.city,
              adults: el.adults,
              babies: el.babies,
              pets: el.pets,
              youngs: el.youngs,
              province: el.province,
              endDate: el.endDate,
              startDate: el.startDate,
            })}
            key={index}
          >
            <LastSearchItem
              adults={el.adults}
              babies={el.babies}
              pets={el.pets}
              youngs={el.youngs}
              province={el.province}
              city={el.city}
              endDate={el.endDate}
              startDate={el.startDate}
              lastCard={index === 3}
            />
          </Link>
        ))}
      </StyledBoxSearchs>
    </LastSearchsContainer>
  );
}

export default memo(LastSearchList);
