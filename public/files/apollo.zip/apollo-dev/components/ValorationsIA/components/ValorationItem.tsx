import { Box, ListItem, Typography } from '@mui/material';
import React from 'react';
import useIsMobile from '../../../hooks/useIsMobile';

interface ValorationItemProps {
  title: string;
  text: string;
}

const ValorationItem = ({ title, text }: ValorationItemProps) => {
  const isMobile = useIsMobile();
  return (
    <ListItem sx={{ padding: '0.125rem 0 0.125rem 1rem' }} data-testid="itemIA">
      <Box display="flex">
        <Typography
          fontSize={isMobile ? 20 : 24}
          lineHeight={isMobile ? '1.25rem' : '1rem'}
          position="relative"
          left={isMobile ? '-0.5rem' : '-0.75rem'}
        >
          •
        </Typography>
        <Typography variant="textPostMobile" data-testid="titleItemIA">
          {title}:{' '}
          <span style={{ fontWeight: 400 }} data-testid="textItemIA">
            {text}
          </span>
        </Typography>
      </Box>
    </ListItem>
  );
};

export default ValorationItem;
