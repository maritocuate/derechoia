import { Skeleton } from '@mui/material';
import React from 'react';

const SkeletonValorationItem = () => {
  return (
    <Skeleton
      width="100%"
      height="4rem"
      variant="rectangular"
      sx={{ borderRadius: '0.25rem' }}
    />
  );
};

export default SkeletonValorationItem;
