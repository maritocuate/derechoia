import AutoAwesomeSharp from '@mui/icons-material/AutoAwesomeSharp';
import { Box, List, Typography, styled } from '@mui/material';
import dynamic from 'next/dynamic';
import React, { useEffect, useState } from 'react';
import themeAA from '../../styles/theme';
import { IValorationsIA } from '../../types/propiedades.types';
import { usePostFeedbackValorationsIaMutation } from '../../services/feedbackValorationsIa';

const Feedback = dynamic(() => import('../Feedback/Feedback'), { ssr: true });

const ValorationItem = dynamic(() => import('./components/ValorationItem'), {
  ssr: true,
});

const StyledContainer = styled(Box)(
  ({ theme }) => `
    display: flex; 
    flex-direction: column;
    gap: 1rem;
    padding: 1rem;
    background-color: #FAFAFA;
    border-radius: 0.5rem;
    margin-top: 1.5rem;
    ${theme.breakpoints.up('lg')}{
      padding: 1rem 1.5rem;
    }
  `,
);

const StyledBox = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: column;
    ${theme.breakpoints.up('lg')}{
      flex-direction: row;
      justify-content: space-between;
    }
  `,
);

const ValorationsIA = ({ caracteristicas: items, refID }: IValorationsIA) => {
  const [valoration, setValoration] = useState<null | 'positive' | 'negative'>(
    null,
  );
  const [postFeedback] = usePostFeedbackValorationsIaMutation();
  const postFeedbackValorations = async () => {
    if (valoration !== null) {
      await postFeedback({ refID: Number(refID), type: valoration });
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      try {
        postFeedbackValorations().finally(() => {});
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error(error);
      }
    }, 3000);
    return () => clearTimeout(handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [valoration, refID, postFeedback]);
  return (
    <StyledContainer>
      <Typography variant="textPostDesktop" data-testid="VorationsIATitle">
        Aspectos destacados por los turistas
      </Typography>
      <List data-testid="VorationsIAList">
        {items?.length &&
          items.map((el, index) => (
            <ValorationItem
              title={el.titulo}
              text={el.recomendacion}
              key={`${index}${el.titulo}`}
            />
          ))}
      </List>
      <StyledBox data-testid="VorationsIAFooter"  >
        <Box display="flex" alignItems="center">
          <AutoAwesomeSharp sx={{ color: themeAA.palette.primary.main }} />
          <Typography
            marginLeft="0.5rem"
            variant="myBookingCardDescription"
            color="#00000099"
          >
            Resumen creado con Inteligencia Artificial
          </Typography>
        </Box>
        <Feedback
          callback={(value) => setValoration(value ? 'positive' : 'negative')}
          initialValue={null}
          text="¿Te resultó útil?"
        />
      </StyledBox>
    </StyledContainer>
  );
};

export default ValorationsIA;
