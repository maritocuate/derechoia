import { Box, styled } from '@mui/material';
import React from 'react';

const StyledContainer = styled(Box)`
  width: 100%;
  max-width: 72.5rem;
`;

const MaxWidthDesktopWrapper = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  return <StyledContainer>{children}</StyledContainer>;
};
export default MaxWidthDesktopWrapper;
