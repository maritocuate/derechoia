/* eslint-disable @typescript-eslint/no-misused-promises */
import React, { FormEvent, useState } from 'react';
import { Box, Button, Divider, styled } from '@mui/material';
import AAButton from '../../Components/Buttons/AAButton';
import AuthLayout from '../../Wrappers/AuthLayout';
import Title from '../../Components/Text/Title';
import Logo from '../../Components/Logo/Logo';
import Text from '../../Components/Text/Typography';
import InputPassword from '../../Components/InputPassword/InputPassword';
import ExternalLogin from '../../Components/ExternalLogin/ExternalLogin';
import { StyledForm } from '../SIngIn/SingIn';
import HelpLink from '../../Components/HelpLink/HelpLink';
import useUserSession from '../../../../hooks/userSession/useUserSession';

export interface IEnterPassword {
  email: string;
  wrongLogin?: boolean;
  isApp?: boolean;
  callback: (password: string) => Promise<void>;
  onClickFacebook: () => void;
  onClickGoogle: () => void;
  onForgotPassword: () => void;
  handleBack: () => void;
  handleClose?: () => void;
}

const StyledDividerContainer = styled('div')`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const StyledDivider = styled(Divider)`
  margin: 1rem 0px 1rem 0px;
  width: 100%;
`;

const StyledButton = styled(AAButton)`
  margin-top: 1rem;
`;

const BoldText = styled('span')`
  font-weight: 700;
`;

const StyledLink = styled(Button)`
  text-decoration: underline;
  margin-top: 5px;
`;

const StyledText = styled(Text)`
  text-align: left;
  whitespace: pre-wrap;
  word-wrap: break-word;
`;

export default function EnterPassword({
  email,
  wrongLogin,
  isApp,
  callback,
  onClickGoogle,
  onClickFacebook,
  onForgotPassword,
  handleBack,
  handleClose,
}: IEnterPassword) {
  const [loading, setLoading] = useState(false);
  const [password, setPassword] = useState('');
  const { getOldCookies, deleteOldCookies } = useUserSession();
  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (getOldCookies().length) {
      deleteOldCookies();
    }
    if (callback) {
      setLoading(true);
      await callback(password);
      setLoading(false);
    }
  };
  return (
    <AuthLayout handleBack={handleBack} handleClose={handleClose}>
      <Logo />
      <Title marginTop="1rem">Inicia sesión</Title>
      <Box width="100%" textAlign="left">
        <Box margin="1rem 0 1rem 0">
          <StyledText margin="1rem 0 1rem 0">
            Ingresá la contraseña de <br /> <BoldText>{email}</BoldText>
          </StyledText>
        </Box>
      </Box>
      <StyledForm onSubmit={onSubmit}>
        <InputPassword
          error={wrongLogin}
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          fullWidth
          label="Contraseña"
          id="password"
          name="password"
          helperText={
            wrongLogin ? 'Contraseña incorrecta, intente nuevamente' : ''
          }
        />
        <Box display="flex" justifyContent="flex-end" width="100%">
          <Box>
            <StyledLink variant="text" onClick={onForgotPassword}>
              ¿Olvidaste la contraseña?
            </StyledLink>
          </Box>
        </Box>
        <StyledButton
          fullWidth
          type="submit"
          disabled={!(password.length > 0) || loading}
        >
          Continuar
        </StyledButton>
      </StyledForm>
      <StyledDividerContainer>
        <StyledDivider>o</StyledDivider>
      </StyledDividerContainer>
      <ExternalLogin
        isApp={isApp}
        onClickFacebook={onClickFacebook}
        onClickGoogle={onClickGoogle}
      />
      <Box marginTop="1rem">
        <HelpLink />
      </Box>
    </AuthLayout>
  );
}
