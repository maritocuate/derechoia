import { z } from 'zod';

export const SIGNIN_VALIDATION = z.object({
  email: z.string().email({
    message: 'Debe ser un email válido.',
  }),
  password: z
    .string()
    .min(8, 'Ingrese un email valido.')
    .regex(/^(?=.*\d).{8,}$/, 'Ingrese un email valido.'),
});
