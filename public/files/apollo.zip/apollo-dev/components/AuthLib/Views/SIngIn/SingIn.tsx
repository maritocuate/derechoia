/* eslint-disable @typescript-eslint/no-misused-promises */
import React, { FormEvent, useCallback, useState } from 'react';
import { Divider, styled } from '@mui/material';
import TextField from '@mui/material/TextField';
import useValidator from '../../Hooks/useValidator/useValidator';
import { SIGNIN_VALIDATION } from './SignInValidations';
import AuthLayout from '../../Wrappers/AuthLayout';
import Title from '../../Components/Text/Title';
import Logo from '../../Components/Logo/Logo';
import ExternalLogin from '../../Components/ExternalLogin/ExternalLogin';
import AAButton from '../../Components/Buttons/AAButton';
import EVENTS_KEYBOARDS from '../../../../constants/login/eventsKeyboardsprohibited';

export interface ISingIn {
  callback: (email: string) => Promise<void>;
  onClickFacebook: () => void;
  onClickGoogle: () => void;
  handleClose?: () => void;
  isApp?: boolean;
}

type EventKeyBoard = React.KeyboardEvent<HTMLDivElement>;

const StyledTextField = styled(TextField)`
  margin-top: 2rem;
  min-height: 1.87rem;
`;

const StyledDividerContainer = styled('div')`
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: 100%;
`;

const StyledDivider = styled(Divider)`
  margin: 1rem 0px 1rem 0px;
  width: 100%;
`;

const StyledButton = styled(AAButton)`
  margin-top: 1rem;
`;

export const StyledForm = styled('form')`
  width: 100%;
`;

export default function SignIn({
  callback,
  onClickGoogle,
  onClickFacebook,
  handleClose,
  isApp,
}: ISingIn) {
  const [email, setEmail] = useState('');
  const [errorEmail, setErrorEmail] = useState(false);
  /*   const timerRef = useRef<NodeJS.Timeout | null>(null);
   */
  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (callback) {
      await callback(email);
    }
  };

  const { handleOnChange } = useValidator({
    validator: SIGNIN_VALIDATION,
    callback: (e) => {
      setErrorEmail(!!e?.email);
    },
  });
  const handleEmailValidation = (e: EventKeyBoard) => {
    if (EVENTS_KEYBOARDS.some((event) => event === e.key) || !errorEmail) {
      return;
    }
    setErrorEmail(false);
  };
  const handleEmailChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      // Actualizar el estado del email sin validar inmediatamente
      setEmail(e.target.value);
      if (e.target.value) handleOnChange({ email: e.target.value });
    },
    [handleOnChange],
  );

  return (
    <AuthLayout handleClose={handleClose}>
      <Logo />
      <Title marginTop="1rem">Inicia sesión o crea una cuenta</Title>
      <StyledForm onSubmit={onSubmit}>
        <StyledTextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          id="email"
          label="Correo electrónico"
          type="email"
          name="email"
          onKeyDown={handleEmailValidation}
          error={email?.length > 0 && errorEmail}
          helperText={
            email?.length > 0 && errorEmail ? 'Correo electrónico inválido' : ''
          }
          autoComplete="email"
          autoFocus
          value={email}
          onChange={handleEmailChange}
        />
        <StyledButton
          type="submit"
          fullWidth
          disabled={email?.length === 0 || errorEmail}
        >
          Continuar
        </StyledButton>
      </StyledForm>
      <StyledDividerContainer>
        <StyledDivider>o</StyledDivider>
      </StyledDividerContainer>

      <ExternalLogin
        isApp={isApp}
        onClickFacebook={onClickFacebook}
        onClickGoogle={onClickGoogle}
      />
    </AuthLayout>
  );
}
