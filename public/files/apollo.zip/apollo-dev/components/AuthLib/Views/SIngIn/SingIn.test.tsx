import React from 'react';
import { render, fireEvent, waitFor } from '@testing-library/react';
import SignIn from './SingIn';

const mockCallback = jest.fn();

test('La función onSubmit se ejecuta cuando se envía el formulario', async () => {
  const { getByLabelText, getByText } = render(
    <SignIn
      onClickFacebook={() => {}}
      onClickGoogle={() => {}}
      callback={mockCallback}
    />,
  );

  const emailInput = getByLabelText('Correo electrónico *');
  fireEvent.change(emailInput, { target: { value: 'test@example.com' } });

  // Enviar el formulario
  const submitButton = getByText('Continuar');
  fireEvent.click(submitButton);
  await waitFor(() => {
    expect(mockCallback).toHaveBeenCalledWith('test@example.com');
  });
});
