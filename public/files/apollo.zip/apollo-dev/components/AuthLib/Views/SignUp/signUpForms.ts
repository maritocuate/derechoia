export const SIGNUP_FORMS = [
  {
    id: 'name',
    type: 'text',
    label: 'Nombre',
    placeholder: 'Nombre',
    helperText: '',
  },
  {
    id: 'surname',
    type: 'text',
    label: 'Apellido',
    placeholder: 'Apellido',
    helperText: '',
  },
  {
    id: 'email',
    type: 'email',
    label: 'Correo electronico',
    placeholder: 'Correo electronico',
    helperText: '',
  },
  {
    id: 'password',
    type: 'password',
    label: 'Contraseña',
    placeholder: 'Contraseña',
    helperText:
      'Debe contener al menos un número y tener 8 caracteres cómo mínimo.',
  },
];
