import React, { FormEvent, useCallback, useMemo, useState } from 'react';
import { Box, Divider, Typography, styled } from '@mui/material';
import TextField from '@mui/material/TextField';
import { REGISTER_VALIDATION } from './SignUpValidations';
import { isValidForm } from '../../Utils/formUtils/isValidForm';
import { SIGNUP_FORMS } from './signUpForms';
import useValidator from '../../Hooks/useValidator/useValidator';

import AuthLayout from '../../Wrappers/AuthLayout';
import AuthHeader from '../../Components/AuthHeader/AuthHeader';
import InputPassword from '../../Components/InputPassword/InputPassword';

import AAButton from '../../Components/Buttons/AAButton';
import TOSRegister from '../../Components/TOSRegister/TOSRegister';
import { getEmailHelperText } from '../../Utils/formUtils/getEmailHelperText';
import { StyledForm } from '../SIngIn/SingIn';
import AuthFooter from '../../Components/AuthFooter/AuthFooter';
import EVENTS_KEYBOARDS_IGNORED from '../../../../constants/login/eventsKeyboardsprohibited';

const StyledTermsContainer = styled(Box)`
  margin-top: 1rem;
  width: 100%;
  display: flex;
  flex-direction: column;
  height: fit-content;
  gap: 1rem;
`;

/* const CustomCheckbox = styled(Checkbox)(({ theme }) => ({
  padding: 0,
  margin: theme.spacing(0),
})); */

const SignUp = ({
  handleClose,
  callback,
  email,
  handleBack,
  hasError,
}: {
  handleClose?: () => void;
  handleBack?: () => void;
  callback: (value: object) => Promise<void>;
  email: string;
  hasError: boolean;
}) => {
  // const [tosAccepted, setTosAccepted] = useState(false);
  const [formData, setFormData] = useState<Record<string, string>>({
    name: '',
    surname: '',
    email,
    password: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const { handleOnChange } = useValidator({
    formData,
    validator: REGISTER_VALIDATION,
    callback: (e) => {
      setErrors(e);
    },
  });
  const handleChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = event.target;
      setFormData((prev) => {
        handleOnChange({ ...prev, [name]: value });
        return { ...prev, [name]: value };
      });
    },
    [handleOnChange],
  );
  const isButtonDisabled = useMemo(() => {
    return !isValidForm({ formData, errors });
  }, [formData, errors]);

  const handleSubmit = useCallback(
    (event: FormEvent) => {
      event.preventDefault();

      if (hasError) {
        setErrors({ email: 'Email ya registrado' });
      }
      if (callback)
        callback({ ...formData })
          .then(() => {})
          .catch(() => {});
    },
    [callback, formData, hasError],
  );
  const handleKeyDownWithVerification = useCallback(
    (e: React.KeyboardEvent, { id }: { id: string }) => {
      if (EVENTS_KEYBOARDS_IGNORED.some((event) => e.key === event)) return;
      setErrors((prev) => ({ ...prev, [id]: '' }));
    },
    [],
  );

  return (
    <AuthLayout hiddenFooter handleClose={handleClose} handleBack={handleBack}>
      <AuthHeader title="Crea un cuenta" />
      <StyledForm onSubmit={handleSubmit}>
        <Box>
          <Box>
            <Typography fontSize="0.87rem" margin="1rem 0 0 0">
              Ingresá tus datos para crear una cuenta
            </Typography>
          </Box>
          {SIGNUP_FORMS.map((form, index) => (
            <>
              {form.id !== 'password' && form.id !== 'email' && (
                <TextField
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  id={form.id}
                  label={form.label}
                  type={form.type}
                  name={form.id}
                  error={formData[form.id]?.length > 0 && !!errors[form.id]}
                  helperText={
                    formData[form.id]?.length > 0 && errors[form.id]
                      ? errors[form.id]
                      : ''
                  }
                  autoFocus={index === 0}
                  value={formData[form.id]}
                  onChange={handleChange}
                  onKeyDown={(e) => {
                    handleKeyDownWithVerification(e, form);
                  }}
                />
              )}
              {form.id === 'email' && (
                <TextField
                  variant="outlined"
                  margin="normal"
                  required
                  fullWidth
                  id={form.id}
                  label={form.label}
                  type={form.type}
                  name={form.id}
                  error={
                    (formData[form.id]?.length > 0 && !!errors[form.id]) ||
                    hasError
                  }
                  helperText={getEmailHelperText(
                    formData.email,
                    errors,
                    hasError,
                  )}
                  autoFocus={index === 0}
                  value={formData[form.id]}
                  onChange={handleChange}
                  onKeyDown={(e) => {
                    handleKeyDownWithVerification(e, form);
                  }}
                />
              )}
              {form.id === 'password' && (
                <Box marginTop="1rem">
                  <InputPassword
                    error={!!formData[form.id] && !!errors[form.id]}
                    value={formData[form.id]}
                    label={form.label}
                    name={form.id}
                    onChange={handleChange}
                    fullWidth
                    id={form.id}
                    helperText={
                      formData[form.id].length > 0 && !!errors[form.id]
                        ? errors[form.id]
                        : 'Utilizá 8 caracteres para tu contraseña.'
                    }
                    onKeyDown={(e) => {
                      handleKeyDownWithVerification(e, form);
                    }}
                  />
                </Box>
              )}
            </>
          ))}
        </Box>
        <Box marginTop="1rem">
          <TOSRegister />
        </Box>

        <AAButton
          fullWidth
          style={{
            marginTop: '1rem',
          }}
          type="submit"
          disabled={isButtonDisabled}
        >
          Aceptar y continuar
        </AAButton>
      </StyledForm>
      <StyledTermsContainer>
        <Divider />
        <Typography variant="small">
          Alquiler Argentina te va a enviar ofertas exclusivas, contenido,
          correos electrónicos comerciales y notificaciones push.
        </Typography>
      </StyledTermsContainer>
      <AuthFooter />
    </AuthLayout>
  );
};

export default SignUp;
