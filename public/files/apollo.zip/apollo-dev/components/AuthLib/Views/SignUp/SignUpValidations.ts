import { z } from 'zod';

export const REGISTER_VALIDATION = z.object({
  name: z.string(),
  surname: z.string(),
  email: z.string().email({
    message: 'Debe ser un email válido.',
  }),
  password: z
    .string()
    .min(
      8,
      'Debe contener al menos un número y tener 8 caracteres cómo mínimo.',
    ),
});
