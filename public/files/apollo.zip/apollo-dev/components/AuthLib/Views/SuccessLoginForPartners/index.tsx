import React from 'react';
import { Box } from '@mui/material';
import Link from 'next/link';
import AuthLayout from '../../Wrappers/AuthLayout';
import AAbuton from '../../Components/Buttons/AAButton';
import Title from '../../Components/Text/Title';
import SeeYouSoon from '../../Components/SVG/SeeYouSoonSVG';

export interface ISuccessLogin {
  linkContinue: string;
  linkPanel: string;
  redirectContinue?: boolean;
  handleClose?: () => void;
}

const SuccessLoginForPartners = ({
  linkContinue,
  redirectContinue,
  linkPanel,
  handleClose,
}: ISuccessLogin) => {
  return (
    <AuthLayout hiddenFooter handleClose={handleClose}>
      <SeeYouSoon />
      <Title marginTop="2.5rem">¿Cómo querés continuar?</Title>
      <Box width="100%" marginTop="2.5rem">
        {linkPanel && (
          <Box
            onClick={() => {
              if (handleClose) handleClose();
            }}
          >
            <Link passHref href={linkPanel}>
              <AAbuton fullWidth>Ingresar al panel</AAbuton>
            </Link>
          </Box>
        )}
        {linkContinue && (
          <Box
            margin="1rem 0 2.5rem 0"
            onClick={() => {
              if (handleClose) handleClose();
            }}
          >
            {redirectContinue ? (
              <Link passHref href={linkContinue}>
                <AAbuton
                  variant={linkPanel ? 'outlined' : 'contained'}
                  fullWidth
                >
                  Continuar al sitio
                </AAbuton>
              </Link>
            ) : (
              <AAbuton variant={linkPanel ? 'outlined' : 'contained'} fullWidth>
                Continuar al sitio
              </AAbuton>
            )}
          </Box>
        )}
      </Box>
    </AuthLayout>
  );
};

export default SuccessLoginForPartners;
