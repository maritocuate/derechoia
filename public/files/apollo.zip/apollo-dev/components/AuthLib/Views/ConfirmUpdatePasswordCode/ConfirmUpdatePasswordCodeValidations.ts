import { z } from 'zod';

export const CONFIRM_UPDATE_PASSWORD_CODE_VALIDATIONS = z.object({
  password: z.string().min(8, 'Ingrese un email valido.'),
});
