import React, { FormEvent, useState } from 'react';
import { Box, styled } from '@mui/material';
import AAbuton from '../../Components/Buttons/AAButton';
import Text from '../../Components/Text/Typography';
import AuthLayout from '../../Wrappers/AuthLayout';
import InputVerficitacionCode from '../../Components/InputVerificationCode/InputVerificationCode';
import InputPassword from '../../Components/InputPassword/InputPassword';
import AuthHeader from '../../Components/AuthHeader/AuthHeader';
import useValidator from '../../Hooks/useValidator/useValidator';
import { CONFIRM_UPDATE_PASSWORD_CODE_VALIDATIONS } from './ConfirmUpdatePasswordCodeValidations';
import { StyledForm } from '../SIngIn/SingIn';
import HelpLink from '../../Components/HelpLink/HelpLink';

interface ConfirmUpdatePasswordCodeProps {
  handleBack?: () => void;
  handleClose?: () => void;
  callback: ({
    password,
    verificationCode,
  }: {
    password: string;
    verificationCode: string;
    email: string;
  }) => void;
  error: boolean;
  email: string;
}

const BoldText = styled(Box)`
  font-weight: 700;
`;

const ConfirmUpdatePasswordCode = ({
  handleBack,
  handleClose,
  callback,
  error,
  email,
}: ConfirmUpdatePasswordCodeProps) => {
  const [verificationCode, setVerificationCode] = useState('');
  const [password, setPassword] = useState('');
  const [errorPassword, setErrorPassword] = useState(false);

  const [isDisabled, setIsDisabled] = useState(true);

  const handleOnChange = (value: string) => {
    setVerificationCode(() => value);
  };

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (callback) callback({ password, verificationCode, email });
  };

  const { handleOnChange: handleOnChangeValidationPass } = useValidator({
    formData: { password },
    validator: CONFIRM_UPDATE_PASSWORD_CODE_VALIDATIONS,
    callback: (e) => {
      setErrorPassword(!!e?.password);
    },
  });

  return (
    <AuthLayout handleClose={handleClose} handleBack={handleBack}>
      <AuthHeader title="Actualizar contraseña" />
      <Box margin="1.5rem 0" width="100%" textAlign="left">
        <Text>
          Ingresá el código de verificación que recibiste por correo electrónico
          en <BoldText component="span">{email}</BoldText> <br /> Si no
          recibiste el código en tu bandeja de entrada, revisá el correo no
          deseado o Spam.
        </Text>
      </Box>
      <Box width="100%">
        <InputVerficitacionCode
          onChange={handleOnChange}
          hasError={error}
          onComplete={setIsDisabled}
        />
      </Box>
      <Box margin="1.5rem 0" width="100%" textAlign="left">
        <Text margin="1.5rem 0">
          Creá tu nueva contraseña, utilizá 8 caracteres como mínimo.
        </Text>
      </Box>
      <StyledForm onSubmit={onSubmit}>
        <InputPassword
          error={password.length > 3 && errorPassword}
          value={password}
          onChange={(event) => {
            setPassword(event.target.value);
            handleOnChangeValidationPass({ password: event.target.value });
          }}
          fullWidth
          label="Contraseña"
          id="password"
          name="password"
          helperText={
            password.length > 3 && errorPassword
              ? 'Utilizá 8 caracteres para tu contraseña.'
              : ''
          }
        />
        <AAbuton
          type="submit"
          sx={{
            marginTop: '2.5rem',
          }}
          fullWidth
          disabled={isDisabled || errorPassword}
        >
          Crear nueva contraseña
        </AAbuton>
      </StyledForm>
      <Box marginTop="1rem">
        <HelpLink />
      </Box>
    </AuthLayout>
  );
};

export default ConfirmUpdatePasswordCode;
