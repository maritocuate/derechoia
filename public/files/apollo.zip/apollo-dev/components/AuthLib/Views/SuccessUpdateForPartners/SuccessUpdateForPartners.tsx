import React from 'react';
import Link from 'next/link';
import { Box } from '@mui/material';
import AuthLayout from '../../Wrappers/AuthLayout';
import SuccessBroSVG from '../../Components/SVG/SuccessBroSVG';
import AAbuton from '../../Components/Buttons/AAButton';
import Title from '../../Components/Text/Title';
import Text from '../../Components/Text/Typography';

const SuccessUpdateForPartners = ({
  linkPanel,
  handleClose,
  handleContinue,
}: {
  linkPanel: string;
  handleClose?: () => void;
  handleContinue: () => void;
}) => {
  return (
    <AuthLayout handleClose={handleClose}>
      <SuccessBroSVG />
      <Title marginTop="2.5rem">¡Contraseña actualizada!</Title>
      <Text marginTop="1.5rem">
        Gracias por actualizar la contraseña, ya podés ingresar al sitio con
        mayor seguridad.
      </Text>
      <Box width="100%" marginTop="2.5rem">
        <Box
          onClick={() => {
            if (handleClose) handleClose();
          }}
        >
          <Link passHref href={linkPanel}>
            <AAbuton fullWidth>Ingresar al panel</AAbuton>
          </Link>
        </Box>
        <Box margin="1rem 0 2.5rem 0" onClick={handleContinue}>
          <AAbuton variant="outlined" fullWidth>
            Continuar al sitio
          </AAbuton>
        </Box>
      </Box>
    </AuthLayout>
  );
};

export default SuccessUpdateForPartners;
