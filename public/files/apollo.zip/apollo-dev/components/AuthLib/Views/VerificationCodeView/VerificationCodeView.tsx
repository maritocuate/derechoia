import React, { FormEvent, useState } from 'react';
import { Box, Typography, styled } from '@mui/material';
import AAbuton from '../../Components/Buttons/AAButton';
import Title from '../../Components/Text/Title';
import AuthLayout from '../../Wrappers/AuthLayout';
import InputVerficitacionCode from '../../Components/InputVerificationCode/InputVerificationCode';
import Logo from '../../Components/Logo/Logo';
import { StyledForm } from '../SIngIn/SingIn';

interface VerificationViewProps {
  handleBack?: () => void;
  handleClose?: () => void;
  onClick: (newValue: string) => Promise<void>;
  email: string;
  error: boolean;
  isLoadingButton: boolean;
}
const StyledTypography = styled(Typography)`
  whitespace: pre-wrap;
  word-wrap: break-word;
`;

const VerificationCodeView = ({
  handleBack,
  onClick,
  handleClose,
  email,
  isLoadingButton,
  error = false,
}: VerificationViewProps) => {
  const [verificationCode, setVerificationCode] = useState('');
  const [isDisabled, setIsDisabled] = useState(true);
  const handleOnChange = (value: string) => {
    setVerificationCode(() => value);
  };
  const handleOnClick = (event: FormEvent) => {
    event.preventDefault();
    onClick(verificationCode).then(
      () => {},
      () => {},
    );
  };
  return (
    <AuthLayout handleClose={handleClose} handleBack={handleBack}>
      <Logo />
      <Title marginTop="2.5rem">
        Verificar dirección de correo electrónico
      </Title>
      <Box width="100%" textAlign="left" margin="1.5rem 0">
        <StyledTypography variant="paragraph">
          Ingresá el código de verificación que recibiste por correo electrónico
          en <strong>{email}</strong> Si no recibiste el código en tu bandeja de
          entrada, revisá el correo no deseado o Spam.
        </StyledTypography>
      </Box>
      <StyledForm onSubmit={handleOnClick}>
        <InputVerficitacionCode
          onChange={handleOnChange}
          hasError={error}
          onComplete={setIsDisabled}
        />
        <AAbuton
          type="submit"
          sx={{
            marginTop: '2.5rem',
          }}
          fullWidth
          disabled={isDisabled || isLoadingButton}
        >
          Verificar correo electrónico
        </AAbuton>
      </StyledForm>
    </AuthLayout>
  );
};

export default VerificationCodeView;
