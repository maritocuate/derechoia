/* eslint-disable @typescript-eslint/no-misused-promises */
import React, { FormEvent, useState } from 'react';
import { Box, TextField, styled } from '@mui/material';
import AAButton from '../../Components/Buttons/AAButton';
import AuthLayout from '../../Wrappers/AuthLayout';
import Text from '../../Components/Text/Typography';
import AuthHeader from '../../Components/AuthHeader/AuthHeader';
import useValidator from '../../Hooks/useValidator/useValidator';
import { UPDATE_PASSWORD_VALIDATIONS } from './UpdatePasswordValidations';
import { StyledForm } from '../SIngIn/SingIn';
import HelpLink from '../../Components/HelpLink/HelpLink';

export interface IEnterPassword {
  email: string;
  newAnfitrion: boolean;
  callback: (email: string) => Promise<void>;
  handleBack: () => void;
  handleClose?: () => void;
}

const StyledButton = styled(AAButton)`
  margin-top: 1rem;
`;

const StyledText = styled(Text)`
  text-align: left;
`;

export default function UpdatePassword({
  email,
  callback,
  handleBack,
  handleClose,
  newAnfitrion,
}: IEnterPassword) {
  const [inputEmail, setEmail] = useState(email || '');
  const [errorEmail, setErrorEmail] = useState(false);

  const onSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (callback) {
      await callback(email);
    }
  };

  const { handleOnChange } = useValidator({
    formData: { inputEmail },
    validator: UPDATE_PASSWORD_VALIDATIONS,
    callback: (e) => {
      setErrorEmail(!!e?.inputEmail);
    },
  });

  return (
    <AuthLayout handleBack={handleBack} handleClose={handleClose}>
      <AuthHeader
        title={
          newAnfitrion ? 'Actualizar contraseña' : '¿Olvidaste la contraseña?'
        }
      />
      <Box width="100%" textAlign="left">
        <Box margin="1rem 0 1rem 0">
          {newAnfitrion ? (
            <StyledText margin="1rem 0 1rem 0">
              Hemos mejorado la seguridad de la cuenta, por lo que necesitamos
              que crees una nueva contraseña. Te enviaremos un código de
              verificación por correo electrónico para actualizarla. <br />{' '}
              <br />
              Si no recibiste el código en tu bandeja de entrada, revisá el
              correo no deseado o Spam.
            </StyledText>
          ) : (
            <StyledText margin="1rem 0 1rem 0">
              ¡No pasa nada! Podemos enviarte un código de verificacion para
              restablecer la contraseña. Ingresa el correo electrónico de la
              cuenta. <br /> <br />
              Te enviaremos un código de verificación por correo electrónico
              para actualizarla. Si no recibiste el código en tu bandeja de
              entrada, revisá el correo no deseado o Spam.
            </StyledText>
          )}
        </Box>
      </Box>
      <StyledForm onSubmit={onSubmit}>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          id="email"
          label="Correo electrónico"
          type="email"
          name="email"
          error={errorEmail}
          helperText={errorEmail ? 'Correo electrónico inválido' : ''}
          autoComplete="email"
          autoFocus
          value={inputEmail}
          onChange={(event) => {
            setEmail(event.target.value);
            if (event.target.value) {
              handleOnChange({ email: event.target.value });
            }
          }}
        />
        <StyledButton fullWidth disabled={errorEmail} type="submit">
          Enviar código de verificación
        </StyledButton>
      </StyledForm>
      <Box marginTop="1rem">
        <HelpLink />
      </Box>
    </AuthLayout>
  );
}
