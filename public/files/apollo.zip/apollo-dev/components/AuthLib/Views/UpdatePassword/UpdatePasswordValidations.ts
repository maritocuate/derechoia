import { z } from 'zod';

export const UPDATE_PASSWORD_VALIDATIONS = z.object({
  email: z.string().email({
    message: 'Debe ser un email válido.',
  }),
});
