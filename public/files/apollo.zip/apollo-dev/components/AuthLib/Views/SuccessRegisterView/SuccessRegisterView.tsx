import React from 'react';
import { styled, Box } from '@mui/material';
import AuthLayout from '../../Wrappers/AuthLayout';
import SeeYouSoonSVG from '../../Components/SVG/SeeYouSoonSVG';
import AAbuton from '../../Components/Buttons/AAButton';
import Title from '../../Components/Text/Title';
import Text from '../../Components/Text/Typography';

const StyledSuccesContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 32.75rem;
`;

const SuccessUpdatePassword = ({
  handleButton,
  handleClose,
  onClickPanel,
  linkPanel,
}: {
  handleButton: () => void;
  handleClose?: () => void;
  onClickPanel: () => void;
  linkPanel?: string;
}) => {
  return (
    <AuthLayout hiddenFooter handleClose={handleClose}>
      <StyledSuccesContainer>
        <SeeYouSoonSVG />
        <Title marginTop="2.5rem">¡Te damos la bienvenida!</Title>
        <Text marginTop="1.5rem">
          Disfrutá de viajar con Alquiler Argentina, descubrí alojamientos en
          todo el país para hospedarte en tu próximo destino.
        </Text>
        <Box width="100%">
          {linkPanel && (
            <Box onClick={onClickPanel} marginTop="1.5rem">
              <AAbuton fullWidth>Ingresar al panel</AAbuton>
            </Box>
          )}
          <Box
            onClick={() => {
              handleButton();
              if (handleClose) handleClose();
            }}
          >
            <AAbuton
              variant={linkPanel ? 'outlined' : 'contained'}
              sx={{
                marginTop: '1.5rem',
              }}
              fullWidth
            >
              Continuar al sitio
            </AAbuton>
          </Box>
        </Box>
      </StyledSuccesContainer>
    </AuthLayout>
  );
};

export default SuccessUpdatePassword;
