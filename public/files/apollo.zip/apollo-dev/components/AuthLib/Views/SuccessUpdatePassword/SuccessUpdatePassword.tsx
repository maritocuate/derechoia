import React from 'react';
import { Box } from '@mui/material';
import AuthLayout from '../../Wrappers/AuthLayout';
import SuccessBroSVG from '../../Components/SVG/SuccessBroSVG';
import AAbuton from '../../Components/Buttons/AAButton';
import Title from '../../Components/Text/Title';
import Text from '../../Components/Text/Typography';

const SuccessUpdatePassword = ({
  handleClose,
  handleContinue,
}: {
  handleClose?: () => void;
  handleContinue: () => void;
}) => {
  return (
    <AuthLayout handleClose={handleClose}>
      <SuccessBroSVG />
      <Title marginTop="2.5rem">¡Contraseña actualizada!</Title>
      <Text marginTop="1.5rem">
        Ahora podés buscar alojamiento para tu próximo destino, esperamos que
        disfrutes de viajar con Alquiler Argentina.
      </Text>
      <Box width="100%" onClick={handleContinue}>
        <AAbuton
          sx={{
            marginTop: '2.5rem',
          }}
          fullWidth
        >
          Continuar al sitio
        </AAbuton>
      </Box>
    </AuthLayout>
  );
};

export default SuccessUpdatePassword;
