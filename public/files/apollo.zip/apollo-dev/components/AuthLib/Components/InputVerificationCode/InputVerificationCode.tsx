import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Box, BoxProps, Input, Typography, styled } from '@mui/material';

const ACTIVE = 'rgba(75, 190, 197, 1)';
const INACTIVE = 'rgba(0, 0, 0, 0.12)';

const handleKeyDown = (
  event: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>,
) => {
  if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) {
    // do not allow to change cursor position
    event.preventDefault();
  }
};
interface StyledInputCodeItemProps extends BoxProps {
  styledbordercolor: string;
}
interface InputVerficitacionCodeProps {
  onChange: (value: string) => void;
  hasError: boolean;
  validChars?: string;
  placeHolder?: string;
  onComplete?: (value: boolean) => void;
  autoFocus?: boolean;
}

const StyledInputCodeItem = styled(Box)(
  ({ styledbordercolor }: StyledInputCodeItemProps) => `
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.87rem;
  height: 4rem;
  border: 1px solid ${styledbordercolor};
  border-radius: 4px;
  cursor: pointer;
`,
);

const InputVerficitacionCode = ({
  onChange,
  hasError = false,
  placeHolder = '-',
  validChars = '0-9',
  onComplete,
  autoFocus = true,
}: InputVerficitacionCodeProps) => {
  const [localValue, setLocalValue] = useState('');
  const [isActive, setActive] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const newValue = event.target.value.replace(/\s/g, '');

      if (RegExp(`^[${validChars}]{0,${6}}$`).test(newValue)) {
        setLocalValue(() => newValue);
      }
    },
    [validChars],
  );

  useEffect(() => {
    if (localValue.length === 6) {
      onComplete?.(false);
      onChange(localValue);
    } else {
      onComplete?.(true);
    }
  }, [localValue, onChange, onComplete]);
  useEffect(() => {
    if (autoFocus) {
      inputRef.current?.focus();
      setActive(() => true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const isColor = useCallback(
    (inputIndex: number) => {
      if (hasError) return '#D32F2F';
      if (inputIndex !== 0 && localValue.length === inputIndex && isActive) {
        return ACTIVE;
      }
      return INACTIVE;
    },
    [hasError, isActive, localValue.length],
  );
  return (
    <Box>
      <Input
        inputProps={{ maxLength: 6, hidden: true }}
        onKeyDown={handleKeyDown}
        value={localValue}
        inputRef={inputRef}
        onChange={handleInputChange}
        sx={{ position: 'absolute', top: 0, zIndex: -111 }}
      />
      <Box>
        <Box
          display="flex"
          bgcolor="white"
          gap="1rem"
          width="100%"
          onClick={() => {
            inputRef.current?.focus();
            setActive(() => true);
          }}
        >
          {[...(Array(6) as unknown[])].map((_, inputIndex) => (
            <StyledInputCodeItem
              display="flex"
              key={`inputVerificationCodeBox-${inputIndex}`}
              styledbordercolor={isColor(inputIndex)}
              ml={inputIndex === 3 ? '.2rem' : undefined}
            >
              <Typography variant="authTitle">
                {inputIndex !== 0 &&
                localValue.length === inputIndex &&
                isActive
                  ? ''
                  : localValue[inputIndex] || placeHolder}
              </Typography>
            </StyledInputCodeItem>
          ))}
        </Box>
      </Box>
      {hasError && (
        <Typography marginTop={0.75} fontSize="0.75rem" color="#D32F2F">
          Código incorrecto. Hemos enviado un nuevo código a tu correo
          electrónico para que ingreses.
        </Typography>
      )}
    </Box>
  );
};
export default InputVerficitacionCode;
