import React from 'react';
import { render, screen } from '@testing-library/react';
import Typography from './Typography';
import '@testing-library/jest-dom';

describe('Typography test', () => {
  test('It render Typography With children', () => {
    render(<Typography>Typography</Typography>);
    const component = screen.getByText('Typography');
    expect(component).toBeTruthy();
  });
});
