import React, { ReactNode } from 'react';
import { Typography, TypographyProps } from '@mui/material';

type Props = {
  children: ReactNode;
} & TypographyProps;

const Title = ({ children, ...props }: Props) => {
  return (
    <Typography
      variant="authTitle"
      textAlign="center"
      {...props}
      data-testid="Title"
    >
      {children}
    </Typography>
  );
};

export default Title;
