import React, { ReactNode } from 'react';
import { Typography, TypographyProps, styled } from '@mui/material';

type Props = {
  children: ReactNode;
} & TypographyProps;

const StyledTypography = styled(Typography)`
  text-align: center;
`;

const Text = ({ children, ...props }: Props) => {
  return (
    <StyledTypography variant="paragraph" {...props}>
      {children}
    </StyledTypography>
  );
};

export default Text;
