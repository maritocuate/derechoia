import React from 'react';
import { render, screen } from '@testing-library/react';
import Title from './Title';
import '@testing-library/jest-dom';

describe('Title test', () => {
  test('It render Typography With children', () => {
    render(<Title>Title</Title>);
    const component = screen.getByText('Title');
    expect(component).toBeTruthy();
  });
});
