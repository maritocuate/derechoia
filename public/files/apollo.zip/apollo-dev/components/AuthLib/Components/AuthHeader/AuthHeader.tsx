import React from 'react';
import { Box, styled } from '@mui/material';
import AlquilerArgentinaLogo from '../SVG/AlquilerArgentinaLogo';
import Title from '../Text/Title';

const StyledHeaderContainer = styled(Box)`
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.2rem;
`;

const AuthHeader = ({ title }: { title?: string }) => {
  return (
    <StyledHeaderContainer>
      <AlquilerArgentinaLogo />
      {title && <Title>{title}</Title>}
    </StyledHeaderContainer>
  );
};

export default AuthHeader;
