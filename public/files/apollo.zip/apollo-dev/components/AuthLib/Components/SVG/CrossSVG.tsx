import React, { SVGProps } from 'react';

const CrossSVG = (props: SVGProps<SVGSVGElement>) => {
  const { fill, width, height } = props;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width || 12}
      height={height || 12}
      {...props}
    >
      <path
        fill={fill || '#000'}
        fillOpacity={0.87}
        d="M11.833 1.342 10.658.167 6 4.825 1.342.167.167 1.342 4.825 6 .167 10.658l1.175 1.175L6 7.175l4.658 4.658 1.175-1.175L7.175 6l4.658-4.658Z"
      />
    </svg>
  );
};
export default CrossSVG;
