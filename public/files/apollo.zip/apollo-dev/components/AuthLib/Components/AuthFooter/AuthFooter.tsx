import React from 'react';
import { Link, Typography, styled } from '@mui/material';

const StyledFooter = styled(Typography)`
  font-size: 14px;
  text-align: center;
  margin-block: 3%;
  margin-top: 1rem;
  color: #707070;
`;

const AuthFooter = () => {
  return (
    <StyledFooter>
      Al iniciar sesión o crear una cuenta, estás aceptando los
      <Link
        marginLeft=".2rem"
        target="_blank"
        underline="always"
        href="https://www.alquilerargentina.com/terminos-condiciones.html"
      >
        Términos y condiciones
      </Link>
      .
    </StyledFooter>
  );
};

export default AuthFooter;
