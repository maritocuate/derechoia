import React from 'react';
import { Typography } from '@mui/material';

const TOSRegister = () => {
  return (
    <Typography variant="small">
      {/* Al seleccionar aceptar y continuar, acepto los{' '}
      <Typography variant="small"> Términos y condiciones</Typography> y
      reconozco la{' '}
      <Typography variant="small">Política de privacidad</Typography>. */}
    </Typography>
  );
};

export default TOSRegister;
