import Image from 'next/image';
import React, { memo } from 'react';

interface ILogo {
  width?: number;
  height?: number;
}

const Logo = ({ width, height }: ILogo) => {
  return (
    <Image
      width={width || 48}
      height={height || 44}
      src={`${process.env.NEXT_PUBLIC_IMAGE_CDN || '/'}_img_/isologo.png?w=48`}
      alt="Logo AA"
    />
  );
};

export default memo(Logo);
