import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import InputPassword from './InputPassword';

describe('BackButton test', () => {
  test('It render BackButton', () => {
    render(<InputPassword />);
    const component = screen.getByTestId('InputPassword');
    expect(component).toBeTruthy();
  });
  test('It render BackButton with variant transparent', () => {
    render(<InputPassword value="password" />);
    const input = screen.getByRole('textbox') as HTMLInputElement | null;
    expect(input && input.value).toBe('password');
  });
});
