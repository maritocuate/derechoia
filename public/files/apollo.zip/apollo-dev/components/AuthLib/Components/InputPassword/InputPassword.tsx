import React, { useState, memo } from 'react';
import TextField, { TextFieldProps } from '@mui/material/TextField';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const InputPassword = (props: TextFieldProps) => {
  const [showPassword, setShowPassword] = useState(false);
  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };
  const showPasswordIcon = {
    endAdornment: (
      <InputAdornment position="end">
        <IconButton onClick={handleClickShowPassword}>
          {showPassword ? <VisibilityIcon /> : <VisibilityOffIcon />}
        </IconButton>
      </InputAdornment>
    ),
  };
  const defaultProps = {
    inputProps: {
      type: showPassword ? 'text' : 'password',
      role: 'textbox',
    },
    InputProps: showPasswordIcon,
    ...props,
  };

  return <TextField data-testid="InputPassword" {...defaultProps} />;
};

export default memo(InputPassword);
