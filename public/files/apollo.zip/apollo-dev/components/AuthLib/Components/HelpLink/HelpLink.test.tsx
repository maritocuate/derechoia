import React from 'react';
import { render } from '@testing-library/react';
import HelpLink from './HelpLink';

test('El enlace tiene el href correcto', () => {
  const { getByText } = render(<HelpLink />);
  const link = getByText('Escribir por Whatsapp') as HTMLAnchorElement;
  expect(link.href).toBe('https://api.whatsapp.com/send?phone=5491152638215');
});
