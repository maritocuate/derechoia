import { Box, Link, Typography } from '@mui/material';
import React from 'react';

const HelpLink = () => {
  return (
    <Box display="flex" textAlign="center" flexDirection="column">
      <Box>
        <Typography fontSize={14}>¿Necesitas ayuda?</Typography>
      </Box>
      <Box>
        <Link
          fontSize={16}
          target="_blank"
          href="https://api.whatsapp.com/send?phone=5491152638215"
        >
          Escribir por Whatsapp
        </Link>
      </Box>
    </Box>
  );
};

export default HelpLink;
