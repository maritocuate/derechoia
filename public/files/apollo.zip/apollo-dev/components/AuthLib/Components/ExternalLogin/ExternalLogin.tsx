import React, { memo } from 'react';
import { Box, styled, Button } from '@mui/material';
import Image from 'next/image';
import Text from '../Text/Typography';

export interface IExternalLogin {
  onClickGoogle: () => void;
  onClickFacebook: () => void;
  isApp?: boolean;
}

const StyledButtonOutlined = styled(Button)`
  border: 1px solid rgba(0, 0, 0, 0.23) !important;
  height: 2.8rem;
`;

const StyledButtonText = styled(Text)`
  text-transform: none;
`;

const ExternalLogin = ({
  onClickGoogle,
  onClickFacebook,
  isApp,
}: IExternalLogin) => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      data-testid="ExternalLoginContainer"
      width="100%"
    >
      {!isApp && (
        <Box marginBottom="0.5rem">
          <StyledButtonOutlined
            data-testid="ExternalLoginFacebook"
            fullWidth
            variant="outlined"
            color="inherit"
            startIcon={
              <Image
                width={22}
                height={22}
                alt="start-icon"
                src="/images/facebookIconColor.png"
              />
            }
            size="large"
            onClick={onClickFacebook}
          >
            <StyledButtonText>Ingresar con Facebook</StyledButtonText>
          </StyledButtonOutlined>
        </Box>
      )}
      <Box>
        <StyledButtonOutlined
          data-testid="ExternalLoginGoogle"
          fullWidth
          variant="outlined"
          color="inherit"
          size="large"
          startIcon={
            <Image
              width={22}
              height={22}
              alt="start-icon"
              src="/images/googleIconColor.png"
            />
          }
          onClick={onClickGoogle}
        >
          <StyledButtonText>Ingresar con Google</StyledButtonText>
        </StyledButtonOutlined>
      </Box>
    </Box>
  );
};

export default memo(ExternalLogin);
