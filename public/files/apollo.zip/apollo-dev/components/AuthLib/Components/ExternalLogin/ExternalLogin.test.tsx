import React from 'react';
import { render, screen } from '@testing-library/react';
import ExternalLogin from './ExternalLogin';
import '@testing-library/jest-dom';

describe('ExternalLogin test', () => {
  test('It render ExternalLogin container', () => {
    render(
      <ExternalLogin onClickFacebook={() => {}} onClickGoogle={() => {}} />,
    );
    const component = screen.getByTestId('ExternalLoginContainer');
    expect(component).toBeTruthy();
  });

  test('It render ExternalLogin button facebook with onClick', () => {
    const mockOnClick = jest.fn();
    render(
      <ExternalLogin onClickFacebook={mockOnClick} onClickGoogle={() => {}} />,
    );
    const component = screen.getByTestId('ExternalLoginFacebook');
    component.click();
    expect(mockOnClick).toHaveBeenCalled();
  });

  test('It render ExternalLogin button Google with onClick', () => {
    const mockOnClick = jest.fn();
    render(
      <ExternalLogin onClickFacebook={() => {}} onClickGoogle={mockOnClick} />,
    );
    const component = screen.getByTestId('ExternalLoginGoogle');
    component.click();
    expect(mockOnClick).toHaveBeenCalled();
  });
});
