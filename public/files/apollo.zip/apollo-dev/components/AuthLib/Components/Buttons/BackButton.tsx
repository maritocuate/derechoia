/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { Button, styled } from '@mui/material';
import BackSVG from '../SVG/BackSVG';

interface IBackButton {
  variant?: 'contained' | 'transparent';
  handleBack?: () => void;
}

const StyledButtonRoot = styled(Button)(
  ({ buttonVariant }: { buttonVariant: 'contained' | 'transparent' }) => `
    background: ${
      buttonVariant === 'contained' ? 'rgba(0, 0, 0, 0.4)' : 'transparent'
    };
    border-radius: 4px;
    min-width: 28px;
    width: 28px;
    height: 28px;
    &:hover {
      background: ${
        buttonVariant === 'contained'
          ? 'rgba(0, 0, 0, 0.6)'
          : 'rgba(0, 0, 0, 0.2)'
      };
  `,
);
const BackButton = ({
  variant = 'contained',
  handleBack = () => {},
}: IBackButton) => (
  <StyledButtonRoot
    data-testid="BackButton"
    onClick={handleBack}
    buttonVariant={variant}
    color="inherit"
  >
    <BackSVG
      fill={variant === 'transparent' ? 'rgba(0, 0, 0, 0.54)' : 'white'}
      height={variant === 'transparent' ? 14 : 12}
      width={variant === 'transparent' ? 14 : 12}
    />
  </StyledButtonRoot>
);

export default BackButton;
