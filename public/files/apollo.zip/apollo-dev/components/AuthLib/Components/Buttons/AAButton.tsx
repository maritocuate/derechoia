import React, { ReactNode, memo } from 'react';
import { Button, ButtonProps, styled } from '@mui/material';

const StyledButton = styled(Button)`
  font-weight: 600;
  font-size: 0.9rem;
  line-height: 1.5rem;
  height: 3rem;
  padding: 0.6rem;
`;

type Props = {
  children?: ReactNode;
  onClick?: () => void;
  fullWidth?: boolean;
  variant?: 'outlined' | 'text' | 'contained';
} & ButtonProps;

const AAbuton = ({
  children,
  onClick,
  fullWidth,
  variant,
  ...props
}: Props) => {
  const handlePress = () => {
    if (onClick) onClick();
  };
  return (
    <StyledButton
      data-testid="AAButton"
      variant={variant || 'contained'}
      onClick={handlePress}
      sx={{
        fontWeight: 600,
        fontSize: '0.9rem',
        lineHeight: '1.5rem',
        padding: '.6rem',
      }}
      fullWidth={fullWidth}
      {...props}
    >
      {children}
    </StyledButton>
  );
};

export default memo(AAbuton);
