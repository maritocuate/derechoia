import React from 'react';
import { render, screen } from '@testing-library/react';
import BackButton from './BackButton';
import '@testing-library/jest-dom';

describe('BackButton test', () => {
  test('It render BackButton', () => {
    render(<BackButton />);
    const component = screen.getByTestId('BackButton');
    expect(component).toBeTruthy();
  });
  test('It render BackButton with variant transparent', () => {
    render(<BackButton variant="transparent" />);
    const component = screen.getByTestId('BackButton');
    expect(component).toBeTruthy();
  });

  test('It render BackButton with variant transparent and onClick', () => {
    const mockOnClick = jest.fn();
    render(<BackButton variant="transparent" handleBack={mockOnClick} />);
    const component = screen.getByTestId('BackButton');
    component.click();
    expect(mockOnClick).toHaveBeenCalled();
  });
});
