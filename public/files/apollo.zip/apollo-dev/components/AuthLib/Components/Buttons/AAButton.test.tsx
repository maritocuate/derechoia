import React from 'react';
import { render, screen } from '@testing-library/react';
import AAbuton from './AAButton';
import '@testing-library/jest-dom';

describe('AAButton test', () => {
  test('It render AAButton without children', () => {
    render(<AAbuton />);
    const component = screen.getByTestId('AAButton');
    expect(component).toBeTruthy();
  });

  test('It render AAButton with children', () => {
    render(<AAbuton>Test</AAbuton>);
    const component = screen.getByText('Test');
    expect(component).toBeTruthy();
  });

  test('It render AAButton with outlined variant', () => {
    render(<AAbuton variant="outlined">Outlined Button</AAbuton>);
    const component = screen.getByText('Outlined Button');
    expect(component).toHaveClass('MuiButton-outlined');
  });

  test('It render AAButton with onClick', () => {
    const mockOnClick = jest.fn();
    render(<AAbuton onClick={mockOnClick}>Test</AAbuton>);
    const component = screen.getByTestId('AAButton');
    component.click();
    expect(mockOnClick).toHaveBeenCalled();
  });
});
