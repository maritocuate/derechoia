import React from 'react';
import { render, screen } from '@testing-library/react';
import CloseButton from './CloseButton';
import '@testing-library/jest-dom';

describe('CloseButton test', () => {
  test('It render CloseButton', () => {
    render(<CloseButton />);
    const component = screen.getByTestId('CloseButton');
    expect(component).toBeTruthy();
  });
  test('It render CloseButton with variant transparent', () => {
    render(<CloseButton variant="transparent" />);
    const component = screen.getByTestId('CloseButton');
    expect(component).toBeTruthy();
  });

  test('It render CloseButton with variant transparent and onClick', () => {
    const mockOnClick = jest.fn();
    render(<CloseButton variant="transparent" handleClose={mockOnClick} />);
    const component = screen.getByTestId('CloseButton');
    component.click();
    expect(mockOnClick).toHaveBeenCalled();
  });
});
