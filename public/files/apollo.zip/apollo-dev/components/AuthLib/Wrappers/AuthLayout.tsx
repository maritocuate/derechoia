import React, { ReactNode } from 'react';
import { Box, styled } from '@mui/material';
import AuthFooter from '../Components/AuthFooter/AuthFooter';
import CloseButton from '../Components/Buttons/CloseButton';
import BackButton from '../Components/Buttons/BackButton';

const StyledLayoutContainer = styled(Box)`
  background-color: white;
  width: 100%;
  padding: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  position: relative;
`;
const StyledContentContainer = styled(Box)`
  margin-top: 2rem;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
  height: fit-content;
`;

const StyledCloseButtonContainer = styled(Box)`
  position: absolute;
  top: 1rem;
  right: 1rem;
`;

const StyledBackButtonContainer = styled(Box)`
  position: absolute;
  top: 1rem;
  left: 1rem;
`;

const AuthLayout = ({
  children,
  handleClose,
  handleBack,
  hiddenFooter = false,
}: {
  children: ReactNode;
  handleClose?: () => void;
  handleBack?: () => void;
  hiddenFooter?: boolean;
}) => {
  return (
    <StyledLayoutContainer maxWidth={handleClose ? '100%' : '22.5rem'}>
      <StyledCloseButtonContainer>
        {handleClose && (
          <CloseButton variant="transparent" handleClose={handleClose} />
        )}
      </StyledCloseButtonContainer>
      <StyledBackButtonContainer>
        {handleBack && (
          <BackButton variant="transparent" handleBack={handleBack} />
        )}
      </StyledBackButtonContainer>
      <StyledContentContainer>{children}</StyledContentContainer>
      {!hiddenFooter && <AuthFooter />}
    </StyledLayoutContainer>
  );
};

export default AuthLayout;
