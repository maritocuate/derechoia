export const PANEL_CLIENTE = process.env.NEXT_PUBLIC_URL_CLIENTES || '';
export const PANEL_ADMIN = process.env.NEXT_PUBLIC_URL_PDC || '';
