export type FormError = {
  [key: string]: string;
};
