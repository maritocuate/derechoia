import { useCallback, useRef, useState } from 'react';
import { ZodObject, ZodRawShape } from 'zod';
import { FormError } from './types';
import { FormErrors, hasFormErrors } from '../../Utils/formUtils/hasFormErrors';

type TUseValidatorProps = {
  formData?: {
    [key: string]: string;
  };
  validator: ZodObject<ZodRawShape>;
  callback?: (errors: FormErrors) => void;
  delay?: number;
};

const useValidator = ({
  validator,
  callback = () => {},
  delay = 700,
}: TUseValidatorProps) => {
  const [errors, setErrors] = useState({});
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const handleOnChangeValidate = useCallback(
    (newDataForm: TUseValidatorProps['formData'] | null) => {
      if (!newDataForm) return setErrors({});
      if (timerRef.current) clearTimeout(timerRef.current);
      const formDataToSet = { ...newDataForm };
      const formsErrors = hasFormErrors(newDataForm, validator);

      const managableErrors: FormError = {};

      Object.keys(formsErrors).forEach((key: string) => {
        if (formDataToSet[key]) managableErrors[key] = formsErrors[key];
      });
      timerRef.current = setTimeout(() => {
        if (formsErrors) {
          callback(formsErrors);
          setErrors(managableErrors);
          return;
        }
        setErrors(formsErrors);
      }, delay);
    },
    [callback, delay, validator],
  );
  return { errors, handleOnChange: handleOnChangeValidate };
};

export default useValidator;

/* 

casos

contraseña
email 
y objeto de errores
*/
