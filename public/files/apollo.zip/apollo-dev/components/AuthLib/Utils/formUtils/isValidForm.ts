type TFormData = {
  [key: string]: string;
};

type TFormErrors = {
  [key: string]: string;
};

export const isValidForm = ({
  formData,
  errors,
}: {
  formData: TFormData;
  errors: TFormErrors;
}) => {
  const formValues = Object.values(formData);
  const errorsValues = Object.values(errors);

  const hasErrors = errorsValues.some((error) => !!error);
  const hasEmptyFields = formValues.some((value) => !value);

  return !hasErrors && !hasEmptyFields;
};
