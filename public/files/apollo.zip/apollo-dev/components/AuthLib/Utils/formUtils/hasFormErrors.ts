/* eslint-disable @typescript-eslint/naming-convention */
import { ZodError, ZodObject, ZodRawShape } from 'zod';

type FormData = {
  [key: string]: string;
};

export type FormErrors = {
  [key: string]: string;
};

type Validator = ZodObject<ZodRawShape>;

type THasFormErrors = (formData: FormData, validator: Validator) => FormData;

type TZodError = {
  _errors?: string[];
  [key: string]: TZodError | string[] | undefined;
};

export const hasFormErrors: THasFormErrors = (formData, validator) => {
  try {
    validator.parse(formData);
    return {};
  } catch (error) {
    const zodError = error as ZodError;
    const formErrors: FormErrors = {};
    const zodErrors: TZodError = zodError.format();
    // eslint-disable-next-line no-underscore-dangle
    delete zodErrors._errors;

    Object.keys(zodErrors).forEach((key) => {
      const { _errors } = zodErrors[key] as TZodError;
      if (!_errors?.length) return {};

      const [firstError] = _errors;

      if (firstError) formErrors[key] = firstError;
    });

    return formErrors;
  }
};
