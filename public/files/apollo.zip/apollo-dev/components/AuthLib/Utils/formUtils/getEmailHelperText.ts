interface Errors {
  [key: string]: string | undefined;
}

export function getEmailHelperText(
  email: string,
  errors: Errors,
  hasError: boolean,
): string {
  if (email.length > 0 && errors.email === 'Debe ser un email válido.') {
    return errors.email;
  }
  if (hasError) {
    return 'Email ya registrado';
  }
  return '';
}
