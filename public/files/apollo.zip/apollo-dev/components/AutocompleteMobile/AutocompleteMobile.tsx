import React, { memo, useCallback, useState } from 'react';
import dynamic from 'next/dynamic';
import Typography from '@mui/material/Typography';
import Tooltip from '@alquiler-argentina/demiurgo/components/Tooltip';
import { textDestinationFormatter } from '../Search/utils/helpers';
import { IOption } from '../../redux/search/type';
import { AutoCompleteProps } from '../Search/components/Autocomplete/index.type';
import ItemContainer from '../Search/components/ItemContainer/ItemContainer';
import useUserSession from '../../hooks/userSession/useUserSession';
import { Modal } from './components/Modal/Modal';

const AutocompleteMobileCore = dynamic(
  () => import('./components/AutocompleteMobileCore/AutocompleteMobileCore'),
);

function AutocompleteMobile({
  value,
  inputValue,
  options,
  setValue,
  setInputValue,
  lastsDestination,
  inputSearchValue,
  clearInputValue,
  tooltip,
  topDestinations,
}: AutoCompleteProps) {
  const [isOpen, setIsOpen] = useState(false);
  const handleSelectSuggestion = useCallback(
    (option: IOption) => {
      setValue(option, option.groupText !== 'Búsquedas recientes');
      setIsOpen(false);
    },
    [setValue],
  );
  const { logedText } = useUserSession();
  return (
    <>
      <ItemContainer
        label="Destino"
        onClick={() => setIsOpen(true)}
        isAutoComplete
        borderPosition="bottom"
      >
        <Tooltip
          title="Ingresá un destino para empezar a buscar"
          open={!!tooltip}
          arrow
          placement="top"
          variant="secondary"
          sx={{
            '& .MuiTooltip-tooltip': {
              mt: '.275rem !important',
              maxWidth: '8rem !important',
              mb: '.625rem !important',
            },
            zIndex: '12',
          }}
        >
          <Typography
            onClick={() => setInputValue(undefined, '', 'input')}
            fontWeight={600}
            color={!textDestinationFormatter(value) ? 'GrayText' : 'inherit'}
          >
            {textDestinationFormatter(value) || logedText}
          </Typography>
        </Tooltip>
      </ItemContainer>
      <Modal open={isOpen}>
        {isOpen && (
          <AutocompleteMobileCore
            setIsOpen={setIsOpen}
            logedText={logedText}
            handleSelectSuggestion={handleSelectSuggestion}
            inputValue={inputValue}
            options={options}
            setInputValue={setInputValue}
            lastsDestination={lastsDestination}
            inputSearchValue={inputSearchValue}
            clearInputValue={clearInputValue}
            topDestinations={topDestinations}
          />
        )}
      </Modal>
    </>
  );
}
export default memo(AutocompleteMobile);
