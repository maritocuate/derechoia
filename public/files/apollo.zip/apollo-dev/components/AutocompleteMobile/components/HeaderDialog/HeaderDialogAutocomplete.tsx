import Close from '@mui/icons-material/Close';
import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import { AutocompleteMobileProps } from '../types';

const StyledHeaderDialog = styled(Box)`
  display: flex;
  width: 100%;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
`;

type HeaderDialogProps = Pick<AutocompleteMobileProps, 'setIsOpen'>;

const HeaderDialogAutocomplete = ({ setIsOpen }: HeaderDialogProps) => {
  return (
    <StyledHeaderDialog>
      <Typography variant="subtitle2" fontWeight={500}>
        Ingresá el destino
      </Typography>
      <Close
        fontSize="medium"
        color="action"
        onClick={() => setIsOpen(false)}
      />
    </StyledHeaderDialog>
  );
};

export default HeaderDialogAutocomplete;
