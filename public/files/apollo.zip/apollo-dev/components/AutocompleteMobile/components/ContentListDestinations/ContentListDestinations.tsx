import React, { HTMLAttributes } from 'react';
import dynamic from 'next/dynamic';
import { Box, Typography, UseAutocompleteRenderedOption } from '@mui/material';
import StyledLi from '../../../Search/components/Autocomplete/components/StyledLi/StyledLi';
import { IOption } from '../../../../redux/search/type';
import { textDestinationFormatter } from '../../../Search/utils/helpers';

const LocationOnOutlined = dynamic(
  () =>
    import('@mui/icons-material/LocationOnOutlined').then((res) => res.default),
  { ssr: false },
);

interface ContentListDestinationsProps {
  options: IOption[];
  onClick: (option: IOption) => void;
  listProps?: {
    getListboxProps: () => React.HTMLAttributes<HTMLUListElement>;
    getOptionProps: (
      renderedOption: UseAutocompleteRenderedOption<IOption>,
    ) => HTMLAttributes<HTMLLIElement>;
  };
}

export const ContentListDestinations = ({
  options,
  onClick,
  listProps,
}: ContentListDestinationsProps) => {
  return (
    <Box
      display="flex"
      flexDirection="column"
      width="100%"
      p="0 1rem 1rem 1rem"
      component="ul"
      {...listProps?.getListboxProps()}
    >
      {' '}
      {!options.length && <StyledLi>Sin resultados.</StyledLi>}
      {options.map((option, index) => (
        <Box key={index} onClick={() => onClick(option)}>
          <StyledLi {...listProps?.getOptionProps({ option, index })}>
            <LocationOnOutlined color="primary" />
            <Typography variant="autocompleteOptionMobile">
              {textDestinationFormatter(option)}
            </Typography>
          </StyledLi>
        </Box>
      ))}
    </Box>
  );
};
