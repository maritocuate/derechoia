import { IOption } from '../../../redux/search/type';
import { AutoCompleteProps } from '../../Search/components/Autocomplete/index.type';

type AutocompletePropsPick =
  | 'inputValue'
  | 'clearInputValue'
  | 'lastsDestination'
  | 'options'
  | 'setInputValue'
  | 'topDestinations'
  | 'inputSearchValue';

export interface AutocompleteMobileProps
  extends Pick<AutoCompleteProps, AutocompletePropsPick> {
  setIsOpen: (newValue: boolean) => void;
  logedText: string;
  handleSelectSuggestion: (newValue: IOption) => void;
}
