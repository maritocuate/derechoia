import React from 'react';
import dynamic from 'next/dynamic';
import {
  Box,
  IconButton,
  Typography,
  createFilterOptions,
  styled,
  useAutocomplete,
} from '@mui/material';
import TextField from '@mui/material/TextField';
import { ContentListDestinations } from '../ContentListDestinations/ContentListDestinations';
import { IOption } from '../../../../redux/search/type';
import { AutocompleteMobileProps } from '../types';
import DefaultSuggestion from '../DefaultSuggestion/DefaultSuggestion';

// import ContentListLastDestination from '../../../Search/components/Autocomplete/components/ContentListLastDestination/ContentListLastDestination';

const SearchOutlined = dynamic(() =>
  import('@mui/icons-material/SearchOutlined').then((res) => res.default),
);
const Close = dynamic(() =>
  import('@mui/icons-material/Close').then((res) => res.default),
);
const CloseOutlined = dynamic(() =>
  import('@mui/icons-material/CloseOutlined').then((res) => res.default),
);

const StyledHeaderDialog = styled(Box)`
  display: flex;
  width: 100%;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
`;
const filterOptions = createFilterOptions<IOption>({
  limit: 5,
});

const AutocompleteMobileCore = ({
  setIsOpen,
  logedText,
  inputValue,
  clearInputValue,
  lastsDestination,
  topDestinations,
  options,
  setInputValue,
  handleSelectSuggestion,
}: AutocompleteMobileProps) => {
  const {
    getRootProps,
    getInputProps,
    getListboxProps,
    getOptionProps,
    groupedOptions,
  } = useAutocomplete({
    id: 'use-autocomplete',
    options,
    filterOptions,
    getOptionLabel: (option) => option.nombre,
    inputValue,
    onInputChange: (_e, newInputValue) =>
      setInputValue(undefined, newInputValue, 'input'),
  });

  return (
    <>
      <StyledHeaderDialog>
        <Typography variant="subtitle2" fontWeight={500}>
          Ingresá el destino
        </Typography>
        <Close
          fontSize="medium"
          color="action"
          onClick={() => setIsOpen(false)}
        />
      </StyledHeaderDialog>
      <Box margin="1rem">
        <Box margin="0" {...getRootProps()}>
          <TextField
            label={logedText}
            fullWidth
            onChange={(e) => {
              return (
                setInputValue &&
                setInputValue(undefined, e.target.value, 'input')
              );
            }}
            inputProps={{
              endorment: !clearInputValue ? (
                <IconButton onClick={clearInputValue}>
                  <SearchOutlined />
                </IconButton>
              ) : (
                <IconButton onClick={clearInputValue}>
                  <CloseOutlined />
                </IconButton>
              ),
              ...getInputProps(),
            }}
          />
        </Box>
      </Box>
      {!!inputValue && (
        <ContentListDestinations
          options={groupedOptions as IOption[]}
          onClick={handleSelectSuggestion}
          listProps={{ getListboxProps, getOptionProps }}
        />
      )}

      {!inputValue && (
        <DefaultSuggestion
          lastsDestination={lastsDestination}
          topDestinations={topDestinations}
          handleSelectSuggestion={handleSelectSuggestion}
          setIsOpen={setIsOpen}
        />
      )}
    </>
  );
};

export default AutocompleteMobileCore;

/* 
-Mobile
- Impletementar :

DefaultSuggestion{
  - Ultimas Busquedas
  - Top Destinations
}
- Buscando

-Desktop logic


// Feature lógica
Usar el useAutocomplete de mui.
Aplicar las reglas de negocio para la suggestion.

// Moleculas
1-Crear HeaderDialog.
2-Crear ItemDestinationsMolecule.
3-Crear ItemLastDestinationMolecule.
4-Crear ModalAutocompleteMobile (AutoCompleteMobile).
5-Crear InputAutocompleteMolecule(AutocompleteMobileCore).
6-Crear ListDestinationsMolecule (AutocompleteMobileCore).

// Organismos
1-Crear en AutocompleteMobileCore

// Plantilla
1- AutoCompleteMobile

*/

/* COMPONENTE */

/*  {!inputValue && (
        <>
          {!!lastsDestination?.length && (
            <List
              title="Búsquedas recientes"
              content={[
                {
                  primaryContent: (
                    <ContentListLastDestination
                      onClick={(newDestination) => {
                        if (newDestination) {
                          handleSelectSuggestion(newDestination);
                        }
                        setIsOpen(false);
                      }}
                      lastDestinations={lastsDestination}
                    />
                  ),
                },
              ]}
              key="lastDestination"
            />
          )}
          {(!lastsDestination?.length || lastsDestination?.length === 1) && (
            <List
              title={
                <Typography variant="onlineBookintTitle">
                  Destinos más populares
                </Typography>
              }
              content={[
                {
                  primaryContent: (
                    <ContentListDestinations
                      options={options.filter((e) => e?.topDestination)}
                      onClick={handleSelectSuggestion}
                    />
                  ),
                },
              ]}
              key="popularDestination"
            />
          )}
        </>
      )} */
