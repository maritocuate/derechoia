import React from 'react';
import List from '@alquiler-argentina/demiurgo/components/List';
import { Typography } from '@mui/material';
import { ContentListDestinations } from '../ContentListDestinations/ContentListDestinations';
import ContentListLastDestination from '../../../Search/components/Autocomplete/components/ContentListLastDestination/ContentListLastDestination';
import { AutocompleteMobileProps } from '../types';

type Props =
  | 'topDestinations'
  | 'lastsDestination'
  | 'handleSelectSuggestion'
  | 'setIsOpen';

type DefaultSuggestionProps = Pick<AutocompleteMobileProps, Props>;

const DefaultSuggestion = ({
  lastsDestination = [],
  topDestinations = [],
  handleSelectSuggestion,
  setIsOpen,
}: DefaultSuggestionProps) => {
  return (
    <div>
      {!!lastsDestination?.length && (
        <List
          title="Búsquedas recientes"
          content={[
            {
              primaryContent: (
                <ContentListLastDestination
                  onClick={(newDestination) => {
                    if (newDestination) {
                      handleSelectSuggestion(newDestination);
                    } else {
                      setIsOpen(false);
                    }
                  }}
                  lastDestinations={lastsDestination}
                />
              ),
            },
          ]}
          key="lastDestination"
        />
      )}
      {(!lastsDestination?.length || lastsDestination?.length === 1) && (
        <List
          title={
            <Typography variant="onlineBookintTitle">
              Destinos más populares
            </Typography>
          }
          content={[
            {
              primaryContent: (
                <ContentListDestinations
                  options={topDestinations}
                  onClick={handleSelectSuggestion}
                />
              ),
            },
          ]}
          key="popularDestination"
        />
      )}
    </div>
  );
};

export default DefaultSuggestion;

/* 


  {!!lastsDestination?.length && (
            <List
              title="Búsquedas recientes"
              content={[
                {
                  primaryContent: (
                    <ContentListLastDestination
                      onClick={(newDestination) => {
                        if (newDestination) {
                          handleSelectSuggestion(newDestination);
                        }
                        setIsOpen(false);
                      }}
                      lastDestinations={lastsDestination}
                    />
                  ),
                },
              ]}
              key="lastDestination"
            />
          )}
          {(!lastsDestination?.length || lastsDestination?.length === 1) && (
            <List
              title={
                <Typography variant="onlineBookintTitle">
                  Destinos más populares
                </Typography>
              }
             
              key="popularDestination"
            />
          )}
        </AutocompleteMobileProps;>
      )}



*/
