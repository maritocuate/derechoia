import { Dialog, styled } from '@mui/material';

export const Modal = styled(Dialog)`
  & .MuiDialog-container {
    align-items: flex-end;
  }
  & .MuiDialog-container .MuiDialog-paper {
    margin: 0;
    border-radius: 8px 8px 0 0;
    width: 100%;
    height: 80%;
  }
`;
