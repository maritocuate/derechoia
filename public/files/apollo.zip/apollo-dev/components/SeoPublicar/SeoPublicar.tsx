/* eslint-disable @typescript-eslint/indent */
import React, { memo } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';

const GlobalStructuredData = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  url: 'https://www.alquilerargentina.com',
  logo: formatUrlWithCdnLink('/logoaa.png'),
  sameAs: [
    'https://www.facebook.com/alquilerargentina',
    'https://www.youtube.com/user/AlquilerArgentinaWeb',
    'https://twitter.com/AlqArgentina',
    'https://plus.google.com/+AlquilerargentinaWeb',
  ],
  contactPoint: [
    {
      '@type': 'ContactPoint',
      telephone: '+540810-888-0845',
      contactType: 'customer service',
    },
  ],
  address: [
    {
      '@type': 'PostalAddress',
      streetAddress: 'Lisandro de la Torre 101',
      addressLocality: 'Villa Carlos Paz',
      addressCountry: 'AR',
    },
  ],
};

const SeoPublicar = () => {
  const router = useRouter();
  const url = `${String(process.env.NEXT_PUBLIC_URL)}${router.asPath.replace(
    '/',
    '',
  )}`;

  return (
    <Head>
      <link
        rel="shortcut icon"
        href="https://www.alquilerargentina.com/imagenes/favicon.png"
        type="image/png"
      />
      <meta charSet="utf-8" />
      <meta name="og:locale" content="es_LA" />
      <meta
        name="og:title"
        content="Publica tu alojamiento en AlquilerArgentina.com - AlquilerArgentina"
      />
      <meta name="og:type" content="place" />
      <meta name="og:url" content={url} />
      <meta
        name="og:description"
        content="Alquiler temporario en Argentina. Encontrá los mejores alquileres temporarios para tus vacaciones: casas, departamentos, cabañas, complejos y más!"
      />
      <meta name="og:site_name" content="Alquiler Argentina" />
      <meta property="og:image" content={formatUrlWithCdnLink('/logoaa.png')} />
      <meta property="fb:app_id" content="193400040680800" />
      <meta property="fb:admins" content="100001734925397,777313376 " />
      <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
      <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"
      />
      <meta name="author" content="Alquiler Argentina" />
      <meta name="geo.region" content="AR" />
      <meta
        name="description"
        content="Alquiler temporario en Argentina. Encontrá los mejores alquileres temporarios para tus vacaciones: casas, departamentos, cabañas, complejos y más!"
      />
      <link rel="canonical" href={url} />
      <meta
        name="keywords"
        content="argentina, alquiler, alquileres, alojamiento, turismo, alojameintos, casas, departamentos, cabañas, complejos, apart, alquiler en argentina, alquilerargentina"
      />
      <script
        type="application/ld+json"
        // eslint-disable-next-line react/no-danger
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(GlobalStructuredData),
        }}
      />
      <title>
        Publica tu alojamiento en AlquilerArgentina.com - AlquilerArgentina
      </title>
    </Head>
  );
};

export default memo(SeoPublicar);
