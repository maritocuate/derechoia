import React from 'react';
import { Box, styled } from '@mui/material';
import CardAd from '../CardAd';
import { TFavouriteCardProps } from './types';

const StyledCloseContainer = styled(Box)`
  width: 100%;
  max-width: 53rem;
  height: fit-content;
`;

const FavoriteCard = ({
  titulo,
  nombre_localidad,
  es_destacado_gold,
  es_destacado,
  fotos,
  puntaje,
  precio_minimo_calculado,
  cantidadUnidades,
  capacidad_max,
  cant_puntaje,
  fecha_carga,
  cancelacion,
  referencia,
  foto_listado,
  link,
  personas, // personas se obtiene de redux no desde el backend
  es_troya,
  permite_reservas,
  tipo,
  imageWidthMobile,
  imageHeightMobile,
  isLoadingFav,
  handleFavorite,
  ofertas_flexibles = [],
  ofertas_um = [],
  porcentaje_oferta,
  precio_sin_descuento,
}: TFavouriteCardProps) => {
  return (
    <StyledCloseContainer>
      <CardAd
        isFav
        titulo={titulo}
        nombre_localidad={nombre_localidad}
        es_destacado_gold={es_destacado_gold}
        es_destacado={es_destacado}
        fotos={fotos}
        puntaje={puntaje}
        precio_minimo_calculado={precio_minimo_calculado}
        cantidadUnidades={cantidadUnidades}
        capacidad_max={capacidad_max}
        cant_puntaje={cant_puntaje}
        fecha_carga={fecha_carga}
        cancelacion={cancelacion}
        referencia={referencia}
        foto_listado={foto_listado}
        link={link}
        personas={personas}
        es_troya={es_troya}
        permite_reservas={permite_reservas}
        tipo={tipo}
        imageWidthMobile={imageWidthMobile}
        imageHeightMobile={imageHeightMobile}
        isLoadingFav={isLoadingFav}
        handleFavorite={() => {
          handleFavorite(referencia).catch(() => {});
        }}
        ofertas_flexibles={ofertas_flexibles}
        ofertas_um={ofertas_um}
        porcentaje_oferta={porcentaje_oferta}
        precio_sin_descuento={precio_sin_descuento}
      />
    </StyledCloseContainer>
  );
};

export default FavoriteCard;
