import { Foto, Ofertasflexible, Ofertasum } from '../../types/listado.type';

export type TFavouriteCardProps = {
  titulo: string;
  nombre_localidad: string;
  es_destacado_gold: boolean;
  es_destacado: boolean;
  fotos: Foto[];
  puntaje: string;
  precio_minimo_calculado: number;
  cantidadUnidades: number;
  capacidad_max: number;
  cant_puntaje: number;
  fecha_carga: string;
  cancelacion: string;
  referencia: string;
  foto_listado: string;
  link: string;
  personas: number;
  es_troya: boolean;
  permite_reservas: number;
  tipo: string;
  imageWidthMobile?: string;
  imageHeightMobile?: string;
  isLoadingFav: boolean;
  handleFavorite: IChangeFavorite;
  ofertas_flexibles: Ofertasflexible[];
  ofertas_um: Ofertasum[];
  precio_sin_descuento?: number | null;
  porcentaje_oferta?: number | null;
};

export interface IChangeFavorite {
  (referencia: string): Promise<void>;
}
