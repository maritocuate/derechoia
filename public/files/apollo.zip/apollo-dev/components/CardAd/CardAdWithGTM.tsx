import React, { memo } from 'react';
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';
import { IPropiedadesListado } from '../../types/listado.type';
import { sendListSelectedItemDataGTM } from '../../utils/helpers/sendDataGTM';
import { useRequestToApiList } from '../../hooks/list/useRequestToApiList';

const CardAd = dynamic(() => import('.'));

interface ICardAdMapProps {
  hasCloseButton?: boolean;
  handleClose?: () => void;
  imageHeightMobile?: string;
}

const CardAdWithGTM = (
  props: IPropiedadesListado & {
    index?: number;
    people: number;
    isFav?: boolean;
    hasDates?: boolean;
    isLoadingFav?: boolean;
    handleFavorite: () => void;
    priorityImage?: true;
    reccommended?: boolean;
  } & ICardAdMapProps,
) => {
  const {
    index,
    referencia,
    titulo,
    nombre_localidad: nombreLocalidad,
    people,
    isFav,
    isLoadingFav,
    hasDates,
    handleFavorite,
    priorityImage,
    reccommended,
  } = props;
  const { urlFilters } = useRequestToApiList();
  const handleClick = () => {
    sendListSelectedItemDataGTM({
      reference: referencia,
      title: titulo,
      index,
      place: nombreLocalidad,
    });
    if (hasDates && urlFilters) {
      localStorage.setItem('listFilter', urlFilters);
    } else {
      localStorage.removeItem('listFilter');
    }
  };
  return (
    <Box onClick={handleClick}>
      <CardAd
        {...props}
        isFav={isFav}
        key={`keyCardAdList-${index || 0}`}
        personas={people}
        isLoadingFav={isLoadingFav}
        hasDates={hasDates}
        handleFavorite={handleFavorite}
        priorityImage={priorityImage}
        reccommended={reccommended}
      />
    </Box>
  );
};

export default memo(CardAdWithGTM);
