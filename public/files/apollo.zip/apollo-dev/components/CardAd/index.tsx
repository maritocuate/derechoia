import React, { memo } from 'react';
import dynamic from 'next/dynamic';
import { Box, styled } from '@mui/material';
import CloseOutlined from '@mui/icons-material/CloseOutlined';
import Link from 'next/link';
import { Foto, Ofertasflexible, Ofertasum } from '../../types/listado.type';
import HeaderCard from './components/Header';
import MainCard from './components/Main';

import getIsNew from '../../utils/helpers/getIsNew';
import useIsMobile from '../../hooks/useIsMobile';
import useFilterList from '../../hooks/list/useFIlterList/useFilterList';
import { useLoadingCardAdList } from '../../containers/CardAdContainer/Hook/useLoadingCardAdList/useLoadingCardAdList';

const FooterCard = dynamic(() => import('./components/Footer'));
const CardItem = dynamic(
  () => import('@alquiler-argentina/demiurgo/components/CardItem'),
  { ssr: true },
);

export type CardAdProps = {
  titulo: string;
  nombre_localidad: string;
  es_destacado_gold: boolean;
  es_destacado: boolean;
  fotos: Foto[];
  puntaje: string;
  precio_minimo_calculado: number;
  cantidadUnidades: number;
  capacidad_max: number;
  cant_puntaje: number;
  fecha_carga: string;
  cancelacion: string;
  referencia: string;
  foto_listado: string;
  link: string;
  personas: number;
  es_troya: boolean;
  permite_reservas: number;
  tipo: string;
  imageWidthMobile?: string;
  imageHeightMobile?: string;
  isLoadingFav?: boolean;
  handleFavorite: () => void;
  ofertas_flexibles: Ofertasflexible[];
  ofertas_um: Ofertasum[];
  hasCloseButton?: boolean;
  isFav?: boolean;
  handleClose?: () => void;
  hasDates?: boolean;
  priorityImage?: true;
  reccommended?: boolean;
  precio_sin_descuento?: number | null;
  porcentaje_oferta?: number | null;
};

const StyledCloseContainer = styled(Box)`
  position: absolute;
  top: 1rem;
  z-index: 10;
`;

function CardAd({
  titulo,
  nombre_localidad,
  es_destacado_gold,
  es_destacado,
  fotos,
  puntaje,
  precio_minimo_calculado,
  cantidadUnidades,
  capacidad_max,
  cant_puntaje,
  fecha_carga,
  cancelacion,
  referencia,
  foto_listado,
  link,
  personas,
  es_troya,
  permite_reservas,
  tipo,
  imageWidthMobile,
  imageHeightMobile,
  hasCloseButton,
  isFav,
  isLoadingFav,
  handleClose,
  handleFavorite,
  ofertas_flexibles = [],
  ofertas_um = [],
  hasDates,
  priorityImage,
  reccommended,
  precio_sin_descuento,
  porcentaje_oferta,
}: CardAdProps) {
  const isMobile = useIsMobile();
  const { isFilterOpen } = useFilterList();
  const { changeLoadingListToAd } = useLoadingCardAdList();
  return (
    <Link
      href={link}
      target={isMobile ? undefined : '_blank'}
      style={{
        WebkitTapHighlightColor: 'transparent',
        textDecoration: 'none',
        color: 'unset',
      }}
      onClick={() => {
        if (isMobile) changeLoadingListToAd(true);
      }}
    >
      {!isMobile && hasCloseButton && handleClose && (
        <StyledCloseContainer
          right={isFilterOpen ? '1.5rem' : '10.5rem'}
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            handleClose();
          }}
        >
          <CloseOutlined />
        </StyledCloseContainer>
      )}
      <CardItem
        width="100%"
        height={isMobile ? '100%' : '192px'}
        direction={isMobile ? 'column' : 'row'}
        bgcolor="white"
        firstComponent={
          <HeaderCard
            imageProps={{
              linkPositionZero: referencia,
              linkPositionOne: foto_listado,
              photosArr: fotos,
              width: imageWidthMobile,
              height: imageHeightMobile,
            }}
            isGold={es_destacado_gold}
            isFeatured={es_destacado}
            isLoadingFav={isLoadingFav}
            isFavorite={isFav || false}
            handleFavorite={handleFavorite}
            hasCloseButton={isMobile ? hasCloseButton : false}
            handleClose={handleClose}
            priorityImage={priorityImage}
            cyberMonday={!!porcentaje_oferta}
          />
        }
        secondComponent={
          <MainCard
            title={titulo}
            subtitle={nombre_localidad}
            isNew={getIsNew(cant_puntaje, fecha_carga)}
            valoration={Number(puntaje)}
            capacity={capacidad_max}
            propertyType={tipo}
            quantityTypologies={cantidadUnidades}
            amountReviews={cant_puntaje}
            flexibleOffers={ofertas_flexibles}
            lastMinutesDeals={ofertas_um}
            mobile={isMobile}
            reccommended={reccommended}
            cyberMonday={!!porcentaje_oferta}
          />
        }
        thirdComponent={
          <FooterCard
            quantityTypologies={cantidadUnidades}
            price={precio_minimo_calculado}
            guestsPerNight={personas}
            isFlexibleCancellation={cancelacion === 'flexible'}
            isFreeCancellation={cancelacion === 'gratis'}
            isSiro={es_troya || permite_reservas === 1}
            hasDates={hasDates}
            cyberMondayPercentage={porcentaje_oferta}
            priceWithoutDiscount={precio_sin_descuento}
          />
        }
      />
    </Link>
  );
}
export default memo(CardAd);
