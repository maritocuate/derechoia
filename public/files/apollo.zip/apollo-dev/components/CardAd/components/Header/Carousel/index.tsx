'use client';

import Image from 'next/image';
import React, { useState } from 'react';
import dynamic from 'next/dynamic';
import NavigateBeforeOutlined from '@mui/icons-material/NavigateBeforeOutlined';
import NavigateNextOutlined from '@mui/icons-material/NavigateNextOutlined';
import { styled, Box, Button } from '@mui/material';
import { Foto } from '../../../../../types/listado.type';
import useHover from '../../../../../hooks/useHover';
import useIsMobile from '../../../../../hooks/useIsMobile';
import imageLoaderCardAd from '../../../../../utils/helpers/imageLoaders/imageLoaderCardAd';

const Carousel = dynamic(() => import('react-material-ui-carousel'), {
  ssr: false,
  loading: () => <div style={{ height: '270px' }} />,
});
interface ICarousel {
  imgsCarousel: Foto[];
  referencia: string;
  priorityImage?: true;
}

interface NavButtonProps {
  // eslint-disable-next-line @typescript-eslint/ban-types
  onClick: Function;
  next: boolean;
  prev: boolean;
  className?: string;
  style?: React.CSSProperties;
}

const StyledImageContainer = styled(Box)(
  ({ theme }) => `
  display: grid;
  width: 100%;
  height: 12.125rem;
  position: relative;
  top: 0;
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: linear-gradient(
      0deg,
      rgba(0, 0, 0, 0.51) 0%,
      rgba(133, 133, 133, 0) 20%
    );
    z-index: 1;
  }
  ${theme.breakpoints.up('lg')}{
    width: 255px;
  }
`,
);

const StyledButtons = styled(Button)`
  margin-top: 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
`;

const NavButton = ({
  onClick,
  next,
  prev,
  className,
  style,
}: NavButtonProps) => {
  return (
    <StyledButtons
      disableRipple
      className={className}
      style={style}
      onClick={(e) => {
        e.stopPropagation();
        e.preventDefault();
        onClick();
      }}
    >
      {next && <NavigateNextOutlined fontSize="large" />}
      {prev && <NavigateBeforeOutlined fontSize="large" />}
    </StyledButtons>
  );
};

export default function CarouselCardAd({
  imgsCarousel,
  referencia,
  priorityImage,
}: ICarousel) {
  const [active, setActive] = useState<number>(1);
  const { isHovered, handleHover } = useHover();
  const isMobile = useIsMobile();
  const handlePrev = () => {
    if (imgsCarousel) {
      setActive(active > 1 ? active - 1 : imgsCarousel.length);
    }
  };
  const handleNext = () => {
    if (imgsCarousel) {
      setActive(active < imgsCarousel.length ? active + 1 : 1);
    }
  };

  return (
    <Box
      onMouseOver={() => handleHover(true)}
      onMouseOut={() => handleHover(false)}
    >
      <Carousel
        NavButton={NavButton}
        navButtonsProps={{
          style: {
            backgroundColor: 'transparent',
            color: '#ffffff',
          },
        }}
        navButtonsAlwaysVisible={!isMobile}
        navButtonsAlwaysInvisible={isMobile || !isHovered}
        indicatorContainerProps={{
          style: {
            position: 'absolute',
            top: isMobile ? '60%' : '80%',
            zIndex: '1000',
            marginTop: '0',
          },
        }}
        activeIndicatorIconButtonProps={{
          style: {
            color: '#ffffff',
            transform: 'scale(1)',
          },
        }}
        indicatorIconButtonProps={{
          style: {
            color: 'rgba(192, 192, 192, 1)',
            transform: 'scale(0.5)',
          },
        }}
        fullHeightHover={false}
        indicators
        animation="slide"
        autoPlay={false}
        swipe={isMobile}
        height={isMobile ? '270px' : '194px'}
        next={handleNext}
        prev={handlePrev}
        changeOnFirstRender
      >
        {imgsCarousel &&
          imgsCarousel.map((image, positionIndex) => (
            <StyledImageContainer
              data-testid="image-container-carousel"
              key={`key-${image.id}`}
            >
              <Image
                loader={imageLoaderCardAd}
                src={`${
                  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
                }_propiedades_/${referencia}/${image.nombreArchivo}`}
                alt={image.descripcion}
                height={194}
                width={255}
                placeholder="blur"
                style={{ objectFit: 'cover' }}
                blurDataURL={`${
                  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
                }_propiedades_/${referencia}/${image.nombreArchivo}`}
                priority={positionIndex === 0 ? priorityImage : undefined}
              />
            </StyledImageContainer>
          ))}
      </Carousel>
    </Box>
  );
}
