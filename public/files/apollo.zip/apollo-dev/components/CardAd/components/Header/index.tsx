import { Box, styled, Button } from '@mui/material';
import React, { useMemo } from 'react';
import BookmarkBorder from '@mui/icons-material/BookmarkBorder';
import WorkspacePremium from '@mui/icons-material/WorkspacePremium';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import FavoriteOutlined from '@mui/icons-material/FavoriteOutlined';
import dynamic from 'next/dynamic';
import CloseButton from '../../../Buttons/CloseButton';
import { Foto } from '../../../../types/listado.type';
import useIsMobile from '../../../../hooks/useIsMobile';

import CarouselCardMobile from '../../../CarouselCardMobile/CarouselCardMobile';

import CarouselCardAd from './Carousel';
import CyberMondayIcon from '../../../CyberMondayIcon/CyberMondayIcon';

const IconWithText = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/IconWithText').then(
      (res) => res.default,
    ),
  { ssr: false },
);

const Icon = dynamic(
  () =>
    import('@alquiler-argentina/demiurgo/components/Icon').then(
      (res) => res.default,
    ),
  { ssr: false },
);

const FavoriteTooltip = dynamic(() => import('../../../FavoriteTooltip'), {
  ssr: false,
  loading: () => <div />,
});

type AccommodationFlagsTypes = 'isFeatured' | 'isGold' | 'isFavorite';

type AccommodationFlags = Record<AccommodationFlagsTypes, boolean>;
interface ImageProps {
  linkPositionZero: string;
  linkPositionOne: string;
  width?: string;
  height?: string;
  photosArr: Foto[];
}
export interface HeaderCardProps extends AccommodationFlags {
  imageProps: ImageProps;
  hasCloseButton?: boolean;
  isLoadingFav?: boolean;
  handleClose?: () => void;
  handleFavorite: () => void;
  priorityImage?: true;
  cyberMonday?: boolean;
}
const ButtonsContainer = styled(Box)`
  display: flex;
  gap: 0.5rem;
  z-index: 10;
`;

const StyledBoxFavorite = styled(Button)`
  background: rgba(255, 255, 255, 0.8);
  border-radius: 4px;
  min-width: 28px;
  width: 28px;
  height: 28px;
  &:hover {
    background: linear-gradient(0deg, rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)),
      rgba(255, 255, 255, 0.8);
  }
`;

const StyledBadgeContainer = styled(Box)`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const StyledBadgeItem = styled(Box)`
  display: flex;
  width: fit-content;
  height: 28px;
  background-color: #fafafa;
  padding: 0.125rem 0.5rem 0.125rem 0.375rem;
  border-radius: 4px;
  z-index: 10;
`;

const StyledImageContainer = styled(Box)(
  ({ theme }) => `
  display: grid;
  width: 100%;
  height: 194px;
  position: relative;
  top: 0;
  ${theme.breakpoints.up('md')}{
    height: 100%;
}
`,
);

const StyledContainerAbsolute = styled(Box)`
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  position: absolute;
  top: 0;
  padding: 0.5rem;
`;

const flagsList = [
  {
    children: 'Destacado',
    icon: <BookmarkBorder color="primary" fontSize="small" />,
  },
  {
    children: 'Gold',
    icon: <WorkspacePremium color="secondary" fontSize="small" />,
  },
  {
    children: 'Premium',
    icon: <Icon name="Crown" color="#EC5A5A" size="small" />,
  },
];

function HeaderCard({
  imageProps,
  isFeatured,
  isGold,
  isFavorite,
  hasCloseButton = false,
  isLoadingFav,
  handleClose,
  handleFavorite,
  priorityImage,
  cyberMonday,
}: HeaderCardProps) {
  const isMobile = useIsMobile();
  const flags = useMemo(() => [isFeatured, isGold], [isFeatured, isGold]);
  return (
    <Box position="relative" width={isMobile ? '100%' : '255px'}>
      <StyledImageContainer>
        {isMobile && (
          <CarouselCardMobile
            images={imageProps.photosArr}
            referencia={imageProps.linkPositionZero}
            priorityImage={priorityImage}
          />
        )}
        {!isMobile && (
          <CarouselCardAd
            imgsCarousel={imageProps.photosArr}
            referencia={imageProps.linkPositionZero}
            priorityImage={priorityImage}
          />
        )}
      </StyledImageContainer>
      <StyledContainerAbsolute>
        <StyledBadgeContainer>
          {flags.map((flag, indexPosition) =>
            flag ? (
              <StyledBadgeItem key={`badgeItem-${indexPosition}`}>
                <IconWithText
                  children={flagsList[indexPosition].children}
                  icon={flagsList[indexPosition].icon}
                  anchor="left"
                />
              </StyledBadgeItem>
            ) : null,
          )}
        </StyledBadgeContainer>
        <ButtonsContainer
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
          }}
        >
          <FavoriteTooltip variant="list" isFavorite={isFavorite}>
            <StyledBoxFavorite
              onClick={!isLoadingFav ? handleFavorite : () => {}}
            >
              {isFavorite ? (
                <FavoriteOutlined fontSize="small" color="primary" />
              ) : (
                <FavoriteBorder
                  fontSize="small"
                  htmlColor="rgba(0, 0, 0, 0.8)"
                />
              )}
            </StyledBoxFavorite>
          </FavoriteTooltip>
          {hasCloseButton && <CloseButton handleClose={handleClose} />}
        </ButtonsContainer>
      </StyledContainerAbsolute>
      {cyberMonday && isMobile && (
        <Box position="absolute" top={110} left={240}>
          <CyberMondayIcon />
        </Box>
      )}
    </Box>
  );
}

export default HeaderCard;
