import LocalOfferOutlined from '@mui/icons-material/LocalOfferOutlined';
import React, { memo } from 'react';
import { Box } from '@mui/material';
import BadgeOffers from '../../../../../BadgeOffers/BadgeOffers';
import { FireDepartmentOutlined } from '../../../../../SVG/FireDeparmentOutlined';

const BadgeOffersCardList = ({
  flexibleOffers,
  lastMinutesDeals,
}: {
  flexibleOffers: unknown[];
  lastMinutesDeals: unknown[];
}) => {
  if (!flexibleOffers.length && !lastMinutesDeals.length) {
    return null;
  }
  return (
    <Box display="flex" alignItems="center" gap="0.75rem" maxWidth="100%">
      {!!flexibleOffers.length && (
        <BadgeOffers
          icon={<LocalOfferOutlined color="primary" fontSize="small" />}
          color="primary"
        >
          Estadía flexible
        </BadgeOffers>
      )}
      {!!lastMinutesDeals.length && (
        <BadgeOffers
          icon={
            <FireDepartmentOutlined
              fontSize="small"
              sx={{ color: '#ffb400', fill: 'currentcolor' }}
            />
          }
          color="secondary"
        >
          ¡Último minuto!
        </BadgeOffers>
      )}
    </Box>
  );
};

export default memo(BadgeOffersCardList);
