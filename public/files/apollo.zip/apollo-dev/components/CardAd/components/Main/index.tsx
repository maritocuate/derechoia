import NewReleasesOutlined from '@mui/icons-material/NewReleasesOutlined';
import { Box, styled, Typography } from '@mui/material';
import React, { useMemo } from 'react';
import dynamic from 'next/dynamic';
import useIsMobile from '../../../../hooks/useIsMobile';
import CyberMondayIcon from '../../../CyberMondayIcon/CyberMondayIcon';

const BadgeOffersCardList = dynamic(
  () => import('./components/BadgeOffersCardList/BadgeOffersCardList'),
  {
    ssr: false,
    loading: () => <Box display="flex" alignItems="center" height="1.75rem" />,
  },
);
const IconWithText = dynamic(() =>
  import('@alquiler-argentina/demiurgo/components/IconWithText').then(
    (res) => res.default,
  ),
);
const Valoraciones = dynamic(() =>
  import('@alquiler-argentina/demiurgo/components/Valoraciones').then(
    (res) => res.default,
  ),
);

interface IMainCard {
  title: string;
  subtitle: string;
  isNew: boolean;
  valoration: number;
  capacity: number;
  propertyType: string;
  quantityTypologies: number;
  amountReviews: number;
  flexibleOffers: unknown[];
  lastMinutesDeals: unknown[];
  mobile: boolean;
  reccommended?: boolean;
  cyberMonday?: boolean;
}

const StyledCardContentTitle = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 1rem;
`;

const StyledBoxValoration = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  margin-top: .5rem;
  ${theme.breakpoints.up('lg')} {
    margin-top: 0;

  }
`,
);

const StyledTitleFirst = styled(Typography)`
  font-weight: 600;
  font-size: 1rem;
  line-height: 1.5rem;
  color: rgba(0, 0, 0, 0.87);
  margin-bottom: 0.25rem;
`;
const StyledTitleSecond = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.87);
`;

const StyledIconWithTextNew = styled(IconWithText)`
  font-size: 0.875rem;
  color: #151515;
`;

const StyledTextAmountGuests = styled(Typography)`
  letter-spacing: 0.011rem;
  font-size: 0.875rem;
`;

const StyledValoraciones = styled(Valoraciones)`
  display: flex;
  margin-right: 0.313rem;
  align-items: flex-end;
  & p {
    display: flex;
    margin: 0;
    margin-block: 0;
    margin-inline: 0;
    font-weight: 700;
    height: 100%;
    font-size: 0.875rem;
  }
`;

const StyledBoxTitles = styled(Box)`
  margin-bottom: 0.25rem;
`;

const onlySingularWords = [
  'Hotel',
  'Resort',
  'Hostería',
  'Complejo',
  'Dúplex',
  'Bed & Breakfast',
  'Habitación',
  'Quinta',
];
const formattedPropertyText = (
  propertyType: string,
  quantityTypologies: number,
) => {
  const isSingularWord = onlySingularWords.find(
    (word) => word === propertyType,
  );
  if (!isSingularWord)
    return quantityTypologies > 1 ? `${propertyType}s` : propertyType;
  return isSingularWord;
};

const Main = ({
  title,
  subtitle,
  isNew,
  valoration,
  capacity,
  propertyType,
  quantityTypologies,
  amountReviews,
  flexibleOffers,
  lastMinutesDeals,
  mobile,
  reccommended,
  cyberMonday,
}: IMainCard) => {
  const propertyText = useMemo(
    () => formattedPropertyText(propertyType, quantityTypologies),
    [propertyType, quantityTypologies],
  );
  const isMobile = useIsMobile();
  return (
    <StyledCardContentTitle
      width={!isMobile && reccommended ? '19.0625rem' : '22.0625rem'}
    >
      <StyledBoxTitles>
        <StyledTitleFirst variant="h3">{title}</StyledTitleFirst>
        <StyledTitleSecond variant="body2">{subtitle}</StyledTitleSecond>
        {!mobile && (
          <BadgeOffersCardList
            flexibleOffers={flexibleOffers}
            lastMinutesDeals={lastMinutesDeals}
          />
        )}
      </StyledBoxTitles>

      <StyledBoxValoration>
        <Box gap={0.5} flexDirection="column" display="flex" alignItems="left">
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="flex-end"
          >
            <Box>
              {valoration && !isNew && amountReviews >= 3 ? (
                <Box display="flex" alignItems="flex-end" mb="0.25rem">
                  <StyledValoraciones
                    average={valoration}
                    anchor="valoracionPromedio"
                    children={0}
                  />
                  <Typography variant="body2" lineHeight="1.5" mb="0.001rem">
                    · {amountReviews} valoraciones
                  </Typography>
                </Box>
              ) : null}
              {isNew && (
                <StyledIconWithTextNew
                  icon={<NewReleasesOutlined color="secondary" />}
                  anchor="left"
                >
                  <Typography fontSize={14} fontWeight={600}>
                    Nuevo alojamiento
                  </Typography>
                </StyledIconWithTextNew>
              )}
              <StyledTextAmountGuests variant="h3" lineHeight="1.5">
                {`${propertyText} hasta ${capacity} personas`}
              </StyledTextAmountGuests>
            </Box>
            {cyberMonday && !mobile && (
              <Box>
                <CyberMondayIcon />
              </Box>
            )}
          </Box>
        </Box>
        {mobile && (
          <BadgeOffersCardList
            flexibleOffers={flexibleOffers}
            lastMinutesDeals={lastMinutesDeals}
          />
        )}
      </StyledBoxValoration>
    </StyledCardContentTitle>
  );
};
export default Main;
