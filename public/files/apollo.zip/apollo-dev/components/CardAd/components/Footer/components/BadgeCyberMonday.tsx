import { Box, styled, Typography } from '@mui/material';
import React from 'react';

const StyledContainer = styled(Box)`
  padding: 0.313rem;
  background: linear-gradient(
    84.39deg,
    rgba(63, 148, 237, 0.15) 8.49%,
    rgba(89, 108, 220, 0.15) 44.73%,
    rgba(125, 52, 196, 0.15) 94.78%
  );
  border-radius: 0.25rem;
`;

const BadgeCyberMonday = ({
  discount,
  isMapView,
}: {
  discount: number;
  isMapView?: boolean;
}) => {
  return (
    <StyledContainer>
      <Box>
        <Typography
          fontSize={isMapView ? '0.60rem' : '0.875rem'}
          fontWeight={600}
          color="#7D34C4"
        >{`${discount}% Off`}</Typography>
      </Box>
    </StyledContainer>
  );
};

export default BadgeCyberMonday;
