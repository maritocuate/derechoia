import React, { useMemo } from 'react';
import IconWithText from '@alquiler-argentina/demiurgo/components/IconWithText';
import BadgeAnuncio, {
  BadgeTypes as BADGE_TYPES,
} from '@alquiler-argentina/demiurgo/components/BadgeAnuncio';
import DateRangeOutlined from '@mui/icons-material/DateRangeOutlined';
import EventRepeatOutlined from '@mui/icons-material/EventRepeatOutlined';
import { Box, styled, Typography } from '@mui/material';
import useIsMobile from '../../../../hooks/useIsMobile';
import { formatPriceToArs } from '../../../../utils/helpers/formatPriceToArs';
import BadgeCyberMonday from './components/BadgeCyberMonday';
import { useMapList } from '../../../../hooks/list/useMapList';

interface IFooterCard {
  price?: number;
  isSiro?: boolean;
  isFlexibleCancellation?: boolean;
  isFreeCancellation?: boolean;
  quantityTypologies: number;
  guestsPerNight: number;
  hasDates?: boolean;
  cyberMondayPercentage?: number | null;
  priceWithoutDiscount?: number | null;
}

const StyledCardContentPrice = styled(Box)(
  ({ theme }) =>
    `
    &:last-child{
      padding: 1rem;
      width: 100%;
    }
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 1rem;
    position: relative;
    ${theme.breakpoints.up('lg')} {
      width: 191px;
    
    }
  `,
);

const StyledPriceOut = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.6);
`;
const StyledSpanPriceOut = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.6);
  text-decoration: line-through;
  margin-left: 0.3rem;
`;

const StyledPrice = styled(Typography)`
  font-weight: 700;
  font-size: 1.25rem;
  line-height: 1.563rem;
  color: rgba(0, 0, 0, 0.87);
  margin-bottom: 0.25rem;
`;

const StyledPerNight = styled(Typography)`
  font-weight: 400;
  font-size: 0.875rem;
  letter-spacing: 0.011rem;
  color: rgba(0, 0, 0, 0.87);
`;

const StyledIconWithText = styled(IconWithText)(
  ({ theme }) => `
    font-weight: 400;
    font-size: 0.775rem;
    letter-spacing: 0.019rem;
    color: rgba(0, 0, 0, 0.87);
    ${theme.breakpoints.up('md')} {
      margin-left: 0.35rem;
    }
   ${theme.breakpoints.down(380)} {
      margin-left: 0.35rem;
    }
  `,
);

const StyledBoxCancelation = styled(Box)(
  ({ theme }) => `
    justify-content: space-between;
    margin-top: 0.75rem;
    width: 100%;
    flex-wrap: nowrap;
    ${theme.breakpoints.up('md')} {
      flex-direction: column-reverse;
      gap: 8px;
    }
   ${theme.breakpoints.down(380)} {
      flex-direction: column-reverse;
      gap: 8px;
    } 
    
  `,
);

const StyleBoxPrice = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: row;
    column-gap: 4px;
    align-items: baseline;
    ${theme.breakpoints.up('md')} {
      flex-direction: column;
    }
    ${theme.breakpoints.down(340)} {
      flex-direction: column;
    }
  `,
);

const CardFooter = ({
  quantityTypologies,
  price,
  guestsPerNight,
  isFlexibleCancellation,
  isFreeCancellation,
  isSiro,
  hasDates,
  cyberMondayPercentage,
  priceWithoutDiscount,
}: IFooterCard) => {
  const isMobile = useIsMobile();
  const { isMapViewOpen } = useMapList();
  const priceFormatted = useMemo(() => {
    if (!price) return '';
    return formatPriceToArs(price);
  }, [price]);
  return (
    <StyledCardContentPrice>
      <Box marginLeft={isMobile ? '0' : '0.35rem'}>
        {!!quantityTypologies && priceFormatted ? (
          <Box alignItems="center" display="flex" marginBottom="0.25rem">
            {quantityTypologies > 1 || !hasDates ? (
              <StyledPriceOut variant="body2"> Desde </StyledPriceOut>
            ) : null}
            {!!cyberMondayPercentage && priceWithoutDiscount && (
              <StyledSpanPriceOut>
                {formatPriceToArs(priceWithoutDiscount)}
              </StyledSpanPriceOut>
            )}
            {!!cyberMondayPercentage && isMobile && !isMapViewOpen && (
              <Box marginLeft="0.75rem">
                <BadgeCyberMonday discount={cyberMondayPercentage} />
              </Box>
            )}
          </Box>
        ) : null}

        <StyleBoxPrice>
          <Box
            display="flex"
            flexDirection="row"
            gap="0.75rem"
            alignItems="center"
          >
            <Box>
              <StyledPrice variant="body2">
                {price ? `${priceFormatted}` : 'Precio a consultar'}
              </StyledPrice>
            </Box>
            {!!cyberMondayPercentage && !isMobile && !isMapViewOpen && (
              <Box marginBottom="0.25rem">
                <BadgeCyberMonday
                  isMapView={isMapViewOpen}
                  discount={cyberMondayPercentage}
                />
              </Box>
            )}
          </Box>
          {!!price && (
            <StyledPerNight variant="body2">
              por noche, {guestsPerNight}{' '}
              {guestsPerNight === 1 ? 'persona' : 'personas'}
            </StyledPerNight>
          )}
        </StyleBoxPrice>
      </Box>

      <StyledBoxCancelation display="flex">
        {!!isFlexibleCancellation && (
          <StyledIconWithText
            children="Cancelación flexible"
            icon={<EventRepeatOutlined color="primary" />}
            anchor="left"
            key={0}
          />
        )}
        {!!isFreeCancellation && (
          <StyledIconWithText
            children="Cancelación gratuita"
            icon={<DateRangeOutlined color="primary" />}
            anchor="left"
            key={1}
          />
        )}
        {!!isSiro && (
          <BadgeAnuncio
            badge={BADGE_TYPES.onlineBooking}
            text={[
              <Typography
                color="rgba(0, 0, 0, 0.87)"
                fontSize="0.775rem"
                key={4}
              >
                Reserva online
              </Typography>,
            ]}
            background
            key={2}
          />
        )}
      </StyledBoxCancelation>
    </StyledCardContentPrice>
  );
};

export default CardFooter;
