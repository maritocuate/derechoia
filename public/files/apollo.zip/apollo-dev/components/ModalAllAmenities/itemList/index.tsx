/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import { Typography } from '@alquiler-argentina/demiurgo';
import { useTranslation } from 'next-i18next';
import { styled } from '@mui/material';
import { IData } from '../modalAllAmenities.type';
import { AgregadosState } from '../../../types/propiedades.types';

interface IStyleTextList {
  status: IData['status'];
}
const numbers = {
  1: '0, 0, 0, .87',
  2: '0, 0, 0, .38',
  3: '0, 0, 0, .38',
};
const StyledTextList = styled(Typography)<IStyleTextList>(
  ({ status }) =>
    `color: rgba(${status ? numbers[status] : numbers[1]}); 
    margin-inline-start: 16px;
    white-space: normal;
    word-wrap: break-word;
    font-family: "Plus Jakarta Sans";
    ${
      status === AgregadosState.NO_DISPONIBLE
        ? 'text-decoration: line-through;'
        : ''
    }`,
);

function ItemList({
  amenities,
  status,
  notes,
  observacions,
}: Omit<IData, 'amenitiesType'>) {
  const { t } = useTranslation('ModalAllAmenities');
  // const toCapitalize = observacions || '';
  const capitalizedOservations = observacions
    ? observacions.charAt(0).toUpperCase() +
      observacions.substring(1).toLocaleLowerCase()
    : '';

  return (
    <StyledTextList variant="body2" status={status}>
      {`${t(`${amenities}`)} `}
      {notes && <Typography variant="caption">{`  - ${notes}`}</Typography>}
      {status === AgregadosState.CONSULTAR && (
        <Typography variant="caption" color="unset">{` (${t(
          'consultar',
        )})`}</Typography>
      )}
      {observacions ? (
        <Typography display="inline" variant="body2">
          - {capitalizedOservations}
        </Typography>
      ) : null}
    </StyledTextList>
  );
}
export default ItemList;
