import { AgregadosState, AgregadosTipos } from '../../types/propiedades.types';

export interface IData {
  status: AgregadosState;
  amenitiesType: AgregadosTipos;
  amenities: string;
  notes?: string;
  observacions?: string;
}
