/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import React from 'react';

import { List, Typography, IconWithText } from '@alquiler-argentina/demiurgo';
import {
  styled,
  Divider as DividerMui,
  Dialog,
  Box,
  IconButton,
  DialogContent,
} from '@mui/material';
import BallotOutlined from '@mui/icons-material/BallotOutlined';
import CottageOutlined from '@mui/icons-material/CottageOutlined';
import MicrowaveOutlined from '@mui/icons-material/MicrowaveOutlined';
import RoomServiceOutlined from '@mui/icons-material/RoomServiceOutlined';
import LockOutlined from '@mui/icons-material/LockOutlined';
import CloseIcon from '@mui/icons-material/Close';
import { useTranslation } from 'next-i18next';
import ItemList from './itemList';
import { IData } from './modalAllAmenities.type';
import { AgregadosTipos } from '../../types/propiedades.types';
import useIsMobile from '../../hooks/useIsMobile';

interface IModalAllAmenitiesProps {
  infoAmenities: IData[];
  setIsOpenModalAmenities: (value: boolean) => void;
  open: boolean;
}
type IAmenitiesByCategory = {
  [K in AgregadosTipos]: IData[];
};

const StyledIconWithText = styled(IconWithText)`
  & .MuiSvgIcon-root {
    color: #00acc1;
    margin-block-end: 5px;
  }
`;
const StyledDivider = styled(DividerMui)`
  margin: 10px 0px;
`;
const StyledCategory = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  margin: 8px 0 12px 12px;
  font-weight: 600;
`;
const HeaderDialogMobile = styled(Box)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px;
  border-bottom: 1px solid #0000003b;
`;

const StyledIconButton = styled(IconButton)`
  color: #0000008a;
`;
const StyledDialog = styled(Dialog)`
  width: 100vw;
`;

const StyledDialogContent = styled(DialogContent)(
  ({ theme }) => `
    padding: 0;
    padding-bottom: 28px;
    max-width: 40rem;
    ${theme.breakpoints.up('sm')}{
      padding-top: 12px;
    }
  `,
);

const handleOrderAmenities = (array: IData[]) => {
  array.sort((a, b) => {
    const order = [1, 3, 2];
    return order.indexOf(a.status) - order.indexOf(b.status);
  });
};

const icons = {
  Instalaciones: <CottageOutlined />,
  Equipamientos: <MicrowaveOutlined />,
  Servicios: <RoomServiceOutlined />,
  Protecciones: <LockOutlined />,
  Otros: <BallotOutlined />,
};

export default function ModalAllAmenities({
  infoAmenities,
  setIsOpenModalAmenities,
  open,
}: IModalAllAmenitiesProps) {
  const isMobile = useIsMobile();
  const { t } = useTranslation('ModalAllAmenities');

  // if somebody can improve it, change.
  const obj: IAmenitiesByCategory = {
    [AgregadosTipos.INSTALACIONES]: [],
    [AgregadosTipos.EQUIPAMIENTOS]: [],
    [AgregadosTipos.SERVICIOS]: [],
    [AgregadosTipos.PROTECCIONES]: [],
    [AgregadosTipos.OTROS]: [],
  };

  const content: IAmenitiesByCategory = infoAmenities.reduce((acc, amenity) => {
    acc[amenity.amenitiesType].push(amenity);
    handleOrderAmenities(acc.Instalaciones);
    handleOrderAmenities(acc.Equipamientos);
    handleOrderAmenities(acc.Servicios);
    handleOrderAmenities(acc.Protecciones);
    handleOrderAmenities(acc.Otros);
    return acc;
  }, obj);
  const handleClose = () => {
    setIsOpenModalAmenities(false);
  };
  return (
    <StyledDialog open={open} fullWidth={isMobile} onClose={handleClose}>
      <HeaderDialogMobile maxWidth="640px" width={!isMobile ? '100vw' : '100%'}>
        <Typography
          variant="h6"
          fontWeight="700"
          color="inherit"
          paddingLeft={!isMobile ? '12px' : undefined}
        >
          {t(isMobile ? 'titleMobile' : 'title')}
        </Typography>
        <StyledIconButton onClick={handleClose}>
          <CloseIcon />
        </StyledIconButton>
      </HeaderDialogMobile>
      <StyledDialogContent>
        {Object.entries(content).map(([category, items], index) =>
          items.length !== 0 ? (
            <Box
              key={index}
              marginBottom={0}
              paddingLeft={!isMobile ? '12px' : '8px'}
            >
              <List
                title={
                  <StyledIconWithText
                    icon={Object.entries(icons).map(
                      (icon) => icon[0] === category && icon[1],
                    )}
                    anchor="left"
                  >
                    <StyledCategory variant="subtitle1">
                      {t(category)}
                    </StyledCategory>
                  </StyledIconWithText>
                }
                content={items.map(
                  ({ amenities, notes, status, observacions }) => ({
                    primaryContent: (
                      <ItemList
                        amenities={amenities}
                        notes={notes}
                        status={status}
                        observacions={observacions}
                      />
                    ),
                  }),
                )}
                key={category}
              />
              {index < Object.keys(content).length - 1 && (
                <Box marginLeft={2} marginRight={2}>
                  <StyledDivider variant="fullWidth" orientation="horizontal" />
                </Box>
              )}
            </Box>
          ) : undefined,
        )}
      </StyledDialogContent>
    </StyledDialog>
  );
}
