import React, { memo } from 'react';
import { Box } from '@mui/material';
import Image from 'next/image';
import Link from 'next/link';
import {
  StyledBackground,
  StyledButton,
  StyledCTAContainer,
  StyledSub,
  StyledTitle,
} from './styled-component';
import useIsMobile from '../../hooks/useIsMobile';
import imageLoaderHeaderDesk from '../../utils/helpers/imageLoaders/imageloaderHeaderDesk';
import formatUrlWithCdnLink from '../../utils/helpers/formatUrlWithCdnLink';

interface IBookingCTA {
  image: string;
  title: string;
  subtitle: string;
  textButton: string;
  href: string;
}

function BookingCTA({ image, title, subtitle, textButton, href }: IBookingCTA) {
  const isMobile = useIsMobile();
  return (
    <StyledBackground maxWidth={isMobile ? '20.5rem' : '36.75rem'}>
      <Box>
        <Image
          style={{
            borderTopRightRadius: '8px',
            borderTopLeftRadius: '8px',
          }}
          alt="booking-cta-1"
          loader={({ src }) =>
            imageLoaderHeaderDesk({
              src,
              width: !isMobile ? 588 : 328,
              height: 202,
            })
          }
          src={formatUrlWithCdnLink(image)}
          height={202}
          width={!isMobile ? 588 : 328}
        />
      </Box>
      <StyledCTAContainer>
        <StyledTitle variant="h6">{title}</StyledTitle>
        <StyledSub color="black">{subtitle}</StyledSub>
        <Link href={href}>
          <StyledButton size="large" variant="contained">
            {textButton}
          </StyledButton>
        </Link>
      </StyledCTAContainer>
    </StyledBackground>
  );
}

export default memo(BookingCTA);
