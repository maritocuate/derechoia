import { Box, Button, Typography, styled } from '@mui/material';

const StyledBackground = styled(Box)(
  ({ theme }) => `
      width: 100%;
      border-radius: 0.5rem;
      box-shadow: 0px 6px 10px 0px #00000024;
      ${theme.breakpoints.up('lg')}{
        width: 100%;
        margin: 5rem 0;
  }
      `,
);

const StyledCTAContainer = styled(Box)(
  ({ theme }) => `
    width: 100%;
    border-radius: 1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 1.5rem;
    padding: 1.5rem;
    height: 14.875rem;
    ${theme.breakpoints.up('lg')}{
      padding: 1.5rem;
      height: 16.25rem;
      gap: 1.5rem
    }
  `,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
      font-weight: 600;
      font-size: 1.5rem;
      color: #000000DE;
      ${theme.breakpoints.up('lg')}{
        font-weight: 600;
        font-size: 2.125rem;
        color: #000000DE;
      }
      `,
);

const StyledSub = styled(Typography)(
  ({ theme }) => `
      font-size: 0.875rem;
      font-weight: 500;
      text-align: center;
      ${theme.breakpoints.up('lg')}{
          font-size: 1rem;
      }
      `,
);

const StyledButton = styled(Button)`
  font-weight: 600;
  letter-spacing: 0.8px;
  height: 2.625rem;
`;

export {
  StyledBackground,
  StyledButton,
  StyledCTAContainer,
  StyledSub,
  StyledTitle,
};
