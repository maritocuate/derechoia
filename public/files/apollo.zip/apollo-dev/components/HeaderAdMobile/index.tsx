/* eslint-disable no-console */
import React, { memo, useCallback, useMemo, useState } from 'react';
import { Grid } from '@mui/material';
import * as Sentry from '@sentry/nextjs';
import HeaderAnuncio from '../HeaderAnuncio';
import { useGetPropiedadQuery } from '../../services/propiedades';

// /// Types to Median
type UrlObject = {
  url: string;
  title: string;
  text: string;
};
type Median = {
  share: {
    sharePage: (prop: UrlObject) => void;
  };
};
declare let median: Median;

const HeaderAdMobile = ({
  referencia,
  open,
  setOpen,
  onClickFavorite,
  isFavorite,
  isLoadingFav,
  testProperty,
  cyberMonday,
}: {
  referencia: string;
  open: boolean;
  setOpen: (open: boolean) => void;
  onClickFavorite: () => void;
  isFavorite?: boolean;
  isLoadingFav?: boolean;
  testProperty?: boolean;
  cyberMonday?: boolean;
}) => {
  const [isOpenPopover, setIsOpenPopover] = useState(false);

  const { data } = useGetPropiedadQuery(
    { referencia, test: testProperty },
    { skip: !referencia },
  );
  const headerProps = useMemo(() => {
    if (!data) return null;
    return data?.formatedData?.headerAdData;
  }, [data]);

  const shareMobile = useCallback(async () => {
    const objectShare: UrlObject = {
      url: document.location.href,
      title: 'Alquiler Argentina',
      text: '¡No te pierdas este alojamiento en Alquiler Argentina!',
    };
    if (navigator.share) {
      try {
        await navigator.share(objectShare);
      } catch (err) {
        // The `nevigator.share` api throws an error on mobile sometimes when the client cancels the sharing action. This is supposed to check if the error catched is than, and proceed to ignore it.
        if (!String(err).includes('AbortError')) {
          Sentry.captureException(err);
        } else {
          console.error(err);
        }
      }
    } else {
      setOpen(false);
      setIsOpenPopover(false);
    }
    if (navigator.userAgent.indexOf('median') > -1) {
      median?.share?.sharePage(objectShare);
    }
  }, [setOpen]);

  return (
    <Grid container={false}>
      {headerProps && (
        <HeaderAnuncio
          imagesTypologys={headerProps?.photosTypologies}
          imagesArray={headerProps?.arrayImagesFinal}
          featuredImage={headerProps?.featuredImage}
          BreadcrumsLocation={
            data?.formatedData?.locationData?.placeExistsInArgentina || null
          }
          title={headerProps?.title}
          average={headerProps?.average}
          href={headerProps?.href}
          total={headerProps?.total}
          mobileShare={shareMobile}
          addFavorite={onClickFavorite}
          isFavorite={isFavorite}
          isLoadingFav={isLoadingFav}
          video={headerProps?.video}
          iframe={headerProps?.iframe}
          isOpenPopover={isOpenPopover}
          dateCreated={headerProps?.dateCreated}
          open={open}
          setOpen={setOpen}
          cyberMonday={cyberMonday}
        />
      )}
    </Grid>
  );
};

export default memo(HeaderAdMobile);
