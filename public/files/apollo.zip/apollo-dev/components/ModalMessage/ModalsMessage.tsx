import React, { ReactNode } from 'react';
import { styled, Button, Grid, Typography } from '@mui/material';
import { useTranslation } from 'react-i18next';

interface IModal {
  title: string;
  message: string;
  image: ReactNode;
  handleClose: () => void;
}

export const StyledContentWrapper = styled(Grid)(
  ({ theme }) => `
  align-items: center;
  padding-block: .5rem;
  color: initial;
  ${theme.breakpoints.up('sm')} {  
    min-width: 560px;
  };
`,
);

const StyledTitleTypography = styled(Typography)`
  font-weight: 600;
  font-size: 1.5rem;
  text-align: center;
`;

const StyledMessageTypography = styled(Typography)(
  ({ theme }) => `
  text-align: center;
  line-height: 24px;
  ${theme.breakpoints.up('sm')} {
    max-width: 448px;
  }
`,
);

const StyledButtonWrapper = styled(Grid)`
  margin-block-start: 1rem;
`;

const StyledButton = styled(Button)`
  text-transform: none;
  font-weight: 600;
  color: white;
  background-color: #008394;
  &:hover {
    background-color: #0097a7;
  }
  min-width: 236px;
`;

export default function ModalMessage({
  title,
  message,
  image,
  handleClose,
}: IModal) {
  const { t } = useTranslation('FormValoration');

  return (
    <StyledContentWrapper container direction="column" rowSpacing={1.5}>
      <Grid item>{image}</Grid>
      <Grid
        item
        container
        rowSpacing={1}
        direction="column"
        alignItems="center"
      >
        <Grid item>
          <StyledTitleTypography variant="h5">{title}</StyledTitleTypography>
        </Grid>
        <Grid item>
          <StyledMessageTypography variant="body1">
            {message}
          </StyledMessageTypography>
        </Grid>
      </Grid>
      <StyledButtonWrapper item>
        <StyledButton variant="contained" size="large" onClick={handleClose}>
          {t('close')}
        </StyledButton>
      </StyledButtonWrapper>
    </StyledContentWrapper>
  );
}
