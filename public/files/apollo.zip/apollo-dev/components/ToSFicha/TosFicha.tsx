import React, { memo, useMemo } from 'react';
import TermsAndConditions from '../TermsAndConditions';
import { useGetPropiedadQuery } from '../../services/propiedades';
import removeHTMLTags from '../../utils/helpers/removeHTMLTags';

const TosFicha = ({ referencia }: { referencia: string }) => {
  const { data } = useGetPropiedadQuery({ referencia }, { skip: !referencia });
  const promotionText = useMemo(
    () => (data && data.promocion ? removeHTMLTags(data.promocion) : null),
    [data],
  );
  return (
    <TermsAndConditions
      valorPagoAnticipado={data?.senia}
      nights={data?.estadia_minima}
      cancelacion={data?.cancelacion}
      cash={data?.efectivo}
      bankTransfer={data?.transferencia}
      creditCard={data?.tarjeta}
      coupon={data?.cupon}
      acepta_familias={data?.acepta_familias}
      acepta_parejas={data?.acepta_parejas}
      acepta_grupo_jovenes={data?.acepta_grupo_jovenes}
      apto_niños={data?.apto_niños}
      apto_bebes={data?.apto_bebes}
      acepta_mascotas={data?.acepta_mascotas}
      apto_movilidad_reducida={data?.apto_movilidad_reducida}
      permite_fumar={data?.permite_fumar}
      permite_hacer_fiestas={data?.permite_hacer_fiestas}
      permite_recibir_visitas={data?.permite_recibir_visitas}
      permite_musica={data?.permite_musica}
      garantia={data?.garantia}
      a_reintegrar={data?.a_reintegrar}
      valor_a_reintegrar={data?.valor_a_reintegrar}
      datos_tarjeta={data?.datos_tarjeta}
      foto_dni={data?.foto_dni}
      presentar_documento={data?.presentar_documento}
      firma_contrato={data?.firma_contrato}
      promotionText={promotionText}
      antelacion={data?.antelacion_minima}
      hora_ingreso={data?.hora_ingreso}
      hora_egreso={data?.hora_egreso}
      cancelationFreeDays={data?.valor_dias_cancelacion_gratis}
      cancelationFlexMonths={data?.valor_meses_cancelacion_flexible}
      es_troya={data?.es_troya}
    />
  );
};

export default memo(TosFicha);
