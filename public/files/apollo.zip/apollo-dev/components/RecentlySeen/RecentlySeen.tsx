import { Box, BoxProps, Typography, styled } from '@mui/material';
import React, { memo } from 'react';
import { useTranslation } from 'react-i18next';
import Link from 'next/link';
import CardRecentlySeen from '../CardRecentlySeen/CardRecentlySeen';
import useRecentlySeenData from '../../hooks/useRecentlySeenData/useRecentlySeenData';

interface BoxStyle extends BoxProps {
  fullseen: string;
}

const RecentlySeenContainer = styled(Box)(
  ({ theme }) => `
        width: 100vw;
        margin-top: 2rem;
        height: 380px;
        overflow-y: hidden;
        padding-left: 1rem;
        ${theme.breakpoints.up('lg')}{
          max-width: 1200px;
          height: unset;
          padding-left: 0rem;
          margin-top: 5rem;
        }
    `,
);

const StyledBox = styled(Box)<BoxStyle>(
  ({ theme, fullseen }) => `
    display: flex;
    flex-wrap: no-wrap;
    widht: 100%;
    overflow: scroll;
    scroll-behavior: smooth;
    ${theme.breakpoints.up('lg')}{
        flex-wrap: wrap;
        overflow: hidden;
        justify-content: ${fullseen === 'true' ? 'space-between' : 'flex-start'}
    }
  `,
);

export const StlyedTypography = styled(Typography)(
  ({ theme }) => `
    margin-bottom: 1.5rem;
    font-size: 1.25rem;
    font-weight: 1000;
    ${theme.breakpoints.up('sm')}{
      margin-bottom: 1.5rem;
      font-size: 1.5rem;
      font-weight: 600;        
    }
    `,
);

function RecentlySeen() {
  const { t } = useTranslation('RecentlySeen');
  const { isLoading, isLogged, recentlySeen } = useRecentlySeenData();
  if (!isLogged || !recentlySeen?.length) {
    return null;
  }
  return (
    <RecentlySeenContainer>
      <StlyedTypography variant="h5">{t('title')}</StlyedTypography>
      {!!recentlySeen?.length && !isLoading && (
        <StyledBox fullseen={recentlySeen?.length === 4 ? 'true' : 'false'}>
          {recentlySeen.map((el) => (
            <Link
              target="_blank"
              href={`/alojamientos/${el.reference}/`}
              key={el.reference}
            >
              <CardRecentlySeen
                city={el.city}
                photo={el.photo}
                province={el.province}
                valoration={el.valoration}
                name={el.name}
                reference={el.reference}
                isLoading={isLoading}
                fullseen={recentlySeen?.length}
                isNew={el.isNew}
              />
            </Link>
          ))}
        </StyledBox>
      )}
    </RecentlySeenContainer>
  );
}

export default memo(RecentlySeen);
