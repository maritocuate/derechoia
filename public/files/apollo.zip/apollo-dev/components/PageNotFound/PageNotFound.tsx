/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable import/no-absolute-path */
import React from 'react';
import SVG404 from '/public/images/Error_404.svg';
import Image from 'next/image';
import { Box, Button, Typography, styled } from '@mui/material';

const Styled404Box = styled(Box)`
  display: flex;
  gap: 1.5rem;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: 100%;
  max-width: 30rem;
`;

const StyledTitleContainer = styled(Box)`
  display: flex;
  gap: 0.5rem;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-bottom: 1rem;
`;

const PageNotFound = () => {
  return (
    <Styled404Box data-testid="Page-NotFound-Container">
      <Image src={SVG404} alt="404_logo" width={240} height={240} />
      <StyledTitleContainer>
        <Typography variant="contentTitle" textAlign="center">
          Página no encontrada
        </Typography>
        <Typography variant="descriptionText" textAlign="center">
          El contenido que buscás no está disponible. <br />
          Cambiá de rumbo y seguí planificando tu viaje.
        </Typography>
      </StyledTitleContainer>
      <Button
        variant="primaryButtonLarge"
        sx={{
          marginTop: '1rem',
        }}
        href={process.env.NEXT_PUBLIC_URL}
      >
        Ir al inicio
      </Button>
    </Styled404Box>
  );
};

export default PageNotFound;
