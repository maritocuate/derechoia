import React from 'react';
import { useTranslation } from 'react-i18next';
import { Box, styled, Typography } from '@mui/material';
import Image from 'next/image';
import Search from '../Search/Search';
import { MainBanner } from '../../types/home.types';
import imageLoaderHome from '../../utils/helpers/imageLoaders/imageLoaderHome';
import useSearchHome from './hooks/useSearchHome';
import imageLoaderHomeMobile from '../../utils/helpers/imageLoaders/imageLoaderHomeMobile';

interface ISearchHome {
  mainBanner?: MainBanner;
  isMobile: boolean;
}

const StyledContainer = styled(Box)(
  ({ theme }) => `
    position: relative;
    align-content: center;
    background-size: cover;
    display: flex;
    flex-direction: column;
    height: 450px;
    justify-content: center;
    margin-top: 4rem;
    text-align: center;
    width: 100vw;
    ${theme.breakpoints.up('md')}{
      height: 60vh;
      width: 100%;
    }
`,
);

const StyledTitle = styled(Typography)(
  ({ theme }) => `
    color: #FFFFFF;  
    font-weight: 600;
    font-size: 2.125rem;
    line-height: 2.6rem;
    margin: 2rem 3rem;
    margin-top: 3rem;
    z-index: 10;
    ${theme.breakpoints.up('lg')}{
      font-size: 3.25rem;
      line-height: 4.5rem;
      margin: 0 0 2rem 0;
    }
  `,
);

const StyledSearchContainer = styled(Box)(
  ({ theme }) => `
    background-color: #FFFFFF;
    border-radius: 0.5rem;
    margin: 0 auto;
    width: calc(100% - 2rem);
    max-width: 37.5rem;
    padding: 1rem;
    text-align: left;
    z-index: 10;
    ${theme.breakpoints.up('lg')}{
      margin: 0 auto;
      max-width: 1080;
      padding: 1rem;
      max-width: 67.5rem;
    }
`,
);

const StyledImage = styled(Image)(
  ({ theme }) => `
    z-index: 0;
    object-fit: cover;
    height: 450px;
    ${theme.breakpoints.up('lg')}{
      height: 60vh;
      object-fit: cover;
    }
`,
);

export default function SearchHome({ mainBanner, isMobile }: ISearchHome) {
  const { t } = useTranslation('SearchHome');
  const { handleApplyOnlySearch, isDisable, isOpenTooltip, setOpenTooltip } =
    useSearchHome();
  return (
    <StyledContainer>
      {isMobile && mainBanner && mainBanner.mobile && (
        <StyledImage
          src={`${mainBanner.mobile}?h=450`}
          alt="Home"
          loader={imageLoaderHomeMobile}
          priority
          fill
          sizes="100%"
          style={{ objectFit: 'cover' }}
        />
      )}
      {!isMobile && mainBanner && mainBanner.url && (
        <StyledImage
          src={`${mainBanner.url}?h=650`}
          alt="Home"
          loader={imageLoaderHome}
          priority
          fill
          sizes="100%"
        />
      )}
      <StyledTitle variant="h4">{t('find')}</StyledTitle>
      <StyledSearchContainer>
        <Search
          isSearchButton
          isDisabled={isDisable}
          onClick={handleApplyOnlySearch}
          tooltipAutocomplete={isOpenTooltip}
          setTooltipAutocomplete={setOpenTooltip}
        />
      </StyledSearchContainer>
    </StyledContainer>
  );
}
