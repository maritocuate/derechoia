import { useCallback, useMemo, useState } from 'react';
import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { ICheckoutState } from '../../../redux/checkout/types';
import { ISearchState } from '../../../redux/search/type';
import { getUrlQueryToBrowser } from '../../../utils/helpers/FormattersList';

const useSearchHome = () => {
  const [isDisable, setDisable] = useState(true);
  const router = useRouter();
  const [isOpenTooltip, setOpenTooltip] = useState(false);
  const {
    startDate,
    endDate,
    adultos: adults,
    menores: youngs,
    bebes: babies,
    mascotas: pets,
  } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );

  const { destination } = useSelector(
    ({ search }: { search: ISearchState }) => search,
  );

  const province = (
    destination.provincia ||
    (destination.tipo === 'provincia' && destination.nombre) ||
    ''
  ).replace(/ /g, '-');

  const locality = useMemo(() => {
    const isLocalityOrDistrict = () => {
      let textLocality = '';
      if (destination.tipo === 'barrio') {
        textLocality = destination.localidad || '';
      }
      if (destination.tipo === 'localidad') {
        textLocality = destination.nombre || '';
      }
      return textLocality;
    };

    return isLocalityOrDistrict().replace(/ /g, '-');
  }, [destination.localidad, destination.nombre, destination.tipo]);

  const district = encodeURI(
    (destination?.tipo === 'barrio' && destination.nombre
      ? `${destination.nombre}`
      : ''
    ).replace(/ /g, '-'),
  );
  const country = destination.tipo === 'país' ? destination.nombre : '';
  const urlParamsToBrowserWithOutFilters = useMemo(() => {
    const filtersCheckout = getUrlQueryToBrowser({
      startDate,
      endDate,
      adults,
      youngs,
      babies,
      pets,
      district,
    });
    if (country) {
      return `${country}/${!filtersCheckout ? '' : `${filtersCheckout}/`}`;
    }
    if (!province) return '';
    return `/${province}/${!locality ? '' : `${locality}/`}${
      !filtersCheckout ? '' : `${filtersCheckout}/`
    }`;
  }, [
    adults,
    babies,
    country,
    district,
    endDate,
    locality,
    pets,
    province,
    startDate,
    youngs,
  ]);
  const handleApplyOnlySearch = useCallback(() => {
    if (!urlParamsToBrowserWithOutFilters) return setOpenTooltip(true);
    setDisable(false);
    router.push(urlParamsToBrowserWithOutFilters).finally(() => {
      setTimeout(() => {}, 800);
      return setDisable(true);
    });
  }, [router, urlParamsToBrowserWithOutFilters]);

  return { handleApplyOnlySearch, isDisable, isOpenTooltip, setOpenTooltip };
};

export default useSearchHome;
