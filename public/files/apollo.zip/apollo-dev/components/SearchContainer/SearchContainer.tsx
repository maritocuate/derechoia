import { Box, styled } from '@mui/material';
import React from 'react';
import SearchHome from '../SearchHome/SearchHome';
import { MainBanner } from '../../types/home.types';

const StyledContainer = styled(Box)`
  width: 100%;
  height: 24.5rem;
  overflow: hidden;
  margin-bottom: 6rem;
`;

const SearchContainer = ({ banner }: { banner?: MainBanner }) => {
  return (
    <StyledContainer>
      <Box marginTop="-8rem">
        <SearchHome mainBanner={banner} isMobile={false} />
      </Box>
    </StyledContainer>
  );
};

export default SearchContainer;
