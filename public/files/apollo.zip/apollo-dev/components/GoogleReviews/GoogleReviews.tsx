import React from 'react';
import Link from 'next/link';
import {
  Avatar,
  Box,
  Divider,
  Rating,
  styled,
  Typography,
} from '@mui/material';
import useIsMobile from '../../hooks/useIsMobile';
import { getRandomColor } from '../../utils/helpers/getRandomColor';
import type { TGoogleReviews } from '../../types/publicar.types';

const StyledContainer = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'withMargin',
})<{
  withMargin?: boolean;
}>(
  ({ theme, withMargin }) => `
    display: flex;
    border-radius: 0.5rem;
    box-shadow: 0px 3px 14px 0px rgba(0, 0, 0, 0.12);
    padding: 2rem 1.5rem;
    flex-direction: column;
    align-items: flex-start;
    flex-shrink: 0;
    width: 100%;
    max-width: 37.5rem;
    margin: 0 auto;
    ${theme.breakpoints.up('lg')}{
      padding: 2rem; 
      max-width: ${withMargin ? '72.5rem' : '100%'};
    }
  `,
);

const StyledReview = styled(Box)(
  ({ theme }) => `
    display: flex;
    flex-direction: row;
    align-items: flex-start;
    gap: 1rem;
    align-self: stretch;
    ${theme.breakpoints.up('lg')}{
      flex-direction: row;
      gap: 1.5rem;
      margin-top: 1.688rem;
    }
  `,
);

const StyledOpinion = styled(Box)`
  gap: 0.25rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex: 1 0 0;
`;

const StyledRaiting = styled(Box)(
  ({ theme }) => `
    display: flex;
    align-items: center;
    align-self: stretch;
    ${theme.breakpoints.up('lg')}{
      margin-bottom: 1.5rem;
  } 
  `,
);

const StyledRaitingSecondary = styled(StyledRaiting)(
  ({ theme }) => `
    gap: 1rem;
    ${theme.breakpoints.up('lg')}{
      margin-bottom: 0.5rem;
    } 
   `,
);

const StyledLink = styled(Link)(
  ({ theme }) => `
    display: flex;
    align-items: center;
    gap: 0.25rem;
    margin-top: 1.688rem;
    ${theme.breakpoints.up('lg')}{
      padding: 0 5.5rem;
    }
  `,
);

const StyledDivider = styled(Divider)`
  stroke-width: 1px;
  stroke: var(--Light-Text-Disabled, rgba(0, 0, 0, 0.38));
  width: 100%;
`;

const TOTAL_COMMENTS_LINKS = {
  DESKTOP:
    'https://www.google.com/search?sca_esv=03b57f710e47560e&q=Alquiler+Argentina&si=AKbGX_pupYoY5_Pz6ilccZjjFXt57YRFxQVuSLPHQeMYhqnkzK1Y_-3_fLCkrxp8-ZBtZtviDJ1dJOzM4GHY9E5sFcMf4HtUZ5XTD6qk7blg0Ere2w6-iYYOiENUjZeQRB8e0G5AuPTFpuY9ZB1WOrRx9Mvzvd07yZi8acYkMQUn6WqKiD_JT8aB091hwAVb0JLYssCoaDPlMV9qTMZNvhIiL3LMoQcUCQ%3D%3D&sa=X&ved=2ahUKEwjj1Yf-05aEAxUmqZUCHSGrAx0Q6RN6BAg_EAE&biw=1745&bih=887&dpr=1.1#lrd=0x942d6640daa97f31:0x3f7c6c2d1506f139,1,,,,',
  MOBILE:
    'https://www.google.com/search?q=alquilerargentina&oq=alquilerargentina&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRhBMgYIAhBFGDwyBggDEEUYPDIGCAQQRRg8MgYIBRBFGEEyBggGEEUYQdIBCDI0MDdqMGoxqAIAsAIA&sourceid=chrome&ie=UTF-8#lkt=LocalPoiReviews&trex=m_t:lcl_akp,rc_ludocids:4574650262383685945,rc_q:alquilerargentina,ru_gwp:0%252C7,ru_q:alquilerargentina,trex_id:w1Save&lpg=cid:CgIgAQ%3D%3D',
};

const GoogleReviews = ({
  title,
  withMargin,
  reviews,
}: {
  title?: string;
  withMargin?: boolean;
  reviews: TGoogleReviews;
}) => {
  const isMobile = useIsMobile();

  if (isMobile) {
    return (
      <Box p="3rem 1.5rem">
        <StyledContainer withMargin={withMargin}>
          <Box width="100%" m="0" p="0">
            <Box mb="1.5rem">
              <Typography variant="textPostDesktop">
                {title ||
                  'Qué opinan los turistas sobre Alquiler Argentina en Google'}
              </Typography>
            </Box>
            <StyledRaiting gap="1rem">
              <Typography
                variant="titleSectionPostMobile"
                color="rgba(0, 0, 0, 0.60)"
              >
                {reviews?.averageRating}
              </Typography>
              <Rating size="large" value={4.7} readOnly />
            </StyledRaiting>
            <Box my="1.5rem">
              <Typography color="rgba(12, 8, 8, 0.6)" variant="descriptionText">
                {reviews?.totalReviewCount?.toLocaleString('es-AR')} opiniones
              </Typography>
            </Box>
            <StyledDivider />
          </Box>
          <Box mt="1.688rem">
            {reviews?.reviews?.map((data, index) => (
              <Box mb="1.688rem" key={index}>
                <StyledReview>
                  <Box>
                    <Avatar
                      alt={data?.name}
                      src={data?.photo}
                      sx={{
                        width: 40,
                        height: 40,
                        bgcolor: getRandomColor(),
                      }}
                    >
                      {data?.name?.charAt(0)}
                    </Avatar>
                  </Box>
                  <StyledOpinion>
                    <Typography variant="textPostMobile">
                      {data?.name}
                    </Typography>
                    <StyledRaiting gap="1.063rem">
                      <Rating size="small" value={4.7} readOnly />
                    </StyledRaiting>
                    <Typography color="rgba(0, 0, 0, 0.60)" variant="orderText">
                      {data?.date}
                    </Typography>
                  </StyledOpinion>
                </StyledReview>
                <Box mt="1rem">
                  <Typography variant="orderText">{data?.review}</Typography>
                </Box>
              </Box>
            ))}
            <StyledLink
              href={
                isMobile
                  ? TOTAL_COMMENTS_LINKS?.MOBILE
                  : TOTAL_COMMENTS_LINKS?.DESKTOP
              }
              target="_blank"
            >
              <Typography variant="linkReviews">
                Ver todos los comentarios
              </Typography>
            </StyledLink>
          </Box>
        </StyledContainer>
      </Box>
    );
  }
  return (
    <Box
      p="4rem 0rem"
      sx={{ maxWidth: withMargin ? '1160px' : '100%', margin: '0 auto' }}
    >
      <StyledContainer withMargin={withMargin}>
        <Box width="100%" m="0" p="0">
          <Box mb="1.5rem">
            <Typography variant="googleReviewsTitle">
              {title ||
                'Qué opinan los turistas sobre Alquiler Argentina en Google'}
            </Typography>
          </Box>
          <StyledRaiting gap="1rem">
            <Typography
              variant="titleSectionPostMobile"
              color="rgba(0, 0, 0, 0.60)"
            >
              {reviews?.averageRating}
            </Typography>
            <Rating size="large" value={4.7} readOnly />
            <Typography
              color="rgba(0, 0, 0, 0.60)"
              variant="descriptionText"
              display="flex"
              justifyContent="center"
              alignItems="center"
            >
              {reviews?.totalReviewCount?.toLocaleString('es-AR')} opiniones
            </Typography>
          </StyledRaiting>
          <StyledDivider />
        </Box>
        <Box gap="1.688rem">
          {reviews?.reviews?.map((data, index) => (
            <StyledReview key={index}>
              <Box>
                <Avatar
                  alt={data?.name}
                  src={data?.photo}
                  sx={{
                    width: '4rem',
                    height: '4rem',
                    bgcolor: getRandomColor(),
                  }}
                >
                  <Typography variant="h3" fontSize="2rem">
                    {data?.name?.charAt(0)}
                  </Typography>
                </Avatar>
              </Box>
              <StyledOpinion>
                <Typography variant="textPostDesktop">{data?.name}</Typography>
                <StyledRaitingSecondary>
                  <Rating size="small" value={4.7} readOnly />
                  <Typography
                    color="rgba(0, 0, 0, 0.60)"
                    variant="descriptionText"
                  >
                    {data?.date}
                  </Typography>
                </StyledRaitingSecondary>
                <Typography variant="descriptionText">
                  {data?.review}
                </Typography>
              </StyledOpinion>
            </StyledReview>
          ))}
          <StyledLink
            href={
              isMobile
                ? TOTAL_COMMENTS_LINKS?.MOBILE
                : TOTAL_COMMENTS_LINKS?.DESKTOP
            }
            target="_blank"
          >
            <Typography variant="linkReviews">
              Ver todos los comentarios
            </Typography>
          </StyledLink>
        </Box>
      </StyledContainer>
    </Box>
  );
};

export default GoogleReviews;
