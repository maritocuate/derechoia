/* eslint-disable @typescript-eslint/indent */
import React from 'react';
import {
  styled,
  Stepper,
  Step,
  StepLabel,
  Grid,
  StepLabelProps,
} from '@mui/material';

interface IStepper {
  active: number;
  isMobile: boolean;
}

interface ISteps extends StepLabelProps {
  incomplete: boolean;
}

const StyledStepperWrapper = styled(Grid)`
  padding-block: 1.6rem;
`;

const StyleStepLabel = styled(StepLabel)<ISteps>(
  ({ incomplete }) => `
    & .MuiStepLabel-alternativeLabel {
      margin-top: 0.25rem;
    }
    ${
      incomplete
        ? ` & .MuiStepLabel-iconContainer .Mui-active,
      .MuiStepLabel-iconContainer .Mui-completed {
        color: rgba(0, 0, 0, 0.38);
      } 
      & .MuiStepLabel-alternativeLabel {
        margin-top: 0.25rem;
        color: rgba(0, 0, 0, 0.38);}`
        : ''
    } 
`,
);

export default function StepperCheckoutSiro({ active, isMobile }: IStepper) {
  return (
    <StyledStepperWrapper item xs={12} data-testid="stepperContainer">
      <Stepper activeStep={active} alternativeLabel={isMobile}>
        <Step data-testid="resume">
          <StyleStepLabel key="resume" incomplete={false}>
            Resumen
          </StyleStepLabel>
        </Step>
        <Step data-testid="data">
          <StyleStepLabel incomplete={active < 1} key="datos">
            Tus datos
          </StyleStepLabel>
        </Step>
        <Step data-testid="confirm">
          <StyleStepLabel incomplete={active < 2} key="confirmar">
            Confirmar
          </StyleStepLabel>
        </Step>
      </Stepper>
    </StyledStepperWrapper>
  );
}
