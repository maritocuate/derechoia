import { CoordsMapArray } from '../../redux/filtersListado/types';
import { TMapBounds } from '../../types/map.types';
import { ListMapMarkerProps } from '../ListMapMarker/ListMapMarker';

export interface IHandleChangePositionParams {
  bounds: TMapBounds;
  center: CoordsMapArray;
  zoom?: number;
}

type TMarkerData = Pick<ListMapMarkerProps, 'variant' | 'price'>;

export type TMapListMarker = {
  id: number;
  lat: number;
  lng: number;
  referencia: string;
} & TMarkerData;
