/* eslint-disable @typescript-eslint/restrict-plus-operands */
import React, { memo, useCallback, useRef, useState } from 'react';
import * as ReactDOMServer from 'react-dom/server';
import {
  MapContainer,
  MapContainerProps,
  ZoomControl,
  TileLayer,
  Marker,
} from 'react-leaflet';
import L, { LatLngTuple, MarkerCluster } from 'leaflet';
import { Box, styled } from '@mui/material';

import MarkerClusterGroup from '../MarkerCluster';
import useIsMobile from '../../hooks/useIsMobile';
import LeafletMoveEndHandler from '../LeafletMoveEndHandler/LeafletMoveEndHandler';
import LeafletResizeHandler from '../LeafletResizeHandler/LeafletResizeHandler';
import NearMeButton from '../MapFicha/components/Buttons/NearMeButton';
import { IHandleChangePositionParams, TMapListMarker } from './types';
import ListMapMarker from '../ListMapMarker/ListMapMarker';
import LeafletMoovStartHandler from '../LeafletMooveStartHandler/LeafletMooveStartHandler';
import LeafletClickHandler from '../LeafletClickHandler/LeafletClickHandler';
import ListMapClusterMarker from '../MapMarker/ListMapClusterMarker';
import PersonPinCircleOutlinedCustom from '../SVG/PersonPinCircleOutlinedCustom';

const StyledTopRightCorner = styled(Box)`
  position: absolute;
  top: 1.2rem;
  right: 1.2rem;
`;

const StyledMapContainer = styled(Box)`
  position: relative;
  height: 100%;
  width: 100%;
`;

interface MapListProps extends MapContainerProps {
  markers?: TMapListMarker[];
  center: LatLngTuple;
  hasMyLocation?: boolean;
  handlePressMarkers: (id: number | undefined) => void;
  handleSetRef: (ref: string) => void;
  handleChangePosition?: (params: IHandleChangePositionParams) => void;
  moveAction?: () => void;
  clickAction?: () => void;
  toggleInvalidateSize?: boolean;
}

const createClusterCustomIcon = (cluster: MarkerCluster) =>
  new L.DivIcon({
    html: ReactDOMServer.renderToString(
      <ListMapClusterMarker count={`${cluster.getChildCount()} `} />,
    ),
    className: 'custom-marker',
  });

const MapList = ({
  markers,
  handlePressMarkers,
  handleChangePosition,
  handleSetRef,
  center,
  hasMyLocation,
  moveAction,
  clickAction,
  toggleInvalidateSize,
  ...rest
}: MapListProps) => {
  const mapRef = useRef<L.Map>(null);
  const isMobile = useIsMobile();
  const [myPosition, setMyPosition] = useState<LatLngTuple | undefined>(
    undefined,
  );

  const handleMapCenter = useCallback(
    (mapCenter: LatLngTuple) => {
      if (mapRef.current) {
        const map = mapRef.current;

        if (mapCenter && map) {
          setMyPosition(mapCenter);
          map?.flyTo(mapCenter, undefined, {
            noMoveStart: false,
            easeLinearity: 1,
          });
        }
      }
    },
    [mapRef],
  );

  return (
    <StyledMapContainer>
      <StyledTopRightCorner onClick={(e) => e.stopPropagation()}>
        {hasMyLocation && <NearMeButton callback={handleMapCenter} />}
      </StyledTopRightCorner>

      <MapContainer
        ref={mapRef}
        zoomControl={false}
        scrollWheelZoom
        style={{
          width: '100%',
          height: '100%',
        }}
        center={center}
        {...rest}
      >
        {!!moveAction && <LeafletMoovStartHandler callback={moveAction} />}
        {!!clickAction && <LeafletClickHandler callback={clickAction} />}
        <LeafletResizeHandler />
        <LeafletMoveEndHandler callback={handleChangePosition} />
        <TileLayer
          attribution='Powered by <a rel="nofollow" href="https://www.geoapify.com/" target="_blank">Geoapify</a> | © OpenStreetMap <a rel="nofollow" href="https://www.openstreetmap.org/copyright" target="_blank">contributors</a>'
          url={`https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${String(
            process.env.NEXT_PUBLIC_GEOAPIFY_KEY,
          )}`}
        />
        {isMobile && myPosition?.length === 2 && (
          <Marker
            position={myPosition}
            icon={L.divIcon({
              html: ReactDOMServer.renderToString(
                <PersonPinCircleOutlinedCustom />,
              ),
              className: 'custom-marker',
            })}
          />
        )}
        <MarkerClusterGroup
          iconCreateFunction={createClusterCustomIcon}
          chunkedLoading
        >
          {markers?.map(
            ({ id, lat, lng, variant = 'default', price, referencia }) => {
              return (
                <Marker
                  key={`markerKey-${id + lat + lng + variant}`}
                  position={[lat, lng]}
                  eventHandlers={{
                    click: () => {
                      handlePressMarkers(id);
                      handleSetRef(referencia);
                    },
                  }}
                  zIndexOffset={variant === 'selected' ? 99 : 0}
                  icon={L.divIcon({
                    html: ReactDOMServer.renderToString(
                      <ListMapMarker variant={variant} price={price} />,
                    ),
                    className: 'custom-marker',
                  })}
                />
              );
            },
          )}
        </MarkerClusterGroup>
        {!isMobile && <ZoomControl position="topright" />}
      </MapContainer>
    </StyledMapContainer>
  );
};

export default memo(MapList);
