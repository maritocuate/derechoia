/* eslint-disable @typescript-eslint/indent */
import Image from 'next/legacy/image';
import {
  Grid,
  IconButton,
  Typography,
  Button,
} from '@alquiler-argentina/demiurgo';
import { Box, LinkProps, styled } from '@mui/material';
import { useTranslation } from 'next-i18next';
import React, { memo, MouseEvent, useState } from 'react';
import CollectionsIcon from '@mui/icons-material/Collections';
import ShareOutlined from '@mui/icons-material/ShareOutlined';
import FavoriteBorder from '@mui/icons-material/FavoriteBorder';
import FavoriteOutlined from '@mui/icons-material/FavoriteOutlined';
import MainInfoAnuncio from '../MainInfoAnuncio';
import MediaViewImages, { IPhotosTypology } from '../MediaViewImages';
import FavoriteTooltip from '../FavoriteTooltip';
import getIsNew from '../../utils/helpers/getIsNew';
import useIsMobile from '../../hooks/useIsMobile';
import imageLoaderHeaderDesk from '../../utils/helpers/imageLoaders/imageloaderHeaderDesk';
import CyberMondayIcon from '../CyberMondayIcon/CyberMondayIcon';

const BoxBodyFeatured = styled(Box)`
  display: flex;
  justify-content: space-between;
  align-items: end;
  position: relative;
`;

const BoxBody = styled(Box)`
  display: flex;
  gap: 8px;
  cursor: pointer;
`;

const BoxBodyDestacada = styled(Box)`
  display: flex;
  width: 100%;
`;

const BoxBodyMansory = styled(Box)`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 475px;
`;

const BoxBodyMansoryHeader = styled(Box)`
  width: 100%;
  height: 100%;
  border-radius: 8px;
  background-repeat: no-repeat;
  background-size: cover;
`;

const BoxBodyMansoryLastPhotos = styled(Box)`
  display: flex;
  height: 100%;
  justify-content: space-between;
  position: relative;
  margin-top: 12px;
`;

const ButtonViewGallery = styled(IconButton)`
  background-color: rgba(0, 0, 0, 0.6);
  position: absolute;
  color: white;
  text-transform: none;
  right: 15px;
  bottom: 15px;
  &:hover {
    background-color: black;
  }
`;

const StyledShareOutlined = styled(ShareOutlined)`
  border-radius: 8px;
  color: rgba(0, 0, 0, 0.87);
  &:hover {
    background-color: rgba(0, 0, 0, 0.12);
  }
`;

const SpanLengthMobile = styled(Box)`
  display: flex;
  align-self: flex-end;
  background: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 2px 10px;
  border-radius: 8px;
  position: absolute;
  bottom: 1rem;
  right: 1rem;
  top: auto;
`;

const ShareIconsAAV4Desktop = styled(Grid)`
  position: absolute;
  right: 0;
  bottom: 0;
`;
const ShareIconsAAV4Mobile = styled(Grid)`
  position: absolute;
  top: 1rem;
  right: 1.2rem;
  color: rgba(0, 0, 0, 0.6);
`;

const IndividualIcons = styled(Button)`
  min-width: 0;
  padding: 0.375rem;
  margin-left: 1rem;
  min-height: 24px;
  min-width: 24px;
  background: rgba(255, 255, 255, 1);
  &:active,
  &:hover {
    background: rgba(255, 255, 255, 1);
  }
`;

const BoxMobileFeaturedCick = styled(Box)`
  width: 100%;
  height: 100%;
`;

const StyledBox = styled(Box)(
  ({ theme }) => `
    ${theme.breakpoints.between(600, 'lg')}{
      width: 100%;
      display: flex;
      justify-content: center;
    }
  `,
);

const AlignBox = styled(Box)(
  ({ theme }) => `
    ${theme.breakpoints.between(600, 'lg')}{
      min-width: 600px;
      ${theme.breakpoints.up('md')}{
        width: 70%;
      }
    }
  `,
);

interface IImagesArray {
  id: number;
  img: string;
  alt: string;
  loading: 'lazy';
}

export interface IHeaderAnuncio {
  imagesArray: IImagesArray[];
  featuredImage: string;
  BreadcrumsLocation: LinkProps[] | null;
  title: string;
  average: number;
  total: number;
  href: string;
  imagesTypologys: IPhotosTypology[];
  mobileShare: (event?: React.MouseEvent<HTMLElement>) => Promise<void>;
  addFavorite: () => void;
  video?: string;
  iframe?: string;
  isOpenPopover?: boolean;
  dateCreated?: string;
  open: boolean;
  isFavorite?: boolean;
  isLoadingFav?: boolean;
  cyberMonday?: boolean;
  setOpen: (value: boolean) => void;
}
const responsiveWidthConversor = (isMobile: boolean, isOnlyPics: boolean) => {
  if (isMobile || isOnlyPics) {
    return 1200;
  }
  return 851;
};
const HeaderAnuncio = ({
  imagesArray,
  featuredImage,
  BreadcrumsLocation,
  title,
  average,
  total,
  href,
  mobileShare,
  addFavorite,
  video,
  iframe,
  isOpenPopover,
  imagesTypologys,
  dateCreated,
  open,
  setOpen,
  isFavorite,
  isLoadingFav,
  cyberMonday,
}: IHeaderAnuncio) => {
  const { t } = useTranslation('HeaderAnuncio');
  const isMobile = useIsMobile();
  const iconsFontSize = isMobile ? 'small' : 'large';

  const [openViewImage, setOpenViewImage] = useState(false);

  const mostrarUnaSolaFoto = imagesArray.length <= 3;

  const arrayQty: number[] = imagesTypologys.map((e) => e.fotos.length);
  const totalPhotos = arrayQty.reduce(
    (previousValue, currentValue) => previousValue + currentValue,
    imagesArray.length,
  );
  const handleOpenModal = () => {
    setOpenViewImage(!openViewImage);
  };
  const isNew = getIsNew(total, dateCreated || '');
  return (
    <Grid container flexDirection={!isMobile ? 'row' : 'column-reverse'}>
      <Grid item md={12}>
        <BoxBodyFeatured>
          <StyledBox>
            <AlignBox>
              <Box padding={isMobile ? '0 1rem' : '0'}>
                <MainInfoAnuncio
                  BreadcrumsLocation={BreadcrumsLocation}
                  title={title}
                  average={average}
                  href={href}
                  total={total}
                  isNew={isNew}
                />
              </Box>
            </AlignBox>
          </StyledBox>

          {!isMobile ? (
            <ShareIconsAAV4Desktop>
              <IndividualIcons
                color="inherit"
                sx={{
                  background: isOpenPopover ? 'rgba(0, 172, 193, 0.3)' : '',
                }}
                size="large"
                // eslint-disable-next-line @typescript-eslint/no-misused-promises
                onClick={mobileShare}
                aria-describedby="simple-popover"
              >
                <StyledShareOutlined
                  fontSize={iconsFontSize}
                  color={isOpenPopover ? 'primary' : undefined}
                />
              </IndividualIcons>
              <FavoriteTooltip variant="ficha" isFavorite={isFavorite || false}>
                <IndividualIcons
                  color={isFavorite ? 'primary' : 'inherit'}
                  size="large"
                  onClick={!isLoadingFav ? addFavorite : () => {}}
                >
                  {isFavorite ? (
                    <FavoriteOutlined fontSize="large" color="primary" />
                  ) : (
                    <FavoriteBorder
                      fontSize="large"
                      htmlColor="rgba(0, 0, 0, 0.8)"
                    />
                  )}
                </IndividualIcons>
              </FavoriteTooltip>
            </ShareIconsAAV4Desktop>
          ) : null}
        </BoxBodyFeatured>
      </Grid>
      <Grid
        item
        md={12}
        mt={2}
        marginTop={isMobile ? '0px' : '10px'}
        marginBottom={isMobile ? '20px' : '0px'}
      >
        <BoxBody
          height={isMobile ? '250px' : 'auto'}
          position={isMobile ? 'relative' : 'static'}
        >
          <BoxBodyDestacada
            data-testid="custom-element"
            onClick={handleOpenModal}
          >
            {featuredImage ? (
              <Image
                src={featuredImage}
                width={responsiveWidthConversor(isMobile, mostrarUnaSolaFoto)}
                height={isMobile ? 250 : 475}
                objectFit="cover"
                alt="Anuncio"
                priority
                loader={({ src }) =>
                  imageLoaderHeaderDesk({
                    src,
                    width: responsiveWidthConversor(
                      isMobile,
                      mostrarUnaSolaFoto,
                    ),
                    height: 475,
                  })
                }
                style={{
                  cursor: 'pointer',
                  borderRadius: `${!isMobile ? '8px' : '0'}`,
                }}
              />
            ) : null}

            {!isMobile && totalPhotos > 2 ? (
              <ButtonViewGallery startIcon={<CollectionsIcon />}>
                {t('textBtn')}
              </ButtonViewGallery>
            ) : null}
            {cyberMonday && !isMobile && (
              <Box position="absolute" bottom={1} left={28}>
                <CyberMondayIcon width="141" height="117" />
              </Box>
            )}
          </BoxBodyDestacada>
          {isMobile ? (
            <Box
              display="flex"
              flexDirection="column"
              width="100%"
              height="100%"
              position="absolute"
              padding="1rem 1rem"
              onClick={(e) => e.stopPropagation()}
            >
              <ShareIconsAAV4Mobile>
                <IndividualIcons
                  color="inherit"
                  size="large"
                  // eslint-disable-next-line @typescript-eslint/no-misused-promises
                  onClick={mobileShare}
                >
                  <ShareOutlined
                    fontSize="medium"
                    sx={{ color: 'rgba(0, 0, 0, .87)' }}
                  />
                </IndividualIcons>
                <FavoriteTooltip
                  variant="ficha"
                  isFavorite={isFavorite || false}
                >
                  <IndividualIcons
                    color="inherit"
                    size="large"
                    onClick={!isLoadingFav ? addFavorite : () => {}}
                  >
                    {isFavorite ? (
                      <FavoriteOutlined color="primary" />
                    ) : (
                      <FavoriteBorder htmlColor="rgba(0, 0, 0, 0.8)" />
                    )}
                  </IndividualIcons>
                </FavoriteTooltip>
              </ShareIconsAAV4Mobile>
              <SpanLengthMobile onClick={handleOpenModal}>
                <Typography fontSize="1rem">1 / {totalPhotos}</Typography>
              </SpanLengthMobile>
              {cyberMonday && (
                <Box position="absolute" top="auto" bottom={1} left={28}>
                  <CyberMondayIcon width="85" height="70" />
                </Box>
              )}
              <BoxMobileFeaturedCick onClick={handleOpenModal} />
            </Box>
          ) : null}
          {!mostrarUnaSolaFoto && !isMobile && (
            <BoxBodyMansory
              sx={{
                display: { xs: 'none', md: 'flex' },
                width: '40%',
                height: '100%',
              }}
              onClick={handleOpenModal}
            >
              <BoxBodyMansoryHeader
                id="imagenDestacadaMansory"
                onClick={handleOpenModal}
              />
              <Image
                src={imagesArray[0].img}
                width={341}
                height={233}
                priority
                objectFit="cover"
                style={{ borderRadius: '8px' }}
                loader={({ src }) =>
                  imageLoaderHeaderDesk({
                    src,
                    width: 341,
                    height: 233,
                  })
                }
              />

              <BoxBodyMansoryLastPhotos>
                {imagesArray.map(({ id, img }, index) => {
                  if (index > 0 && index < 3) {
                    return (
                      <Image
                        src={img}
                        width={167}
                        height={233}
                        objectFit="cover"
                        priority
                        key={`header_sm-${id}`}
                        style={{ borderRadius: '8px' }}
                        loader={({ src }) =>
                          imageLoaderHeaderDesk({
                            src,
                            width: 167,
                            height: 233,
                          })
                        }
                      />
                    );
                  }
                  return null;
                })}

                <ButtonViewGallery startIcon={<CollectionsIcon />}>
                  {t('textBtn')}
                </ButtonViewGallery>
              </BoxBodyMansoryLastPhotos>
            </BoxBodyMansory>
          )}
        </BoxBody>
      </Grid>
      <MediaViewImages
        imagesTypologys={imagesTypologys}
        video={video ? `https://www.youtube.com/embed/${video}` : ''}
        iframe={iframe}
        imagelist={imagesArray}
        openViewImage={openViewImage}
        setOpenViewImage={setOpenViewImage}
        featuredImage={featuredImage}
        open={open}
        setOpen={setOpen}
      />
    </Grid>
  );
};

export default memo(HeaderAnuncio);
