/* eslint-disable no-console */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/indent */
/* eslint-disable consistent-return */
import {
  Button,
  Divider,
  Grid,
  Typography,
  Alert,
  SelectPeople,
  IconButton,
  Tooltip,
} from '@alquiler-argentina/demiurgo';
import {
  Box,
  Divider as DividerMUI,
  styled,
  Dialog,
  DialogTitle,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  ClickAwayListener,
  Paper,
  LinkProps,
} from '@mui/material';
import LoadingButton from '@mui/lab/LoadingButton';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CloseIcon from '@mui/icons-material/Close';
import React, { memo, useCallback, useMemo } from 'react';
import { useTranslation } from 'next-i18next';
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import * as Sentry from '@sentry/nextjs';
import groupBy from '../../utils/helpers/groupBy';

import CheckoutSic from '../CheckoutSic';
import {
  sendBeginCheckoutSIRODataGTM,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  sendCheckoutSIRODataGTM,
  TEventType,
} from '../../utils/helpers/sendDataGTM';
import { fillMountAndSenia } from '../../redux/checkout/slice';
import { ICheckoutState } from '../../redux/checkout/types';
import InactiveBookingSummary, {
  LinkPropsExt,
} from '../InactiveBookingSummary';
import { IPrice } from '../../types/propiedades.types';
import formatPriceNoDiscount from '../../utils/helpers/formatPriceNoDiscount';
import calculateDateRange from '../../utils/helpers/calculateDateRange';
import calculateRevenuePercentage from '../../utils/helpers/calculateRevenuePercentage';
import { formatPriceToArs } from '../../utils/helpers/formatPriceToArs';
import useIsMobile from '../../hooks/useIsMobile';
import determinateCheckoutRoute from '../../utils/helpers/determinateCheckoutRoute';
import ChatFAQS from '../ChatFAQS/ChatFAQS';
import { addUrlToHistory } from '../../utils/helpers/localStorageHelper';

const SummaryReserveData = styled(Grid)`
  border: 1px solid rgba(0, 0, 0, 0.12);
  margin-bottom: 24px;
  border-radius: 4px;
`;

const CaptionInput = styled(Typography)`
  color: rgba(0, 0, 0, 0.6);
  margin: 0.25rem 0;
`;

const InputDataExtra = styled(Typography)`
  font-size: 12px;
  color: rgba(0, 0, 0, 0.87);
  margin-left: 4px;
`;

const LabelMoreInfoPrice = styled(Typography)`
  font-size: 12px;
  margin-left: 4px;
  display: flex;
  margin-top: 4px;
`;

const ContactButton = styled(Button)`
  width: 100%;
  text-transform: none;
  font-weight: 600;
`;

const ContactButtonLoading = styled(LoadingButton)`
  width: 100%;
  text-transform: none;
  font-weight: 600;
`;

const BookingSummaryDesktop = styled(Grid)`
  width: 340px;
  border-radius: 8px;
  padding: 24px;
  box-shadow: 0px 0px 18px 3px rgba(0, 0, 0, 0.09);
  margin-right: -55px;
`;

const BookingSummaryMobile = styled(Paper)`
  width: 100%;
  padding: 1rem;
  background-color: #fff;
  position: fixed;
  bottom: 0;
  left: 0;
  /* box-shadow: 0px -1px 12px -4px rgba(0, 0, 0, 0.25); */
`;

const LabelTextDesde = styled(Typography)`
  margin-right: 6px;
  font-size: 12px;
  color: rgba(0, 0, 0, 0.6);
`;

const LabelTextPeople = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  font-size: 14px;
`;

const ItemsDetailsPrice = styled(Typography)`
  color: rgba(0, 0, 0, 0.87);
  font-size: 14px;
`;

const ItemsDetailsPriceDiscount = styled(Typography)`
  color: #00acc1;
  font-size: 14px;
`;

const ItemsDetailsCyberMonday = styled(Typography)`
  color: #7d34c4;
  font-size: 0.875rem;
`;

const AccordionValueDiffers = styled(Accordion)`
  border-radius: 0;
  box-shadow: none;
  .MuiButtonBase-root {
    min-height: auto !important;
    padding: 0;
    .MuiAccordionSummary-content {
      margin: 0;
    }
  }
  .MuiCollapse-root {
    .MuiAccordionDetails-root {
      padding: 0;
    }
  }
`;

const ButtonBaseDates = styled(Button)`
  padding: 0;
  text-transform: none;
  margin-right: 5px;
  text-decoration: underline;
  color: rgba(0, 0, 0, 0.87);
`;

const ModalMoreInfo = styled(Dialog)`
  .MuiDialog-container {
    align-items: flex-end;
    .MuiDialog-paper {
      margin: 0;
      width: 100%;
      padding: 0.5rem 1rem;
      border-radius: 8px 8px 0px 0px;
      margin-bottom: 80px;
      padding-bottom: 24px;
      z-index: 1301;
    }
  }
`;

const TitleDetailsPriceDialog = styled(DialogTitle)`
  display: flex;
  padding-left: 0;
  padding-right: 0;
  justify-content: space-between;
  padding-bottom: 2rem;
  color: black;
`;

const StyledSelectPeople = styled('div')`
  width: 95%;
  position: absolute;
  z-index: 1;
  right: 26px;
  top: 24px;
`;

const StyleAlert = styled(Alert)`
  margin-bottom: 24px;
`;

const StyledCloseIcon = styled(CloseIcon)`
  color: rgba(0, 0, 0, 0.54);
`;

const StyledInfoOutlinedIcon = styled(InfoOutlinedIcon)`
  position: relative;
  top: 0.125rem;
  left: 0.3rem;
  color: #0000008a;
`;

interface ITelefonos {
  number?: string;
}

interface Props {
  isSIC: boolean;
  isSIRO?: boolean;
  blocked: boolean;
  blockedMessage: string | null;
  price?: number | null;
  startDate: string | null;
  endDate: string | null;
  cleaningFee?: number;
  cargoExtra?: number;
  guests?: number;
  dayValueDiffers: boolean;
  title?: string;
  unidad?: string;
  referencia: string;
  whatsappNumber?: string;
  telefonos?: ITelefonos[];
  name?: string;
  peopleMax?: number;
  pets?: boolean;
  basePrice: number | null;
  totalDays: number | null;
  idTipologia?: number | null;
  persons: {
    adults: number;
    children: number;
    babies: number;
    total: number;
    mascotas: boolean;
  };
  porcentajeSenia?: number | null;
  selectedDiscount: number | null;
  dataOcupaciones?: IPrice[];
  setOpenCalendar: (value: boolean) => void;
  changeProps: (key: string, value: unknown) => void;
  gtm: (eventType: TEventType) => void;
  setOpenCheckoutSic: (value: boolean) => void;
  openCheckoutSIC: boolean;
  emailPropietario: boolean | null;
  active?: boolean;
  location: LinkProps[] | null;
  hasPhoneNumber?: boolean;
  hasWhatsapp?: boolean;
  isFeatured?: boolean;
  isImmediate: boolean;
  testProperty: boolean;
  isGold?: boolean;
  cyberMondayDiscount?: number | null;
}

const SHOW_FOMO = Math.random() > 0.5;

function BookingSummary({
  title,
  unidad,
  name,
  telefonos,
  whatsappNumber,
  referencia,
  isSIC,
  isSIRO,
  price,
  startDate,
  endDate,
  cleaningFee,
  guests,
  dayValueDiffers,
  peopleMax,
  idTipologia,
  persons,
  pets,
  basePrice,
  totalDays,
  cargoExtra,
  porcentajeSenia,
  selectedDiscount,
  blocked,
  blockedMessage,
  setOpenCalendar,
  changeProps,
  gtm,
  dataOcupaciones,
  setOpenCheckoutSic,
  openCheckoutSIC,
  emailPropietario,
  active,
  location,
  hasPhoneNumber,
  hasWhatsapp,
  isGold,
  isFeatured,
  isImmediate,
  testProperty,
  cyberMondayDiscount,
}: Props) {
  const { t } = useTranslation('BookingSummary');
  const dispatch = useDispatch();
  const isMobile = useIsMobile();
  const [openModal, setOpenModal] = React.useState(false);
  const [selectPeople, setSelectPeople] = React.useState(false);
  const handleClose = () => {
    setOpenModal(false);
  };
  const { personas, mascotas } = useSelector(
    ({ checkout }: { checkout: ICheckoutState }) => checkout.reserva,
  );
  const prices = dataOcupaciones?.find((el) => el.id === idTipologia);
  const initialValue = 0;
  const subtotalPrice = prices?.precios.descuentos[personas - 1]
    ? prices?.precios.base.reduce(
        (acc, curr) => acc + curr.precio,
        initialValue,
      )
    : 0;
  const noDates = !!(!startDate && !endDate);
  const costoLimpieza = cleaningFee || 0;
  const costoExtra = cargoExtra || 0;
  const discount = selectedDiscount || 0;
  const totalDiscount = subtotalPrice ? subtotalPrice * (discount / 100) : 0;
  const basePriceWithCosts = basePrice
    ? costoLimpieza + costoExtra + basePrice
    : basePrice;
  const detailPrice = groupBy(
    prices?.precios ? prices?.precios.base : [],
    'precio',
  );
  const auxDiscount = prices?.precios.descuentos.find(
    (el) => el.personas === personas,
  )?.descuento;
  const noDatesDiscount =
    !auxDiscount || auxDiscount === 0 ? 1 : 1 - auxDiscount / 100;
  const priceToMap = useMemo(
    () => (detailPrice ? Object.values(detailPrice) : []),
    [detailPrice],
  );
  const cyberMondayDiscounted =
    subtotalPrice && cyberMondayDiscount
      ? subtotalPrice * (cyberMondayDiscount / 100)
      : 0;
  const totalPrice = subtotalPrice
    ? Math.round(
        costoLimpieza +
          costoExtra +
          subtotalPrice -
          totalDiscount -
          cyberMondayDiscounted,
      )
    : 0;
  const seniaTotal = porcentajeSenia ? totalPrice * (porcentajeSenia / 100) : 0;
  const [openButtonLoading, setOpenButtonLoading] = React.useState(false);
  const router = useRouter();
  const arrangedStartDate = startDate?.split('/').reverse().join('-');
  const arrangedEndDate = endDate?.split('/').reverse().join('-');
  const nextRoute = determinateCheckoutRoute(discount, SHOW_FOMO, testProperty);
  // eslint-disable-next-line consistent-return
  const handleGTMTrigger = useCallback(
    (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
      e.preventDefault();

      if (!startDate || !endDate) {
        setOpenCalendar(true);
        setOpenButtonLoading(false);
        return;
      }

      const totalPriceRounded = auxDiscount
        ? Math.round(totalPrice / 100) * 100
        : totalPrice;

      const payload = {
        monto: totalPriceRounded,
        senia: seniaTotal,
        precioBase: subtotalPrice,
        descuento: discount,
        detallePrecio: priceToMap as [],
        isImmediate,
      };
      dispatch(
        // eslint-disable-next-line @typescript-eslint/no-unsafe-call
        fillMountAndSenia(payload),
      );
      if (
        referencia &&
        title &&
        arrangedStartDate &&
        arrangedEndDate &&
        payload.monto
      ) {
        const revenuePercentage = calculateRevenuePercentage(
          isFeatured,
          isGold,
        );
        const revenueWithTax = !isSIRO ? 0 : payload.monto * revenuePercentage;
        const tax = revenueWithTax - revenueWithTax / 1.21;
        const revenue = revenueWithTax - tax;

        const beginCheckoutData = {
          reference: referencia,
          title,
          stay: calculateDateRange(arrangedStartDate, arrangedEndDate),
          revenueWithTax,
          tax,
          revenue,
        };

        sendCheckoutSIRODataGTM({ referencia, titulo: title }, 1);
        sendBeginCheckoutSIRODataGTM(beginCheckoutData);
      }
      router
        .push(nextRoute)
        .then(() => {
          addUrlToHistory(router.asPath);
        })
        .catch((error) => {
          Sentry.captureException(error);
        });
    },
    [
      auxDiscount,
      discount,
      dispatch,
      endDate,
      priceToMap,
      referencia,
      router,
      seniaTotal,
      setOpenCalendar,
      startDate,
      subtotalPrice,
      title,
      totalPrice,
      arrangedStartDate,
      arrangedEndDate,
      isGold,
      isFeatured,
      isImmediate,
      isSIRO,
      nextRoute,
    ],
  );

  const handleCheckoutSic = () => {
    if (!startDate || !endDate) {
      setOpenCalendar(true);
    } else {
      setOpenCheckoutSic(true);
    }
  };

  const openSelectPeople = () => {
    setSelectPeople(true);
  };

  if (active === undefined) {
    return null;
  }

  if (!active && !isMobile) {
    return <InactiveBookingSummary location={location as LinkPropsExt[]} />;
  }

  if (openCheckoutSIC && !isMobile) {
    return (
      <CheckoutSic
        totalAmount={
          auxDiscount ? Math.round(totalPrice / 100) * 100 : totalPrice
        }
        setOpenCheckoutSic={setOpenCheckoutSic}
        telefonos={telefonos}
        name={name}
        alojamiento={title}
        unidad={unidad}
        whatsappNumber={whatsappNumber}
        referencia={referencia}
        huespedes={personas}
        mascotas={mascotas}
        gtm={gtm}
        emailPropietario={emailPropietario}
        hasPhoneNumber={hasPhoneNumber}
        hasWhatsapp={hasWhatsapp}
      />
    );
  }
  return (
    <Box data-testid="BookingSummaryContainer">
      {!isMobile ? (
        <BookingSummaryDesktop>
          {blocked && (
            <StyleAlert severity="error">
              <Typography>{blockedMessage}</Typography>
            </StyleAlert>
          )}
          <SummaryReserveData>
            {!blocked ? (
              <Box padding="0 6px">
                <CaptionInput
                  variant="body1"
                  fontSize="0.75rem"
                  sx={{ marginBottom: '0px' }}
                >
                  {(endDate && startDate) !== null || basePrice === null
                    ? t('total-price')
                    : t('start-price')}
                </CaptionInput>
                <Box display="flex" alignItems="baseline" marginBottom="4px">
                  {subtotalPrice > 0 ? (
                    <>
                      <Typography
                        variant="body1"
                        fontWeight="700"
                        fontSize="1.25rem"
                      >
                        {noDates && basePriceWithCosts && auxDiscount
                          ? `${formatPriceToArs(
                              basePriceWithCosts * noDatesDiscount,
                            )}`
                          : null}
                        {noDates && basePriceWithCosts && !auxDiscount
                          ? `$${formatPriceNoDiscount(basePriceWithCosts)}`
                          : null}
                        {!noDates && basePriceWithCosts && auxDiscount
                          ? `${formatPriceToArs(totalPrice)}`
                          : null}
                        {!noDates && basePriceWithCosts && !auxDiscount
                          ? `$${formatPriceNoDiscount(totalPrice)}`
                          : null}
                      </Typography>
                      {startDate && endDate ? (
                        <InputDataExtra> {t('taxes-included')} </InputDataExtra>
                      ) : (
                        <Box display="flex" alignItems="flex-end">
                          <InputDataExtra marginRight={1}>
                            {t('per-night')}
                          </InputDataExtra>
                          <Tooltip
                            variant="secondary"
                            placement="top"
                            arrow
                            title={t('titleTooltip')}
                            sx={{
                              marginLeft: '8px',
                            }}
                          >
                            <InfoOutlinedIcon
                              fontSize="small"
                              sx={{ color: '#0000008A' }}
                            />
                          </Tooltip>
                        </Box>
                      )}
                    </>
                  ) : (
                    <Typography
                      variant="body1"
                      fontWeight="600"
                      fontSize="1.25rem"
                    >
                      {t('checkPrice')}
                    </Typography>
                  )}
                </Box>
              </Box>
            ) : null}
            <Divider />
            <Box
              onClick={() => setOpenCalendar(true)}
              sx={{ cursor: 'pointer' }}
              display="flex"
              justifyContent="space-between"
              padding="0 8px"
            >
              <Box width="45%" marginBottom="6px">
                <CaptionInput variant="body1" fontSize="0.75rem">
                  {t('arrival')}
                </CaptionInput>
                <Typography
                  variant="body1"
                  fontWeight="700"
                  fontSize="0.8rem"
                  color={!startDate ? 'GrayText' : 'initial'}
                >
                  {!startDate ? t('choose-date') : startDate}
                </Typography>
              </Box>
              <DividerMUI orientation="vertical" flexItem />
              <Box width="45%" marginBottom="6px">
                <CaptionInput variant="body1" fontSize="0.75rem">
                  {t('exit')}
                </CaptionInput>
                <Typography
                  variant="body1"
                  fontWeight="700"
                  fontSize="0.8rem"
                  color={!endDate ? 'GrayText' : 'initial'}
                >
                  {!endDate ? t('choose-date') : endDate}
                </Typography>
              </Box>
            </Box>
            <Divider />
            <Box
              onClick={openSelectPeople}
              sx={{
                cursor: 'pointer',
                paddingLeft: '6px',
                paddingBottom: '4px',
              }}
            >
              <CaptionInput variant="body1" fontSize="0.75rem">
                {t('guests')}
              </CaptionInput>
              <Typography variant="body1" fontWeight={700} fontSize="0.8rem">
                {personas > 1 ? `${personas} personas` : `${personas} persona`}{' '}
              </Typography>
            </Box>
            {selectPeople && (
              <ClickAwayListener onClickAway={() => setSelectPeople(false)}>
                <StyledSelectPeople>
                  <SelectPeople
                    handleClose={() => setSelectPeople(false)}
                    aceptaMascotas={pets || false}
                    persons={persons}
                    changeProps={changeProps}
                    typologyMaxCapacity={peopleMax || 2}
                  />
                </StyledSelectPeople>
              </ClickAwayListener>
            )}
            <Divider />
            <Box padding="0 6px 4px 6px">
              <CaptionInput variant="body1" fontSize="0.75rem">
                {t('unit-selected')}
              </CaptionInput>
              <Typography variant="body1" fontWeight="700" fontSize="0.8rem">
                {!blocked ? unidad : 'No hay opciones disponibles'}
              </Typography>
            </Box>
          </SummaryReserveData>

          {isSIRO && active ? (
            <ContactButtonLoading
              variant="contained"
              size="large"
              disabled={blocked || subtotalPrice === 0 || !idTipologia}
              loading={openButtonLoading}
              onClick={handleGTMTrigger}
            >
              {t('reserve')}
            </ContactButtonLoading>
          ) : null}

          {isSIRO &&
            !isSIC &&
            startDate &&
            endDate &&
            !!active &&
            !blocked &&
            router.query?.sm === 'a' && (
              <ChatFAQS
                reference={referencia}
                handleReserve={handleGTMTrigger}
                price={totalPrice}
              />
            )}

          {isSIC && active ? (
            <ContactButton
              variant={isSIRO ? 'outlined' : 'contained'}
              size="large"
              onClick={handleCheckoutSic}
              disabled={blocked || !idTipologia}
              sx={isSIRO ? { marginTop: '16px' } : null}
              data-testid="boton-contactar"
            >
              {t('contact-accommodation')}
            </ContactButton>
          ) : null}

          {price && startDate && endDate && !blocked && subtotalPrice > 0 && (
            <Box marginTop="24px">
              <Typography
                variant="body1"
                marginBottom="12px"
                sx={{ fontWeight: '600' }}
              >
                {t('price-detail')}
              </Typography>
              <Box
                display="flex"
                justifyContent="space-between"
                marginBottom="8px"
              >
                <Box display="flex" alignItems="baseline">
                  {dayValueDiffers ? (
                    <AccordionValueDiffers>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        id="panel1a-header"
                      >
                        <Typography variant="body2">
                          {t('accommodation')} ({totalDays}
                          {totalDays && totalDays > 1 ? ' noches' : ' noche'})
                        </Typography>
                      </AccordionSummary>
                      <AccordionDetails>
                        {priceToMap.map((elem: any, ind) => {
                          if (auxDiscount) {
                            return (
                              <LabelMoreInfoPrice key={ind}>
                                {`${formatPriceToArs(
                                  (elem[0].precio as number) || 0,
                                )} x
                              ${elem.length as number}
                              ${t('nights', {
                                count: elem.length as number,
                                nights: elem.length as number,
                              })}`}
                              </LabelMoreInfoPrice>
                            );
                          }
                          return (
                            <LabelMoreInfoPrice key={ind}>
                              {`$${formatPriceNoDiscount(
                                (elem[0].precio as number) || 0,
                              )} x
                            ${elem.length as number}
                            ${t('nights', {
                              count: elem.length as number,
                              nights: elem.length as number,
                            })}`}
                            </LabelMoreInfoPrice>
                          );
                        })}
                      </AccordionDetails>
                    </AccordionValueDiffers>
                  ) : (
                    <>
                      <Typography variant="body2">
                        {t('accommodation')}
                      </Typography>
                      <LabelMoreInfoPrice>
                        {auxDiscount &&
                          `${formatPriceToArs(basePrice || 0)} x ${
                            totalDays || 0
                          } noches`}
                        {!auxDiscount &&
                          `${formatPriceNoDiscount(basePrice || 0)} x ${
                            totalDays || 0
                          } noches`}
                      </LabelMoreInfoPrice>
                    </>
                  )}
                </Box>
                <Typography variant="body2">
                  {auxDiscount
                    ? `${formatPriceToArs(subtotalPrice)}`
                    : `$${formatPriceNoDiscount(subtotalPrice)}`}
                </Typography>
              </Box>
              {selectedDiscount ? (
                <Box
                  display="flex"
                  justifyContent="space-between"
                  marginBottom="8px"
                  color="#00ACC1"
                >
                  <ItemsDetailsPriceDiscount variant="body2">
                    Descuento {Math.trunc(selectedDiscount)}% Off
                  </ItemsDetailsPriceDiscount>
                  <ItemsDetailsPriceDiscount variant="body2">
                    -
                    {totalDays !== null && basePrice !== null
                      ? formatPriceToArs(totalDiscount)
                      : null}
                  </ItemsDetailsPriceDiscount>
                </Box>
              ) : null}
              {cyberMondayDiscount ? (
                <Box
                  display="flex"
                  justifyContent="space-between"
                  marginBottom="0.5rem"
                  color="#7D34C4"
                >
                  <ItemsDetailsCyberMonday variant="body2">
                    Cyber Monday {cyberMondayDiscount}% Off
                  </ItemsDetailsCyberMonday>
                  <ItemsDetailsCyberMonday variant="body2">
                    -{formatPriceToArs(cyberMondayDiscounted)}
                  </ItemsDetailsCyberMonday>
                </Box>
              ) : null}
              {cleaningFee && (
                <Box
                  display="flex"
                  justifyContent="space-between"
                  marginBottom="8px"
                >
                  <Typography variant="body2"> {t('cleaning')} </Typography>
                  <Typography variant="body2">
                    {formatPriceToArs(cleaningFee)}
                  </Typography>
                </Box>
              )}
              {cargoExtra && (
                <Box
                  display="flex"
                  justifyContent="space-between"
                  marginBottom="8px"
                >
                  <Typography variant="body2"> Otros cargos</Typography>
                  <Typography variant="body2">
                    {formatPriceToArs(cargoExtra)}
                  </Typography>
                </Box>
              )}

              <Divider />
              <Box
                display="flex"
                justifyContent="space-between"
                marginTop="8px"
              >
                <Typography
                  variant="button"
                  fontWeight="600"
                  textTransform="none"
                >
                  {t('total')} (ARS)
                </Typography>
                <Typography variant="button" fontWeight="600">
                  {auxDiscount
                    ? `${formatPriceToArs(totalPrice)}`
                    : `$${formatPriceNoDiscount(totalPrice)}`}
                </Typography>
              </Box>
            </Box>
          )}
        </BookingSummaryDesktop>
      ) : (
        <BookingSummaryMobile
          sx={{
            zIndex: openModal ? 9999 : 400,
            display: `${active ? 'initial' : 'none'}`,
          }}
          elevation={6}
        >
          {openCheckoutSIC ? (
            <CheckoutSic
              totalAmount={
                auxDiscount ? Math.round(totalPrice / 100) * 100 : totalPrice
              }
              setOpenCheckoutSic={setOpenCheckoutSic}
              telefonos={telefonos}
              name={name}
              alojamiento={title}
              unidad={unidad}
              whatsappNumber={whatsappNumber}
              referencia={referencia}
              huespedes={personas}
              mascotas={mascotas}
              gtm={gtm}
              emailPropietario={emailPropietario}
              hasWhatsapp={hasWhatsapp}
              hasPhoneNumber={hasPhoneNumber}
            />
          ) : (
            <>
              <Grid container display="flex" alignItems="center">
                {totalPrice ? (
                  <>
                    <Grid item xs={6}>
                      <Box
                        display="flex"
                        alignItems="baseline"
                        onClick={() => setOpenModal(true)}
                      >
                        {!startDate && !endDate && (
                          <LabelTextDesde variant="caption">
                            {t('since')}
                          </LabelTextDesde>
                        )}

                        <Typography
                          variant="h6"
                          fontWeight="700"
                          fontSize="1.25rem"
                        >
                          {noDates && basePriceWithCosts
                            ? `${formatPriceToArs(
                                Math.round(
                                  basePriceWithCosts * noDatesDiscount,
                                ),
                              )}`
                            : `${formatPriceToArs(totalPrice)}`}
                        </Typography>
                        <Tooltip
                          variant="secondary"
                          placement="top"
                          arrow
                          title={t('titleTooltip')}
                          disableTouchListener
                        >
                          <StyledInfoOutlinedIcon
                            fontSize="small"
                            color="inherit"
                          />
                        </Tooltip>
                      </Box>
                      {selectPeople ?? (
                        <SelectPeople
                          handleClose={setSelectPeople}
                          aceptaMascotas={pets || false}
                          persons={persons}
                          changeProps={changeProps}
                          typologyMaxCapacity={guests || 2}
                        />
                      )}
                      <LabelTextPeople
                        onClick={openSelectPeople}
                        variant="body2"
                      >
                        {!startDate && !endDate
                          ? `${t('per-night')}, ${persons.total || ''} ${
                              persons.total === 1 ? 'persona' : 'personas'
                            }`
                          : `${totalDays || 1} ${
                              totalDays === 1 ? 'noche' : 'noches'
                            }, ${persons.total || ''} ${
                              persons.total === 1 ? 'persona' : 'personas'
                            }`}
                      </LabelTextPeople>
                    </Grid>
                    <Grid item xs={6} display={active ? 'grid' : 'none'}>
                      {isSIRO ? (
                        <ContactButtonLoading
                          variant="contained"
                          size="large"
                          disabled={
                            blocked || subtotalPrice === 0 || !idTipologia
                          }
                          loading={openButtonLoading}
                          onClick={handleGTMTrigger}
                        >
                          <Typography fontSize="0.9rem" fontWeight="600">
                            {t('reserve')}
                          </Typography>
                        </ContactButtonLoading>
                      ) : (
                        <ContactButton
                          onClick={handleCheckoutSic}
                          variant="contained"
                          size="large"
                          disabled={blocked || !idTipologia}
                        >
                          <Typography fontSize="0.9rem" fontWeight="600">
                            {t('contact')}
                          </Typography>
                        </ContactButton>
                      )}
                    </Grid>
                  </>
                ) : (
                  <Grid item xs={12} display={active ? 'grid' : 'none'}>
                    {isSIRO ? (
                      <ContactButtonLoading
                        variant="contained"
                        size="large"
                        disabled={
                          blocked || subtotalPrice === 0 || !idTipologia
                        }
                        loading={openButtonLoading}
                        onClick={handleGTMTrigger}
                      >
                        <Typography fontSize="0.9rem" fontWeight="600">
                          {t('reserve')}
                        </Typography>
                      </ContactButtonLoading>
                    ) : (
                      <ContactButton
                        onClick={handleCheckoutSic}
                        variant="contained"
                        size="large"
                        disabled={blocked || !idTipologia}
                        sx={{ display: `${active ? 'initial' : 'none'}` }}
                      >
                        <Typography fontSize="0.9rem" fontWeight="600">
                          {t('contact-accommodation')}
                        </Typography>
                      </ContactButton>
                    )}
                  </Grid>
                )}
              </Grid>
              <ModalMoreInfo onClose={handleClose} open={openModal}>
                {startDate && endDate && (
                  <TitleDetailsPriceDialog onClick={() => handleClose()}>
                    <Typography fontSize="1rem">{t('price-detail')}</Typography>
                    <StyledCloseIcon />
                  </TitleDetailsPriceDialog>
                )}
                {startDate && endDate && subtotalPrice > 0 ? (
                  <Box>
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      marginBottom="8px"
                    >
                      <Box display="flex" alignItems="baseline">
                        {dayValueDiffers ? (
                          <Box>
                            <ItemsDetailsPrice variant="body2">
                              {t('accommodation')}
                            </ItemsDetailsPrice>
                            {priceToMap.map((elem: any, ind) => (
                              <LabelMoreInfoPrice key={ind}>
                                {`${formatPriceToArs(
                                  (elem[0].precio as number) || 0,
                                )}
                                x ${elem.length as number} noches`}
                              </LabelMoreInfoPrice>
                            ))}
                          </Box>
                        ) : (
                          <>
                            <ItemsDetailsPrice variant="body2">
                              {t('accommodation')}
                            </ItemsDetailsPrice>
                            <LabelMoreInfoPrice>
                              ({formatPriceToArs(basePrice || 0)} x {totalDays}{' '}
                              noches)
                            </LabelMoreInfoPrice>
                          </>
                        )}
                      </Box>
                      <ItemsDetailsPrice variant="body2">
                        {formatPriceToArs(subtotalPrice)}
                      </ItemsDetailsPrice>
                    </Box>
                    {selectedDiscount ? (
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        marginBottom="8px"
                        color="#00ACC1"
                      >
                        <ItemsDetailsPriceDiscount variant="body2">
                          Descuento {Math.trunc(selectedDiscount)}% Off
                        </ItemsDetailsPriceDiscount>
                        <ItemsDetailsPriceDiscount variant="body2">
                          -{formatPriceToArs(totalDiscount)}
                        </ItemsDetailsPriceDiscount>
                      </Box>
                    ) : null}
                    {cyberMondayDiscount ? (
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        marginBottom="0.5rem"
                        color="#7D34C4"
                      >
                        <ItemsDetailsCyberMonday variant="body2">
                          Cyber Monday {cyberMondayDiscount}% Off
                        </ItemsDetailsCyberMonday>
                        <ItemsDetailsCyberMonday variant="body2">
                          -{formatPriceToArs(cyberMondayDiscounted)}
                        </ItemsDetailsCyberMonday>
                      </Box>
                    ) : null}
                    {cleaningFee && (
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        marginBottom="8px"
                      >
                        <ItemsDetailsPrice variant="body2">
                          {t('cleaning')}
                        </ItemsDetailsPrice>
                        <ItemsDetailsPrice variant="body2">
                          {formatPriceToArs(cleaningFee)}
                        </ItemsDetailsPrice>
                      </Box>
                    )}
                    {cargoExtra && (
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        marginBottom="8px"
                      >
                        <ItemsDetailsPrice variant="body2">
                          Otros cargos
                        </ItemsDetailsPrice>
                        <ItemsDetailsPrice variant="body2">
                          {formatPriceToArs(cargoExtra)}
                        </ItemsDetailsPrice>
                      </Box>
                    )}

                    <Divider />
                    <Box
                      display="flex"
                      justifyContent="space-between"
                      marginTop="8px"
                    >
                      <ItemsDetailsPrice
                        variant="button"
                        fontWeight="600"
                        textTransform="none"
                      >
                        {t('total')} (ARS)
                      </ItemsDetailsPrice>
                      <ItemsDetailsPrice variant="button" fontWeight="600">
                        {formatPriceToArs(totalPrice)}
                      </ItemsDetailsPrice>
                    </Box>
                  </Box>
                ) : (
                  <Box paddingTop={1} display="flex" alignItems="center">
                    <Typography
                      variant="body2"
                      color="rgba(0, 0, 0, 0.87)"
                      fontSize="0.8rem"
                      width="90%"
                    >
                      <ButtonBaseDates onClick={() => setOpenCalendar(true)}>
                        <Typography fontWeight="600" fontSize="0.8rem">
                          {t('selected-date')}
                        </Typography>
                      </ButtonBaseDates>
                      {t('of-arrival-and-departure')}
                    </Typography>
                    <IconButton
                      endIcon={<StyledCloseIcon />}
                      color="inherit"
                      onClick={handleClose}
                    />
                  </Box>
                )}
              </ModalMoreInfo>
            </>
          )}
        </BookingSummaryMobile>
      )}
    </Box>
  );
}

export default memo(BookingSummary);
