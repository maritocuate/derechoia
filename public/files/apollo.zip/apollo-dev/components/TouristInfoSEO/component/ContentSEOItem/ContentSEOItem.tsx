import { Box, Typography, styled } from '@mui/material';
import React from 'react';
import { LocalityTouristInfoSeo } from '../../../../types/listado.type';
import { getTitleTouristInfo } from '../../../../utils/helpers/getTitleTouristInfo/getTitleTouristInfo';

const StyledTypographyTitle = styled(Typography)`
  display: flex;
  padding: 0.5rem 0rem;
  align-items: center;
  align-self: stretch;
  font-weight: 600;
` as typeof Typography;

const ContentSEOItem = ({
  contentSEO: { title, content },
  place,
}: {
  contentSEO: LocalityTouristInfoSeo;
  place: string;
}) => {
  const newTitle = getTitleTouristInfo(title, place);
  return (
    <Box display="flex" flexDirection="column" marginTop="1rem">
      <StyledTypographyTitle component="h2" color="primary">
        {newTitle}
      </StyledTypographyTitle>
      <Typography fontSize="1rem" color="rgba(0, 0, 0, 0.87)">
        {content}
      </Typography>
    </Box>
  );
};

export default ContentSEOItem;
