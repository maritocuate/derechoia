import React, { memo } from 'react';
import { Box, Typography, styled } from '@mui/material';
import { LocalityTouristInfoSeo } from '../../types/listado.type';
import ContentSEOItem from './component/ContentSEOItem/ContentSEOItem';

interface TouristInfoSEOProps {
  contentSEO: LocalityTouristInfoSeo[];
  place: string;
}

const StyledContaninerMaster = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  margin-bottom: 5.69rem;
  padding: 1rem;
  ${theme.breakpoints.up('lg')} {
    padding: 1rem 0;
    margin-bottom: 0;
  }`,
);

const StyledContaninerChildren = styled(Box)(
  ({ theme }) => `
  display: flex;
  flex-direction: column;
  width: 100%;
  gap: 1rem;
  padding: 1.5rem 1.5rem 2rem 1.5rem;
  border-radius: 8px;
  border: 1px solid rgba(0, 0, 0, 0.23);
  ${theme.breakpoints.up('lg')} {
    width: 100%;
  }

`,
);

const TouristInfoSEO = ({ contentSEO, place }: TouristInfoSEOProps) => {
  return (
    <StyledContaninerMaster>
      <StyledContaninerChildren data-testid="TouristInfoSEO-container">
        <Typography
          component="h2"
          fontSize="1.25rem"
          fontWeight={700}
          data-testid="TouristInfoSEO-h6"
        >
          Información turística de {place}
        </Typography>
        {contentSEO.map(
          (contentItem) =>
            contentItem &&
            contentItem.title && (
              <ContentSEOItem
                contentSEO={contentItem}
                key={contentItem.title}
                place={place}
              />
            ),
        )}
      </StyledContaninerChildren>
    </StyledContaninerMaster>
  );
};

export default memo(TouristInfoSEO);
