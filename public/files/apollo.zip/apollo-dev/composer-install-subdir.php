<?php

chdir("src");
exec("composer install --no-dev");