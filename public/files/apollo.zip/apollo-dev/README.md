# Apollo

Front de [Alquier Argentina](https://www.alquilerargentina.com) basado en nextjs, react y typescript.

## Description

> Es un pequeño paso para un hombre, pero un gran salto para la humanidad. — Neil Armstrong.

Inspirados en este gran hito de la humanidad nos proponemos a dar el gran salto y cumplir con nuestra visión acompañados de las ultimas tecnologías.

### Technologies

- [Next.js](https://nextjs.org/)
- [React](https://es.reactjs.org/)
- [Typescript](https://www.typescriptlang.org/)

## Storybook

TBI or not TBI that is the question

## Installation

Crear un archivo llamado '.npmrc' en el root del proyecto con el siguiente contenido:

```
@alquiler-argentina:registry=https://gitlab.com/api/v4/projects/37125859/packages/npm/
//gitlab.com/api/v4/projects/37125859/packages/npm/:_authToken=${NPM_TOKEN}
```

y cambiar NPM_TOKEN por uno personal generado en gitlab.

[Guía para generarlo](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html)

seleccionar el scope 'read_api'

```
npm i
```

## Usage

```
npm run dev
```

## Documentación

- Colleción de Postman con los endpoints del listado: (https://blue-star-662761.postman.co/workspace/New-Team-Workspace~1629265d-aa56-4266-8783-5e9ec5755f94/collection/25667127-41c540e7-bf9c-4466-91b2-82ad23059f6c?action=share&creator=25667127)[https://blue-star-662761.postman.co/workspace/New-Team-Workspace~1629265d-aa56-4266-8783-5e9ec5755f94/collection/25667127-41c540e7-bf9c-4466-91b2-82ad23059f6c?action=share&creator=25667127]
