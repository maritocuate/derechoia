import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import CheckoutInfo, {
  ICheckoutInfo,
} from '../../components/CheckoutSiro/CheckoutInfo';
import StepperCheckoutSiro from '../../components/StepperCheckoutSiro/StepperCheckoutSiro';
import SecondStep from '../../components/CheckoutSiro/SecondStep';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

const info: ICheckoutInfo = {
  averageRating: 4.5,
  dayValueDiffers: true,
  detallePrecio: [
    [
      {
        precio: 2400,
        fecha: '',
      },
    ],
  ],
  image: '/images/CTAreserva.png',
  prices: {
    type: '',
    base: 1233,
    total: 12451,
    advance: 1241,
    discounts: {
      percentage: 12,
      total: 12,
    },
    rest: 12,
  },
  reservationInfo: {
    dates: {
      endDate: '',
      startDate: '',
    },
    guests: 3,
    stay: 5,
    typology: {
      bathrooms: 2,
      capacity: 5,
      rooms: 2,
      title: 'La propiedad',
    },
  },
  titleAlojamiento: 'La casita',
  cargoExtra: 1574,
  cleaningFee: 2000,
  location: undefined,
};
const StepInfo = {
  datosPersonales: {
    nombre: 'Juan',
    apellido: 'Perez',
    tipo_identificacion: 'DNI',
    nombre_pais: 'Argentina',
    identificacion: '37985165',
    email: 'jperez@gmail.com',
    telefono: '3482949320',
  },
  dispatchOnChange: () => {},
  dispatchSetError: () => {},
  inputError: {
    nombre: false,
    apellido: false,
    idError: false,
    telefono: false,
    tipoIdentificacion: false,
    identificacion: false,
    email: false,
  },
};

describe('Step2', () => {
  test('CheckoutInfo', () => {
    render(
      <>
        <CheckoutInfo {...info} />,
        <StepperCheckoutSiro active={1} isMobile={false} />,
        <SecondStep {...StepInfo} />
      </>,
    );
    const item = screen.getByTestId('checkoutInfo');
    expect(item).toBeInTheDocument();
    const stepper = screen.getByTestId('stepperContainer');
    const resume = screen.getByTestId('resume');
    const data = screen.getByTestId('data');
    const dataSelected = data.querySelector('svg');
    const confirm = screen.getByTestId('confirm');
    const inputName = screen.getByTestId('inputName');
    const inputSubname = screen.getByTestId('inputSubname');
    const inputIDType = screen.getByTestId('inputIDType');
    const inputID = screen.getByTestId('inputID');
    const inputCountry = screen.getByTestId('inputCountry');
    const inputPhone = screen.getByTestId('inputPhone');
    const inputEmail = screen.getByTestId('inputEmail');
    expect(stepper).toBeInTheDocument();
    expect(resume).toBeInTheDocument();
    expect(data).toBeInTheDocument();
    expect(dataSelected).toHaveClass('Mui-active');
    expect(confirm).toBeInTheDocument();
    expect(inputName.querySelector('input')).toHaveValue('Juan');
    expect(inputSubname.querySelector('input')).toHaveValue('Perez');
    expect(inputIDType.querySelector('input')).toHaveValue('DNI');
    expect(inputID.querySelector('input')).toHaveValue(37985165);
    expect(inputCountry.querySelector('input')).toHaveValue();
    expect(inputPhone.querySelector('input')).toHaveValue(3482949320);
    expect(inputEmail.querySelector('input')).toHaveValue('jperez@gmail.com');
  });
});
