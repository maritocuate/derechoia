import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import CheckoutInfo, {
  ICheckoutInfo,
} from '../../components/CheckoutSiro/CheckoutInfo';
import StepperCheckoutSiro from '../../components/StepperCheckoutSiro/StepperCheckoutSiro';
import ThirdStep from '../../components/CheckoutSiro/ThirdStep';
import { renderWithStore } from '../hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

const info: ICheckoutInfo = {
  averageRating: 4.5,
  dayValueDiffers: true,
  detallePrecio: [
    [
      {
        precio: 2400,
        fecha: '',
      },
    ],
  ],
  image: '/images/CTAreserva.png',
  prices: {
    type: '',
    base: 1233,
    total: 12451,
    advance: 1241,
    discounts: {
      percentage: 12,
      total: 12,
    },
    rest: 12,
  },
  reservationInfo: {
    dates: {
      endDate: '',
      startDate: '',
    },
    guests: 3,
    stay: 5,
    typology: {
      bathrooms: 2,
      capacity: 5,
      rooms: 2,
      title: 'La propiedad',
    },
  },
  titleAlojamiento: 'La casita',
  cargoExtra: 1574,
  cleaningFee: 2000,
  location: undefined,
};
const stepInfo = {
  setPaymentId: () => {},
  paymentMethods: [
    {
      value: 'Transferencia',
      label: 'Transferencia',
      idPayment: 1,
    },
  ],
  paymentAmount: {
    type: 'Transferencia',
    advance: 1000,
    rest: 2000,
    total: 3000,
  },
  name: 'Juan',
  paymentId: 1,
};

describe('Step3', () => {
  test('CheckoutInfo', () => {
    renderWithStore(
      <>
        <CheckoutInfo {...info} />,
        <StepperCheckoutSiro active={2} isMobile={false} />,
        <ThirdStep {...stepInfo} />
      </>,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'checkout',
        },
      },
    );
    const item = screen.getByTestId('checkoutInfo');
    const stepper = screen.getByTestId('stepperContainer');
    const resume = screen.getByTestId('resume');
    const data = screen.getByTestId('data');
    const confirm = screen.getByTestId('confirm');
    const confirmSelected = confirm.querySelector('svg');
    const container = screen.getByTestId('thirdStep');
    const almostDone = screen.getByTestId('almostDone');
    const prepayment = screen.getByTestId('prepayment');
    const paymentMethods = screen.getByTestId('payment-methods');
    const terms = screen.getByTestId('terms');
    expect(item).toBeInTheDocument();
    expect(stepper).toBeInTheDocument();
    expect(resume).toBeInTheDocument();
    expect(data).toBeInTheDocument();
    expect(confirm).toBeInTheDocument();
    expect(confirmSelected).toHaveClass('Mui-active');
    expect(container).toBeInTheDocument();
    expect(almostDone).toHaveStyle('font-weight:700');
    expect(prepayment.querySelector('svg')).toHaveStyle('fill:#00bcd4');
    expect(paymentMethods).toBeInTheDocument();
    expect(paymentMethods.querySelector('input')).toBeChecked();
    expect(terms).toBeInTheDocument();
  });
});
