import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import CheckoutInfo, {
  ICheckoutInfo,
} from '../../components/CheckoutSiro/CheckoutInfo';
import StepperCheckoutSiro from '../../components/StepperCheckoutSiro/StepperCheckoutSiro';
import TermsAndConditions, {
  ITermsConditions,
} from '../../components/TermsAndConditions';
import { renderWithStore } from '../hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

const info: ICheckoutInfo = {
  averageRating: 4.5,
  dayValueDiffers: true,
  detallePrecio: [
    [
      {
        precio: 2400,
        fecha: '',
      },
    ],
  ],
  image: '/images/CTAreserva.png',
  prices: {
    type: '',
    base: 1233,
    total: 12451,
    advance: 1241,
    discounts: {
      percentage: 12,
      total: 12,
    },
    rest: 12,
  },
  reservationInfo: {
    dates: {
      endDate: '',
      startDate: '',
    },
    guests: 3,
    stay: 5,
    typology: {
      bathrooms: 2,
      capacity: 5,
      rooms: 2,
      title: 'La propiedad',
    },
  },
  titleAlojamiento: 'La casita',
  cargoExtra: 1574,
  cleaningFee: 2000,
  location: undefined,
};
const terms: ITermsConditions = {
  valorPagoAnticipado: 1500,
  nights: 3,
  cancelacion: 'Gratuita',
  cash: true,
  bankTransfer: true,
  creditCard: true,
  coupon: false,
  acepta_familias: 1,
  acepta_parejas: 1,
  acepta_grupo_jovenes: 1,
  apto_niños: 1,
  apto_bebes: 1,
  acepta_mascotas: 1,
  apto_movilidad_reducida: 1,
  permite_fumar: 1,
  permite_hacer_fiestas: 1,
  permite_recibir_visitas: 1,
  permite_musica: 1,
  garantia: 2000,
  a_reintegrar: true,
  valor_a_reintegrar: '1000',
  datos_tarjeta: true,
  foto_dni: false,
  presentar_documento: false,
  firma_contrato: true,
  promotionText: 'Alta promo',
  antelacion: 1,
  hora_ingreso: '15:00',
  hora_egreso: '15:00',
  cancelationFlexMonths: 2,
  cancelationFreeDays: 5,
};

describe('Step1', () => {
  test('CheckoutInfo', () => {
    renderWithStore(
      <>
        <CheckoutInfo {...info} />
        <StepperCheckoutSiro active={0} isMobile={false} />
        <TermsAndConditions {...terms} />
      </>,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'checkout',
        },
      },
    );
    const item = screen.getByTestId('checkoutInfo');
    const stepper = screen.getByTestId('stepperContainer');
    const resume = screen.getByTestId('resume');
    const resumeSelected = resume.querySelector('svg');
    const data = screen.getByTestId('data');
    const confirm = screen.getByTestId('confirm');
    const cancelation = screen.getByTestId('cancelation');
    const checkTime = screen.getByTestId('checkTime');
    const guarantee = screen.getByTestId('guarantee');
    const payment = screen.getByTestId('payment');
    const rules = screen.getByTestId('rules');
    const termsItem = screen.getByTestId('terms');
    expect(item).toBeInTheDocument();
    expect(stepper).toBeInTheDocument();
    expect(resume).toBeInTheDocument();
    expect(resumeSelected).toHaveClass('Mui-active');
    expect(data).toBeInTheDocument();
    expect(confirm).toBeInTheDocument();
    expect(cancelation).toBeInTheDocument();
    expect(checkTime).toBeInTheDocument();
    expect(guarantee).toBeInTheDocument();
    expect(payment).toBeInTheDocument();
    expect(rules).toBeInTheDocument();
    expect(termsItem).toBeInTheDocument();
  });
});
