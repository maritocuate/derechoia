import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import BuscarPageTitle from '../components/BuscarPageTitle/BuscarPageTitle';

describe('BuscarSection', () => {
  it('renders BuscarSection', () => {
    renderWithStore(<BuscarPageTitle />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const container = screen.getByTestId('BuscarPageTitleContainer');
    const titleSection = screen.getByTestId('BuscarPageTitleContainerTitle');
    const text = screen.getByTestId('BuscarPageTitleContainerText');
    expect(container).toBeInTheDocument();
    expect(titleSection).toBeInTheDocument();
    expect(text).toBeInTheDocument();
  });
});
