import React from 'react';
import { screen } from '@testing-library/react';
import ValorationContainer from '../components/ValorationContainer';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const ratingsData = [
  {
    valoracion: 2,
    comentario: 'bien',
    nombre_apellido: 'nombre',
    replica: '',
    mes_estadia: new Date().getMonth(),
    anio_estadia: new Date().getFullYear(),
  },
  {
    valoracion: 2,
    comentario: 'bien',
    nombre_apellido: 'nombre',
    replica: '',
    mes_estadia: new Date().getMonth(),
    anio_estadia: new Date().getFullYear(),
  },
];

const valorationsIAprops = {
  caracteristicas: [
    {
      titulo: 'Limpieza',
      recomendacion: 'Esta unidad destaca por su limpieza',
    },
  ],
  refID: 24212,
};

describe('ValorationContainer', () => {
  it('Renders valoration resume inside the container', () => {
    renderWithStore(
      <ValorationContainer
        valorationTotal={3.7}
        ratingsData={ratingsData}
        hostName="Juan"
        valorationsIA={valorationsIAprops}
        refID={valorationsIAprops.refID}
      />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'adsDetail',
        },
      },
    );
    const component = screen.getByTestId('valoration-resume');
    expect(component).toBeInTheDocument();
  });
});
