import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import EmptyStateActiveBookingsDesktop from '../components/ActiveBookings/components/EmptyStateActiveBookingsDesktop';
import EmptyStateActiveBookingsMobile from '../components/ActiveBookings/components/EmptyStateActiveBookingsMobile';

describe('EmptyStateActiveBookingsMobile', () => {
  it('renders EmptyStateActiveBookingsMobile', () => {
    render(<EmptyStateActiveBookingsMobile />);
    const container = screen.getByTestId('ContainerEmptyState');
    const title = screen.getByTestId('TitleEmptyState');
    const subtitle = screen.getByTestId('SubtitleEmptyState');
    const button = screen.getByTestId('ButtonEmptyState');
    expect(container).toBeInTheDocument();
    expect(title).toHaveTextContent('Tu lista de reservas activas está vacía');
    expect(subtitle).toHaveTextContent(
      'Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.',
    );
    expect(button).toHaveTextContent('Realizar una búsqueda');
  });
  it('renders EmptyStateActiveBookingsDesktop', () => {
    render(<EmptyStateActiveBookingsDesktop />);
    const container = screen.getByTestId('ContainerEmptyState');
    const image = screen.getByTestId('SVGEmptyState');
    const title = screen.getByTestId('TitleEmptyState');
    const subtitle = screen.getByTestId('SubtitleEmptyState');
    const button = screen.getByTestId('ButtonEmptyState');

    expect(container).toBeInTheDocument();
    expect(image).toBeInTheDocument();
    expect(title).toHaveTextContent('Tu lista de reservas activas está vacía');
    expect(subtitle).toHaveTextContent(
      'Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.',
    );
    expect(button).toHaveTextContent('Realizar una búsqueda');
  });
});
