import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import NoResults from '../components/NoResults';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('No Results Test', () => {
  test('No Results Text', () => {
    const { container } = render(<NoResults />);
    const item = container.querySelector('.MuiTypography-root');
    expect(item?.classList.contains('MuiTypography-root')).toBeTruthy();
  });
  test('No Results Icon', () => {
    const { container } = render(<NoResults />);
    const item = container.querySelector('.MuiGrid-root');
    expect(item?.classList.contains('MuiGrid-root')).toBeTruthy();
  });
});
