import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import NewHostProfileMobile from '../components/HostProfile/NewHostProfile/NewHostProfileMobile';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const mockProfile = {
  name: 'Pepe Doe',
  profilePhoto: '',
  clientAntiquity: 12,
  maxSpeedOfAction: true,
  maxConfirmedPercentage: true,
  isStarClient: true,
  formattedClientAntiquity: {
    number: 1,
    text: ' year',
  },
  isMobile: false,
};

describe('HostProfile', () => {
  it('renders HostProfile Profile', () => {
    render(<NewHostProfileMobile {...mockProfile} />);
    expect(screen.getByText(/Pepe Doe/)).toBeInTheDocument();
    expect(screen.getByText(/Verificado/)).toBeInTheDocument();
  });

  it('renders avatar HostProfile', () => {
    const { container } = render(<NewHostProfileMobile {...mockProfile} />);
    const item = container.querySelector('.MuiAvatar-root');
    expect(item).toBeInTheDocument();
  });

  it('renders icon HostProfile', () => {
    const { container } = render(<NewHostProfileMobile {...mockProfile} />);
    const item = container.querySelector('.MuiSvgIcon-root');
    expect(item).toBeInTheDocument();
  });

  it('renders star Client', () => {
    render(<NewHostProfileMobile {...mockProfile} />);
    expect(screen.getByText(/Anfitrión estrella/)).toBeInTheDocument();
  });
  it('renders qualitties', () => {
    render(<NewHostProfileMobile {...mockProfile} />);
    expect(screen.getByText(/Reservas efectivas/)).toBeInTheDocument();
    expect(
      screen.getByText(/Tiempo promedio de respuesta/),
    ).toBeInTheDocument();
    expect(screen.getByText(/Años en la plataforma/)).toBeInTheDocument();
  });
});
