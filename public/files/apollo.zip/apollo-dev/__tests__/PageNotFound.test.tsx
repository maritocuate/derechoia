import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import PageNotFound from '../components/PageNotFound/PageNotFound';

describe('PageNotFound', () => {
  it('renders PageNotFound', () => {
    render(<PageNotFound />);
    const container = screen.getByTestId('Page-NotFound-Container');
    expect(container).toBeInTheDocument();

    expect(container).toHaveTextContent('Página no encontrada');
  });
});
