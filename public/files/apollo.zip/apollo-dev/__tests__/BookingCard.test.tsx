import React from 'react';
import '@testing-library/jest-dom';
import { screen } from '@testing-library/react';
import BookingCard from '../components/BookingCard/BookingCard';
import {
  Booking,
  HotelDetails,
  Actions,
} from '../components/BookingCard/types';
import { renderWithStore } from './hoc/render-with-store';

describe('paymentCard component', () => {
  const mockBookingValues: Booking = {
    checkIn: 'Viernes 06 de Febrero 2023 | 16:30hs',
    checkOut: 'Domingo 08 de Febrero 2023 | 12:30hs',
    roomType: 'Habitación Doble Superior',
    maxPeople: 3,
    rooms: 1,
    bathrooms: 1,
    confirmationCode: 'F5487985-5',
    imageUrl: '/images/logo192.png',
    anteriores: false,
  };

  const mockHotelDetails: HotelDetails = {
    name: 'Hotel Villa Carlos Paz',
    location: 'Los Platanos 555, Villa Carlos Paz, Córdoba, Argentina',
  };

  const mockActions: Actions = {
    goAlojamiento: '/alojamiento123',
    goVoucher: '/voucher123',
    goMaps:
      'https://www.google.com/maps/place/Hurlingham,+Provincia+de+Buenos+Aires/',
  };

  beforeEach(() => {
    renderWithStore(
      <BookingCard
        booking={mockBookingValues}
        hotelDetails={mockHotelDetails}
        actions={mockActions}
      />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'home',
        },
      },
    );
  });

  it('renders the child components', () => {
    expect(screen.getByTestId('booking-thumbnail')).toBeInTheDocument();
    expect(screen.getByTestId('booking-checks')).toBeInTheDocument();
  });

  it('renders the hotel location', () => {
    const hotelLocation = screen.getByText(mockHotelDetails.location);
    expect(hotelLocation).toBeInTheDocument();
  });

  it('verifies the Google Maps link opens correctly', () => {
    const googleMapsLink = screen.getByText('Abrir en Google Maps');
    expect(googleMapsLink).toBeInTheDocument();
    expect(googleMapsLink.closest('a')).toHaveAttribute(
      'href',
      mockActions.goMaps,
    );
    expect(googleMapsLink.closest('a')).toHaveAttribute('target', '_blank');
  });
});
