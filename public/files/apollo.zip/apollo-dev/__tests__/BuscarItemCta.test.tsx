import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import ItemCta from '../components/BuscarCtaContainer/components/ItemCta';

const itemProps = {
  buttonText: 'Buscar',
  callback: () => {},
  children: <p>Buscar alojamiento</p>,
  title: 'Buscar alojamiento',
  redirectHome: true,
};

describe('ItemCtaBuscar', () => {
  it('renders ItemCtaBuscar', () => {
    renderWithStore(<ItemCta {...itemProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const itemCta = screen.getByTestId('ItemCtaBuscar');
    const titleCta = screen.getByTestId('ItemCtaBuscarTitle');
    const childrenCta = screen.getByTestId('ItemCtaBuscarChildren');
    const buttonCta = screen.getByTestId('ItemCtaBuscarButton');
    expect(itemCta).toBeInTheDocument();
    expect(titleCta).toBeInTheDocument();
    expect(childrenCta).toBeInTheDocument();
    expect(buttonCta).toBeInTheDocument();
  });
});
