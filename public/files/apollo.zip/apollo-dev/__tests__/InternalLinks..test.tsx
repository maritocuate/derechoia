import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import InternalLinks from '../components/InternalLinks';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('InternalLinks', () => {
  it('renders InternalLinks Container', () => {
    const { container } = render(<InternalLinks province="Córdoba" />);
    const item = container.querySelector('.MuiBox-root ');
    expect(item).toBeInTheDocument();
  });
  it('renders InternalLinks title', () => {
    const { getByText } = render(<InternalLinks province="Córdoba" />);
    const titleElement = getByText('test: title-province');
    expect(titleElement).toBeInTheDocument();
  });
  it('renders InternalLinks links', () => {
    const { container } = render(<InternalLinks province="Córdoba" />);
    const item = container.querySelector('.MuiTypography-root');
    expect(item).toBeInTheDocument();
  });
});
