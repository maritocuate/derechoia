import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import MapMarker from '../components/MapMarker/ListMapMarker';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('MapMarker', () => {
  it('renders MapMarker Container', () => {
    render(<MapMarker price={60000} handleClick={() => {}} />);
    expect(screen.getByTestId('marker-container')).toBeInTheDocument();
  });
  it('renders MapMarker prices', () => {
    render(<MapMarker price={60000} handleClick={() => {}} />);
    const item = screen.getByTestId('marker-text');
    expect(item).toBeInTheDocument();
    expect(item?.textContent).toEqual('$60.000');
  });
  it('renders MapMarker without prices', () => {
    render(<MapMarker handleClick={() => {}} />);
    const item = screen.getByTestId('marker-text');
    expect(item).toBeInTheDocument();
    expect(item?.textContent).toEqual('$ Consultar');
  });
});
