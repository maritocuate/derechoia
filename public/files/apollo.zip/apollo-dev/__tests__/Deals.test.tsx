import React from 'react';
import Deals from '../components/Deals';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { IAppStatusState } from '../redux/appStatus/types';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('Deals', () => {
  const initialState: { appStatus: IAppStatusState } = {
    appStatus: {
      preloaded: true,
      showNewBanner: false,
      isOpenLoginModal: false,
      isMobile: false,
      isError: false,
      page: 'adsDetail',
    },
  };

  it('It renders Deals', () => {
    const { container } = renderWithStore(
      <Deals itemsStayFlexible={[]} itemsLastMinute={[]} />,
      initialState,
    );
    const item = container.querySelector('.MuiGrid-root');
    expect(item).toBeInTheDocument();
  });
});
