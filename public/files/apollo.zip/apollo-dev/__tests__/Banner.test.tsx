import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import BannerDesktop from '../components/BannersPromotion/BannerDesktop';
import BannerMobile from '../components/BannersPromotion/BannerMobile';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

const banners = [
  {
    path: {
      url: '/images/BannerGrowth.png',
      target: '',
      link_type: '',
    },
    size: {
      mobile: {
        height: 100,
        width: 200,
        url: '/',
      },
      desktop_dual: {
        height: 100,
        width: 200,
        url: '/',
      },
      desktop_full: {
        height: 100,
        width: 200,
        url: '/',
      },
    },
  },
  {
    path: {
      url: '/images/BannerGrowth1.png',
      target: '',
      link_type: '',
    },
    url: '/',
    size: {
      mobile: {
        height: 100,
        width: 200,
        url: '/',
      },
      desktop_dual: {
        height: 100,
        width: 200,
        url: '/',
      },
      desktop_full: {
        height: 100,
        width: 200,
        url: '/',
      },
    },
  },
];
describe('Banners', () => {
  test('Banner desktop', () => {
    render(<BannerDesktop bannersPromotions={banners} />);
    const item = document.querySelector('.MuiBox-root');
    expect(item).toBeInTheDocument();
    expect(banners).not.toHaveLength(0);
  });
});
describe('Banners', () => {
  test('Banner mobile', () => {
    render(<BannerMobile bannersPromotions={banners} />);
    const item = document.querySelector('.MuiBox-root');
    expect(item).toBeInTheDocument();
    expect(banners).not.toHaveLength(0);
  });
});
