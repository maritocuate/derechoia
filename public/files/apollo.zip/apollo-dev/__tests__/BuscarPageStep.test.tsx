import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import BuscarPageStep from '../components/BuscarPageStep/BuscarPageStep';
import Step3 from '../layout/buscar/svgs/Mobile/Step3';

const stepWithLinkAndList = {
  step: 1,
  title: 'Ingresá',
  link: {
    href: '/',
    text: 'www.alquilerargentina.com',
  },
  description: 'Accedé a nuestro sitio web',
  imageDesktop: '/images/step1.png',
  list: [
    {
      title: 'Reserva online',
      text: 'si permite reservas online, presioná el botón de “Reservar”',
    },
  ],
};

const stepMobileProps = {
  step: 3,
  title: 'Ingresá',
  description: 'Accedé a nuestro sitio web',
  imageMobile: <Step3 />,
};

describe('BuscarStep', () => {
  it('renders BuscarStepDesktop with link and list', () => {
    renderWithStore(<BuscarPageStep {...stepWithLinkAndList} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const container = screen.getByTestId('stepContainer');
    const image = screen.getByTestId('stepImageDesktop');
    const stepNumber = screen.getByTestId('stepNumber');
    const title = screen.getByTestId('stepTitle');
    expect(container).toBeInTheDocument();
    expect(image).toBeInTheDocument();
    expect(stepNumber.textContent).toContain(
      `Paso ${stepWithLinkAndList.step}`,
    );
    expect(title).toBeInTheDocument();
  });
  it('renders BuscarStepMobile', () => {
    renderWithStore(<BuscarPageStep {...stepMobileProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const container = screen.getByTestId('stepContainer');
    const stepNumber = screen.getByTestId('stepNumber');
    const title = screen.getByTestId('stepTitle');
    expect(container).toBeInTheDocument();
    expect(stepNumber.textContent).toContain(`Paso ${stepMobileProps.step}`);
    expect(title).toBeInTheDocument();
  });
});
