import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import ModalFakeDoor from '../components/Header/FakeDoorIa/components/ModalFakeDoor';

describe('ModalFakeDoor Component', () => {
  const defaultProps = {
    onClose: jest.fn(),
    setEmail: jest.fn(),
    onSubmit: jest.fn(),
    success: false,
    open: true,
    email: '',
    isLoading: false,
    errorMessage: '',
  };

  test('renders correctly when open', () => {
    render(<ModalFakeDoor {...defaultProps} />);

    expect(screen.getByText('¡No te lo pierdas!')).toBeInTheDocument();
    expect(screen.getByLabelText('Correo electrónico')).toBeInTheDocument();
    expect(screen.getByText('Avisarme')).toBeInTheDocument();
  });

  test('shows success message and hides input field when success is true', () => {
    render(<ModalFakeDoor {...defaultProps} success />);

    expect(screen.getByText('¡Gracias por suscribirte!')).toBeInTheDocument();
    expect(
      screen.queryByLabelText('Correo electrónico'),
    ).not.toBeInTheDocument();
    expect(screen.getByText('Cerrar')).toBeInTheDocument();
  });

  test('calls onClose when close button is clicked', () => {
    render(<ModalFakeDoor {...defaultProps} />);

    fireEvent.click(screen.getByLabelText('close'));

    expect(defaultProps.onClose).toHaveBeenCalled();
  });

  test('calls onSubmit when "Avisarme" button is clicked', () => {
    render(<ModalFakeDoor {...defaultProps} />);

    fireEvent.change(screen.getByLabelText('Correo electrónico'), {
      target: { value: 'test@example.com' },
    });
    fireEvent.click(screen.getByText('Avisarme'));

    expect(defaultProps.onSubmit).toHaveBeenCalled();
  });

  test('disables the button and shows loading state when isLoading is true', () => {
    render(<ModalFakeDoor {...defaultProps} isLoading />);

    expect(screen.getByText('Avisarme')).toBeDisabled();
  });

  test('shows error message when errorMessage is set', () => {
    const errorProps = {
      ...defaultProps,
      errorMessage: 'Correo electrónico inválido',
    };
    render(<ModalFakeDoor {...errorProps} />);

    expect(screen.getByText('Correo electrónico inválido')).toBeInTheDocument();
  });
});
