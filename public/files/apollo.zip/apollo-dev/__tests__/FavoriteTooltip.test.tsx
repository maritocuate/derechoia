import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import FavoriteTooltip from '../components/FavoriteTooltip';

describe('Favorite Tooltip tests', () => {
  it('renders FavoriteTooltip text if is Favorite', async () => {
    render(
      <FavoriteTooltip variant="list" isFavorite>
        <div>Test</div>
      </FavoriteTooltip>,
    );
    const item = screen.getByText('Test');

    fireEvent.mouseEnter(item);

    await waitFor(() => {
      expect(screen.queryByText('Quitar de favoritos')).toBeVisible();
    });
  });
  it('renders FavoriteTooltip text if is not favorite', async () => {
    render(
      <FavoriteTooltip variant="ficha" isFavorite={false}>
        <div>Test</div>
      </FavoriteTooltip>,
    );
    const item = screen.getByText('Test');

    fireEvent.mouseEnter(item);

    await waitFor(() => {
      expect(screen.queryByText('Agregar a favoritos')).toBeVisible();
    });
  });
});
