import React from 'react';
import { Button } from '@mui/material';
import { render } from '@testing-library/react';
import PopoverShare from '../components/PopoverShare';
import '@testing-library/jest-dom';

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '/',
      query: '',
      asPath:
        '/alojamientos/eh05-Casa-Sueños-de-Libertad-Villa-Santa-Cruz-Del-Lago.html',
    };
  },
}));

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('PopoverShare', () => {
  test('PopoverShare dom test', () => {
    render(
      <>
        <Button className="MuiButton-root">click!</Button>
        <PopoverShare
          open
          anchorEl={document.querySelector('.MuiButton-root')}
        />
      </>,
    );
    const item = document.querySelector('.MuiPopover-root');
    expect(item).toBeInTheDocument();
  });
});
