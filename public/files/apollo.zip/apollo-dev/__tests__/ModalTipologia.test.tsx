import React from 'react';
import '@testing-library/jest-dom';
import ModalTipologia from '../components/ModalTipologia';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));
const ModalTipologiaDATA = {
  isOpenModalTipology: true,
  setOpenViewModal: () => {},
  handleClose: () => {},
  paddingcontent: '24px',
  imgsCarousel: [
    {
      id: 0,
      alt: 'es una casa',
      src: `${
        process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
      }_propiedades_/za61/o_za61_Departamento_1K7HGR3R.jpg`,
    },
    {
      id: 1,
      alt: 'es una casa',
      src: `${
        process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
      }_propiedades_/za61/o_za61_Departamento_1K7HGR3R.jpg`,
    },
    {
      id: 2,
      alt: 'es una casa',
      src: `${
        process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
      }_propiedades_/za61/o_za61_Departamento_1K7HGR3R.jpg`,
    },
    {
      id: 3,
      alt: 'es una casa',
      src: `${
        process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
      }_propiedades_/za61/o_za61_Departamento_1K7HGR3R.jpg`,
    },
  ],
  hostName: "La casa feli'",
  roomAmount: 5,
  bathAmount: 2,
  peopleAmount: 7,
  descriptionHost:
    'Descripción de la tipología. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellenque odio orci, posuere sed ante non tellus.',
};

describe('Modal', () => {
  test('Modal standard', () => {
    renderWithStore(<ModalTipologia {...ModalTipologiaDATA} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    const item = document.querySelector('.MuiGrid-root');
    expect(item).toBeInTheDocument();
  });
});
