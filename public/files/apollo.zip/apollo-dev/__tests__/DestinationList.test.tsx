import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import DestinationsList from '../components/Header/DestinationsHeader/components/DestinationsList';

describe('DestinationList', () => {
  const oneDestinationProps = {
    content: {
      listTitle: 'Córdoba',
      links: [
        {
          title: 'Ciudad de Córdoba',
          href: '/Córdoba/Ciudad-De-Córdoba',
        },
        {
          title: 'Villa General Belgrano',
          href: '/Córdoba/Villa-General-Belgrano',
        },
      ],
      image: {
        src: '/images/Cordoba-header.jpg',
        alt: 'Ciudad de Córdoba',
      },
    },
    type: 'oneDestination' as 'oneDestination' | 'multiDestinations',
    destinations: undefined,
    showDestinations: true,
  };
  it('renders DestinationList', () => {
    renderWithStore(<DestinationsList {...oneDestinationProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'default',
      },
    });
    const list = screen.getByTestId('List');
    const image = screen.getByTestId('ImageDestination');
    const title = screen.getByTestId('ListTitle');
    expect(list).toBeInTheDocument();
    expect(image).toBeInTheDocument();
    expect(title).toBeInTheDocument();
  });
});
