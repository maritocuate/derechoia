import React from 'react';
import { render } from '@testing-library/react';
import DescriptionAnuncio from '../components/DescriptionAnuncio';
import '@testing-library/jest-dom';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('DescriptionAnuncio', () => {
  it('renders DescriptionAnuncio title', () => {
    const { container } = render(
      <DescriptionAnuncio descripcion="Barrio residencial mari-mat ubicada a 3 cuadras del arroyo tanti a 8 cuadras del balneario el diquesito a 2 cuadras de la ruta provincial n.28 a 4 cuadras de zona céntrica a 15 kilómetros de villa carlos paz a 5 klm del balneario cabalango. Ubicada a 3 cuadras del arroyo tanti a 8 cuadras del balneario el diquesito a 2 cuadras de la ruta provincial n.28 a 4 cuadras de zona céntrica a 15 kilómetros de villa carlos paz a 5 klm del balneario cabalango." />,
    );
    const item = container.querySelector('.MuiTypography-h2');
    expect(item).toBeInTheDocument();
  });
  it('renders DescriptionAnuncio description', () => {
    const { container } = render(
      <DescriptionAnuncio descripcion="Barrio residencial mari-mat ubicada a 3 cuadras del arroyo tanti a 8 cuadras del balneario el diquesito a 2 cuadras de la ruta provincial n.28 a 4 cuadras de zona céntrica a 15 kilómetros de villa carlos paz a 5 klm del balneario cabalango. Ubicada a 3 cuadras del arroyo tanti a 8 cuadras del balneario el diquesito a 2 cuadras de la ruta provincial n.28 a 4 cuadras de zona céntrica a 15 kilómetros de villa carlos paz a 5 klm del balneario cabalango." />,
    );
    const item = container.querySelector('.MuiTypography-body1');
    expect(item).toBeInTheDocument();
  });
});
