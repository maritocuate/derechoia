import React from 'react';
import { screen, fireEvent, act } from '@testing-library/react';
import TestimonialSlider from '../components/TestimonialSection/components/TestimonialSlider';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { MOCKED_TESTIMONIALS } from '../layout/publicar/constants/mockedData';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('TestimonialSlider', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders correctly', () => {
    renderWithStore(<TestimonialSlider testimonials={MOCKED_TESTIMONIALS} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('Esther')).toBeInTheDocument();
    expect(
      screen.getByText(
        'Recomiendo Alquiler Argentina. Todo ha sido correcto. A pesar de que soy de la generación que le cuesta adaptarse a la tecnología, la tranquilidad y seguridad que brinda a pasajeros y anfitriones es destacable. La comisión en pesos y sin cargos sorpresa hace que sea una excelente opción. Continuaré usando la plataforma.',
      ),
    ).toBeInTheDocument();
  });

  it('handles next and previous buttons correctly', () => {
    renderWithStore(<TestimonialSlider testimonials={MOCKED_TESTIMONIALS} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    act(() => {
      fireEvent.click(screen.getByLabelText('carousel indicator 1'));
    });

    act(() => {
      fireEvent.click(screen.getByLabelText('carousel indicator 2'));
    });
  });
});
