import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ValorationsIA from '../components/ValorationsIA/ValorationsIA';
import ValorationsItem from '../components/ValorationsIA/components/ValorationItem';
import { renderWithStore } from './hoc/render-with-store';

const valorationProps = {
  caracteristicas: [
    {
      titulo: 'Limpieza',
      recomendacion: 'Los usuarios destacan la limpieza',
    },
  ],
  refID: 21321,
};

describe('ValorationsIA', () => {
  it('renders ValorationsIA', () => {
    renderWithStore(<ValorationsIA {...valorationProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const title = screen.getByTestId('VorationsIATitle');
    const list = screen.getByTestId('VorationsIAList');
    const footer = screen.getByTestId('VorationsIAFooter');
    expect(title).toBeInTheDocument();
    expect(list).toBeInTheDocument();
    expect(footer).toBeInTheDocument();
  });
});

describe('ValorationsItem', () => {
  const valorationItemsProps = {
    title: 'Excelente',
    text: 'Un lugar muy lindo en las sierras',
  };
  it('renders ValorationsITem', () => {
    renderWithStore(<ValorationsItem {...valorationItemsProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const item = screen.getByTestId('itemIA');
    const title = screen.getByTestId('titleItemIA');
    const text = screen.getByTestId('textItemIA');
    expect(item).toBeInTheDocument();
    expect(title).toBeInTheDocument();
    expect(text).toBeInTheDocument();
  });
});
