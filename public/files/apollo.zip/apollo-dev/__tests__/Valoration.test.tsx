import React from 'react';
import { render } from '@testing-library/react';
import Valoration from '../components/Valoration';
import '@testing-library/jest-dom';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('Valoration Test', () => {
  test('Valoracion Texto', () => {
    const { container } = render(
      <Valoration
        foto="MO"
        nombre_apellido="Martín"
        comentario="Muy lindo lugar, volería a venir sin dudas!"
        valoracion={5}
        replica=""
        mes_estadia={new Date().getMonth()}
        anio_estadia={new Date().getFullYear()}
        hostName="Juan"
      />,
    );
    const item = container.querySelector('.MuiListItemText-multiline');
    expect(item?.classList.contains('MuiListItemText-multiline')).toBeTruthy();
  });
  test('Valoracion Avatar', () => {
    const { container } = render(
      <Valoration
        foto="MO"
        nombre_apellido="Martín"
        comentario="Muy lindo lugar, volería a venir sin dudas!"
        valoracion={5}
        replica=""
        mes_estadia={new Date().getMonth()}
        anio_estadia={new Date().getFullYear()}
        hostName="Juan"
      />,
    );
    const item = container.querySelector('.MuiListItemAvatar-root');
    expect(item?.classList.contains('MuiListItemAvatar-root')).toBeTruthy();
  });
  test('Valoracion Rating', () => {
    const { container } = render(
      <Valoration
        foto="MO"
        nombre_apellido="Martín"
        comentario="Muy lindo lugar, volería a venir sin dudas!"
        valoracion={5}
        replica=""
        mes_estadia={new Date().getMonth()}
        anio_estadia={new Date().getFullYear()}
        hostName="Juan"
      />,
    );
    const item = container.querySelector('.MuiRating-root');
    expect(item?.classList.contains('MuiRating-root')).toBeTruthy();
  });
  test('Valoracion Comentario', () => {
    const { container } = render(
      <Valoration
        foto="MO"
        nombre_apellido="Martín"
        comentario="Muy lindo lugar, volería a venir sin dudas!"
        valoracion={5}
        replica=""
        mes_estadia={new Date().getMonth()}
        anio_estadia={new Date().getFullYear()}
        hostName="Juan"
      />,
    );
    const item = container.querySelector('.MuiTypography-root');
    expect(item?.classList.contains('MuiTypography-root')).toBeTruthy();
  });
});
