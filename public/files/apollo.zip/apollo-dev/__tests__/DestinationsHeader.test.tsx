import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import DestinationsHeader from '../components/Header/DestinationsHeader/DestinationsHeader';

describe('DestinationsHeader', () => {
  it('renders DestinationsHeader', () => {
    renderWithStore(<DestinationsHeader isOpenDrawer={false} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'default',
      },
    });
    const button = screen.getByTestId('DestinationsButton');
    const container = screen.getByTestId('DestinationsContainer');
    expect(button).toBeInTheDocument();
    expect(container).toBeInTheDocument();
  });
});
