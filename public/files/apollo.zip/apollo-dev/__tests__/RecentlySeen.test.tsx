import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import CardRecentlySeen from '../components/CardRecentlySeen/CardRecentlySeen';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const dataItem = {
  city: 'Ciudad de Córdoba',
  name: 'Test',
  province: 'Córdoba',
  valoration: 1.5,
  photo: '/',
  isNew: false,
  reference: 'mg51',
  fullseen: 3,
};
const props = {
  ...dataItem,
};
describe('RecentlySeen', () => {
  test('RecentlySeen', () => {
    render(<CardRecentlySeen {...props} isLoading={false} />);
    const component = screen.getByTestId('RecentlySeenCard');
    expect(component).toBeInTheDocument();
  });
});

const dataItem2 = {
  city: 'Resistencia',
  name: 'La casa de Eli',
  province: 'Chaco',
  valoration: 1.5,
  isNew: false,
  photo: '/',
  reference: 'el23',
  fullseen: 4,
};
const props2 = {
  ...dataItem2,
};
describe('RecentlySeen', () => {
  test('RecentlySeen', () => {
    render(<CardRecentlySeen {...props2} isLoading={false} />);
    const component = screen.getByTestId('RecentlySeenCard');
    expect(component).toBeInTheDocument();
  });
});
