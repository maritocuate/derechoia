import React from 'react';
import { render } from '@testing-library/react';
import LocationAnuncio from '../components/LocationAnuncio';
import '@testing-library/jest-dom';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('LocationAnuncio', () => {
  it('renders LocationAnuncio', () => {
    const { container } = render(
      <LocationAnuncio
        mapProps={{ lat: 5000, long: 0.5 }}
        reference="ls22"
        ubication="Tanti, Córdoba"
      />,
    );
    const item = container.querySelector('.MuiGrid-container');
    expect(item?.classList.contains('MuiGrid-container')).toBeTruthy();
  });
  it('renders button of LocationAnuncio', () => {
    const { container } = render(
      <LocationAnuncio
        mapProps={{ lat: 5000, long: 0.5 }}
        reference="ls22"
        ubication="Tanti, Córdoba"
      />,
    );
    const item = container.querySelector('button');
    expect(item?.classList.contains('MuiButton-root')).toBeTruthy();
  });
});
