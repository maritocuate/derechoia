import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import MapButton from '../components/MapButton';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('MapButton Test', () => {
  test('It render MapButton', () => {
    const { container } = render(
      <MapButton isLoading handleOpenMap={() => {}} />,
    );
    const item = container.querySelector('.MuiButtonBase-root');
    expect(item?.classList.contains('MuiButtonBase-root')).toBeTruthy();
  });
});
