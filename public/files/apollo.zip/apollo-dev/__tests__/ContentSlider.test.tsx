import React from 'react';
import { screen } from '@testing-library/react';
import ContentSlider from '../components/TestimonialSection/components/ContentSlider';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const testimonialData = {
  key: 1,
  img: 'path/to/image.jpg',
  title: 'Nombre usuario',
  subtitle: 'Cálido Departamento en Balvanera con vista a la ciudad',
  text: 'La plataforma me resultó muy satisfactoria, se puede lograr un excelente feedback con los huéspedes y desde ya generar confianza a la hora de las reservas',
};

describe('ContentSlider', () => {
  it('it renders correctly', () => {
    renderWithStore(<ContentSlider {...testimonialData} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    // Use screen queries to assert the presence of elements in the rendered component
    expect(screen.getByText('Nombre usuario')).toBeInTheDocument();
    expect(
      screen.getByText(
        'Cálido Departamento en Balvanera con vista a la ciudad',
      ),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        'La plataforma me resultó muy satisfactoria, se puede lograr un excelente feedback con los huéspedes y desde ya generar confianza a la hora de las reservas',
      ),
    ).toBeInTheDocument();
  });
});
