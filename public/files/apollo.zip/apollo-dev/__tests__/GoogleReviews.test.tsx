import React from 'react';
import { screen } from '@testing-library/react';
import GoogleReviews from '../components/GoogleReviews/GoogleReviews';
import type { TGoogleReviews } from '../types/publicar.types';
import { renderWithStore } from './hoc/render-with-store';
import '@testing-library/jest-dom';

describe('GoogleReviews', () => {
  const reviews: TGoogleReviews = {
    averageRating: 4.5,
    totalReviewCount: 10,
    reviews: [
      {
        name: 'Juan Carlos',
        photo: 'profile.jpg',
        rating: '4',
        review: 'Muy buen servicio!',
        date: 'Hace 22 horas',
      },
    ],
  };
  test('renders correctly with mobile view', () => {
    jest.mock('../hooks/useIsMobile', () => () => true);

    renderWithStore(<GoogleReviews reviews={reviews} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(
      screen.getByText(
        'Qué opinan los turistas sobre Alquiler Argentina en Google',
      ),
    ).toBeInTheDocument();
    expect(screen.getByText(`${reviews?.averageRating}`)).toBeInTheDocument();
    expect(
      screen.getByText(
        `${reviews?.totalReviewCount.toLocaleString('es-AR')} opiniones`,
      ),
    ).toBeInTheDocument();
    expect(screen.getByText('Juan Carlos')).toBeInTheDocument();
    expect(screen.getByText('Muy buen servicio!')).toBeInTheDocument();
  });

  test('renders correctly with desktop view', () => {
    jest.mock('../hooks/useIsMobile', () => () => false);

    renderWithStore(<GoogleReviews reviews={reviews} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(
      screen.getByText(
        'Qué opinan los turistas sobre Alquiler Argentina en Google',
      ),
    ).toBeInTheDocument();
    expect(screen.getByText(`${reviews?.averageRating}`)).toBeInTheDocument();
    expect(
      screen.getByText(
        `${reviews?.totalReviewCount.toLocaleString('es-AR')} opiniones`,
      ),
    ).toBeInTheDocument();
    expect(screen.getByText('Juan Carlos')).toBeInTheDocument();
    expect(screen.getByText('Muy buen servicio!')).toBeInTheDocument();
  });
});
