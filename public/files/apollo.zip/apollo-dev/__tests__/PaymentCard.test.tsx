import React from 'react';
import '@testing-library/jest-dom';
import { render, screen } from '@testing-library/react';
import PaymentCard from '../components/PaymentCard/PaymentCard';
import { Values, PaymentType } from '../components/PaymentCard/types';

describe('paymentCard component', () => {
  const mockValues: Values = { total: 20, advance: 10, balance: 5 };
  const mockPaymentOptions: PaymentType[] = ['cash', 'bank-transfer'];

  beforeEach(() => {
    render(
      <PaymentCard values={mockValues} paymentOptions={mockPaymentOptions} />,
    );
  });

  it('renders the child components', () => {
    expect(screen.getByTestId('payment-body')).toBeInTheDocument();
    expect(screen.getByTestId('payment-footer')).toBeInTheDocument();
  });

  it('renders a payment value', () => {
    const hostName = screen.getByText(`$ ${mockValues.total}`);
    expect(hostName).toBeInTheDocument();
  });

  it('renders the payment options', () => {
    const paymentTypes = {
      cash: 'Efectivo',
      'bank-transfer': 'Transferencia bancaria',
    };

    Object.entries(paymentTypes).forEach(([payment, translation]) => {
      if (mockPaymentOptions.includes(payment as PaymentType)) {
        expect(screen.getByText(translation)).toBeInTheDocument();
      }
    });
  });
});
