import React from 'react';
import { LinkProps } from '@mui/material';
import HeaderAnuncio from '../components/HeaderAnuncio';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const DataUbicacion: LinkProps[] = [
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Argentina',
    target: '_blank',
    color: 'inherit',
    underline: 'always',
  },
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Cordoba',
    target: '_blank',
    color: 'inherit',
    underline: 'always',
  },
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Villa Carlos Paz',
    target: '_blank',
    color: '#000000DE',
    underline: 'none',
  },
];

const arrayImagenes = [
  {
    id: 0,
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/sg59/sg59-Casa-H9I6CN16.jpg?p=galeria_lg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
  {
    id: 1,
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/sg59/sg59-Casa-MQTVYGRQ.jpg?p=galeria_lg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
  {
    id: 2,
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/sg59/sg59-Casa-GDXPNX6S.jpg?p=galeria_lg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
  {
    id: 3,
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/sg59/sg59-Casa-GDXPNX6S.jpg?p=galeria_lg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
  {
    id: 3,
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/sg59/sg59-Casa-GDXPNX6S.jpg?p=galeria_lg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
];
const imagesTypologys = [
  {
    title: 'hola',
    fotos: [
      {
        src: 'hola',
        alt: 'hola',
        loading: 'lazy' as const,
      },
    ],
  },
];

const imagenDestacada = `${
  process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
}_propiedades_/sg59/sg59-Casa-ZHYW4K7E.jpg?p=galeria_lg`;

describe('HeaderAnuncio', () => {
  const { container } = renderWithStore(
    <HeaderAnuncio
      imagesTypologys={imagesTypologys}
      imagesArray={arrayImagenes}
      featuredImage={imagenDestacada}
      BreadcrumsLocation={DataUbicacion}
      title="Alquiler Cabañas con acceso al rio San Antonio"
      average={4.9}
      href="/"
      total={57}
      mobileShare={async () => {}}
      addFavorite={() => {}}
      open
      setOpen={() => true}
    />,
    {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    },
  );

  it('Se renderiza correctamente HeaderAnuncio', () => {
    const item = container.querySelector('.MuiGrid-root');
    expect(item).toBeInTheDocument();
  });
});
