import React from 'react';
import { screen } from '@testing-library/react';
import TestimonialSection from '../components/TestimonialSection/TestimonialSection';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { MOCKED_TESTIMONIALS } from '../layout/publicar/constants/mockedData';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('TestimonialSection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('it renders correctly', () => {
    renderWithStore(
      <TestimonialSection
        onClickPublicar={() => {}}
        testimonials={MOCKED_TESTIMONIALS}
      />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'adsDetail',
        },
      },
    );

    expect(screen.getByText('Esteban')).toBeInTheDocument();
    expect(
      screen.getByText(
        'Alquiler Argentina es excelente. Siempre hemos tenido buena respuesta y nos ha sido útil para alquilar nuestro Complejo. La plataforma es sencilla y ofrece contacto directo con huéspedes. Agradezco el apoyo de Alquiler Argentina para seguir con mi emprendimiento familiar.',
      ),
    ).toBeInTheDocument();
  });
});
