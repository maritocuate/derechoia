import React from 'react';
import { render } from '@testing-library/react';
import HostProfile from '../components/HostProfile';
import '@testing-library/jest-dom';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('HostProfile', () => {
  it('renders HostProfile text', () => {
    const { container } = render(
      <HostProfile name="Martín" lastname="Ortiz" />,
    );
    const item = container.querySelector('.MuiListItemText-root');
    expect(item).toBeInTheDocument();
  });
  it('render avatar HostProfile', () => {
    const { container } = render(
      <HostProfile name="Martín" lastname="Ortiz" />,
    );
    const item = container.querySelector('.MuiAvatar-root');
    expect(item).toBeInTheDocument();
  });
  it('render icon HostProfile', () => {
    const { container } = render(
      <HostProfile name="Martín" lastname="Ortiz" />,
    );
    const item = container.querySelector('.MuiSvgIcon-root');
    expect(item).toBeInTheDocument();
  });
});
