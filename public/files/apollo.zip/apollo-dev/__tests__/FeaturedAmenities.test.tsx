import React from 'react';
import { render } from '@testing-library/react';
import DirectionsCarFilledOutlinedIcon from '@mui/icons-material/DirectionsCarFilledOutlined';
import FeaturedAmenities from '../components/FeaturedAmenities';
import '@testing-library/jest-dom';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const DatosAmenities = [
  {
    icon: <DirectionsCarFilledOutlinedIcon />,
    text: 'Cochera',
  },
  {
    icon: <DirectionsCarFilledOutlinedIcon />,
    text: 'Cochera',
  },
  {
    icon: <DirectionsCarFilledOutlinedIcon />,
    text: 'Piscina',
  },
];

describe('Tests in FeaturedAmenities', () => {
  it('Se muestra en pantalla', () => {
    const { container } = render(
      <FeaturedAmenities
        ameneties={DatosAmenities}
        isOpenModalAmenities={false}
        setIsOpenModalAmenities={() => {}}
      />,
    );
    const item = container.querySelector('.MuiGrid-root');
    expect(item).toBeInTheDocument();
  });
  it('Cantidad de items no debe ser mayor que 6', () => {
    const { container } = render(
      <FeaturedAmenities
        ameneties={DatosAmenities}
        isOpenModalAmenities={false}
        setIsOpenModalAmenities={() => {}}
      />,
    );
    const buttons = container.querySelectorAll('svg');
    expect(buttons.length <= 6).toBeTruthy();
  });
});
