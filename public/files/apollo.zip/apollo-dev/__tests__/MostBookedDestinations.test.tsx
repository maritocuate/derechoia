import React from 'react';
import '@testing-library/jest-dom';
import MostBookDestinations from '../components/MostBookedDestinations/MostBookedDestinations';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const destinations = [
  {
    city: 'Ciudad Autónoma de Buenos Aires ',
    province: 'Buenos Aires',
    cityV4: 'Ciudad Autónoma de Buenos Aires ',
    provinceV4: 'Buenos Aires',
    url: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/0f/0c/8a/ba/twilight-time.jpg?w=1200&h=-1&s=1',
    amount: 2271,
  },
  {
    city: 'Mar del Plata',
    province: 'Buenos Aires',
    cityV4: 'Mar del Plata',
    provinceV4: 'Buenos Aires',
    url: 'https://1001beach.com/img/posts/1028/1200/mar_del_plata_beach-1.jpg',
    amount: 1455,
  },
  {
    city: 'Bariloche',
    province: 'Río Negro',
    cityV4: 'Bariloche',
    provinceV4: 'Río Negro',
    url: 'https://www.travelclass.tur.br/uploads/2020/09/galeria-hero-710x564.jpg',
    amount: 764,
  },
  {
    city: 'Puerto Iguazú',
    province: 'Misiones',
    cityV4: 'Puerto Iguazú',
    provinceV4: 'Misiones',
    url: 'https://i0.wp.com/canal12misiones.com/wp-content/uploads/2022/10/bossetti.jpeg?resize=1089%2C730&ssl=1',
    amount: 1062,
  },
  {
    city: 'Ciudad de Córdoba',
    province: 'Córdoba',
    cityV4: 'Ciudad de Córdoba',
    provinceV4: 'Córdoba',
    url: 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhHalcfDVJsHQIX2Od8NhC7tFMymaCggr1GlwBPPm4j7j3CXWDaqnCXWPnT8ZHbrTGczFlR89OGi08UWgZl9KFv7MBqtKC2YBhSFDJknkh6y6E-74UfKiBlgjWERHeWkh9rT9RbjmT5tg1ii80Ltn7DE4R5lN2jppU4ULaOx-klK1w2yQOVGqeaDdMS6g/s2048/FgqJseOWQAcbZng.jpg',
    amount: 3282,
  },
  {
    city: 'Ciudad de Salta',
    province: 'Salta',
    cityV4: 'Ciudad de Salta',
    provinceV4: 'Salta',
    url: 'https://static1.evcdn.net/images/reduction/122591_w-1600_h-1200_q-75_m-crop.jpg',
    amount: 1098,
  },
];
describe('MostBookedDestinations', () => {
  test('MostBookedDestinations', () => {
    renderWithStore(<MostBookDestinations mostBooked={destinations} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'home',
      },
    });
    const item = document.querySelector('.MuiBox-root');
    expect(item).toBeInTheDocument();
    expect(destinations).toHaveLength(6);
  });
});
