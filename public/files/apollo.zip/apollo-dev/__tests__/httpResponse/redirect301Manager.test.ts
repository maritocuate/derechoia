import { destinationAndFiltersFormatter } from '../../serverSide/managers/formatters/index.formatter';
import { paramsOfUrlTransform } from '../../serverSide/managers/formatters/paramsOfUrls.formatter';
import { redirect301Manager } from '../../serverSide/managers/redirect301Manager';
import { formatFilters } from '../../utils/helpers/destinationAndFilters/formatFilters';
import { mockedLocality } from '../../mocks/data';

describe('hardCode Validator URL', () => {
  test('200 OK', () => {
    const pathname = '/Córdoba/Villa-Carlos-Paz/_C:2_P:S/';
    const url = '/Córdoba/Villa-Carlos-Paz/_C:2_P:S/';

    const paramsOfUrl = paramsOfUrlTransform(pathname);

    const destinationAndFiltersFormatted =
      destinationAndFiltersFormatter(paramsOfUrl);
    expect(
      redirect301Manager({
        destination: destinationAndFiltersFormatted.destination,
        destinationDB: mockedLocality,
        filters: formatFilters({ slug: paramsOfUrl }),
        pathname,
        url,
      }),
    ).toStrictEqual(undefined);
  });

  test('Province redirect', () => {
    const pathname = '/cordoba/Villa-Carlos-Paz/_C:2_P:S/';
    const url = '/cordoba/Villa-Carlos-Paz/_C:2_P:S/';
    const paramsOfUrl = paramsOfUrlTransform(pathname);
    const destinationAndFiltersFormatted =
      destinationAndFiltersFormatter(paramsOfUrl);
    expect(
      redirect301Manager({
        destination: destinationAndFiltersFormatted.destination,
        destinationDB: mockedLocality,
        filters: formatFilters({ slug: paramsOfUrl }),
        pathname,
        url,
      }),
    ).toStrictEqual({
      code: 301,
      value: '/C%C3%B3rdoba/Villa-Carlos-Paz/_C:2_P:S/',
    });
  });
  test('locality redirect', () => {
    const pathname = '/Córdoba/Villa-carlos-Paz/_C:2_P:S/';
    const url = '/Córdoba/Villa-carlos-Paz/_C:2_P:S/';
    const paramsOfUrl = paramsOfUrlTransform(pathname);

    const destinationAndFiltersFormatted =
      destinationAndFiltersFormatter(paramsOfUrl);
    expect(
      redirect301Manager({
        destination: destinationAndFiltersFormatted.destination,
        destinationDB: mockedLocality,
        filters: formatFilters({ slug: paramsOfUrl }),
        pathname,
        url,
      }),
    ).toStrictEqual({
      code: 301,
      value: '/C%C3%B3rdoba/Villa-Carlos-Paz/_C:2_P:S/',
    });
  });
  test('order filters', () => {
    const pathname = '/Córdoba/Villa-carlos-Paz/_P:S_C:2_A:20/';
    const url = '/Córdoba/Villa-carlos-Paz/_P:S_C:2_A:20/';
    const paramsOfUrl = paramsOfUrlTransform(pathname);

    const destinationAndFiltersFormatted =
      destinationAndFiltersFormatter(paramsOfUrl);
    expect(
      redirect301Manager({
        destination: destinationAndFiltersFormatted.destination,
        destinationDB: mockedLocality,
        filters: formatFilters({ slug: paramsOfUrl }),
        pathname,
        url,
      }),
    ).toStrictEqual({
      code: 301,
      value: '/C%C3%B3rdoba/Villa-Carlos-Paz/_A:20_C:2_P:S/',
    });
  });
});
