import { validateDestinationServiceManager } from '../../serverSide/managers/validateDestinationServiceManager';

describe('hardCode Validator URL', () => {
  test('No Result', () => {
    expect(() => validateDestinationServiceManager(0)).toThrow('No Result');
  });

  test('200 OK', () => {
    expect(validateDestinationServiceManager(12)).toBe(undefined);
  });
});
