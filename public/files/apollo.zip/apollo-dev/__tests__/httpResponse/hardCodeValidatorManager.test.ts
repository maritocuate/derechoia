import { destinationAndFiltersFormatter } from '../../serverSide/managers/formatters/index.formatter';
import { ManagerHardCodeValidate } from '../../serverSide/managers/hardCodemanager';

describe('hardCode Validator URL', () => {
  const managagerValidatorHardCode = new ManagerHardCodeValidate();

  test('Error Filters', () => {
    const slugWithErrorInFilter = [
      'Córdoba',
      'Villa-Carlos-Paz',
      '_C:estoEstáMal_P:C',
    ];
    const FilterAndDestiantion = destinationAndFiltersFormatter(
      slugWithErrorInFilter,
    );
    expect(() =>
      managagerValidatorHardCode.validate({
        ...FilterAndDestiantion,
        paramsOfUrl: slugWithErrorInFilter,
        url: 'Córdoba/Villa-Carlos-Paz/_C:estoEstáMal_P:C/',
      }),
    ).toThrow();
  });
  test('Error Destination', () => {
    const slugWithErrorInDestination = [
      '_Córdoba',
      'Villa-Carlos-Paz',
      '_C:2_P:C',
    ];
    const FilterAndDestiantion = destinationAndFiltersFormatter(
      slugWithErrorInDestination,
    );
    expect(() =>
      managagerValidatorHardCode.validate({
        ...FilterAndDestiantion,
        paramsOfUrl: slugWithErrorInDestination,
        url: '_Córdoba/Villa-Carlos-Paz/_C:2_P:C/',
      }),
    ).toThrow('invalid Destination');
  });
  test('200 OK', () => {
    const slug = ['Córdoba', 'Villa-Carlos-Paz', '_C:2_P:C'];
    const FilterAndDestiantion = destinationAndFiltersFormatter(slug);
    expect(
      managagerValidatorHardCode.validate({
        ...FilterAndDestiantion,
        paramsOfUrl: slug,
        url: 'Córdoba/Villa-Carlos-Paz/_C:2_P:C/',
      }),
    ).toBe(undefined);
  });
});
