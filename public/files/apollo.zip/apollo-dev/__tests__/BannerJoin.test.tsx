import React from 'react';
import { screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import BannerJoin from '../components/BannerJoin/BannerJoin';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

describe('BannerJoin Component', () => {
  it('renders correctly', () => {
    const mockOnClick = jest.fn();
    renderWithStore(<BannerJoin onClick={mockOnClick} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'home',
      },
    });

    expect(screen.getByText('test: bannerTitle')).toBeInTheDocument();
    expect(screen.getByText('test: bannerButton')).toBeInTheDocument();

    fireEvent.click(screen.getByText('test: bannerButton'));

    expect(mockOnClick).toHaveBeenCalledTimes(1);
  });
});
