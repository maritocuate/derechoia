import React from 'react';
import '@testing-library/jest-dom';
import FavoriteModal from '../components/FavoriteModal';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('FavoriteModal', () => {
  it('renders FavoriteModal container', () => {
    const { getByTestId } = renderWithStore(
      <FavoriteModal onClickLogin={() => {}} onClose={() => {}} />,
      {},
    );
    const title = getByTestId('container-modal');
    expect(title).toBeInTheDocument();
  });
  it('renders FavoriteModal SVG', () => {
    const { getByTestId } = renderWithStore(
      <FavoriteModal onClickLogin={() => {}} onClose={() => {}} />,
      {},
    );
    const title = getByTestId('svg-modal');
    expect(title).toBeInTheDocument();
  });
  it('renders FavoriteModal text', () => {
    const { getByTestId } = renderWithStore(
      <FavoriteModal onClickLogin={() => {}} onClose={() => {}} />,
      {},
    );
    const title = getByTestId('text-modal');
    expect(title).toBeInTheDocument();
  });
  it('renders FavoriteModal button', () => {
    const { getByTestId } = renderWithStore(
      <FavoriteModal onClickLogin={() => {}} onClose={() => {}} />,
      {},
    );
    const title = getByTestId('button-modal');
    expect(title).toBeInTheDocument();
  });
});
