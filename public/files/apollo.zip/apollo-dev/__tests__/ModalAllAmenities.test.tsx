import React from 'react';
import ModalAllAmenities from '../components/ModalAllAmenities';
import '@testing-library/jest-dom';
import { AgregadosState, AgregadosTipos } from '../types/propiedades.types';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const dataAmenities = [
  {
    status: AgregadosState.DISPONIBLE,
    amenities: 'prueba1',
    amenitiesType: AgregadosTipos.EQUIPAMIENTOS,
  },
  {
    status: AgregadosState.DISPONIBLE,
    amenities: 'prueba1',
    amenitiesType: AgregadosTipos.EQUIPAMIENTOS,
  },
  {
    status: AgregadosState.DISPONIBLE,
    amenities: 'prueba1',
    amenitiesType: AgregadosTipos.EQUIPAMIENTOS,
  },
  {
    status: AgregadosState.DISPONIBLE,
    amenities: 'prueba1',
    amenitiesType: AgregadosTipos.EQUIPAMIENTOS,
  },
  {
    status: AgregadosState.DISPONIBLE,
    amenities: 'prueba1',
    amenitiesType: AgregadosTipos.EQUIPAMIENTOS,
  },
];
describe('Valorate', () => {
  test('Valoracion Texto', () => {
    renderWithStore(
      <ModalAllAmenities
        infoAmenities={dataAmenities}
        open
        setIsOpenModalAmenities={() => {}}
      />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'adsDetail',
        },
      },
    );
    const item = document.querySelector('.MuiDialog-root');
    expect(item).toBeInTheDocument();
  });
});
