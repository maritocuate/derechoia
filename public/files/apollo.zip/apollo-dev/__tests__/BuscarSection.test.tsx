import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import BuscarPageSection from '../components/BuscarPageSection/BuscarSection';

const sectionProps = {
  children: <p>Buscar alojamiento</p>,
};

describe('BuscarSection', () => {
  it('renders BuscarSection', () => {
    renderWithStore(<BuscarPageSection {...sectionProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const container = screen.getByTestId('BuscarPageSection');
    const titleSection = screen.getByTestId('BuscarPageSectionTitle');
    // const feedback = screen.getByTestId('BuscarPageSectionFeedback');
    expect(container).toBeInTheDocument();
    expect(titleSection).toBeInTheDocument();
    // expect(feedback).toBeInTheDocument();
  });
});
