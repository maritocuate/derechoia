import React from 'react';
import { screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import CardAdSkeletonDesk from '../components/Skeletons/CardAdSkeletonDesk';
import CardAdSkeletonMobile from '../components/Skeletons/CardAdSkeletonMobile';
import FiltersSkeleton from '../components/Skeletons/FiltersSkeleton';
import ListTitleDeskSkeleton from '../components/Skeletons/ListTitleDeskSkeleton';

describe('Skeletons', () => {
  it('renders CardAdSkeletonDesk', () => {
    renderWithStore(<CardAdSkeletonDesk />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const skeleton = screen.getByTestId('CardAdsSkeletonDesk');
    expect(skeleton).toBeInTheDocument();
  });
  it('renders CardAdSkeletonDesk', () => {
    renderWithStore(<CardAdSkeletonMobile />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const skeleton = screen.getByTestId('CardAdsSkeletonMobile');
    expect(skeleton).toBeInTheDocument();
  });
  it('renders CardAdSkeletonDesk', () => {
    renderWithStore(<FiltersSkeleton />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const skeleton = screen.getByTestId('FiltersSkeleton');
    expect(skeleton).toBeInTheDocument();
  });
  it('renders CardAdSkeletonDesk', () => {
    renderWithStore(<ListTitleDeskSkeleton />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const skeleton = screen.getByTestId('ListTitleSkeleton');
    expect(skeleton).toBeInTheDocument();
  });
});
