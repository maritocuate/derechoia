import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Feedback from '../components/Feedback/Feedback';

describe('Feedback', () => {
  const feedbackProps = {
    initialValue: true,
    text: '¿Fue útil?',
    callback: () => {},
  };
  it('renders Feedback', () => {
    render(<Feedback {...feedbackProps} />);
    const text = screen.getByTestId('feedbackText');
    const container = screen.getByTestId('iconsContainer');
    const positiveFeedback = screen.getByTestId('thumbUpIcon');
    const negativeFeedback = screen.getByTestId('thumbDownIcon');
    expect(text).toHaveTextContent('¿Fue útil?');
    expect(container).toBeInTheDocument();
    expect(positiveFeedback).toBeInTheDocument();
    expect(negativeFeedback).toBeInTheDocument();
  });
});
