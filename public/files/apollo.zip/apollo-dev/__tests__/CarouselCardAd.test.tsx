import React from 'react';
import '@testing-library/jest-dom';
import CarouselCardAd from '../components/CardAd/components/Header/Carousel';
import { renderWithStore } from './hoc/render-with-store';
import { IAppStatusState } from '../redux/appStatus/types';

const carouselCardAdProps = [
  {
    id: 1,
    id_propiedad: 2,
    nombreArchivo: 'propiedad1',
    descripcion: 'img-carousel',
  },
  {
    id: 2,
    id_propiedad: 3,
    nombreArchivo: 'propiedad1',
    descripcion: 'img-carousel',
  },
  {
    id: 3,
    id_propiedad: 4,
    nombreArchivo: 'propiedad1',
    descripcion: 'img-carousel',
  },
];

describe('CarouselCardAD', () => {
  const initialState: { appStatus: IAppStatusState } = {
    appStatus: {
      preloaded: true,
      showNewBanner: false,
      isOpenLoginModal: false,
      isMobile: false,
      isError: false,
      page: 'adsList',
    },
  };

  it('renders CarouselCardAD container', () => {
    const { container } = renderWithStore(
      <CarouselCardAd imgsCarousel={carouselCardAdProps} referencia="ls22" />,
      initialState,
    );
    const item = container.querySelector('.MuiBox-root');
    expect(item).toBeInTheDocument();
  });
  it('renders CarouselCardAD dots', () => {
    const { container } = renderWithStore(
      <CarouselCardAd imgsCarousel={carouselCardAdProps} referencia="ls22" />,
      initialState,
    );
    const item = container.querySelector('.MuiSvgIcon-root');
    expect(item).toBeInTheDocument();
  });
  it('renders CarouselCardAD nav buttons', () => {
    const { container } = renderWithStore(
      <CarouselCardAd imgsCarousel={carouselCardAdProps} referencia="ls22" />,
      initialState,
    );
    const item = container.querySelector('.MuiButtonBase-root');
    expect(item).toBeInTheDocument();
  });
  it('renders CarouselCardAD image', () => {
    const { queryAllByAltText } = renderWithStore(
      <CarouselCardAd imgsCarousel={carouselCardAdProps} referencia="ls22" />,
      initialState,
    );
    const imgElements = queryAllByAltText('img-carousel');
    expect(imgElements.length).toBeGreaterThan(0);
  });
  it('renders CarouselCardAD containers with correct height on mobile', () => {
    window.innerWidth = 320;
    const { queryAllByTestId } = renderWithStore(
      <CarouselCardAd imgsCarousel={carouselCardAdProps} referencia="ls22" />,
      initialState,
    );
    const items = queryAllByTestId('image-container-carousel');
    items.forEach((item) => {
      expect(item).toHaveStyle('height: 12.125rem;');
    });
  });
});
