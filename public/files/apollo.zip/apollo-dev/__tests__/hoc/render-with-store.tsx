import React, { ReactElement, ReactNode } from 'react';
import { configureStore } from '@reduxjs/toolkit';
import { Provider } from 'react-redux';

import { render } from '@testing-library/react';

import { RootState } from '../../redux/store/store';
import rootReducer from '../../redux/reducers/reducers';

const testStore = (state: Partial<RootState>) =>
  configureStore({
    reducer: rootReducer,
    preloadedState: state,
  });

const defaultValues = {};
const AppContext = React.createContext(defaultValues);

export const renderWithStore = (
  component: ReactElement,
  initialState: Partial<RootState>,
) => {
  const Wrapper = ({ children }: { children: ReactNode }) => (
    <Provider store={testStore(initialState)}>{children}</Provider>
  );
  return render(
    <AppContext.Provider value={defaultValues}>
      <Wrapper>{component}</Wrapper>
    </AppContext.Provider>,
  );
};
