import React from 'react';
import { fireEvent, screen } from '@testing-library/react';
import CheckoutSic from '../components/CheckoutSic';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { IAppStatusState } from '../redux/appStatus/types';

jest.mock('next-i18next', () => ({
  useTranslation: () => ({
    t: (str: string) => `${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('CheckoutSic', () => {
  const initialState: { appStatus: IAppStatusState } = {
    appStatus: {
      preloaded: true,
      showNewBanner: false,
      isOpenLoginModal: false,
      isMobile: false,
      isError: false,
      page: 'adsDetail',
    },
  };

  const mockOnClickWhatsapp = jest.fn();
  const props = {
    referencia: 'eh05',
    setOpenCheckoutSic: () => {},
    gtm: () => {},
    emailPropietario: null,
    hasWhatsapp: true,
    onClickWhtsapp: mockOnClickWhatsapp,
    name: 'Liliana y Juan',
    unidad: 'Casa Sueños (Hasta 10 Personas)',
    whatsappNumber: '0351155427950',
    hasPhoneNumber: true,
  };

  it('redirects to WhatsApp on button click when fields are completed', () => {
    renderWithStore(<CheckoutSic {...props} />, initialState);

    const whatsappButton = screen.getByText('WhatsApp');
    fireEvent.click(whatsappButton);

    expect(mockOnClickWhatsapp);
  });

  it('edirects to phone numbers on button click when fields are completed', () => {
    const mockOnPhoneCall = jest.fn();

    renderWithStore(<CheckoutSic {...props} />, initialState);

    const phoneCallButton = screen.getByText('phone-call');
    fireEvent.click(phoneCallButton);

    expect(mockOnPhoneCall);
  });
});
