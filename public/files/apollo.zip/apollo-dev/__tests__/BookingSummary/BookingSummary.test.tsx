import React from 'react';
import '@testing-library/jest-dom';
import { screen, fireEvent } from '@testing-library/react';
import fetchMock from 'jest-fetch-mock';
import BookingSummary from '../../components/BookingSummary';
import { renderWithStore } from '../hoc/render-with-store';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

jest.mock('next/router', () => ({
  useRouter() {
    return {
      route: '/',
      pathname: '',
      query: '',
      asPath: '',
      push: jest.fn(),
      events: {
        on: jest.fn(),
        off: jest.fn(),
      },
      beforePopState: jest.fn(() => null),
      prefetch: jest.fn(() => null),
    };
  },
}));

fetchMock.enableMocks();

describe('BookingSummary', () => {
  const props = {
    title: 'Las cabañas Aire Fresco',
    startDate: '',
    endDate: '',
    persons: {
      adults: 0,
      children: 0,
      babies: 0,
      mascotas: true,
      total: 0,
    },
    isImmediate: true,
    isSIC: true,
    blocked: false,
    blockedMessage: null,
    dayValueDiffers: true,
    referencia: 'wd40',
    basePrice: null,
    totalDays: null,
    selectedDiscount: null,
    setOpenCalendar: jest.fn(),
    changeProps: jest.fn(),
    gtm: jest.fn(),
    setOpenCheckoutSic: jest.fn(),
    openCheckoutSIC: false,
    emailPropietario: null,
    active: true,
    location: null,
  };

  it('renders correctly', () => {
    renderWithStore(<BookingSummary testProperty={false} {...props} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('test: unit-selected')).toBeInTheDocument();
    expect(screen.getByText('test: contact-accommodation')).toBeInTheDocument();
  });

  it('It must show the amount of people', () => {
    renderWithStore(<BookingSummary testProperty={false} {...props} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('2 personas')).toBeInTheDocument();
  });

  it('open Modal Calendan when the dates were not selected', () => {
    const calendarOpenProps = { ...props, openCalendar: true };

    renderWithStore(
      <BookingSummary testProperty={false} {...calendarOpenProps} />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'adsDetail',
        },
      },
    );

    fireEvent.click(screen.getByText('test: contact-accommodation'));
  });

  it('opens Checkout SIC when contact button is clicked', () => {
    const checkoutSICprops = {
      ...props,
      openCheckoutSIC: true,
      startDate: '08/09/2023',
      endDate: '17/09/2023',
      persons: {
        adults: 6,
        children: 0,
        babies: 0,
        mascotas: true,
        total: 6,
      },
      price: 324000,
    };

    renderWithStore(
      <BookingSummary testProperty={false} {...checkoutSICprops} />,
      {
        appStatus: {
          preloaded: true,
          showNewBanner: false,
          isOpenLoginModal: false,
          isMobile: false,
          isError: false,
          page: 'adsDetail',
        },
      },
    );

    expect(
      screen.getByText('Completá los datos para poder realizar la consulta'),
    ).toBeInTheDocument();
  });

  it('changes selectPeople state on click', () => {
    renderWithStore(<BookingSummary testProperty={false} {...props} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    fireEvent.click(screen.getByText('test: guests'));
    expect(screen.getByText('2 personas')).toBeInTheDocument();
  });

  it('disables buttons when necessary', () => {
    const disableProps = {
      ...props,
      blocked: true,
      subTotalPrice: 0,
    };

    renderWithStore(<BookingSummary testProperty={false} {...disableProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    const contactButton = screen.getByText('test: contact-accommodation');
    expect(contactButton).toBeDisabled();
  });

  it('displays "No hay opciones disponibles" when blocked', () => {
    const blockedProps = {
      ...props,
      blocked: true,
    };

    renderWithStore(<BookingSummary testProperty={false} {...blockedProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('No hay opciones disponibles')).toBeInTheDocument();
  });

  it('displays check price when subtotalPrice is 0', () => {
    const priceProps = {
      ...props,
      subtotalPrice: 0,
    };

    renderWithStore(<BookingSummary testProperty={false} {...priceProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('test: checkPrice')).toBeInTheDocument();
  });

  it('displays correct unit information', () => {
    const unitProps = {
      ...props,
      unidad: 'Cabaña 5',
    };

    renderWithStore(<BookingSummary testProperty={false} {...unitProps} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });

    expect(screen.getByText('Cabaña 5')).toBeInTheDocument();
  });
});
