import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import BookingSummaryMobile from '../../components/BookingSummaryMobile/index';

jest.mock('next-i18next', () => ({
  useTranslation: () => ({
    t: (str: string) => `${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('BookingSummaryMobile', () => {
  const props = {
    startDate: '2023-08-01',
    endDate: '2023-08-05',
    guests: 2,
    persons: {
      adults: 2,
      children: 0,
      babies: 0,
      total: 2,
      mascotas: false,
    },
    blocked: false,
    blockedDays: [],
    blockedMessage: null,
    onChange: jest.fn(),
    changeProps: jest.fn(),
    active: true,
    openCalendar: false,
    setOpenCalendar: jest.fn(),
    handleResetCalendar: jest.fn(),
  };

  it('should render correctly', () => {
    render(<BookingSummaryMobile {...props} />);
    expect(screen.getByText('01 ago - 05 ago')).toBeTruthy();
    expect(screen.getByText('people')).toBeTruthy();
  });

  it('should show blocked message when blocked is true', () => {
    const blockedProps = {
      ...props,
      blocked: true,
      blockedMessage:
        'Esta propiedad esta bloqueada para las fechas seleccionadas.',
    };
    render(<BookingSummaryMobile {...blockedProps} />);
    expect(
      screen.getByText(
        'Esta propiedad esta bloqueada para las fechas seleccionadas.',
      ),
    ).toBeTruthy();
  });

  it('should show "pick-date" when startDate and endDate are empty', () => {
    const emptyDateProps = { ...props, startDate: '', endDate: '' };
    render(<BookingSummaryMobile {...emptyDateProps} />);
    expect(screen.getByText('pick-date')).toBeTruthy();
  });

  it('should open ModalCalendarMobile when "stay" input is clicked', async () => {
    const calendarOpenProps = { ...props, openCalendar: true };
    render(<BookingSummaryMobile {...calendarOpenProps} />);
    const lazyContent = await waitFor(() =>
      screen.getByText('Seleccioná las fechas de tu estadía'),
    );

    fireEvent.click(lazyContent);
    expect(
      screen.queryByText('Seleccioná las fechas de tu estadía'),
    ).toBeTruthy();
  });

  it('should open SelectPeople when "guests" input is clicked', () => {
    const selectPeopleOpenProps = {
      ...props,
      guests: 0,
      persons: {
        adults: 0,
        children: 0,
        babies: 0,
        total: 0,
        mascotas: false,
      },
    };
    render(<BookingSummaryMobile {...selectPeopleOpenProps} />);
    fireEvent.click(screen.getByTestId('guests-input'));
    expect(screen.queryByTestId('select-people'));
  });
});
