import React from 'react';
import { fireEvent } from '@testing-library/react';
import ModalDuplicateReservation from '../components/ModalDuplicateReservation/ModalDuplicateReservation';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { IAppStatusState } from '../redux/appStatus/types';

const appStatusDefaultProps: IAppStatusState = {
  page: 'adsDetail',
  preloaded: true,
  showNewBanner: false,
  isOpenLoginModal: false,
  isMobile: false,
  isError: false,
};

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('ModalDuplicateReservation', () => {
  it('renders correctly when open is true', () => {
    const onCloseMock = jest.fn();
    const onContinueMock = jest.fn();
    const { getByText, getByTestId } = renderWithStore(
      <ModalDuplicateReservation
        open
        onClose={onCloseMock}
        onContinue={onContinueMock}
      />,
      {
        appStatus: appStatusDefaultProps,
      },
    );

    expect(getByText('test: header-title')).toBeInTheDocument();
    expect(getByTestId('close-button')).toBeInTheDocument();
  });

  it('calls onClose when close button is clicked', () => {
    const onCloseMock = jest.fn();
    const onContinueMock = jest.fn();
    const { getByTestId } = renderWithStore(
      <ModalDuplicateReservation
        open
        onClose={onCloseMock}
        onContinue={onContinueMock}
      />,
      {
        appStatus: appStatusDefaultProps,
      },
    );

    const closeButton = getByTestId('close-button');
    fireEvent.click(closeButton);
    expect(onCloseMock).toHaveBeenCalled();
  });
});
