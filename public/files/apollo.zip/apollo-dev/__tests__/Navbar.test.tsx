import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import Navbar from '../components/Navbar';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('Navbar', () => {
  it('renders navbar container', () => {
    const { container } = render(<Navbar />);
    const item = container.querySelector('.MuiGrid-container');
    expect(item).toBeInTheDocument();
  });
  it('renders navbar icons', () => {
    render(<Navbar />);
    const { container } = render(<Navbar />);
    const item = container.querySelector('.MuiSvgIcon-root');
    expect(item).toBeInTheDocument();
  });
});
