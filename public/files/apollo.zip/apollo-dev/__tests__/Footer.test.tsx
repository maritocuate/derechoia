import React from 'react';
import Footer from '../components/Footer/index';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';
import { IAppStatusState } from '../redux/appStatus/types';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: number) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('Footer', () => {
  const initialState: { appStatus: IAppStatusState } = {
    appStatus: {
      preloaded: true,
      showNewBanner: false,
      isOpenLoginModal: false,
      isMobile: false,
      isError: false,
      page: 'default',
    },
  };
  it('renders Footer text', () => {
    const { container } = renderWithStore(<Footer footerList />, initialState);
    const item = container.querySelector('.MuiGrid-root');
    expect(item).toBeInTheDocument();
  });
});
