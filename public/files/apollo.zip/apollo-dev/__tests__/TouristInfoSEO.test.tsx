import React from 'react';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom';
import { ThemeProvider } from '@mui/material';
import TouristInfoSEO from '../components/TouristInfoSEO/TouristInfoSEO';
import themeAA from '../styles/theme';

const exampleData = [
  {
    title: 'Vacaciones de verano en Ciudad de Córdoba',
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra.
  Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra. Duis a arcu convallis, gravida purus eget, mollis diam.`,
  },
  {
    title: 'Disfruta a pleno del turismo en Ciudad de Córdoba',
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra.
    Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra. Duis a arcu convallis, gravida purus eget, mollis diam.`,
  },
  {
    title:
      'Los alquileres temporarios en Ciudad de Córdoba, tu pasaje a unas vacaciones inolvidables',
    content: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra.
    Donec vel egestas dolor, nec dignissim metus. Donec augue elit, rhoncus ac sodales id, porttitor vitae est. Donec laoreet rutrum libero sed pharetra. Duis a arcu convallis, gravida purus eget, mollis diam.`,
  },
];

describe('TouristInfoSEO', () => {
  it('Render Contantainer', () => {
    const screen = render(
      <ThemeProvider theme={themeAA}>
        <TouristInfoSEO place="Ciudad de Córdoba" contentSEO={exampleData} />,
      </ThemeProvider>,
    );
    const item = screen.getByTestId('TouristInfoSEO-container');
    const title = screen.getByTestId('TouristInfoSEO-h6');
    expect(item).toBeInTheDocument();
    expect(title).toBeInTheDocument();
  });

  it('renders TouristInfoSEO H3 title', () => {
    const { container } = render(
      <ThemeProvider theme={themeAA}>
        <TouristInfoSEO place="Ciudad de Córdoba" contentSEO={exampleData} />,
      </ThemeProvider>,
    );
    const h3Elements = container.querySelectorAll('h3');

    expect(h3Elements.length).toBeCloseTo(0);

    h3Elements.forEach((h3Element) => {
      const computedStyles = window.getComputedStyle(h3Element);
      const { color } = computedStyles;
      expect(color).toBe('rgb(0, 172, 193)'); // Verificar que el color es #00ACC1
    });
  });

  it('renders TouristInfoSEO Paragraph', () => {
    const { container } = render(
      <ThemeProvider theme={themeAA}>
        <TouristInfoSEO place="Ciudad de Córdoba" contentSEO={exampleData} />,
      </ThemeProvider>,
    );
    const paragraphElements = container.querySelectorAll('p');

    expect(paragraphElements.length).toBeGreaterThan(0);
    paragraphElements.forEach((paragraphElement) => {
      const computedStyles = window.getComputedStyle(paragraphElement);
      const { color } = computedStyles;
      expect(color).toBe('rgba(0, 0, 0, 0.87)'); // Verificar que el color es #00ACC1
    });
  });
});
