import React from 'react';
import { render, screen } from '@testing-library/react';
import { LinkProps } from '@mui/material';
import MainInfoAnuncio from '../components/MainInfoAnuncio';
import '@testing-library/jest-dom';

const DataUbicacion: LinkProps[] = [
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Argentina',
    target: '_blank',
    color: 'inherit',
    underline: 'always',
  },
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Cordoba',
    target: '_blank',
    color: 'inherit',
    underline: 'always',
  },
  {
    href: 'https://www.alquilerargentina.com/',
    children: 'Villa Carlos Paz',
    target: '_blank',
    color: '#000000DE',
    underline: 'none',
  },
];

describe('Home', () => {
  it('renders MainInfoAnuncio', () => {
    render(
      <MainInfoAnuncio
        BreadcrumsLocation={DataUbicacion}
        title="Alquiler Cabañas con acceso al rio San Antonio"
        average={4.9}
        href="./"
        total={57}
      />,
    );
    const component = screen.getByTestId('main-info-anuncio');
    expect(component).toBeInTheDocument();
  });
  it('Title text is font weight 700', () => {
    render(
      <MainInfoAnuncio
        BreadcrumsLocation={DataUbicacion}
        title="Alquiler Cabañas con acceso al rio San Antonio"
        average={4.9}
        href="./"
        total={57}
      />,
    );
    const component = screen.getByTestId('info-anuncio-title');
    expect(component).toHaveStyle('font-weight: 700');
  });
});
