import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import LastSearchItem from '../components/LastSearchItem/LastSearchItem';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));
const dataItem = {
  city: 'Ciudad de Salta',
  province: 'Salta',
  startDate: '08-20-2023',
  endDate: '08-27-2023',
  adults: 4,
  youngs: 0,
  babies: 1,
  pets: false,
};
const props = {
  ...dataItem,
  lastCard: false,
};
describe('LastSearch', () => {
  test('LastSearch', () => {
    render(<LastSearchItem {...props} />);
    const component = screen.getByTestId('LastSearchsItem');
    expect(component).toBeInTheDocument();
  });
});

const dataItem2 = {
  city: '',
  province: 'Córdoba',
  startDate: '',
  endDate: '',
  adults: 4,
  youngs: 0,
  babies: 1,
  pets: false,
};
const props2 = {
  ...dataItem2,
  lastCard: false,
};
const props3 = {
  ...props2,
  province: 'Chile',
};
describe('LastSearch', () => {
  test('LastSearch', () => {
    render(<LastSearchItem {...props2} />);
    const component = screen.getByTestId('LastSearchsItem');
    expect(component).toBeInTheDocument();
  });
  test('LastSearch Country', () => {
    render(<LastSearchItem {...props3} />);
    const component = screen.getByTestId('LastSearchsItem');
    expect(component).toBeInTheDocument();
    expect(component).toHaveTextContent('Chile (País)');
    expect(component).toHaveTextContent('(País)');
    expect(component).not.toHaveTextContent('Chile (Provincia)');
    expect(component).not.toHaveTextContent('(Provincia)');
    expect(component).not.toHaveTextContent('Brasil (País)');
  });
});
