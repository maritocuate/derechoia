import React from 'react';
import CardAnuncio from '../components/CardAnuncio';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown

  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const props = {
  featuredimage: `${
    process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
  }_propiedades_/tf09/tf09-Casa-VPNZ5HE5.jpg?p=galeria_lg`,
  title: 'Cabañas con acceso al río San Antonio con vistas a las sierras',
  locality: 'San Antonio de Arredondo',
  averageScore: 4.9,
  offers: 1,
  capacity: 3,
  price: {
    base: 35200,
    total: 27100,
  },
  guests: 2,
  cancellation: {
    type: 'flexible' as const,
  },
};

describe('CardAnuncio', () => {
  it('renders the CardAnuncio component', () => {
    const { container } = renderWithStore(<CardAnuncio {...props} />, {
      appStatus: {
        preloaded: true,
        showNewBanner: false,
        isOpenLoginModal: false,
        isMobile: false,
        isError: false,
        page: 'adsDetail',
      },
    });
    const component = container.querySelector('.MuiGrid-root');
    expect(component).toBeInTheDocument();
  });
});
