import React from 'react';
import { screen } from '@testing-library/react';
import MediaViewImages from '../components/MediaViewImages';
import '@testing-library/jest-dom';
import { renderWithStore } from './hoc/render-with-store';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

const itemData = [
  {
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/pa46/o_pa46_Casa_IDNEBKGK.jpg`,
    alt: 'Casa',
    loading: 'lazy' as const,
  },
  {
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/pa46/o_pa46_Casa_ODFSO35D.jpg`,
    alt: 'Habitación',
    loading: 'lazy' as const,
  },
  {
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/pa46/o_pa46_Casa_6WJCTXJ8.jpg`,
    alt: 'Cocina',
    loading: 'lazy' as const,
  },
  {
    img: `${
      process.env.NEXT_PUBLIC_IMAGE_CDN || '/'
    }_propiedades_/pa46/o_pa46_Casa_6WJCTXJ8.jpg`,
    alt: 'Cocina',
    loading: 'lazy' as const,
  },
];

const imagesTypologys = [
  {
    title: 'hola',
    fotos: [
      {
        src: '/images/MediaPlaceholderImage.png',
        alt: 'hola',
        loading: 'lazy' as const,
      },
    ],
  },
];

describe('MediaViewImages', () => {
  it('it renders MediaViewImages', () => {
    renderWithStore(
      <MediaViewImages
        video="https://www.youtube.com/embed/FcoUvu0mGog"
        iframe="https://www.guia360.com.ar/files/galerias/437tamylu/index2.html"
        imagelist={itemData}
        openViewImage
        setOpenViewImage={() => {}}
        imagesTypologys={imagesTypologys}
        open={false}
        setOpen={() => false}
        featuredImage={itemData[0].img}
      />,
      {},
    );
    const modal = screen.getByRole('dialog');
    expect(modal).toBeInTheDocument();
  });
  it('renders Modal width of MediaViewImages', () => {
    renderWithStore(
      <MediaViewImages
        video="https://www.youtube.com/embed/FcoUvu0mGog"
        iframe="https://www.guia360.com.ar/files/galerias/437tamylu/index2.html"
        imagelist={itemData}
        openViewImage
        setOpenViewImage={() => {}}
        imagesTypologys={imagesTypologys}
        open={false}
        setOpen={() => false}
        featuredImage={itemData[1].img}
      />,
      {},
    );
    const dialog = screen.getByRole('dialog');
    expect(window.getComputedStyle(dialog).maxWidth).toBe('100%');
  });
  it('renders Modal Height of MediaViewImages', () => {
    renderWithStore(
      <MediaViewImages
        video="https://www.youtube.com/embed/FcoUvu0mGog"
        iframe="https://www.guia360.com.ar/files/galerias/437tamylu/index2.html"
        imagelist={itemData}
        openViewImage
        setOpenViewImage={() => {}}
        imagesTypologys={imagesTypologys}
        open={false}
        setOpen={() => false}
        featuredImage={itemData[2].img}
      />,
      {},
    );
    const dialog = screen.getByRole('dialog');
    expect(window.getComputedStyle(dialog).height).toBe('100%');
  });
});
