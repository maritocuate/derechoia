import { formatPriceToArs } from '../utils/helpers/formatPriceToArs';

describe('formatPrice', () => {
  it('should format numbers with thousands separator', () => {
    expect(formatPriceToArs(1000)).toBe('$1.000');
    expect(formatPriceToArs(10000)).toBe('$10.000');
    expect(formatPriceToArs(1000000)).toBe('$1.000.000');
  });

  it('should handle edge cases', () => {
    expect(formatPriceToArs(0)).toBe('$0');
    expect(formatPriceToArs(1)).toBe('$0');
    expect(formatPriceToArs(999)).toBe('$1.000');
    expect(formatPriceToArs(123456789)).toBe('$123.456.800');
  });
});
