import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import EmptyStateBookings from '../components/EmptyStateBookings/EmptyStateBookings';

describe('EmptyStateActiveBookingsMobile', () => {
  it('renders EmptyStateActiveBookingsMobile', () => {
    render(<EmptyStateBookings />);
    const container = screen.getByTestId('ContainerEmptyState');
    const image = screen.getByTestId('SVGEmptyState');
    const title = screen.getByTestId('TitleEmptyState');
    const subtitle = screen.getByTestId('SubtitleEmptyState');
    const button = screen.getByTestId('ButtonEmptyState');
    expect(container).toBeInTheDocument();
    expect(image).toBeInTheDocument();
    expect(title).toHaveTextContent('Tu lista de reservas está vacía');
    expect(subtitle).toHaveTextContent(
      'Comenzá a planificar tu próximo viaje y disfrutá de nuevas aventuras.',
    );
    expect(button).toHaveTextContent('Realizar una búsqueda');
  });
});
