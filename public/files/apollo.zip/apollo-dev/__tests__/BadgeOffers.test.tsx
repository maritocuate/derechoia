import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { LocalOfferOutlined } from '@mui/icons-material';
import BadgeOffers from '../components/BadgeOffers/BadgeOffers';

// Un ejemplo de prueba
test('renders badge with icon and text', () => {
  const testText = 'Estadía flexible';
  const testColor = 'primary';

  render(
    <BadgeOffers
      icon={<LocalOfferOutlined color={testColor} />}
      color={testColor}
    >
      {testText}
    </BadgeOffers>,
  );

  const badgeContainer = screen.getByTestId('badgeOffers-container');
  const badgeIcon = screen.getByTestId('badgeOffers-icon');
  const badgeTypography = screen.getByTestId('badgeOffers-typography');

  // Verifica que el contenedor del badge esté presente en la pantalla
  expect(badgeContainer).toBeInTheDocument();

  expect(badgeContainer).toHaveStyle(
    'background-color: rgba(128, 222, 234, 0.08); border-color: rgba(128, 222, 234, 1)',
  );
  // Verifica que el icono y el texto sean visibles en la pantalla
  expect(badgeIcon).toBeInTheDocument();

  expect(badgeTypography).toBeInTheDocument();
  expect(badgeTypography).toHaveTextContent(testText);
});

test('Badgeoffers Secondary', () => {
  const testText = '¡Último minuto!';
  const testColor = 'secondary';

  render(
    <BadgeOffers
      icon={<LocalOfferOutlined color={testColor} />}
      color={testColor}
    >
      {testText}
    </BadgeOffers>,
  );

  const badgeContainer = screen.getByTestId('badgeOffers-container');
  const badgeIcon = screen.getByTestId('badgeOffers-icon');
  const badgeTypography = screen.getByTestId('badgeOffers-typography');

  // Verifica que el contenedor del badge esté presente en la pantalla
  expect(badgeContainer).toBeInTheDocument();
  expect(badgeContainer).toHaveStyle(
    'background-color: rgba(251, 192, 45, 0.08); border-color: rgba(251, 192, 45, 1)',
  );

  // Verifica que el icono y el texto sean visibles en la pantalla
  expect(badgeIcon).toBeInTheDocument();

  expect(badgeTypography).toBeInTheDocument();
  expect(badgeTypography).toHaveTextContent(testText);
});
