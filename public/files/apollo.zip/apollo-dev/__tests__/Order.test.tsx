import React from 'react';
import { render, screen } from '@testing-library/react';
import Order from '../components/Order';
import '@testing-library/jest-dom';
import { ordersOptions } from '../containers/OrderContainer/constants/ordersOptions';

jest.mock('react-i18next', () => ({
  // this mock makes sure any components using the translate hook can use it without a warning being shown
  useTranslation: () => ({
    t: (str: string) => `test: ${str}`,
    i18n: {
      changeLanguage: () => new Promise(() => {}),
    },
  }),
}));

describe('Order', () => {
  it('renders Order button', () => {
    render(
      <Order
        handleClickMenuItem={() => {}}
        selectedProp="rating"
        orderOptions={ordersOptions}
        propValue={2}
      />,
    );
    const button = screen.getByRole('button');
    expect(button).toBeInTheDocument();
  });
});
