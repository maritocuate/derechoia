export const isServer = typeof window === 'undefined';

export const countriesListDestinations = [
  'Argentina',
  'Chile',
  'Uruguay',
  'Brasil',
];

export default { isServer, countriesListDestinations };
