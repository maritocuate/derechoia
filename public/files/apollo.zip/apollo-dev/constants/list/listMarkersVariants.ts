export const LIST_MAP_MARKER_VARIANTS = {
  default: {
    fontWeight: 500,
  },
  gold: {
    tagColor: ' #FBC02D',
    fontWeight: 500,
  },
  featured: {
    tagColor: '#00ACC1',
    fontWeight: 500,
  },
  selected: {
    backgroundColor: '#00ACC1',
    fontColor: '#FFFFFF',
    fontWeight: 700,
  },
};
