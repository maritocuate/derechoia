export const LAST_LIST_DESTINATION_VISITED = 'lastListDestinationVisited';
export const LAST_ADS_VISITED = 'lastAdsVisited';
