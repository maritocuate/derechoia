const EVENTS_KEYBOARDS_IGNORED = [
  'Tab',
  'CapsLock',
  'Shift',
  'Control',
  'Alt',
  'AltGraph',
  'ContextMenu',
  'Enter',
];

export default EVENTS_KEYBOARDS_IGNORED;
